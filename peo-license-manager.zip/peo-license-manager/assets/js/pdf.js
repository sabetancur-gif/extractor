/* global PEO, PDFLib */
/* pdf.js — llenado de formularios PDF y validación de templates */
"use strict";

const { PDFDocument, StandardFonts } = PDFLib;

// ── Metadatos del PDF (tipos de campo, campos requeridos) ──────────────────
PEO.getPdfMeta = async function(templateBytes) {
  const pdfDoc     = await PDFDocument.load(templateBytes);
  const fieldTypes = new Map();
  const requiredFields = new Set();
  for (const f of pdfDoc.getForm().getFields()) {
    const n = PEO.norm(f.getName());
    fieldTypes.set(n, f.constructor.name);
    try { if (f.isRequired && f.isRequired()) requiredFields.add(n); } catch {}
  }
  return { fieldTypes, requiredFields };
};

// ── Obtener archivo de template por estado y proceso ──────────────────────
PEO.getTemplateFile = function(stateName, proceso) {
  const f = PEO.findFile(`templates/pdf/plantilla_${stateName}_${proceso}.pdf`);
  if (!f) throw new Error(`Template not found: plantilla_${stateName}_${proceso}.pdf`);
  return f;
};

// ── Pre-flight: detecta campos requeridos vacíos antes de generar ──────────
PEO.preflightValidate = async function(rows, templateBytes) {
  const { requiredFields } = await PEO.getPdfMeta(templateBytes);
  const ctrl   = new Set(["# case", "creado", "estado", "proceso"]);
  const issues = [];
  for (const row of rows) {
    const cv = String(PEO.getRowValue(row, "# Case") || "").trim() || "(no case #)";
    for (const fn of requiredFields) {
      if (ctrl.has(fn)) continue;
      const [val] = PEO.getEffectiveValue(row, fn);
      if (!val) issues.push({ caseVal: cv, field: fn });
    }
  }
  return issues;
};

// Modal de advertencia de campos faltantes (pre-flight)
PEO.showPreflightModal = function(issues, onProceed) {
  const byCase = {};
  for (const { caseVal, field } of issues) {
    if (!byCase[caseVal]) byCase[caseVal] = [];
    byCase[caseVal].push(field);
  }
  const body = Object.entries(byCase).map(([c, fs]) =>
    `<div style="margin-bottom:10px">
       <div style="font-weight:600;font-size:12px;margin-bottom:3px">${PEO.esc(c)}</div>
       ${fs.map(f => `<div style="font-size:11px;color:var(--alert);padding:1px 0">⚠ Required field empty: <code>${PEO.esc(f)}</code></div>`).join("")}
     </div>`
  ).join("");

  const ov = document.createElement("div");
  ov.className = "modal-overlay open";
  ov.style.zIndex = "300";
  ov.innerHTML = `<div style="background:#fff;border-radius:12px;padding:28px 32px;max-width:520px;width:90vw;max-height:80vh;display:flex;flex-direction:column;gap:12px;overflow:hidden">
    <div style="font-size:15px;font-weight:700;color:var(--alert)">⚠ Required fields missing</div>
    <div style="font-size:12px;color:var(--muted)">${issues.length} required field${issues.length > 1 ? "s are" : " is"} empty across ${Object.keys(byCase).length} record(s). You can generate anyway and complete manually before submitting, or cancel and fix in Excel first.</div>
    <div style="overflow-y:auto;flex:1;border:1px solid var(--border);border-radius:6px;padding:12px">${body}</div>
    <div style="display:flex;gap:8px">
      <button class="main-btn cta" id="pfProceed">Generate anyway</button>
      <button class="main-btn" id="pfCancel">Cancel — fix in Excel</button>
    </div>
  </div>`;
  document.body.appendChild(ov);
  PEO.$("pfProceed").addEventListener("click", () => { ov.remove(); onProceed(); });
  PEO.$("pfCancel").addEventListener("click",  () => ov.remove());
};

// ── Llenado del PDF con valores de fila + defaults ─────────────────────────
PEO.fillPdf = async function(templateBytes, row, { flatten = false } = {}) {
  const pdfDoc = await PDFDocument.load(templateBytes);
  const form   = pdfDoc.getForm();
  const font   = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const ctrl   = new Set(["# case", "creado", "estado", "proceso"]);

  for (const f of form.getFields()) {
    const n = PEO.norm(f.getName());
    if (ctrl.has(n)) continue;
    const [value] = PEO.getEffectiveValue(row, n);
    try {
      if      (typeof f.setText   === "function") f.setText(value);
      else if (typeof f.check     === "function")
        ["si","sí","yes","true","1","x"].includes(value.toLowerCase()) ? f.check() : f.uncheck();
      else if (typeof f.select    === "function") try { f.select(value); } catch {}
    } catch {}
  }
  try { form.updateFieldAppearances(font); } catch {}
  if (flatten) try { form.flatten(); } catch {}
  return await pdfDoc.save({ updateFieldAppearances: true });
};

PEO.blobUrl = bytes =>
  URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));

// ── Validación de template en el panel de detalle ──────────────────────────
PEO.validateTemplate = async function(abbr, proceso) {
  const box = PEO.$("validationBox");
  try {
    const d  = PEO.buildStateMap(PEO.state.currentRows)[abbr] || { fullName: PEO.ABBR_TO_NAME[abbr] || abbr };
    const tf = PEO.getTemplateFile(d.fullName, proceso);
    const { fieldTypes, requiredFields } = await PEO.getPdfMeta(await tf.arrayBuffer());
    const pdfNorm  = [...fieldTypes.keys()];
    const ctrl     = new Set(["# case", "creado", "estado", "proceso"]);
    const rows     = PEO.state.currentRows.filter(r =>
      PEO.norm(PEO.getRowValue(r, "Estado")) === PEO.norm(d.fullName) &&
      PEO.norm(PEO.getRowValue(r, "Proceso")) === PEO.norm(proceso)
    );
    const excelNorm = rows.length
      ? Object.keys(rows[0]).filter(h => !ctrl.has(PEO.norm(h))).map(PEO.norm)
      : [];
    const defNorm   = Object.keys(PEO.state.defaults.fields).map(PEO.norm);
    const covered   = new Set([...excelNorm, ...defNorm]);
    const missingInPdf = [...covered].filter(h => !pdfNorm.includes(h));
    const extraInPdf   = pdfNorm.filter(h => !covered.has(h));
    const reqGap       = [...requiredFields].filter(n => !covered.has(n));
    const ok = !missingInPdf.length && !reqGap.length;

    if (box) {
      box.classList.remove("hidden");
      box.innerHTML = `<div class="validation-box">
        <div class="panel-title" style="margin-bottom:8px">${PEO.esc(d.fullName)} / ${PEO.esc(proceso)}</div>
        <div class="${ok ? "text-done" : "text-alert"}" style="font-weight:600;margin-bottom:8px">${ok ? "✓ All required fields covered" : "⚠ Issues found"}</div>
        <div><strong>PDF fields:</strong> ${pdfNorm.length} &nbsp;·&nbsp; <strong>Required:</strong> ${requiredFields.size}</div>
        ${reqGap.length       ? `<div class="text-alert" style="margin-top:6px"><strong>Required but not covered:</strong> ${reqGap.join(", ")}</div>` : ""}
        ${missingInPdf.length ? `<div style="margin-top:4px"><strong>Not in PDF:</strong> ${missingInPdf.join(", ")}</div>` : ""}
        ${extraInPdf.length   ? `<div style="margin-top:4px"><strong>PDF fields not mapped:</strong> ${extraInPdf.slice(0, 10).join(", ")}${extraInPdf.length > 10 ? ` …+${extraInPdf.length - 10}` : ""}</div>` : ""}
      </div>`;
      box.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
    PEO.logKpiEvent("VALIDATE_TEMPLATE", { state: d.fullName, process: proceso });
    PEO.notify("Validation complete.", "ok");
  } catch(e) {
    PEO.notify(e.message, "err");
    if (box) { box.classList.remove("hidden"); box.innerHTML = `<div class="validation-box text-alert">${PEO.esc(e.message)}</div>`; }
  }
};
