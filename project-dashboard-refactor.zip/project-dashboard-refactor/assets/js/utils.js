/* Módulo 2 · utilidades
Funciones puras reutilizables para formato de fechas, sanitización y pequeñas transformaciones.
*/

function esc(v){
  return String(v ?? '')
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;')
    .replaceAll("'","&#39;");
}
function fullName(code){ return MEMBER_NAMES[code] || code; }
function toDate(ds){ return ds ? new Date(ds) : null; }
function isValidDate(d){ return d instanceof Date && !Number.isNaN(d.getTime()); }
function daysTo(ds){
  const d = toDate(ds);
  if(!isValidDate(d)) return 0;
  const now = new Date();
  now.setHours(0,0,0,0);
  d.setHours(0,0,0,0);
  return Math.ceil((d - now) / 864e5);
}
function fmtDate(ds){
  const d = toDate(ds);
  if(!isValidDate(d)) return {s:'sin fecha', c:''};
  const days = daysTo(ds);
  const s = d.toLocaleDateString('es-CO',{day:'numeric',month:'short'});
  if(days < 0) return {s:`${s} · vencido`, c:'past'};
  if(days <= 7) return {s:`${s} · ${days}d`, c:'soon'};
  return {s, c:''};
}
function pct(p){
  if(!p.deliverables?.length) return 0;
  return Math.round(p.deliverables.filter(d=>d.done).length / p.deliverables.length * 100);
}
function pbClsFromScore(score){
  if(score >= 85) return 'pb-cyan';
  if(score >= 65) return 'pb-green';
  if(score >= 40) return 'pb-amber';
  return 'pb-red';
}
function pbCls(p){
  if(p.status === 'delivered') return 'pb-blue';
  if(p.status === 'risk') return 'pb-amber';
  if(p.status === 'paused') return 'pb-red';
  return 'pb-green';
}
function sbadge(s){
  const m = {active:'b-active', risk:'b-risk', delivered:'b-delivered', paused:'b-paused'};
  const l = {active:'activo', risk:'en riesgo', delivered:'entregado', paused:'pausado'};
  return `<span class="badge ${m[s] || 'b-paused'}">${l[s] || s}</span>`;
}
function pbadge(p){
  const m = {critical:'b-danger', high:'b-risk', medium:'b-delivered', low:'b-paused'};
  const l = {critical:'critical', high:'high', medium:'medium', low:'low'};
  return `<span class="badge ${m[p] || 'b-paused'}">${l[p] || p}</span>`;
}
function av(i, idx){
  const [bg, fg] = AV_COLORS[idx % AV_COLORS.length];
  return `<div class="av" style="background:${bg};color:${fg}" title="${esc(fullName(i))}" aria-label="${esc(fullName(i))}">${esc(i)}</div>`;
}
