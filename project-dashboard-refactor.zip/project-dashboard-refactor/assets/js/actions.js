/* Módulo 5 · acciones y persistencia
Mutaciones del estado, edición, creación, eliminación y sincronización con almacenamiento.
*/

function setF(f){
  S.filter = f;
  S.sel = null;
  render();
}
function pick(id){
  S.sel = (S.sel === id) ? null : id;
  S.tab = 'executive';
  render();
  if(S.sel) setTimeout(() => document.querySelector('.detail')?.scrollIntoView({behavior:'smooth', block:'nearest'}), 50);
}
function setTab(t){ S.tab = t; render(); }
function tgForm(){ S.showForm = !S.showForm; S.editId = null; S.form = {}; render(); }
function cancelF(){ S.showForm = false; S.editId = null; S.form = {}; render(); }

/* Persistencia local del dashboard.
   Guarda la lista completa de proyectos en localStorage (o en el storage inyectado por el entorno). */
async function save(){
  await storage.set('devdash2', JSON.stringify(S.projects));
}
function parseCSV(v){ return String(v || '').split(',').map(s => s.trim()).filter(Boolean); }
function parseLines(v){ return String(v || '').split('\n').map(s => s.trim()).filter(Boolean); }
function slugId(){ return 'd' + Date.now() + Math.random().toString(36).slice(2,6); }

function editP(id){
  const p = S.projects.find(x => x.id === id);
  if(!p) return;
  S.form = {
    name: p.name,
    description: p.description,
    status: p.status,
    priority: p.priority,
    businessPriority: p.businessPriority,
    technicalSeverity: p.technicalSeverity,
    urgency: p.urgency,
    dependencyCriticality: p.dependencyCriticality,
    deadline: p.deadline,
    committedAt: p.committedAt,
    actualAt: p.actualAt,
    assignees: p.assignees.join(', '),
    tech: p.tech.join(', '),
    blockers: (p.blockers || []).join('\n'),
    dependencies: (p.dependencies || []).join('\n'),
    deliverables: p.deliverables.map(d => d.text).join('\n')
  };
  S.editId = id;
  S.showForm = true;
  S.sel = null;
  render();
  setTimeout(() => document.querySelector('.fs')?.scrollIntoView({behavior:'smooth', block:'start'}), 50);
}
async function delP(id){
  if(!confirm('¿Eliminar este proyecto?')) return;
  S.projects = S.projects.filter(p => p.id !== id);
  S.sel = null;
  await save();
  render();
}
async function saveP(){
  const name = document.getElementById('fn').value.trim();
  if(!name){ alert('El nombre es requerido'); return; }

  const base = {
    name,
    description: document.getElementById('fd').value.trim(),
    status: document.getElementById('fst').value,
    priority: document.getElementById('fp').value,
    businessPriority: Number(document.getElementById('fbp').value),
    technicalSeverity: Number(document.getElementById('fts').value),
    urgency: Number(document.getElementById('fur').value),
    dependencyCriticality: Number(document.getElementById('fdc').value),
    deadline: document.getElementById('fdl').value,
    committedAt: document.getElementById('fca').value,
    actualAt: document.getElementById('fra').value,
    assignees: parseCSV(document.getElementById('fass').value),
    tech: parseCSV(document.getElementById('ftc').value),
    blockers: parseLines(document.getElementById('fblk').value),
    dependencies: parseLines(document.getElementById('fdep').value)
  };

  const deliveredMap = new Map();
  if(S.editId){
    const ex = S.projects.find(p => p.id === S.editId);
    if(ex){
      for(const d of ex.deliverables || []) deliveredMap.set(d.text, d);
    }
  }
  const newDels = parseLines(document.getElementById('fdels').value).map((t,i) => {
    const existing = deliveredMap.get(t);
    return existing ? {...existing, text:t} : {id:slugId()+i, text:t, done:false, owner: base.assignees[i % Math.max(base.assignees.length,1)] || 'CR', sla:'', committed:'', actual:'', goal:'', criteria:'', notes:''};
  });

  if(S.editId){
    const idx = S.projects.findIndex(p => p.id === S.editId);
    if(idx >= 0){
      const ex = S.projects[idx];
      S.projects[idx] = {
        ...ex,
        ...base,
        deliverables: newDels,
        comments: ex.comments || [],
        timeline: ex.timeline || [],
        history: ex.history || [],
        recentActivity: ex.recentActivity || []
      };
    }
  }else{
    const today = new Date().toISOString().slice(0,10);
    S.projects.unshift({
      id:'p'+Date.now(),
      ...base,
      timeline:[{date:today, title:'Proyecto creado', desc:'Registro inicial creado desde el dashboard.'}],
      history:[{date:today + ' 00:00', author:'SYS', action:'Creó el proyecto', detail:'Alta inicial desde panel ejecutivo.'}],
      recentActivity:[],
      comments:[],
      deliverables: newDels
    });
  }

  S.showForm = false;
  S.editId = null;
  S.form = {};
  await save();
  render();
}
async function toggleD(pid, did){
  const p = S.projects.find(x => x.id === pid);
  if(!p) return;
  const d = p.deliverables.find(x => x.id === did);
  if(!d) return;
  d.done = !d.done;
  if(d.done && !d.actual){
    d.actual = new Date().toISOString().slice(0,10);
  }
  await save();
  render();
}
async function addDel(pid){
  const inp = document.getElementById('nd');
  if(!inp) return;
  const txt = inp.value.trim();
  if(!txt) return;
  const p = S.projects.find(x => x.id === pid);
  if(!p) return;
  p.deliverables.push({id:slugId(), text:txt, done:false, owner:p.assignees?.[0] || 'CR', sla:'', committed:'', actual:'', goal:'', criteria:'', notes:''});
  await save();
  render();
}
async function addCmt(pid){
  const inp = document.getElementById('nc');
  if(!inp) return;
  const txt = inp.value.trim();
  if(!txt) return;
  const p = S.projects.find(x => x.id === pid);
  if(!p) return;
  const now = new Date().toLocaleDateString('es-CO',{day:'numeric',month:'short'});
  p.comments.push({author:'TÚ', date:now, text:txt});
  p.recentActivity = [{author:'TÚ', date:'Ahora', text:txt}, ...(p.recentActivity || [])].slice(0,5);
  inp.value = '';
  await save();
  render();
}

async function load(){
  try{
    const r = await storage.get('devdash2');
    S.projects = r ? JSON.parse(r.value) : DEFAULTS;
    if(!Array.isArray(S.projects)) S.projects = DEFAULTS;
  }catch{
    S.projects = DEFAULTS;
  }
  render();
}

load();
