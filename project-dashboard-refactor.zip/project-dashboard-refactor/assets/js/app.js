/* Punto de arranque.
   Espera a que el DOM esté listo y luego carga el dashboard. */
(function startApp(){
  const boot = () => {
    if (typeof load === 'function') load();
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
})();
