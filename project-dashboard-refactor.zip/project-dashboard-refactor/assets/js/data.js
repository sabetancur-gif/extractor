/* Módulo 1 · datos base y estado
Aquí viven las constantes, el estado global de la interfaz y la capa de almacenamiento local.
*/

const AV_COLORS = [
  ['#1D9E75','#E1F5EE'],
  ['#378ADD','#E6F1FB'],
  ['#D85A30','#FAECE7'],
  ['#D4537E','#FBEAF0'],
  ['#BA7517','#FAEEDA'],
  ['#7F77DD','#EEEDFE']
];

const MEMBER_NAMES = {
  CR: 'Camila Rojas',
  ML: 'María López',
  JP: 'Juan Pérez',
  SA: 'Sofía Acosta',
  RG: 'Raúl Gómez',
  VK: 'Valeria Kaur'
};

const MEMBER_CAPACITY = {
  CR: 3,
  ML: 3,
  JP: 4,
  SA: 2,
  RG: 3,
  VK: 2
};

const DEFAULTS = [
  {
    id:'p1',
    name:'API Gateway v2.0',
    description:'Migración al nuevo API Gateway con rate limiting, OAuth2, circuit breaker y observabilidad de latencia para producción.',
    status:'active',
    businessPriority:5,
    technicalSeverity:4,
    urgency:4,
    dependencyCriticality:5,
    deadline:'2026-05-15',
    committedAt:'2026-05-10',
    actualAt:'2026-05-15',
    assignees:['CR','ML','JP'],
    tech:['Node.js','Redis','K8s','gRPC'],
    blockers:[
      'Ajuste final de thresholds en circuit breaker',
      'Validación de rotación de refresh token'
    ],
    dependencies:['Auth Service','Billing Core','Service Mesh'],
    timeline:[
      {date:'2026-04-08', title:'ADR aprobado', desc:'Se definió la arquitectura objetivo y el alcance del gateway v2.'},
      {date:'2026-04-17', title:'Rate limiting implementado', desc:'Sliding window validado en staging con tráfico mixto.'},
      {date:'2026-04-22', title:'OAuth2 en revisión', desc:'Pendiente de confirmar rotación de refresh tokens.'}
    ],
    history:[
      {date:'2026-04-22 09:20', author:'ML', action:'Actualizó estado a en progreso', detail:'Edge case en refresh token rotation detectado.'},
      {date:'2026-04-20 17:40', author:'CR', action:'Cerró ADR', detail:'Arquitectura aprobada por el equipo senior.'},
      {date:'2026-04-18 13:05', author:'JP', action:'Subió PR de middleware', detail:'Integración OAuth2 + PKCE en rama feature/gw2-auth.'}
    ],
    recentActivity:[
      {author:'CR', date:'Hoy 10:12', text:'Se ajustó la estrategia de fallback para errores 5xx en picos de tráfico.'},
      {author:'ML', date:'Hoy 08:40', text:'Se validó el umbral de rate limit en staging con 4.8k RPS sostenidos.'}
    ],
    deliverables:[
      {id:'d1', text:'Diseño de arquitectura y ADR documentado', done:true, owner:'CR', sla:'2026-04-10', committed:'2026-04-09', actual:'2026-04-08', goal:'Definir la arquitectura objetivo y dejar decisiones técnicas trazables', criteria:'ADR aprobado y compartido con el equipo', notes:'Incluye dependencias, riesgos y estrategia de despliegue'},
      {id:'d2', text:'Implementación de rate limiting con sliding window', done:true, owner:'ML', sla:'2026-04-16', committed:'2026-04-15', actual:'2026-04-17', goal:'Controlar tráfico y evitar saturación del gateway', criteria:'Pruebas en staging sin degradación significativa', notes:'Validado en escenarios de carga inicial'},
      {id:'d3', text:'OAuth2 middleware + PKCE flow', done:false, owner:'JP', sla:'2026-04-25', committed:'2026-04-24', actual:'', goal:'Autenticación segura para clientes internos y externos', criteria:'Login, refresh y revoke operativos', notes:'Pendiente revisar rotación de refresh token'},
      {id:'d4', text:'Circuit breaker con fallbacks', done:false, owner:'CR', sla:'2026-04-27', committed:'2026-04-26', actual:'', goal:'Evitar cascadas de fallos entre servicios', criteria:'Fallback funcional con métricas visibles', notes:'Requiere ajuste de thresholds'},
      {id:'d5', text:'Tests de carga — objetivo: 10k RPS', done:false, owner:'ML', sla:'2026-05-03', committed:'2026-05-02', actual:'', goal:'Validar estabilidad del gateway bajo presión', criteria:'Informe de rendimiento documentado', notes:'Usar escenario mixto con picos'}
    ],
    comments:[
      {author:'CR',date:'Apr 20',text:'Redis cluster listo en staging. Latencia p99 < 12ms bajo carga de 5k RPS.'},
      {author:'ML',date:'Apr 22',text:'OAuth2 en progreso. Edge case con refresh token rotation — investigando RFC 6749 §6.'}
    ]
  },
  {
    id:'p2',
    name:'Dashboard Analytics RT',
    description:'Rediseño del dashboard de métricas en tiempo real con WebSockets, virtualización de listas y una nueva capa ejecutiva de filtros.',
    status:'risk',
    businessPriority:5,
    technicalSeverity:5,
    urgency:5,
    dependencyCriticality:4,
    deadline:'2026-04-30',
    committedAt:'2026-04-28',
    actualAt:'2026-05-02',
    assignees:['SA','RG'],
    tech:['React','D3','WebSocket','TS'],
    blockers:[
      'Memory leak en el servidor WebSocket bajo carga sostenida',
      'Validación final del modelo de exportación'
    ],
    dependencies:['Telemetry API','Auth Layer','Export Service'],
    timeline:[
      {date:'2026-04-14', title:'UX aprobado', desc:'Se validó la jerarquía visual y navegación con producto.'},
      {date:'2026-04-19', title:'Base UI lista', desc:'Design tokens y componentes base implementados.'},
      {date:'2026-04-23', title:'Incidente de memoria', desc:'Heap crece ~8MB/min durante sesiones largas.'}
    ],
    history:[
      {date:'2026-04-24 16:10', author:'RG', action:'Abrió investigación técnica', detail:'Listeners no se desuscriben al cerrar conexión.'},
      {date:'2026-04-23 11:05', author:'SA', action:'Marcó proyecto en riesgo', detail:'Bloquea pruebas de aceptación del dashboard.'},
      {date:'2026-04-22 09:40', author:'RG', action:'Subió fix parcial', detail:'Ajustes en reconexión automática y limpieza de listeners.'}
    ],
    recentActivity:[
      {author:'SA', date:'Hoy 11:30', text:'Se priorizó la capa ejecutiva de KPIs para la vista portfolio.'},
      {author:'RG', date:'Hoy 09:55', text:'Se redujo el consumo de memoria en staging tras limpiar handlers.'}
    ],
    deliverables:[
      {id:'d1', text:'Diseño UX aprobado por producto', done:true, owner:'SA', sla:'2026-04-13', committed:'2026-04-12', actual:'2026-04-12', goal:'Validar estructura y navegación del nuevo dashboard', criteria:'Aprobación formal de producto', notes:'Se prioriza la vista en tiempo real'},
      {id:'d2', text:'Componentes base + design tokens', done:true, owner:'RG', sla:'2026-04-17', committed:'2026-04-17', actual:'2026-04-17', goal:'Unificar estilos y base visual', criteria:'Implementación reutilizable en todo el dashboard', notes:'Base lista para extender'},
      {id:'d3', text:'Integración WebSocket con reconexión', done:false, owner:'RG', sla:'2026-04-26', committed:'2026-04-25', actual:'', goal:'Mantener datos en vivo con tolerancia a desconexiones', criteria:'Reconexión automática funcionando', notes:'Pendiente ajuste por memory leak'},
      {id:'d4', text:'Filtros avanzados y exportación CSV/XLSX', done:false, owner:'SA', sla:'2026-04-29', committed:'2026-04-28', actual:'', goal:'Mejorar análisis y descarga de datos', criteria:'Exportación correcta desde UI', notes:'Depende de la integración final del modelo de datos'}
    ],
    comments:[
      {author:'SA',date:'Apr 23',text:'BLOCKER: WS server tiene memory leak bajo carga sostenida. Heap crece ~8MB/min.'},
      {author:'RG',date:'Apr 24',text:'Revisé el código; EventEmitter no desuscribe listeners al cerrar conexión. PR listo.'}
    ]
  },
  {
    id:'p3',
    name:'Mobile SDK iOS/Android',
    description:'SDK nativo multiplataforma para integración de pagos y autenticación biométrica en apps de terceros.',
    status:'active',
    businessPriority:4,
    technicalSeverity:5,
    urgency:3,
    dependencyCriticality:4,
    deadline:'2026-06-30',
    committedAt:'2026-06-20',
    actualAt:'2026-06-30',
    assignees:['JP','VK','CR'],
    tech:['Swift','Kotlin','Rust','C FFI'],
    blockers:[
      'Revisión de interoperabilidad en bindings nativos',
      'Definición final de callbacks en iOS'
    ],
    dependencies:['Payments Core','Identity Provider','Crypto Module'],
    timeline:[
      {date:'2026-04-12', title:'API pública definida', desc:'Se cerró el contrato base del SDK y el versionado.'},
      {date:'2026-04-18', title:'Core en Rust iniciado', desc:'Se compartió la lógica crítica para ambas plataformas.'},
      {date:'2026-04-24', title:'Biometría en evaluación', desc:'Se revisan políticas de Face ID / Touch ID / Android biometrics.'}
    ],
    history:[
      {date:'2026-04-24 12:20', author:'VK', action:'Documentó riesgos de FFI', detail:'Se requiere revisar manejo de memoria en bindings.'},
      {date:'2026-04-21 15:15', author:'JP', action:'Aprobó arquitectura del SDK', detail:'Se validó Rust como core compartido.'},
      {date:'2026-04-19 10:00', author:'CR', action:'Publicó ejemplos de integración', detail:'Se agregaron snippets para iOS y Android.'}
    ],
    recentActivity:[
      {author:'JP', date:'Hoy 09:10', text:'Se definieron contratos para callbacks de pago y error handling.'},
      {author:'VK', date:'Ayer 18:25', text:'Se probó el bridge nativo con un payload mínimo sin crashes.'}
    ],
    deliverables:[
      {id:'d1', text:'Arquitectura del SDK y API pública', done:true, owner:'JP', sla:'2026-04-14', committed:'2026-04-14', actual:'2026-04-13', goal:'Definir contratos y estructura base del SDK', criteria:'Documento aprobado por el equipo', notes:'Incluye consideraciones de versionado'},
      {id:'d2', text:'Core en Rust con bindings C', done:false, owner:'VK', sla:'2026-05-10', committed:'2026-05-09', actual:'', goal:'Compartir lógica crítica entre plataformas', criteria:'Compila y consume desde iOS y Android', notes:'Revisar interoperabilidad'},
      {id:'d3', text:'Módulo de pagos iOS (Swift)', done:false, owner:'CR', sla:'2026-05-18', committed:'2026-05-16', actual:'', goal:'Exponer pagos en apps iOS', criteria:'Flujo de pago completado en demo', notes:'Pendiente integración de callbacks'},
      {id:'d4', text:'Módulo de pagos Android (Kotlin)', done:false, owner:'JP', sla:'2026-05-22', committed:'2026-05-20', actual:'', goal:'Exponer pagos en apps Android', criteria:'Flujo de pago completado en demo', notes:'Sincronizar con el core'},
      {id:'d5', text:'Autenticación biométrica multiplataforma', done:false, owner:'VK', sla:'2026-06-05', committed:'2026-06-03', actual:'', goal:'Unificar el acceso biométrico', criteria:'Face ID / Touch ID / biometría Android funcionando', notes:'Depende de políticas de cada plataforma'},
      {id:'d6', text:'Documentación y ejemplos de integración', done:false, owner:'CR', sla:'2026-06-12', committed:'2026-06-11', actual:'', goal:'Facilitar adopción por terceros', criteria:'README y quickstart listos', notes:'Agregar snippets y guías de error'}
    ],
    comments:[
      {author:'JP',date:'Apr 18',text:'Arquitectura definida. Core en Rust es la decisión correcta para compartir lógica crítica.'}
    ]
  },
  {
    id:'p4',
    name:'Security Audit Q1/2026',
    description:'Auditoría de seguridad completa: OWASP Top 10, pentesting de APIs, rotación de secretos y hardening de infraestructura.',
    status:'delivered',
    businessPriority:5,
    technicalSeverity:5,
    urgency:2,
    dependencyCriticality:5,
    deadline:'2026-04-10',
    committedAt:'2026-04-10',
    actualAt:'2026-04-08',
    assignees:['ML','CR','SA'],
    tech:['Vault','Snyk','Trivy','Burp'],
    blockers:[],
    dependencies:['IAM','Container Registry','Secrets Manager'],
    timeline:[
      {date:'2026-03-29', title:'Inicio del audit', desc:'Se definió alcance, superficies y sistema de evidencias.'},
      {date:'2026-04-04', title:'Hallazgos medios resueltos', desc:'Las vulnerabilidades intermedias quedaron mitigadas.'},
      {date:'2026-04-08', title:'Informe final entregado', desc:'Se consolidó el remediación plan y la versión ejecutiva.'}
    ],
    history:[
      {date:'2026-04-08 15:00', author:'ML', action:'Cerró la auditoría', detail:'0 vulnerabilidades críticas, 3 medias resueltas.'},
      {date:'2026-04-06 11:30', author:'CR', action:'Ejecutó pentest final', detail:'Cobertura REST/gRPC completada y documentada.'},
      {date:'2026-04-04 09:45', author:'SA', action:'Rotó secretos', detail:'Vault actualizado en entornos clave.'}
    ],
    recentActivity:[
      {author:'ML', date:'Cerrado', text:'Informe ejecutivo enviado al CISO con remediación y trazabilidad.'}
    ],
    deliverables:[
      {id:'d1', text:'Escaneo de dependencias — CVEs', done:true, owner:'ML', sla:'2026-04-02', committed:'2026-04-01', actual:'2026-04-02', goal:'Detectar vulnerabilidades de terceros', criteria:'Reporte generado y clasificado', notes:'Sin hallazgos críticos'},
      {id:'d2', text:'Pentesting de APIs REST/gRPC', done:true, owner:'CR', sla:'2026-04-05', committed:'2026-04-04', actual:'2026-04-05', goal:'Validar superficie de ataque', criteria:'Pruebas ejecutadas y documentadas', notes:'Hallazgos resueltos'},
      {id:'d3', text:'Rotación de secretos en Vault', done:true, owner:'SA', sla:'2026-04-07', committed:'2026-04-06', actual:'2026-04-07', goal:'Eliminar secretos expuestos', criteria:'Rotación completada en entornos clave', notes:'Tokens renovados'},
      {id:'d4', text:'Informe ejecutivo para CISO', done:true, owner:'ML', sla:'2026-04-10', committed:'2026-04-09', actual:'2026-04-08', goal:'Consolidar resultados y riesgos', criteria:'Informe entregado', notes:'Incluye plan de remediación'}
    ],
    comments:[
      {author:'ML',date:'Apr 8',text:'Completado. 0 vulnerabilidades críticas. 3 medias resueltas. Informe enviado al CISO.'}
    ]
  }
];

const storage = (window.storage && typeof window.storage.get === 'function')
  ? window.storage
  : {
      async get(key){ const v = localStorage.getItem(key); return v ? {value:v} : null; },
      async set(key, value){ localStorage.setItem(key, value); }
    };

const S = {
  projects: [],
  filter: 'all',
  sel: null,
  tab: 'executive',
  showForm: false,
  editId: null,
  form: {}
};
