/* Módulo 3 · cálculos ejecutivos
Métricas de negocio, indicadores de riesgo y agregaciones del portafolio.
*/

function statusCounts(){
  const counts = {active:0,risk:0,delivered:0,paused:0};
  for(const p of S.projects) counts[p.status] = (counts[p.status] || 0) + 1;
  return counts;
}
function memberCounts(){
  const map = new Map();
  for(const p of S.projects){
    for(const a of p.assignees || []) map.set(a, (map.get(a) || 0) + 1);
  }
  return [...map.entries()].sort((a,b)=>b[1]-a[1]);
}
function upcomingDeadlines(){
  return [...S.projects].sort((a,b)=>daysTo(a.deadline) - daysTo(b.deadline)).slice(0,4);
}
function completionRate(){
  const dels = S.projects.flatMap(p => p.deliverables || []);
  if(!dels.length) return 0;
  return Math.round(dels.filter(d => d.done).length / dels.length * 100);
}
function overdueDeliverablesCount(){
  const today = new Date(); today.setHours(0,0,0,0);
  let c = 0;
  for(const p of S.projects){
    for(const d of (p.deliverables || [])){
      if(!d.done && d.sla){
        const dd = toDate(d.sla); if(isValidDate(dd)) { dd.setHours(0,0,0,0); if(dd < today) c++; }
      }
    }
  }
  return c;
}
function blockedProjectsCount(){
  return S.projects.filter(p => (p.blockers || []).length > 0 && p.status !== 'delivered').length;
}
function deliveredRecently(){
  const now = new Date(); now.setHours(0,0,0,0);
  let count = 0;
  for(const p of S.projects){
    for(const d of (p.deliverables || [])){
      if(d.done && d.actual){
        const dd = toDate(d.actual);
        if(isValidDate(dd)){
          dd.setHours(0,0,0,0);
          const delta = Math.round((now - dd)/864e5);
          if(delta >= 0 && delta <= 7) count++;
        }
      }
    }
  }
  return count;
}
function loadVsCapacity(){
  const load = new Map();
  for(const p of S.projects){
    for(const a of (p.assignees || [])) load.set(a, (load.get(a) || 0) + 1);
  }
  let assigned = 0, cap = 0;
  for(const [member, tasks] of load.entries()){
    assigned += tasks;
    cap += (MEMBER_CAPACITY[member] || 2);
  }
  return {assigned, cap, pct: cap ? Math.round((assigned / cap) * 100) : 0};
}
function velocity(){
  const done7 = deliveredRecently();
  const done14 = (() => {
    const now = new Date(); now.setHours(0,0,0,0);
    let count = 0;
    for(const p of S.projects){
      for(const d of (p.deliverables || [])){
        if(d.done && d.actual){
          const dd = toDate(d.actual);
          if(isValidDate(dd)){
            dd.setHours(0,0,0,0);
            const delta = Math.round((now - dd)/864e5);
            if(delta >= 0 && delta <= 14) count++;
          }
        }
      }
    }
    return count;
  })();
  return Math.round((done7 * 70 + done14 * 30) / 10) / 10;
}
function riskScore(p){
  const priorityWeight = {critical:28, high:20, medium:12, low:6}[p.priority || 'medium'] || 10;
  const business = (p.businessPriority || 0) * 6;
  const technical = (p.technicalSeverity || 0) * 5;
  const urgency = (p.urgency || 0) * 5;
  const dependency = (p.dependencyCriticality || 0) * 4;
  const overdue = Math.max(0, -daysTo(p.deadline)) * 5;
  const near = daysTo(p.deadline);
  const nearPenalty = near >= 0 && near <= 7 ? (8 - near) * 3 : 0;
  const blockers = Math.min((p.blockers || []).length * 7, 21);
  const progressPenalty = Math.max(0, 60 - pct(p)) * 0.4;
  const statusPenalty = p.status === 'risk' ? 14 : p.status === 'paused' ? 18 : 0;
  const raw = priorityWeight + business + technical + urgency + dependency + overdue + nearPenalty + blockers + progressPenalty + statusPenalty;
  return Math.max(0, Math.min(100, Math.round(raw)));
}
function riskLabel(score){
  if(score >= 80) return 'Crítico';
  if(score >= 60) return 'Alto';
  if(score >= 35) return 'Medio';
  return 'Bajo';
}
function riskClass(score){
  if(score >= 80) return 'crit';
  if(score >= 60) return 'high';
  if(score >= 35) return 'med';
  return 'low';
}
function priorityScore(p){
  const n = {
    critical: 4,
    high: 3,
    medium: 2,
    low: 1
  }[p.priority || 'medium'];
  return n;
}
function execKpis(){
  const cap = loadVsCapacity();
  const overdue = overdueDeliverablesCount();
  const blocked = blockedProjectsCount();
  const avgRisk = S.projects.length ? Math.round(S.projects.reduce((a,p)=>a + riskScore(p), 0) / S.projects.length) : 0;
  const portfolioProgress = completionRate();
  const sprintVel = velocity();
  const riskProjects = S.projects.filter(p => riskScore(p) >= 60).length;
  return [
    {l:'Avance global', v:`${portfolioProgress}`, s:'porcentaje de entregables completados', cls: portfolioProgress >= 75 ? 'good' : portfolioProgress >= 45 ? 'warn' : 'danger'},
    {l:'Riesgo acumulado', v:`${avgRisk}`, s:`promedio portfolio · ${riskProjects} proyectos con riesgo alto`, cls: avgRisk >= 60 ? 'danger' : avgRisk >= 35 ? 'warn' : 'good'},
    {l:'Vencidos', v:`${overdue}`, s:'entregables fuera de SLA', cls: overdue ? 'danger' : 'good'},
    {l:'Carga/capacidad', v:`${cap.pct}%`, s:`${cap.assigned}/${cap.cap} asignaciones vs capacidad`, cls: cap.pct >= 100 ? 'danger' : cap.pct >= 75 ? 'warn' : 'good'},
    {l:'Velocidad sprint', v:`${sprintVel}`, s:'entregables cerrados en los últimos 14 días', cls: sprintVel >= 4 ? 'good' : sprintVel >= 2 ? 'warn' : 'danger'},
    {l:'Bloqueados', v:`${blocked}`, s:'proyectos con blockers activos', cls: blocked ? 'danger' : 'good'}
  ];
}
