/* Módulo 4 · renderizado de vistas
Generadores de HTML del panel, tarjetas, pestañas y panel de detalle.
*/

function donutSVG(data){
  const items = [
    {k:'active', color:'#7fcb67'},
    {k:'risk', color:'#e2b24a'},
    {k:'delivered', color:'#8db7ee'},
    {k:'paused', color:'#8f8a80'}
  ];
  const total = items.reduce((acc,x)=>acc + (data[x.k] || 0), 0) || 1;
  let start = -90;
  const cx = 56, cy = 56, r = 38, stroke = 14;
  const circ = 2 * Math.PI * r;
  const parts = items.filter(x => (data[x.k] || 0) > 0).map(x => {
    const val = data[x.k] || 0;
    const len = circ * val / total;
    const dashoffset = circ * (start + 90) / 360;
    const angle = (val / total) * 360;
    const segment = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${x.color}" stroke-width="${stroke}" stroke-linecap="round" stroke-dasharray="${len} ${circ - len}" stroke-dashoffset="${-dashoffset}"></circle>`;
    start += angle;
    return segment;
  }).join('');
  return `
    <svg viewBox="0 0 112 112" width="122" height="122" aria-label="Distribución de estados">
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#3a3a3a" stroke-width="${stroke}"></circle>
      ${parts}
      <circle cx="${cx}" cy="${cy}" r="24" fill="#12161b"></circle>
      <text x="56" y="53" text-anchor="middle" fill="#f3f1ec" font-size="18" font-family="var(--mono)" font-weight="700">${total}</text>
      <text x="56" y="68" text-anchor="middle" fill="#8f8a80" font-size="8" font-family="var(--mono)" letter-spacing=".12em">PROYECTOS</text>
    </svg>`;
}

function renderInsights(){
  const counts = statusCounts();
  const mem = memberCounts();
  const topMembers = mem.slice(0,4);
  const deadlines = upcomingDeadlines();
  const cap = loadVsCapacity();
  return `
    <div class="analytics">
      <article class="ins-card">
        <div class="ins-head">
          <div>
            <p class="ins-title">Distribución ejecutiva</p>
            <p class="ins-sub">estado del portfolio</p>
          </div>
          <div class="kpi-mini">${S.projects.length} total</div>
        </div>
        <div class="donut-wrap">
          ${donutSVG(counts)}
          <div class="donut-legend">
            <div class="leg"><span class="legend-left"><span class="dot" style="background:#7fcb67"></span>Activos</span><span>${counts.active || 0}</span></div>
            <div class="leg"><span class="legend-left"><span class="dot" style="background:#e2b24a"></span>Riesgo</span><span>${counts.risk || 0}</span></div>
            <div class="leg"><span class="legend-left"><span class="dot" style="background:#8db7ee"></span>Entregados</span><span>${counts.delivered || 0}</span></div>
            <div class="leg"><span class="legend-left"><span class="dot" style="background:#8f8a80"></span>Pausados</span><span>${counts.paused || 0}</span></div>
          </div>
        </div>
      </article>

      <article class="ins-card">
        <div class="ins-head">
          <div>
            <p class="ins-title">Carga por miembro</p>
            <p class="ins-sub">asignaciones vs capacidad</p>
          </div>
          <div class="kpi-mini">${cap.assigned}/${cap.cap}</div>
        </div>
        <div class="bars">
          ${topMembers.map(([m,c]) => `
            <div class="bar-row">
              <div class="bar-label">${esc(fullName(m))}</div>
              <div class="bar-track"><div class="bar-fill" style="width:${Math.max(8, Math.round(c / Math.max(...mem.map(x=>x[1]),1) * 100))}%"></div></div>
              <div class="bar-num">${c}</div>
            </div>
          `).join('')}
          ${!topMembers.length ? `<div class="kpi-mini">Sin asignaciones</div>` : ''}
        </div>
      </article>

      <article class="ins-card">
        <div class="ins-head">
          <div>
            <p class="ins-title">Próximos vencimientos</p>
            <p class="ins-sub">alerta operativa</p>
          </div>
          <div class="kpi-mini">${deadlines.length}/${S.projects.length}</div>
        </div>
        <div class="deadlist">
          ${deadlines.map(p => {
            const d = fmtDate(p.deadline);
            const prog = pct(p);
            return `
              <div class="deaditem">
                <div class="deadtop">
                  <p class="deadname">${esc(p.name)}</p>
                  <span class="deadmeta">${esc(d.s)}</span>
                </div>
                <div class="deadprogress"><div class="${pbCls(p)} pb" style="width:${prog}%"></div></div>
              </div>
            `;
          }).join('')}
        </div>
      </article>
    </div>
  `;
}

function stats(){
  const all = S.projects;
  const today = new Date().toLocaleDateString('es-CO',{weekday:'short',day:'numeric',month:'short',year:'numeric'});
  const avgRisk = all.length ? Math.round(all.reduce((a,p)=>a + riskScore(p), 0) / all.length) : 0;
  return `
    <div class="hdr">
      <div>
        <p class="team-name">ENGINEERING · SENIOR TEAM</p>
        <p class="hdr-title">Project Dashboard</p>
        <p class="hdr-desc">Vista ejecutiva para seguimiento de portfolio, riesgo, capacidad y entregas críticas.</p>
      </div>
      <div class="hdr-date">
        <div>${esc(today)}</div>
        <div style="margin-top:4px;color:var(--soft)">Sprint activo</div>
        <div style="margin-top:8px;color:var(--muted)">Riesgo medio: ${avgRisk}</div>
      </div>
    </div>
    <div class="kpis">
      ${execKpis().map(k => `
        <div class="kpi ${k.cls}">
          <p class="kpi-l">${esc(k.l)}</p>
          <p class="kpi-v">${esc(k.v)}${k.l === 'Carga/capacidad' || k.l === 'Velocidad sprint' ? '' : '<span></span>'}</p>
          <p class="kpi-s">${esc(k.s)}</p>
        </div>
      `).join('')}
    </div>
  `;
}

function riskView(p){
  const s = riskScore(p);
  const pr = pct(p);
  const overdue = Math.max(0, -daysTo(p.deadline));
  return `
    <div class="risk-grid">
      <div class="metric-card">
        <p class="metric-title">Risk score automático</p>
        <p class="metric-value">${s}</p>
        <p class="metric-desc">${riskLabel(s)} · combinación de prioridad, severidad, urgencia, dependencias, blockers y vencimiento.</p>
        <div class="badge-stack">
          <span class="risk-pill ${riskClass(s)}">${riskLabel(s)}</span>
          <span class="risk-pill">${overdue ? `${overdue}d vencido` : `${Math.max(0, daysTo(p.deadline))}d para deadline`}</span>
          <span class="risk-pill">${pr}% avance</span>
        </div>
        <div class="metric-rows">
          <div class="metric-row"><span>Prioridad de negocio</span><strong>${p.businessPriority || 0}/5</strong></div>
          <div class="metric-row"><span>Severidad técnica</span><strong>${p.technicalSeverity || 0}/5</strong></div>
          <div class="metric-row"><span>Urgencia</span><strong>${p.urgency || 0}/5</strong></div>
          <div class="metric-row"><span>Dependencia crítica</span><strong>${p.dependencyCriticality || 0}/5</strong></div>
        </div>
      </div>
      <div class="metric-card">
        <p class="metric-title">Portfolio de entregables</p>
        <p class="metric-value">${p.deliverables.filter(d => d.done).length}<span>/${p.deliverables.length}</span></p>
        <p class="metric-desc">Avance por proyecto con SLA comprometido vs real y responsables claros por entregable.</p>
        <div class="metric-rows">
          ${p.deliverables.map(d => {
            const sl = d.sla ? fmtDate(d.sla) : {s:'sin SLA', c:''};
            const cls = d.done ? 'good' : (daysTo(d.sla) < 0 ? 'danger' : 'warn');
            return `
              <div class="metric-row">
                <span style="max-width:68%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(d.text)}</span>
                <strong style="color:var(${cls === 'good' ? '--ok' : cls === 'danger' ? '--danger' : '--warn'})">${esc(sl.s)}</strong>
              </div>
            `;
          }).join('')}
        </div>
      </div>
      <div class="metric-card">
        <p class="metric-title">Capacidad y bloqueo</p>
        <p class="metric-value">${(p.blockers || []).length}</p>
        <p class="metric-desc">Blockers activos, dependencias y señales de riesgo operativo para priorizar decisiones.</p>
        <div class="metric-rows">
          <div class="metric-row"><span>Estado</span><strong>${esc((p.status || '').toUpperCase())}</strong></div>
          <div class="metric-row"><span>Deadline</span><strong>${esc(fmtDate(p.deadline).s)}</strong></div>
          <div class="metric-row"><span>SLA comprometido</span><strong>${esc(p.committedAt || 'N/D')}</strong></div>
          <div class="metric-row"><span>Fecha real</span><strong>${esc(p.actualAt || 'N/D')}</strong></div>
        </div>
      </div>
    </div>
  `;
}

function timelineView(p){
  return `
    <div class="stack-grid">
      <div class="metric-card">
        <p class="metric-title">Timeline</p>
        <div class="timeline">
          ${(p.timeline || []).map((t, idx) => `
            <div class="tl-item">
              <div style="display:flex;flex-direction:column;align-items:center;height:100%">
                <div class="tl-dot" style="background:${idx % 2 ? 'var(--purple)' : 'var(--info)'}"></div>
                ${idx < (p.timeline || []).length - 1 ? '<div class="tl-line"></div>' : ''}
              </div>
              <div class="tl-main">
                <div class="tl-head">
                  <p class="tl-title">${esc(t.title)}</p>
                  <span class="tl-meta">${esc(t.date)}</span>
                </div>
                <p class="tl-desc">${esc(t.desc)}</p>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
      <div class="metric-card">
        <p class="metric-title">Dependencias y blockers</p>
        <div class="block-list">
          <div class="block-card">
            <div class="block-top">
              <p class="block-name">Dependencias principales</p>
              <span class="block-meta">${(p.dependencies || []).length} items</span>
            </div>
            <p class="block-desc">${(p.dependencies || []).length ? p.dependencies.map(esc).join(' · ') : 'No hay dependencias registradas.'}</p>
          </div>
          ${(p.blockers || []).length ? p.blockers.map((b, i) => `
            <div class="block-card">
              <div class="block-top">
                <p class="block-name">Blocker ${i + 1}</p>
                <span class="block-meta">activo</span>
              </div>
              <p class="block-desc">${esc(b)}</p>
            </div>
          `).join('') : `
            <div class="block-card"><p class="block-desc">Sin blockers activos.</p></div>
          `}
        </div>
      </div>
    </div>
  `;
}

function historyView(p){
  return `
    <div class="stack-grid">
      <div class="metric-card">
        <p class="metric-title">Historial de cambios</p>
        <div class="hist-list">
          ${(p.history || []).map(h => `
            <div class="hist-item">
              <div class="hist-top">
                <p class="hist-name">${esc(h.action)}</p>
                <span class="hist-meta">${esc(h.date)}</span>
              </div>
              <p class="hist-desc"><strong>${esc(h.author)}.</strong> ${esc(h.detail)}</p>
            </div>
          `).join('')}
        </div>
      </div>
      <div class="metric-card">
        <p class="metric-title">Actividad reciente</p>
        <div class="hist-list">
          ${(p.recentActivity || []).map(r => `
            <div class="hist-item">
              <div class="hist-top">
                <p class="hist-name">${esc(r.author)}</p>
                <span class="hist-meta">${esc(r.date)}</span>
              </div>
              <p class="hist-desc">${esc(r.text)}</p>
            </div>
          `).join('')}
          ${!(p.recentActivity || []).length ? `<div class="hist-item"><p class="hist-desc">Sin actividad reciente.</p></div>` : ''}
        </div>
      </div>
    </div>
  `;
}

function slaView(p){
  return `
    <div class="sla-grid">
      ${(p.deliverables || []).map(d => {
        const sla = d.sla ? toDate(d.sla) : null;
        const committed = d.committed ? toDate(d.committed) : null;
        const actual = d.actual ? toDate(d.actual) : null;
        const diff = (committed && actual && isValidDate(committed) && isValidDate(actual)) ? Math.round((actual - committed)/864e5) : null;
        const delta = diff === null ? 'N/D' : diff === 0 ? 'a tiempo' : diff > 0 ? `+${diff}d` : `${diff}d`;
        const slaDiff = sla && actual && isValidDate(sla) && isValidDate(actual) ? Math.round((actual - sla)/864e5) : null;
        const slaText = slaDiff === null ? 'N/D' : slaDiff <= 0 ? 'cumplió SLA' : `tarde +${slaDiff}d`;
        return `
          <div class="sla-card">
            <p class="sla-k">${d.done ? 'entregado' : 'en curso'}</p>
            <p class="sla-v">${esc(delta)}</p>
            <p class="sla-s">${esc(d.text)}</p>
            <div class="badge-stack">
              <span class="risk-pill">Owner: ${esc(fullName(d.owner || ''))}</span>
              <span class="risk-pill">SLA: ${esc(d.sla || 'N/D')}</span>
              <span class="risk-pill">${esc(slaText)}</span>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function renderCard(p){
  const dl = fmtDate(p.deadline);
  const pc = pct(p);
  const sel = S.sel === p.id;
  const rs = riskScore(p);
  return `
    <div class="card${sel ? ' sel' : ''}" onclick="pick('${p.id}')">
      <div class="ch">
        <p class="cn">${esc(p.name)}</p>
        ${sbadge(p.status)}
      </div>
      <p class="desc">${esc(p.description)}</p>
      <div class="tech">${(p.tech || []).map(t=>`<span class="tt">${esc(t)}</span>`).join('')}</div>
      <div class="progress"><div class="${pbCls(p)} pb" style="width:${pc}%"></div></div>
      <div class="meta">
        <span class="dl ${dl.c}">${esc(dl.s)}</span>
        <span style="font-size:11px;color:var(--soft);font-family:var(--mono)">${pc}%</span>
      </div>
      <div class="cf">
        <div class="members">${(p.assignees || []).map((a,i)=>av(a,i)).join('')}</div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;justify-content:flex-end">
          ${pbadge(p.priority)}
          <span class="risk-pill ${riskClass(rs)}">RS ${rs}</span>
          <span class="cm-count">${(p.comments || []).length} note${(p.comments || []).length!==1?'s':''}</span>
        </div>
      </div>
    </div>
  `;
}

function renderDetail(){
  const p = S.projects.find(x => x.id === S.sel);
  if(!p) return '';
  let body = '';
  if(S.tab === 'executive') body = riskView(p);
  else if(S.tab === 'deliverables'){
    body = `
      ${p.deliverables.map(d => `
        <details class="deliv-item">
          <summary class="deliv-sum">
            <input type="checkbox" ${d.done ? 'checked' : ''} onclick="event.stopPropagation()" onchange="toggleD('${p.id}','${d.id}')">
            <div class="deliv-main">
              <span class="dt ${d.done ? 'done' : ''}">${esc(d.text)}</span>
              <span class="deliv-hint">${d.done ? 'Completado' : 'Pendiente'} · responsable ${esc(fullName(d.owner || ''))}</span>
            </div>
            <span class="deliv-arrow">▾</span>
          </summary>
          <div class="deliv-extra">
            <div class="kv"><span class="kv-k">Responsable</span><span>${esc(d.owner ? fullName(d.owner) : 'Sin definir')}</span></div>
            <div class="kv"><span class="kv-k">Objetivo</span><span>${esc(d.goal || 'No definido')}</span></div>
            <div class="kv"><span class="kv-k">Criterio</span><span>${esc(d.criteria || 'No definido')}</span></div>
            <div class="kv"><span class="kv-k">Notas</span><span>${esc(d.notes || 'Sin notas')}</span></div>
            <div class="kv"><span class="kv-k">SLA</span><span>${esc(d.sla || 'N/D')}</span></div>
            <div class="kv"><span class="kv-k">Compromiso</span><span>${esc(d.committed || 'N/D')}</span></div>
            <div class="kv"><span class="kv-k">Real</span><span>${esc(d.actual || 'N/D')}</span></div>
          </div>
        </details>
      `).join('')}
      <div style="margin-top:12px">
        <input id="nd" placeholder="+ Añadir entregable..." onkeydown="if(event.key==='Enter')addDel('${p.id}')">
      </div>
    `;
  }else if(S.tab === 'comments'){
    body = `
      ${p.comments.length ? p.comments.map(c => `
        <div class="cmt">
          <div class="cmt-m">
            <span class="cmt-a">${esc(c.author)}</span>
            <span class="cmt-d">${esc(c.date)}</span>
          </div>
          <p class="cmt-t">${esc(c.text)}</p>
        </div>
      `).join('') : `<p style="font-size:12px;color:var(--soft);font-family:var(--mono)">Sin comentarios aún.</p>`}
      <div class="add-cmt">
        <input id="nc" placeholder="Añadir comentario..." onkeydown="if(event.key==='Enter')addCmt('${p.id}')">
        <button class="btn-p" onclick="addCmt('${p.id}')">Enviar</button>
      </div>
    `;
  }else if(S.tab === 'timeline'){
    body = timelineView(p) + historyView(p);
  }else if(S.tab === 'sla'){
    body = slaView(p);
  }else{
    const overdue = daysTo(p.deadline) < 0;
    const near = daysTo(p.deadline) >= 0 && daysTo(p.deadline) <= 7;
    body = `
      <details class="acc" open>
        <summary>Resumen general</summary>
        <div class="acc-body">
          <div class="kv"><span class="kv-k">Estado</span>${sbadge(p.status)}</div>
          <div class="kv"><span class="kv-k">Prioridad</span>${pbadge(p.priority)}</div>
          <div class="kv"><span class="kv-k">Progreso</span><span>${pct(p)}% (${p.deliverables.filter(d=>d.done).length}/${p.deliverables.length})</span></div>
          <div class="kv"><span class="kv-k">Deadline</span><span style="font-family:var(--mono)">${esc(p.deadline)}</span></div>
          <div class="kv"><span class="kv-k">Alerta</span><span style="color:${overdue ? 'var(--danger)' : near ? 'var(--warn)' : 'var(--soft)'}">${overdue ? 'Vencido' : near ? 'Próximo a vencer' : 'OK'}</span></div>
          <div class="kv"><span class="kv-k">Risk score</span><span>${riskScore(p)} · ${riskLabel(riskScore(p))}</span></div>
        </div>
      </details>
      <details class="acc">
        <summary>Equipo asignado</summary>
        <div class="acc-body">
          <div class="kv"><span class="kv-k">Miembros</span><span>${(p.assignees || []).map(a => `${esc(a)} · ${esc(fullName(a))}`).join('<br>')}</span></div>
        </div>
      </details>
      <details class="acc">
        <summary>Stack técnico</summary>
        <div class="acc-body"><div class="tech" style="margin:0">${(p.tech || []).map(t => `<span class="tt">${esc(t)}</span>`).join('')}</div></div>
      </details>
      <details class="acc">
        <summary>Gestión y acciones</summary>
        <div class="acc-body">
          <div class="kv"><span class="kv-k">Comentarios</span><span>${p.comments.length} nota${p.comments.length !== 1 ? 's' : ''}</span></div>
          <div class="kv"><span class="kv-k">Blockers</span><span>${(p.blockers || []).length}</span></div>
          <div class="kv"><span class="kv-k">Dependencias</span><span>${(p.dependencies || []).length}</span></div>
          <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
            <button class="btn-p" onclick="editP('${p.id}')">Editar</button>
            <button class="btn-s btn-d" onclick="delP('${p.id}')">Eliminar</button>
          </div>
        </div>
      </details>
    `;
  }

  return `
    <div class="detail">
      <div class="dp-hdr">
        <div>
          <p class="dp-title">${esc(p.name)}</p>
          <p class="dp-sub">${esc(p.description.slice(0,110))}${p.description.length > 110 ? '…' : ''}</p>
        </div>
        <div class="dp-actions">
          <button onclick="pick(null)" class="tiny-btn" style="background:none">✕</button>
        </div>
      </div>
      <div class="dp-tabs">
        ${[
          ['executive','Executive'],
          ['deliverables','Entregables'],
          ['timeline','Timeline'],
          ['comments','Comentarios'],
          ['sla','SLA'],
          ['info','Info']
        ].map(([k,l]) => `<div class="dpt ${S.tab===k?'on':''}" onclick="setTab('${k}')">${l}</div>`).join('')}
      </div>
      ${body}
    </div>
  `;
}

function renderForm(){
  if(!S.showForm) return '';
  const ed = S.editId ? S.projects.find(p => p.id === S.editId) : null;
  const f = S.form || {};
  return `
    <div class="fs">
      <p style="font-size:11px;font-family:var(--mono);text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin:0 0 16px">
        ${ed ? '// editar proyecto' : '// nuevo proyecto'}
      </p>
      <div class="fg">
        <div class="full">
          <label class="flabel">Nombre del proyecto</label>
          <input id="fn" value="${esc(f.name || '')}" placeholder="Ej: Plataforma de observabilidad">
        </div>
        <div class="full">
          <label class="flabel">Descripción</label>
          <textarea id="fd" placeholder="Objetivo y alcance del proyecto...">${esc(f.description || '')}</textarea>
        </div>
        <div>
          <label class="flabel">Estado</label>
          <select id="fst">
            <option value="active" ${(f.status || 'active') === 'active' ? 'selected' : ''}>Activo</option>
            <option value="risk" ${f.status === 'risk' ? 'selected' : ''}>En riesgo</option>
            <option value="delivered" ${f.status === 'delivered' ? 'selected' : ''}>Entregado</option>
            <option value="paused" ${f.status === 'paused' ? 'selected' : ''}>Pausado</option>
          </select>
        </div>
        <div>
          <label class="flabel">Prioridad</label>
          <select id="fp">
            <option value="critical" ${f.priority === 'critical' ? 'selected' : ''}>Critical</option>
            <option value="high" ${(f.priority || 'high') === 'high' ? 'selected' : ''}>High</option>
            <option value="medium" ${f.priority === 'medium' ? 'selected' : ''}>Medium</option>
            <option value="low" ${f.priority === 'low' ? 'selected' : ''}>Low</option>
          </select>
        </div>
        <div>
          <label class="flabel">Prioridad de negocio</label>
          <select id="fbp">
            ${[5,4,3,2,1].map(n => `<option value="${n}" ${(String(f.businessPriority || 3) === String(n)) ? 'selected' : ''}>${n}/5</option>`).join('')}
          </select>
        </div>
        <div>
          <label class="flabel">Severidad técnica</label>
          <select id="fts">
            ${[5,4,3,2,1].map(n => `<option value="${n}" ${(String(f.technicalSeverity || 3) === String(n)) ? 'selected' : ''}>${n}/5</option>`).join('')}
          </select>
        </div>
        <div>
          <label class="flabel">Urgencia</label>
          <select id="fur">
            ${[5,4,3,2,1].map(n => `<option value="${n}" ${(String(f.urgency || 3) === String(n)) ? 'selected' : ''}>${n}/5</option>`).join('')}
          </select>
        </div>
        <div>
          <label class="flabel">Dependencia crítica</label>
          <select id="fdc">
            ${[5,4,3,2,1].map(n => `<option value="${n}" ${(String(f.dependencyCriticality || 3) === String(n)) ? 'selected' : ''}>${n}/5</option>`).join('')}
          </select>
        </div>
        <div>
          <label class="flabel">Fecha de entrega</label>
          <input type="date" id="fdl" value="${esc(f.deadline || '')}">
        </div>
        <div>
          <label class="flabel">SLA comprometido</label>
          <input type="date" id="fca" value="${esc(f.committedAt || '')}">
        </div>
        <div>
          <label class="flabel">Fecha real</label>
          <input type="date" id="fra" value="${esc(f.actualAt || '')}">
        </div>
        <div>
          <label class="flabel">Miembros</label>
          <input id="fass" value="${esc(f.assignees || '')}" placeholder="CR, ML, JP">
        </div>
        <div class="full">
          <label class="flabel">Tech stack</label>
          <input id="ftc" value="${esc(f.tech || '')}" placeholder="Node.js, Redis, K8s">
        </div>
        <div class="full">
          <label class="flabel">Blockers (uno por línea)</label>
          <textarea id="fblk" placeholder="Bloqueador 1\nBloqueador 2">${esc(f.blockers || '')}</textarea>
        </div>
        <div class="full">
          <label class="flabel">Dependencias (una por línea)</label>
          <textarea id="fdep" placeholder="Servicio A\nServicio B">${esc(f.dependencies || '')}</textarea>
        </div>
        <div class="full">
          <label class="flabel">Entregables (uno por línea)</label>
          <textarea id="fdels" placeholder="Diseño de arquitectura\nImplementación de auth\nTests de carga">${esc(f.deliverables || '')}</textarea>
        </div>
      </div>
      <div class="fa">
        <button class="btn-s" onclick="cancelF()">Cancelar</button>
        <button class="btn-p" onclick="saveP()">${ed ? 'Guardar cambios' : 'Crear proyecto'}</button>
      </div>
    </div>
  `;
}

function render(){
  const fil = S.projects.filter(p => S.filter === 'all' || p.status === S.filter);
  const root = document.getElementById('root');
  root.innerHTML = `
    ${stats()}
    ${renderInsights()}
    <div class="bar">
      <div class="filters">
        ${[['all','Todos'],['active','Activos'],['risk','En riesgo'],['delivered','Entregados'],['paused','Pausados']].map(([k,l]) =>
          `<button class="fb ${S.filter===k?'on':''}" onclick="setF('${k}')">${l}</button>`
        ).join('')}
      </div>
      <button class="add-btn" onclick="tgForm()">${S.showForm && !S.editId ? '✕ Cancelar' : '+ Nuevo proyecto'}</button>
    </div>
    ${renderForm()}
    <div class="grid">
      ${fil.length ? fil.map(renderCard).join('') : `<div class="empty" style="grid-column:1/-1">// no hay proyectos en esta vista</div>`}
    </div>
    ${renderDetail()}
  `;
}
function render(){
  const fil = S.projects.filter(p => S.filter === 'all' || p.status === S.filter);
  const root = document.getElementById('root');
  root.innerHTML = `
    ${stats()}
    ${renderInsights()}
    <div class="bar">
      <div class="filters">
        ${[['all','Todos'],['active','Activos'],['risk','En riesgo'],['delivered','Entregados'],['paused','Pausados']].map(([k,l]) =>
          `<button class="fb ${S.filter===k?'on':''}" onclick="setF('${k}')">${l}</button>`
        ).join('')}
      </div>
      <button class="add-btn" onclick="tgForm()">${S.showForm && !S.editId ? '✕ Cancelar' : '+ Nuevo proyecto'}</button>
    </div>
    ${renderForm()}
    <div class="grid">
      ${fil.length ? fil.map(renderCard).join('') : `<div class="empty" style="grid-column:1/-1">// no hay proyectos en esta vista</div>`}
    </div>
    ${renderDetail()}
  `;
}
