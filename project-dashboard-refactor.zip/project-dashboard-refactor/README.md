# Project Dashboard — estructura profesional

Este proyecto mantiene el mismo comportamiento del HTML original, pero ahora está organizado en archivos separados.

## Estructura

- `index.html`: punto de entrada
- `assets/css/styles.css`: estilos
- `assets/js/data.js`: datos, estado y almacenamiento
- `assets/js/utils.js`: utilidades
- `assets/js/calculations.js`: cálculos y métricas
- `assets/js/renderers.js`: renderizado de vistas
- `assets/js/actions.js`: acciones del usuario y persistencia
- `assets/js/app.js`: arranque de la app

## Ejecución local

Abre `index.html` directamente en el navegador.

## GitHub Pages

1. Crea un repositorio nuevo en GitHub.
2. Sube toda la carpeta del proyecto.
3. Confirma que `index.html` esté en la raíz del repositorio.
4. Ve a **Settings** → **Pages**.
5. En **Build and deployment**, elige:
   - **Source**: `Deploy from a branch`
   - **Branch**: `main`
   - **Folder**: `/ (root)`
6. Guarda los cambios.
7. Espera unos segundos y abre la URL publicada por GitHub Pages.
