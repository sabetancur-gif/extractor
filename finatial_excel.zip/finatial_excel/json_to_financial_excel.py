"""
json_to_financial_excel.py
==========================
Convierte document.json (salida de OCR/PDF parser) a un Excel financiero
reproduciendo la estructura del PDF: Balance Sheet + Income Statement.

Uso:
    python json_to_financial_excel.py                        # document.json -> output.xlsx
    python json_to_financial_excel.py mis.json reporte.xlsx  # rutas personalizadas
"""

import json
import re
import sys
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ─────────────────────────────────────────────────────────────────────────────
# ESTILOS
# ─────────────────────────────────────────────────────────────────────────────

FONT_NAME = "Arial"

C_HEADER_BG    = "FF1F4E79"
C_HEADER_FG    = "FFFFFFFF"
C_SUBHEADER_BG = "FFD6E4F0"
C_TOTAL_BG     = "FFDCE6F1"
C_GRAND_BG     = "FFBDD7EE"
C_ALT_BG       = "FFF2F7FB"
C_INPUT_FG     = "FF0070C0"
C_FORMULA_FG   = "FF000000"
C_NEGATIVE_FG  = "FFCC0000"
C_SECTION_FG   = "FFFFFFFF"

_T = Side(style="thin",   color="FFB8CCE4")
_M = Side(style="medium", color="FF1F4E79")
B_THIN = Border(left=_T, right=_T, top=_T, bottom=_T)
B_HTOP = Border(left=_T, right=_T, top=_M, bottom=_T)

FMT_NUM = '#,##0.00;[RED]-#,##0.00;"-"'
FMT_PCT = '0"%"'


def sc(cell, bold=False, italic=False, size=10,
       fg=C_FORMULA_FG, bg=None, align="left",
       border=B_THIN, wrap=False, num_fmt=None):
    cell.font = Font(name=FONT_NAME, bold=bold, italic=italic, size=size, color=fg)
    if bg:
        cell.fill = PatternFill("solid", start_color=bg)
    cell.alignment = Alignment(horizontal=align, vertical="center", wrap_text=wrap)
    cell.border = border
    if num_fmt:
        cell.number_format = num_fmt


# ─────────────────────────────────────────────────────────────────────────────
# LIMPIEZA OCR
# ─────────────────────────────────────────────────────────────────────────────

def clean_num(s: str) -> Optional[float]:
    """Convierte string OCR ruidoso a float."""
    if not s:
        return None
    s = str(s).strip()
    s = re.sub(r"[~\u2014\u2013=]", "-", s)
    s = re.sub(r"[^0-9.,\-]", "", s)
    s = s.replace(",", "")
    parts = s.split(".")
    if len(parts) > 2:
        s = "".join(parts[:-1]) + "." + parts[-1]
    if s in ("", ".", "-", "-."):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def clean_text(s: str) -> str:
    s = re.sub(r"[~\u2014\u2013]", "-", s)
    s = re.sub(r"\u2019", "'", s)
    s = re.sub(r"\*kk\*?|\*kkk?\*?|«+", "***", s)
    s = re.sub(r"\s{2,}", " ", s)
    return s.strip()


# ─────────────────────────────────────────────────────────────────────────────
# MODELO
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class FinRow:
    row_type:    str
    account:     Optional[str] = None
    description: str           = ""
    values:      list          = field(default_factory=list)
    pct_values:  list          = field(default_factory=list)


# ─────────────────────────────────────────────────────────────────────────────
# PATRONES GLOBALES
# ─────────────────────────────────────────────────────────────────────────────

RE_ACCT8 = re.compile(r"^\d{8}$")
RE_PAIR  = re.compile(r"(-?[\d,]+\.?\d*)\s+(-?\d+)%")

META_SKIP = re.compile(
    r"^\d{2}/\d{2}/\d{4}|PAGE:\s*\d+|\*{3}\s*Company:|^MIS/Digilog|"
    r"Balance Sheet|Income Statement|^As of|thru|^Last Y|^Curr\.|"
    r"Period\s+Year|^Description\s|K{3,}|^we$|^END\b|\d{2}:\d{2}:\d{2}|"
    r"^Last Year$|^This Year|Curr,\s+Period",
    re.I
)

SECTION_PAT = re.compile(
    r"^\*+\s*(Assets|Liabilities|Equity|Sales|Expenses|COST|Gross|Stockholders)",
    re.I
)

TOTAL_PAT = re.compile(
    r"^(TOTAL|FIXED ASSETS|Total\s+Assets|Total\s+Equity|Total\s+Liabilities|"
    r"Liabilities\s+&\s+Equity|Net\s+Income|Net\s+Loss|END\s+OF)",
    re.I
)

GRAND_PAT = re.compile(
    r"^(Total\s+Assets|Total\s+Equity|Total\s+Liabilities|Liabilities\s+&\s+Equity)",
    re.I
)


def is_meta(line: str) -> bool:
    return bool(META_SKIP.search(line))


def is_section(line: str) -> bool:
    return bool(SECTION_PAT.match(line))


def parse_section_name(line: str) -> str:
    return re.sub(r"^\*+\s*|\s*\*+$", "", line).strip().upper()


# ─────────────────────────────────────────────────────────────────────────────
# PARSER BALANCE SHEET
# ─────────────────────────────────────────────────────────────────────────────

def parse_bs_line(line: str) -> Optional[FinRow]:
    line = clean_text(line)
    if not line:
        return FinRow(row_type="blank")
    if is_meta(line) or re.match(r"K{3,}", line):
        return None
    if is_section(line):
        return FinRow(row_type="section", description=parse_section_name(line))

    # Limpiar prefijos decorativos
    work = re.sub(r"^\*+\s*", "", line).strip()
    work = re.sub(r"\s*=\s*", " ", work).strip()

    acct = None
    desc_part = ""
    values = []

    # Caso 1: línea con código de cuenta (8 dígitos) + descripción + valores
    # Patrón: ACCT TEXT ... NUM [NUM]
    # Los valores financieros tienen formato #,###.## (con punto decimal o al menos 4+ dígitos con comas)
    m_acct = re.match(r"^(\d{5,8})\s+(.*)", work)
    if m_acct:
        acct = m_acct.group(1)
        rest = m_acct.group(2).strip()
        # Los valores monetarios: buscar desde el final de la parte de texto
        # Estrategia: el texto termina donde empieza la primera secuencia numérica "grande"
        # (número con coma de miles o decimal, precedido de espacio)
        val_match = re.search(
            r"\s+([-~]?\d{1,3}(?:,\d{3})*(?:\.\d+)?|\d{4,}(?:\.\d+)?|-\d+(?:\.\d+)?)\s*$",
            " " + rest
        )
        # Buscar todos los pares de valores al final
        vals_raw = re.findall(r"(?<!\d)(-?[\d,]+\.\d{2}|-?\d{1,3}(?:,\d{3})+(?:\.\d*)?)(?!\d)", rest)
        if not vals_raw:
            # Fallback: números simples >= 2 dígitos al final
            vals_raw = re.findall(r"\b(-?\d[\d,]*\.?\d*)\b", rest)
        
        # Separar descripción de valores:
        # La descripción es texto alfabético; los valores son los números al final
        desc_m = re.match(r"^([A-Za-z][A-Z &\-'/\.a-z0-9]*?)\s+(-?[\d,])", rest)
        if desc_m:
            desc_part = desc_m.group(1).strip()
            num_start = rest.index(desc_m.group(2), len(desc_part))
            nums_str = rest[num_start:]
            values = [v for v in [clean_num(n) for n in
                      re.findall(r"-?[\d,]+\.?\d*", nums_str)] if v is not None]
        else:
            desc_part = re.sub(r"[-\d,.\s]+$", "", rest).strip()
            values = [v for v in [clean_num(n) for n in
                      re.findall(r"-?[\d,]+\.?\d*", rest)] if v is not None]

        rtype = "data"

    else:
        # Caso 2: línea sin código de cuenta (totales, secciones, grand totals)
        clean_desc_raw = re.sub(r"^\*+\s*|\s*=\s*$", "", work).strip()
        # Extraer números del final
        vals_in_line = re.findall(r"-?[\d,]+\.\d{2}|-?\d{1,3}(?:,\d{3})+", clean_desc_raw)
        if not vals_in_line:
            vals_in_line = re.findall(r"\b-?\d+\.\d+\b", clean_desc_raw)
        values = [v for v in [clean_num(n) for n in vals_in_line] if v is not None]

        # Descripción: quitar los números del final
        desc_part = re.sub(r"\s+[-\d,.\s]+$", "", clean_desc_raw).strip()
        desc_part = re.sub(r"\s*=\s*$", "", desc_part).strip()

        if not desc_part and not values:
            return None

        if GRAND_PAT.match(desc_part):
            rtype = "grand"
        elif TOTAL_PAT.match(work) or TOTAL_PAT.match(desc_part):
            rtype = "total"
        elif values:
            rtype = "total"
        else:
            if re.search(r"\d{5,}", desc_part):
                return None
            return FinRow(row_type="meta", description=desc_part)

    clean_desc = re.sub(r"\s*=\s*$", "", desc_part).strip()
    return FinRow(row_type=rtype, account=acct, description=clean_desc, values=values)


def merge_bs_lines(lines: list) -> list:
    merged, buf = [], ""
    for ln in lines:
        ln = clean_text(ln)
        if not ln:
            continue
        starts_new = (
            re.match(r"^\d{5,8}", ln) or
            re.match(r"^\*+\s*(Assets|Liabilities|Stockholders|Equity)", ln, re.I) or
            re.match(r"^(TOTAL|FIXED|END\s+OF|Total\s+|Net\s+Income)", ln, re.I) or
            is_meta(ln) or is_section(ln)
        )
        if starts_new:
            if buf:
                merged.append(buf)
            buf = ln
        else:
            if buf and re.search(r"\d$", buf.strip()):
                merged.append(buf)
                buf = ln
            else:
                buf = (buf + " " + ln).strip() if buf else ln
    if buf:
        merged.append(buf)
    return merged


def parse_balance_sheet(doc: dict) -> tuple:
    meta_lines = []
    rows = []
    in_bs = False

    for page in doc["pages"]:
        for block in sorted(page["blocks"], key=lambda b: b.get("order", 0)):
            text = block.get("text", "")
            if not text:
                continue
            if "Balance Sheet" in text and not in_bs:
                in_bs = True
                for ln in text.split("\n"):
                    ln = ln.strip()
                    if ln and not re.match(r"K{3,}|^\d{2}:\d{2}", ln):
                        meta_lines.append(clean_text(ln))
                continue
            if "Income Statement" in text and in_bs:
                in_bs = False
                break
            if not in_bs:
                continue
            lines = [l.strip() for l in text.split("\n") if l.strip()]
            for ln in merge_bs_lines(lines):
                fr = parse_bs_line(ln)
                if fr is not None and fr.row_type != "blank":
                    rows.append(fr)

    return meta_lines, rows


# ─────────────────────────────────────────────────────────────────────────────
# PARSER INCOME STATEMENT
# ─────────────────────────────────────────────────────────────────────────────

def extract_is_pairs(line: str) -> tuple:
    line = clean_text(line)
    pairs = RE_PAIR.findall(line)
    vals = [clean_num(p[0]) for p in pairs[:4]]
    pcts = [clean_num(p[1]) for p in pairs[:4]]
    return vals, pcts


def parse_is_block_split(text: str) -> list:
    """
    Parsea bloque OCR donde cuentas, descripciones y valores están
    en columnas separadas dentro del mismo bloque de texto.
    """
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    rows = []
    accounts, descriptions, value_lines = [], [], []

    i = 0
    # Fase 1: cuentas (8 dígitos exactos)
    while i < len(lines) and RE_ACCT8.match(lines[i]):
        accounts.append(lines[i])
        i += 1

    # Fase 2: descripciones (texto libre)
    while i < len(lines):
        ln = lines[i]
        if is_meta(ln) or re.match(r"^(Curr\.|Period|Last Y|MIS/|PAGE:|Income|01/)", ln, re.I):
            i += 1
            continue
        if RE_PAIR.search(clean_text(ln)):
            break
        descriptions.append(clean_text(ln))
        i += 1

    # Fase 3: saltar encabezados de columnas
    while i < len(lines):
        if RE_PAIR.search(clean_text(lines[i])):
            break
        i += 1

    # Fase 4: líneas de valores
    while i < len(lines):
        value_lines.append(lines[i])
        i += 1

    n = max(len(accounts), len(descriptions))
    for j in range(n):
        acct = accounts[j] if j < len(accounts) else None
        desc = descriptions[j] if j < len(descriptions) else ""
        vals, pcts = [], []
        if j < len(value_lines):
            vals, pcts = extract_is_pairs(value_lines[j])
        if acct or desc:
            rows.append(FinRow(
                row_type="data",
                account=acct,
                description=desc,
                values=vals,
                pct_values=pcts
            ))
    return rows


def parse_is_line(line: str) -> Optional[FinRow]:
    line = clean_text(line)
    if not line or is_meta(line):
        return None
    if is_section(line):
        return FinRow(row_type="section", description=parse_section_name(line))

    is_grand = bool(re.match(r".*Total\s+Net\s+(Profit|Loss|Income)", line, re.I))
    is_tot = bool(re.match(
        r"^(\*+\s*)?(Total\s+(Sales|Expenses|Cost|Gross)|TOTAL\s+COST|Gross\s+Profit)",
        line, re.I
    ))

    vals, pcts = extract_is_pairs(line)
    desc_part = RE_PAIR.sub("", line).strip()
    desc_part = re.sub(r"\*+\s*|\s*=\s*$", "", desc_part).strip()

    acct = None
    acct_m = re.match(r"^(\d{5,8})\s+(.*)", desc_part)
    if acct_m:
        acct = acct_m.group(1)
        desc_part = acct_m.group(2).strip()

    if not desc_part and not acct and not vals:
        return None

    if is_grand:
        rtype = "grand"
    elif is_tot:
        rtype = "total"
    elif acct:
        rtype = "data"
    else:
        rtype = "total" if vals else "meta"

    return FinRow(row_type=rtype, account=acct, description=desc_part,
                  values=vals, pct_values=pcts)


def parse_income_statement(doc: dict) -> list:
    rows = []

    for page in doc["pages"]:
        pn = page["page_number"]
        if pn == 1:
            continue

        for block in sorted(page["blocks"], key=lambda b: b.get("order", 0)):
            text = block.get("text", "")
            if not text:
                continue
            if re.match(r"^\d{2}/\d{2}/\d{4}", text.strip()):
                continue
            if "Income Statement" in text and len(text) < 200:
                continue

            lines = [l.strip() for l in text.split("\n") if l.strip()]
            acct_count = sum(1 for l in lines[:15] if RE_ACCT8.match(l))

            if acct_count >= 5:
                rows.extend(parse_is_block_split(text))
                continue

            data_start = 0
            for idx, ln in enumerate(lines):
                if re.match(r"(Description|Last Year|Curr\.)", ln, re.I):
                    data_start = idx + 1

            for ln in lines[data_start:]:
                fr = parse_is_line(ln)
                if fr:
                    rows.append(fr)

    return rows


# ─────────────────────────────────────────────────────────────────────────────
# DEDUP
# ─────────────────────────────────────────────────────────────────────────────

def dedup_rows(rows: list) -> list:
    seen = set()
    result = []
    for fr in rows:
        key = (fr.row_type, fr.account, (fr.description or "")[:40])
        if key in seen and fr.row_type not in ("section", "grand", "total"):
            continue
        seen.add(key)
        result.append(fr)
    return result


# ─────────────────────────────────────────────────────────────────────────────
# ESCRITOR EXCEL
# ─────────────────────────────────────────────────────────────────────────────

class ExcelWriter:

    def __init__(self, doc: dict):
        self.doc = doc
        self.wb = Workbook()
        self.wb.remove(self.wb.active)

    def _report_header(self, ws, row, lines, n_cols):
        for offset, line in enumerate(lines):
            for c in range(1, n_cols + 1):
                cell = ws.cell(row=row + offset, column=c)
                cell.fill = PatternFill("solid", start_color=C_HEADER_BG)
                cell.border = B_THIN
            cell = ws.cell(row=row + offset, column=1, value=line)
            sc(cell, bold=True, size=11, fg=C_HEADER_FG, bg=C_HEADER_BG, align="center")
            ws.merge_cells(
                start_row=row + offset, start_column=1,
                end_row=row + offset, end_column=n_cols
            )
        return row + len(lines)

    def _col_header_row(self, ws, row, headers):
        for ci, h in enumerate(headers, 1):
            c = ws.cell(row=row, column=ci, value=h)
            sc(c, bold=True, size=9, bg=C_SUBHEADER_BG, align="center", border=B_HTOP)
        return row + 1

    def _section_row(self, ws, row, desc, n_cols):
        SEC_BG = "FF2E5F8A"
        for c in range(1, n_cols + 1):
            cell = ws.cell(row=row, column=c)
            cell.fill = PatternFill("solid", start_color=SEC_BG)
            cell.border = B_THIN
        cell = ws.cell(row=row, column=1, value=desc)
        sc(cell, bold=True, size=10, fg=C_SECTION_FG, bg=SEC_BG, border=B_HTOP)
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=n_cols)
        return row + 1

    def _write_data_row(self, ws, row, fr, has_acct, n_vals, has_pct, alt):
        if fr.row_type == "grand":
            bg, bold, bord, sz = C_GRAND_BG, True, B_HTOP, 10
        elif fr.row_type == "total":
            bg, bold, bord, sz = C_TOTAL_BG, True, B_HTOP, 10
        else:
            bg = C_ALT_BG if alt else None
            bold, bord, sz = False, B_THIN, 9

        col = 1
        if has_acct:
            c = ws.cell(row=row, column=col, value=fr.account or "")
            sc(c, bold=bold, size=sz, bg=bg, border=bord)
            col += 1

        indent = "    " if (fr.row_type == "data" and fr.account) else ""
        c = ws.cell(row=row, column=col, value=indent + (fr.description or ""))
        sc(c, bold=bold, size=sz, bg=bg, border=bord)
        col += 1

        for vi in range(n_vals):
            val = fr.values[vi] if vi < len(fr.values) else None
            is_neg = val is not None and val < 0
            fg = C_NEGATIVE_FG if is_neg else (C_INPUT_FG if not bold else C_FORMULA_FG)
            c = ws.cell(row=row, column=col, value=val)
            sc(c, bold=bold, size=sz, bg=bg, border=bord, align="right", fg=fg, num_fmt=FMT_NUM)
            col += 1

            if has_pct:
                pval = fr.pct_values[vi] if vi < len(fr.pct_values) else None
                c = ws.cell(row=row, column=col, value=pval)
                sc(c, bold=bold, size=8, bg=bg, border=bord, align="right",
                   fg=C_FORMULA_FG, num_fmt=FMT_PCT)
                col += 1

        return row + 1

    # ── Balance Sheet ──────────────────────────────────────────────────────

    def build_balance_sheet(self):
        meta, rows = parse_balance_sheet(self.doc)
        rows = dedup_rows(rows)
        ws = self.wb.create_sheet("Balance Sheet")
        N = 4

        header = [l for l in meta if l and not re.match(r"K{3,}|^we$|\d{2}:\d{2}", l)]
        if not header:
            header = ["Balance Sheet", "MIS/Digilog"]
        r = self._report_header(ws, 1, header, N)
        r += 1
        r = self._col_header_row(ws, r, ["Account", "Description", "This Year ($)", "Last Year ($)"])

        alt = False
        for fr in rows:
            if fr.row_type == "blank":
                r += 1
                continue
            if fr.row_type == "section":
                r = self._section_row(ws, r, fr.description, N)
                alt = False
                continue
            if fr.row_type == "meta":
                if fr.description and not re.match(r"^\d", fr.description):
                    c = ws.cell(row=r, column=2, value=fr.description)
                    sc(c, italic=True, size=8, fg="FF888888")
                    r += 1
                continue
            r = self._write_data_row(ws, r, fr, has_acct=True, n_vals=2, has_pct=False, alt=alt)
            alt = not alt if fr.row_type == "data" else False

        ws.column_dimensions["A"].width = 12
        ws.column_dimensions["B"].width = 46
        ws.column_dimensions["C"].width = 18
        ws.column_dimensions["D"].width = 18
        ws.freeze_panes = "C4"
        ws.sheet_view.showGridLines = False

    # ── Income Statement ───────────────────────────────────────────────────

    def build_income_statement(self):
        rows = parse_income_statement(self.doc)
        rows = dedup_rows(rows)
        ws = self.wb.create_sheet("Income Statement")
        N = 10

        r = self._report_header(ws, 1, [
            "Income Statement - MIS/Digilog",
            "01/01/2025 thru 01/31/2025",
        ], N)
        r += 1
        r = self._col_header_row(ws, r, [
            "Account", "Description",
            "Curr. Period ($)", "CP %",
            "Year-to-Date ($)", "YTD %",
            "LY Curr. Period ($)", "LY CP %",
            "LY Year-to-Date ($)", "LY YTD %",
        ])

        alt = False
        for fr in rows:
            if fr.row_type == "blank":
                r += 1
                continue
            if fr.row_type == "section":
                r = self._section_row(ws, r, fr.description, N)
                alt = False
                continue
            if fr.row_type == "meta":
                if fr.description:
                    c = ws.cell(row=r, column=2, value=fr.description)
                    sc(c, italic=True, size=8, fg="FF888888")
                    r += 1
                continue
            r = self._write_data_row(ws, r, fr, has_acct=True, n_vals=4, has_pct=True, alt=alt)
            alt = not alt if fr.row_type == "data" else False

        for col, w in zip("ABCDEFGHIJ", [12, 40, 16, 7, 16, 7, 16, 7, 16, 7]):
            ws.column_dimensions[col].width = w
        ws.freeze_panes = "C4"
        ws.sheet_view.showGridLines = False

    # ── Raw OCR Data ───────────────────────────────────────────────────────

    def build_raw_sheet(self):
        ws = self.wb.create_sheet("Raw OCR Data")
        hdrs = ["Page", "Block ID", "Semantic Type", "Table-like", "Confidence", "Original Text"]
        for ci, h in enumerate(hdrs, 1):
            c = ws.cell(row=1, column=ci, value=h)
            sc(c, bold=True, size=9, bg=C_SUBHEADER_BG, border=B_HTOP, align="center")

        r = 2
        for page in self.doc["pages"]:
            for block in sorted(page["blocks"], key=lambda b: b.get("order", 0)):
                ws.cell(row=r, column=1).value = block.get("page_number")
                ws.cell(row=r, column=2).value = block.get("block_id")
                ws.cell(row=r, column=3).value = block.get("semantic_type")
                ws.cell(row=r, column=4).value = str(block.get("is_table_like", ""))
                ws.cell(row=r, column=5).value = round(block.get("confidence", 0), 1)
                ws.cell(row=r, column=6).value = block.get("text", "")
                for ci in range(1, 7):
                    cell = ws.cell(row=r, column=ci)
                    cell.border = B_THIN
                    cell.font = Font(name=FONT_NAME, size=9)
                    cell.alignment = Alignment(vertical="top", wrap_text=(ci == 6))
                ws.row_dimensions[r].height = 60
                r += 1

        for col, w in zip("ABCDEF", [7, 14, 14, 9, 10, 95]):
            ws.column_dimensions[col].width = w
        ws.sheet_view.showGridLines = False

    # ── Entry point ───────────────────────────────────────────────────────

    def write(self, output_path: str):
        self.build_balance_sheet()
        self.build_income_statement()
        self.build_raw_sheet()
        order = {"Balance Sheet": 0, "Income Statement": 1, "Raw OCR Data": 2}
        self.wb._sheets.sort(key=lambda s: order.get(s.title, 9))
        self.wb.save(output_path)
        info = ", ".join(f"{s.title} ({s.max_row} filas)" for s in self.wb.worksheets)
        print(f"Generado: {output_path}")
        print(f"   {info}")


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def main():
    json_path   = sys.argv[1] if len(sys.argv) > 1 else "document.json"
    output_path = sys.argv[2] if len(sys.argv) > 2 else "output/financials_sep_2025.xlsx"
    if not Path(json_path).exists():
        print(f"Archivo no encontrado: {json_path}")
        sys.exit(1)
    print(f"Procesando: {json_path}")
    with open(json_path, encoding="utf-8") as f:
        doc = json.load(f)
    writer = ExcelWriter(doc)
    writer.write(output_path)


if __name__ == "__main__":
    main()
