/** Módulo 6 · traducción
  * Responsabilidad:
 * - Inicializar el texto de la interfaz con soporte i18n (ES/EN)
 * - Gestionar el cambio dinámico de idioma (toggle ES ↔ EN)
 * - Aplicar traducciones a elementos del DOM usando atributos [i18n]
 * - Sincronizar el idioma con localStorage
 * - Actualizar etiquetas dinámicas (botones, filtros, UI interactiva)
 * - Ejecutar el bootstrap del dashboard al cargar el DOM

* Nota: i18n; internationalization (i primera letra + 18 + n ultima letra)
*/
const traducciones = { 
  "es": {
    //  Encabezados 
    header_etiqueta: "MATEMATICAS ·DESARROLLO DE SOFTWARE· EQUIPO DATA",
    titulo_principal:"Panel de proyectos",
    subtitulo: "Vista ejecutiva de portafolio · riesgo · capacidad · blockers · entregas críticas. ",
    sprint_activo: "Sprint activo",
    riesgo_medio: "Riesgo medio",
    proyectos_activos_label: "Proyectos activos",

    // Tarjetas KPI
    kpi_avance_titulo: "AVANCE GLOBAL", 
    kpi_avance_sub: "entregables completados",
    kpi_riesgo_titulo: "RIESGO ACUMULADO",
    kpi_riesgo_sub: "proyectos con riesgo alto",
    kpi_sla_titulo: "SLA VENCIDOS",
    kpi_sla_sub: "Entregables fuera de plazo",
    kpi_carga_titulo: "CARGA/CAPACIDAD",
    kpi_carga_sub:"Asignaciones",
    kpi_velocidad_titulo: "VELOCIDAD SPRINT",
    kpi_velocidad_sub: "entregas cerradas · 14 días",
    kpi_blockers_titulo: "BLOQUEOS ACTIVOS", 
    kpi_blockers_sub:"proyectos bloqueados",

    //  Paneles del medio 
    panel_distribucion: "DISTRIBUCIÓN EJECUTIVA",
    panel_carga_miembro: "CARGA POR MIEMBRO",
    panel_proximos: "PROXIMOS VENCIMIENTOS",

    // == Estados( leyenda del doonut de distribución) ==
    estado_activos: "Activos",
    estado_riesgo: "Riesgo",
    estado_entregados: "Entregados",
    estado_pausados: "Pausados",

    //  Títulos de gráficos 
    chart_radar_titulo: "RADAR DE RIESGO POR PROYECTO",
    chart_burndown_titulo: "BURNDOWN DE ENTREGABLES", 
    chart_estados_titulo: "ENTREGABLES POR ESTADO",

    // == Ejes de radar 
    eje_prioridad: "Prioridad",
    eje_severidad: "Severidad",
    eje_urgencia: "Urgencia",
    eje_dependencia: "Dependencia",
    eje_blockers: "Blockers",
    eje_progreso: "Progreso",

    //  Burndown 
    burndown_pendientes: "Pendientes",
    burndown_semana: "Sem",
    burndown_actual: "Actual",
    burndown_ideal: "Ideal",
    burndown_real: "Real",

    //  Donut de estado 
    chart_completados: "Completados",
    chart_pendientes: "Pendientes",
    chart_vencidos: "Vencidos",

    //  Sección de blockers 
    blockers_titulo: "Bloqueos activos del portafolio",
    blockers_criticos: "críticos",
    blockers_medios: "medios",
    badge_critico: "CRÍTICO", 
    badge_medio: "MEDIO",

    // Filtros 
    filtro_todos: "Todos",
    filtro_activos: "Activos",
    filtro_riesgo: "En riesgo",
    filtro_entregados: "Entregados",
    filtro_pausados: "Pausados",
    boton_nuevo: "+ Nuevo proyecto",

    // Tarjetas de proyecto 
    badge_activo: "ACTIVO",
    badge_pausado: "PAUSADO",
    badge_entregado: "ENTREGADO",
    label_notas: "notas",
    label_blockers: "blockers",
    label_mas: "más",

    // Claves de pestañas y textos dinámicos
    Ejecutivo: 'Ejecutivo',
    Avance: 'avance',
    Entregables: 'Entregables',
    Timeline: 'Timeline',
    Blockers: 'Blockers',
    Comentarios: 'Comentarios',
    SLA: 'SLA',
    Info: 'Info',
    entregables: 'entregables',
    'para deadline': 'para deadline',
    'Resumen general': 'Resumen general',
    'combinación de prioridad, severidad, urgencia, dependencias, blockers y vencimiento.': 'combinación de prioridad, severidad, urgencia, dependencias, blockers y vencimiento.',
    'Factor de riesgo': 'Factor de riesgo',
    'Prioridad negocio': 'Prioridad negocio',
    'Severidad técnica': 'Severidad técnica',
    Urgencia: 'Urgencia',
    'Dependencia crítica': 'Dependencia crítica',
    'Capacidad y bloqueo': 'Capacidad y bloqueo',
    Miembros: 'Miembros',
    Tech: 'Tech',
    Dependencias: 'Dependencias',
    gestion: 'Gestión',
    responsable: 'Responsable',
    objetivo: 'Objetivo',
    criterio: 'Criterio',
    notas: 'Notas',
    sin_notas: 'Sin notas',
    compromiso: 'Compromiso',
    real: 'Real',
    sin_definir: 'Sin definir',
    no_definido: 'No definido',
    nd: 'N/D',
    agregar_entregable: '+ Añadir entregable...',
    entregable_completado: 'Completado',
    entregable_pendiente: 'Pendiente',
    editar_proyecto: 'Editar proyecto',
    eliminar_proyecto: 'Eliminar',
    form_editar_modo: '// editar proyecto',
    form_nuevo_modo: '// nuevo proyecto',
    form_nombre: 'Nombre',
    form_nombre_placeholder: 'Nombre del proyecto',
    form_descripcion: 'Descripción',
    form_descripcion_placeholder: 'Objetivo y alcance...',
    form_estado: 'Estado',
    form_estado_activo: 'Activo',
    form_estado_riesgo: 'En riesgo',
    form_estado_entregado: 'Entregado',
    form_estado_pausado: 'Pausado',
    form_prioridad_negocio: 'Prioridad negocio',
    form_severidad_tecnica: 'Severidad técnica',
    form_urgencia: 'Urgencia',
    form_dependencia_critica: 'Dependencia crítica',
    form_fecha_entrega: 'Fecha de entrega',
    form_sla_comprometido: 'SLA comprometido',
    form_fecha_real: 'Fecha real',
    form_miembros: 'Miembros',
    form_miembros_placeholder: 'CR, ML, JP',
    form_tech_stack: 'Tech stack',
    form_tech_stack_placeholder: 'Node.js, Redis, K8s',
    form_blockers: 'Blockers (uno por línea)',
    form_blockers_placeholder: 'Bloqueador 1\nBloqueador 2',
    form_dependencias: 'Dependencias (una por línea)',
    form_dependencias_placeholder: 'Servicio A\nServicio B',
    form_entregables: 'Entregables (uno por línea)',
    form_entregables_placeholder: 'Diseño de arquitectura\nImplementación de auth\nTests de carga',
    form_cancelar: 'Cancelar',
    form_guardar_cambios: 'Guardar cambios',
    form_crear_proyecto: 'Crear proyecto',
    'Blockers activos, dependencias y señales de riesgo operativo para priorizar decisiones.': 'Blockers activos, dependencias y señales de riesgo operativo para priorizar decisiones.',
    Estado: 'Estado',
    Deadline: 'Deadline',
    'SLA comprometido': 'SLA comprometido',
    'Entrega real': 'Entrega real',
    Vencido: 'Vencido',
    'Próximo a vencer': 'Próximo a vencer',
    OK: 'OK',
    'Risk score': 'Risk score',
    Progreso: 'Progreso',

    //  Textos de pestañas de detalle 
    sin_comentarios: 'Sin comentarios aún.',
    anadir_comentario: 'Añadir comentario...',
    enviar: 'Enviar',
    sin_hitos: 'Sin hitos registrados.',
    distribucion_temporal: 'Distribución temporal de hitos',
    historial: 'Historial',
    sin_historial: 'Sin historial.',
    actividad_reciente: 'Actividad reciente',
    sin_actividad: 'Sin actividad.',
    blocker_critico_titulo: '— Blockers críticos',
    blocker_medio_titulo: '— Blockers medios',
    blocker_critico_badge: 'Crítico',
    blocker_medio_badge: 'Medio',
    blocker_dependencias: '— Dependencias externas',
    blocker_impacto_critico: 'Impacto directo en producción y entrega',
    blocker_impacto_medio: 'Impacto en velocidad y calidad',
    blocker_sin_dependencias: 'Sin dependencias.',
    blocker_ninguno: 'Ninguno.',
    sla_sin_fecha: 'sin fecha',
    sla_vencido: 'vencido',
    sla_hoy: 'hoy',
    sla_en_plazo: 'en plazo',
    sla_entregado: ' entregado',
    sla_en_curso: ' en curso',
    info_estado: 'Estado',
    info_progreso: 'Progreso',
    info_deadline: 'Deadline',
    info_alerta: 'Alerta',
    info_riesgo: 'Risk score',
    info_equipo: 'Equipo y Stack',
    info_miembros: 'Miembros',
    info_tech: 'Tech',
    info_vencido: 'Vencido',
    info_proximo: 'Próximo a vencer',
    info_ok: 'OK',

    // Estados de las tarjetas de proyecto
    estado_activo: "Activo",
    estado_pausado: "Pausado",
    estado_entregado: "Entregado",

    // Pantalla de bienvenida (Etapa 1 y 2)
    wlc_selecciona: "Selecciona tu",
    wlc_departamento: "Departamento",
    wlc_elige_sub: "Elige el departamento y el área para continuar",
    wlc_dept_label: "Departamento",
    wlc_area_label: "Área",
    wlc_graph_hint: "O navega el grafo 3D — haz clic en un nodo",
    wlc_quien: "¿Quién",
    wlc_eres_tu: "eres tú?",
    wlc_arrastra_sub: "Arrastra para girar · haz clic en tu tarjeta",
    wlc_sin_miembros: "Sin miembros asignados a esta área",
    wlc_cambiar_area: "Cambiar área",
    wlc_procesar_btn: "⚙ Procesar proyectos",

    // SLA - Calendario y heatmap 
    sla_calendario_titulo: "Calendario SLA",
  },

  en: {
    // Headers 
    header_etiqueta: "Mathematics ·Software development· DATA TEAM",
    titulo_principal:"Projects Dashboard",
    subtitulo: "Executive view of portfolio · risk · capacity · blockers · critical deliveries. ",
    sprint_activo: "Active sprint",
    riesgo_medio: "Average risk",
    proyectos_activos_label: "Active projects",
    

    // KPI Cards 
    kpi_avance_titulo: "OVERALL PROGRESS", 
    kpi_avance_sub: "deliverables completed",
    kpi_riesgo_titulo: "ACCUMULATED RISK",
    kpi_riesgo_sub: "high-risk projects",
    kpi_sla_titulo: "OVERDUE SLAS",
    kpi_sla_sub: "Deliverables pastdue",
    kpi_carga_titulo: "LOAD/CAPACITY",
    kpi_carga_sub:"Assignments",
    kpi_velocidad_titulo: "SPRINT VELOCITY",
    kpi_velocidad_sub: "closed deliverables · 14 days",
    kpi_blockers_titulo: "ACTIVE BLOCKERS", 
    kpi_blockers_sub:"blocked projects",
    
    //  Middle Panels 
    panel_distribucion: "EXECUTIVE DISTRIBUTION",
    panel_carga_miembro: "LOAD BY MEMBER",
    panel_proximos: "UPCOMING DEADLINES",

    // == States (donut legend) ==
    estado_activos: "Active",
    estado_riesgo: "Risk",
    estado_entregados: "Delivered",
    estado_pausados: "Paused",

    //  Chart Titles 
    chart_radar_titulo: "RISK RADAR BY PROJECT",
    chart_burndown_titulo: "DELIVERABLES BURNDOWN", 
    chart_estados_titulo: "DELIVERABLES BY STATUS",

    // == Radar Axes 
    eje_prioridad: "Priority",
    eje_severidad: "Severity",
    eje_urgencia: "Urgency",
    eje_dependencia: "Dependency",
    eje_blockers: "Blockers",
    eje_progreso: "Progress",

    //  Burndown 
    burndown_pendientes: "Pending",
    burndown_semana: "Wk",
    burndown_actual: "Current",
    burndown_ideal: "Ideal",
    burndown_real: "actual",

    //  Status Donut 
    chart_completados: "Completed",
    chart_pendientes: "Pending",
    chart_vencidos: "   overdue",

    //  Blockers Section 
    blockers_titulo: "Active portfolio blockers",
    blockers_criticos: "critical",
    blockers_medios: "medium",
    badge_critico: "CRITICAL", 
    badge_medio: "MEDIUM",

    // Filters 
    filtro_todos: "All",
    filtro_activos: "Active",
    filtro_riesgo: "At risk",
    filtro_entregados: "Delivered",
    filtro_pausados: "Paused",
    boton_nuevo: "+ New project",

    // Project Cards 
    badge_activo: "ACTIVE",
    badge_pausado: "PAUSED",
    badge_entregado: "DELIVERED",
    label_notas: "notes",
    label_blockers: "blockers",
    label_mas: "more",

    // información de tarjetas 
    panel_ejecutivo: "Ejecutive",
    panel_entregables: "DELIVERABLES",
    panel_timeline: "TIMELINE",
    panel_blockers: "BLOCKERS",
    panel_comentarios: "COMMENTS",
    panel_sla: "SLA",
    panel_info: "INFO",

    // Claves de pestañas y textos dinámicos
    Ejecutivo: 'Executive',
    Avance: 'Progress',
    Entregables: 'Deliverables',
    Timeline: 'Timeline',
    Blockers: 'Blockers',
    Comentarios: 'Comments',
    SLA: 'SLA',
    Info: 'Info',
    entregables: 'deliverables',
    'para deadline': 'for deadline',
    'Resumen general': 'General Summary',
    'combinación de prioridad, severidad, urgencia, dependencias, blockers y vencimiento.': 'combination of priority, severity, urgency, dependencies, blockers and deadlines.',
    'Factor de riesgo': 'Risk Factor',
    'Prioridad negocio': 'Business Priority',
    'Severidad técnica': 'Technical Severity',
    Urgencia: 'Urgency',
    'Dependencia crítica': 'Critical Dependency',
    'Capacidad y bloqueo': 'Capacity and Blocking',
    Miembros: 'Members',
    Tech: 'Tech',
    Dependencias: 'Dependencies',
    gestion: 'Management',
    responsable: 'Owner',
    objetivo: 'Objective',
    criterio: 'Criterion',
    notas: 'Notes',
    sin_notas: 'No notes',
    compromiso: 'Commitment',
    real: 'Actual',
    sin_definir: 'Undefined',
    no_definido: 'Not defined',
    nd: 'N/A',
    agregar_entregable: '+ Add deliverable...',
    entregable_completado: 'Completed',
    entregable_pendiente: 'Pending',
    editar_proyecto: 'Edit project',
    eliminar_proyecto: 'Delete',
    form_editar_modo: '// edit project',
    form_nuevo_modo: '// new project',
    form_nombre: 'Name',
    form_nombre_placeholder: 'Project name',
    form_descripcion: 'Description',
    form_descripcion_placeholder: 'Goal and scope...',
    form_estado: 'Status',
    form_estado_activo: 'Active',
    form_estado_riesgo: 'At risk',
    form_estado_entregado: 'Delivered',
    form_estado_pausado: 'Paused',
    form_prioridad_negocio: 'Business priority',
    form_severidad_tecnica: 'Technical severity',
    form_urgencia: 'Urgency',
    form_dependencia_critica: 'Critical dependency',
    form_fecha_entrega: 'Delivery date',
    form_sla_comprometido: 'Committed SLA',
    form_fecha_real: 'Actual date',
    form_miembros: 'Members',
    form_miembros_placeholder: 'CR, ML, JP',
    form_tech_stack: 'Tech stack',
    form_tech_stack_placeholder: 'Node.js, Redis, K8s',
    form_blockers: 'Blockers (one per line)',
    form_blockers_placeholder: 'Blocker 1\nBlocker 2',
    form_dependencias: 'Dependencies (one per line)',
    form_dependencias_placeholder: 'Service A\nService B',
    form_entregables: 'Deliverables (one per line)',
    form_entregables_placeholder: 'Architecture design\nAuth implementation\nLoad tests',
    form_cancelar: 'Cancel',
    form_guardar_cambios: 'Save changes',
    form_crear_proyecto: 'Create project',
    'Blockers activos, dependencias y señales de riesgo operativo para priorizar decisiones.': 'Active blockers, dependencies and operational risk signals to prioritize decisions.',
    Estado: 'Status',
    Deadline: 'Deadline',
    'SLA comprometido': 'Committed SLA',
    'Entrega real': 'Actual Delivery',
    Vencido: 'Overdue',
    'Próximo a vencer': 'About to Expire',
    OK: 'OK',
    'Risk score': 'Risk score',
    Progreso: 'Progress',
    Ninguna: 'None',

    //  Detail tab texts 
    sin_comentarios: 'No comments yet.',
    anadir_comentario: 'Add comment...',
    enviar: 'Send',
    sin_hitos: 'No milestones recorded.',
    distribucion_temporal: 'Temporal distribution of milestones',
    historial: 'History',
    sin_historial: 'No history.',
    actividad_reciente: 'Recent Activity',
    blocker_critico_titulo: '— Critical Blockers',
    blocker_medio_titulo: '— Medium Blockers',
    blocker_critico_badge: 'Critical',
    blocker_medio_badge: 'Medium',
    blocker_dependencias: '— External Dependencies',
    blocker_impacto_critico: 'Direct impact on production and delivery',
    blocker_impacto_medio: 'Impact on velocity and quality',
    blocker_sin_dependencias: 'No dependencies.',
    blocker_ninguno: 'None.',
    sla_sin_fecha: 'no date',
    sla_vencido: 'overdue',
    sla_hoy: 'today',
    sla_en_plazo: 'on schedule',
    sla_entregado: 'delivered',
    sla_en_curso: 'in progress',
    info_estado: 'Status',
    info_progreso: 'Progress',
    info_deadline: 'Deadline',
    info_alerta: 'Alert',
    info_riesgo: 'Risk score',
    info_equipo: 'Team and Stack',
    info_miembros: 'Members',
    info_tech: 'Tech',
    info_vencido: 'Overdue',
    info_proximo: 'About to Expire',
    info_ok: 'OK', 
    Progreso: 'Progress',
    Ninguna:'None',

    //  Welcome screen (Stage 1 & 2) 
    wlc_selecciona: "Select your",
    wlc_departamento: "Department",
    wlc_elige_sub: "Choose the department and area to continue",
    wlc_dept_label: "Department",
    wlc_area_label: "Area",
    wlc_graph_hint: "Or navigate the 3D graph — click a node",
    wlc_quien: "Who",
    wlc_eres_tu: "are you?",
    wlc_arrastra_sub: "Drag to rotate · click on your card",
    wlc_sin_miembros: "No members assigned to this area",
    wlc_cambiar_area: "Change area",
    wlc_procesar_btn: "⚙ Manage projects",

    //  SLA - Calendar and heatmap 
    sla_calendario_titulo: "SLA Calendar",
  },
    
  // Status of project cards
  estado_activo: "Active",
  estado_pausado: "Paused",
  estado_entregado: "Delivered",
        
};

//Función para cambiar el idioma y actualizar la interfaz
// Actualiza el texto visual del botón de idioma
function updateLangBtn(idioma) {
  document.querySelectorAll('#btn-idioma').forEach(btn => {
    btn.textContent = idioma === 'es' ? 'EN' : 'ES';
  });
}

// Aplica traducciones al DOM
function aplicarIdioma(idioma) {
  if (!idioma) idioma = localStorage.getItem('idioma') || 'es';

  // Elementos con atributo i18n
  document.querySelectorAll('[i18n]').forEach(el => {
    const clave = el.getAttribute('i18n');
    const texto = traducciones[idioma]?.[clave];
    if (texto) el.textContent = texto;
  });

  // Botones de filtro
  const map = {
    'Todos':'filtro_todos','All':'filtro_todos',
    'Activos':'filtro_activos','Active':'filtro_activos',
    'En riesgo':'filtro_riesgo','At risk':'filtro_riesgo',
    'Entregados':'filtro_entregados','Delivered':'filtro_entregados',
    'Pausados':'filtro_pausados','Paused':'filtro_pausados',
    '+ Nuevo proyecto':'boton_nuevo','+ New project':'boton_nuevo'
  };
  document.querySelectorAll('.fb').forEach(btn => {
    const t = btn.textContent.trim();
    if (map[t]) btn.textContent = traducciones[idioma][map[t]] || btn.textContent;
  });

  // Botón "Nuevo proyecto"
  const addBtn = document.querySelector('.add-btn');
  if (addBtn) {
    const t = addBtn.textContent.trim();
    if (t.includes('Nuevo') || t.includes('New')) {
      addBtn.textContent = traducciones[idioma]['boton_nuevo'];
    }
  }

  localStorage.setItem('idioma', idioma);
  updateLangBtn(idioma);
}

// Alterna entre ES ↔ EN
function cambiarIdioma() {
  const actual = localStorage.getItem('idioma') || 'es';
  const nuevo  = actual === 'es' ? 'en' : 'es';
  localStorage.setItem('idioma', nuevo);
  updateLangBtn(nuevo);
  // Re-renderizar la pantalla actual para aplicar el idioma
  if (typeof WLC !== 'undefined' && WLC.active) {
    if (typeof renderWelcome === 'function') renderWelcome();
  } else {
    if (typeof render === 'function') render();
    // También aplicar a DOM estático
    if (typeof aplicarIdioma === 'function') aplicarIdioma(nuevo);
  }
}

// Función de traducción inline
function t(clave) {
  const idioma = localStorage.getItem('idioma') || 'es';
  return traducciones[idioma]?.[clave] ?? clave;
}

// Arranque: aplicar idioma guardado
document.addEventListener('DOMContentLoaded', () => {
  const idioma = localStorage.getItem('idioma') || 'es';
  aplicarIdioma(idioma);
});
