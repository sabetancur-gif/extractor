#!/usr/bin/env python3
"""
Servidor local que sirve el dashboard Y abre el panel cuando se solicita.
Ejecutar: python server.py
Luego abrir: http://localhost:3000
"""
import subprocess, sys, threading, webbrowser
from http.server import SimpleHTTPRequestHandler, HTTPServer
from pathlib import Path

PORT = 8000
PANEL_SCRIPT = Path(__file__).parent / "panel_proyectos.py"


class Handler(SimpleHTTPRequestHandler):
    def do_POST(self):
        # El botón del dashboard llama a POST /open-panel
        if self.path == '/open-panel':
            try:
                # Abrir el panel en un proceso independiente (no bloquea el servidor)
                subprocess.Popen([sys.executable, str(PANEL_SCRIPT)],
                                 cwd=str(PANEL_SCRIPT.parent))
                self._respond(200, b'ok')
            except Exception as e:
                self._respond(500, str(e).encode())
        else:
            self._respond(404, b'not found')

    def _respond(self, code, body):
        self.send_response(code)
        self.send_header('Content-Type', 'text/plain')
        # Permite que el dashboard en localhost:3000 llame a localhost:3000/open-panel
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        # Solo loguear errores, no cada request estático
        if args and str(args[1]) not in ('200', '304'):
            super().log_message(fmt, *args)


def main():
    server = HTTPServer(('localhost', PORT), Handler)
    url = f'http://localhost:{PORT}'
    print(f'  Dashboard corriendo en {url}')
    print(f'  Panel: {PANEL_SCRIPT.name}')
    print(f'  Ctrl+C para detener\n')
    # Abrir el navegador automáticamente tras 1 segundo
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    server.serve_forever()


if __name__ == '__main__':
    main()
