# panel/main_panel.py — Ventana principal: selector de área + lista + editor
import tkinter as tk
from tkinter import messagebox, filedialog
from pathlib import Path
from panel.config import (C, DATA_DIR, listar_archivos_json, cargar_json,
                          guardar_json, generar_id_proyecto, timestamp_ahora, PROYECTO_TEMPLATE)
from panel.editor import ProyectoEditor
import copy

# PANEL PRINCIPAL

class PanelProyectos:
    r"""
    Ventana principal del panel de gestión.
    Organiza la interfaz en dos zonas:
        - IZQUIERDA: selector de área JSON + lista de proyectos + botones de acción
        - DERECHA:   ProyectoEditor (Notebook con 6 pestañas)

    Flujo de uso:
        1. Usuario selecciona un archivo JSON de área (columna izquierda)
        2. Se carga la lista de proyectos del área
        3. Usuario selecciona un proyecto → se carga en el editor
        4. Usuario edita campos y guarda → se actualiza el JSON en disco
        5. O crea un nuevo proyecto con el botón "+" y guarda
    """

    def __init__(self, root: tk.Tk):
        r"""
        Inicializa la ventana principal y construye todos los componentes UI.

        Args:
            root: Ventana raíz de tkinter.
        """
        self.root = root
        root.title("◈  Panel de Proyectos - Data Team Dashboard  v4.0")
        root.geometry("1440x860")
        root.minsize(1100, 700)
        root.configure(bg=C["bg"])

        # Estado interno del panel
        self.archivo_actual: Path | None = None   # Archivo JSON abierto
        self.proyectos: list              = []     # Lista de proyectos en memoria
        self.idx_sel:   int  | None       = None   # Índice del proyecto seleccionado
        self.modo_nuevo: bool             = False  # True = creando nuevo proyecto

        # Construir la interfaz
        self._build_header()
        self._build_body()
        self._build_status_bar()

        # Cargar lista inicial de archivos JSON
        self._refresh_archivos()

    # Layout principal

    def _build_header(self):
        r"""Construye la barra de título superior con nombre, versión e instrucción."""
        hdr = tk.Frame(self.root, bg=C["bg2"], height=52)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Frame(self.root, bg=C["border"], height=1).pack(fill="x")

        tk.Label(
            hdr, text="◈  PANEL DE GESTIÓN DE PROYECTOS",
            font=(C["mono"], 14, "bold"),
            bg=C["bg2"], fg=C["orange"]
        ).pack(side="left", padx=18, pady=10)

        tk.Label(
            hdr, text="Data Team Dashboard · v4.0  |  Selecciona un área para comenzar",
            font=(C["mono"], 9),
            bg=C["bg2"], fg=C["soft"]
        ).pack(side="right", padx=18)

    def _build_body(self):
        r"""Construye el cuerpo principal: columna izquierda + columna derecha."""
        body = tk.Frame(self.root, bg=C["bg"])
        body.pack(fill="both", expand=True, padx=10, pady=10)

        # Columna izquierda (fija, 270px)
        left = tk.Frame(body, bg=C["border"], width=300)
        left.pack(side="left", fill="y", padx=(0, 8))
        left.pack_propagate(False)

        left_inner = tk.Frame(left, bg=C["card"])
        left_inner.pack(fill="both", expand=True, padx=1, pady=1)

        self._build_col_archivos(left_inner)
        self._build_col_proyectos(left_inner)

        # Columna derecha (flexible)
        right = tk.Frame(body, bg=C["border"])
        right.pack(side="left", fill="both", expand=True)

        right_inner = tk.Frame(right, bg=C["card"])
        right_inner.pack(fill="both", expand=True, padx=1, pady=1)

        self._editor = ProyectoEditor(right_inner)
        self._editor.pack(fill="both", expand=True)

        # Conectar callbacks del editor al panel
        self._editor.on_save_callback   = self._guardar_proyecto
        self._editor.on_cancel_callback = self._cancelar_edicion

    def _build_status_bar(self):
        """Construye la barra de estado inferior con mensajes del sistema."""
        tk.Frame(self.root, bg=C["border"], height=1).pack(fill="x")
        bar = tk.Frame(self.root, bg=C["bg2"], height=26)
        bar.pack(fill="x")
        bar.pack_propagate(False)

        self._status_var = tk.StringVar(value="  Listo. Selecciona un archivo JSON para comenzar.")
        tk.Label(bar, textvariable=self._status_var,
                 font=(C["mono"], 8), bg=C["bg2"], fg=C["muted"],
                 anchor="w").pack(fill="x", padx=14, pady=4)

    # Columna: selector de archivos JSON

    def _build_col_archivos(self, parent):
        r"""
        Construye la sección superior de la columna izquierda:
        título, listbox de archivos JSON disponibles en DATA_DIR,
        y botón para abrir archivo externo.
        """
        # Título de sección
        hdr = tk.Frame(parent, bg=C["card2"])
        hdr.pack(fill="x")
        tk.Label(hdr, text="📁  ÁREAS (JSON)",
                 font=(C["mono"], 9, "bold"),
                 bg=C["card2"], fg=C["accent"],
                 anchor="w", pady=6, padx=10).pack(fill="x")
        tk.Frame(parent, bg=C["border"], height=1).pack(fill="x")

        # Listbox + Scrollbar de archivos
        frame = tk.Frame(parent, bg=C["card"])
        frame.pack(fill="x", padx=6, pady=6)

        sb = tk.Scrollbar(frame, bg=C["bg2"], troughcolor=C["bg"])
        sb.pack(side="right", fill="y")

        self._lb_archivos = tk.Listbox(
            frame, bg=C["bg3"], fg=C["text"],
            selectbackground=C["orange"], selectforeground=C["bg"],
            font=(C["mono"], 9), bd=0, highlightthickness=0,
            activestyle="none", height=6, yscrollcommand=sb.set
        )
        self._lb_archivos.pack(side="left", fill="x", expand=True)
        sb.configure(command=self._lb_archivos.yview)
        self._lb_archivos.bind("<<ListboxSelect>>", self._on_archivo_select)

        # Botón abrir archivo externo
        self._mkbtn_small(parent, "＋ Abrir otro JSON",
                           C["muted"], self._abrir_json_externo).pack(fill="x", padx=6, pady=(0, 6))

    def _build_col_proyectos(self, parent):
        """
        Construye la sección inferior de la columna izquierda:
        título, listbox de proyectos del área seleccionada,
        y botones Nuevo + Eliminar.
        """
        tk.Frame(parent, bg=C["border"], height=1).pack(fill="x")
        hdr = tk.Frame(parent, bg=C["card2"])
        hdr.pack(fill="x")
        tk.Label(hdr, text="📋  PROYECTOS",
                 font=(C["mono"], 9, "bold"),
                 bg=C["card2"], fg=C["accent"],
                 anchor="w", pady=6, padx=10).pack(fill="x")
        tk.Frame(parent, bg=C["border"], height=1).pack(fill="x")

        # Listbox + Scrollbar de proyectos
        frame = tk.Frame(parent, bg=C["card"])
        frame.pack(fill="both", expand=True, padx=6, pady=6)

        sb = tk.Scrollbar(frame, bg=C["bg2"], troughcolor=C["bg"])
        sb.pack(side="right", fill="y")

        self._lb_proyectos = tk.Listbox(
            frame, bg=C["bg3"], fg=C["text"],
            selectbackground=C["accent"], selectforeground=C["bg"],
            font=(C["mono"], 10),   # ← fuente ligeramente más grande
            bd=0, highlightthickness=0,
            activestyle="none", yscrollcommand=sb.set
        )
        self._lb_proyectos.pack(side="left", fill="both", expand=True)
        sb.configure(command=self._lb_proyectos.yview)
        self._lb_proyectos.bind("<<ListboxSelect>>", self._on_proyecto_select)

        # Botones de acción sobre proyectos
        btn_frame = tk.Frame(parent, bg=C["card"])
        btn_frame.pack(fill="x", padx=6, pady=(0, 8))

        self._mkbtn_small(btn_frame, "＋ Nuevo proyecto",
                           C["green"], self._nuevo_proyecto).pack(fill="x", pady=(0, 4))
        self._mkbtn_small(btn_frame, "🗑  Eliminar seleccionado",
                           C["red"], self._eliminar_proyecto).pack(fill="x")

    # ── Lógica de archivos ────────────────────────────────────────────────────

    def _refresh_archivos(self):
        """
        Recarga el listbox de archivos JSON con los archivos disponibles en DATA_DIR.
        Llama a listar_archivos_json() para obtener las rutas actualizadas.
        """
        self._lb_archivos.delete(0, tk.END)
        self._archivos_list = listar_archivos_json()
        if not self._archivos_list:
            self._lb_archivos.insert(tk.END, "  (sin archivos en assets/data/)")
        for p in self._archivos_list:
            self._lb_archivos.insert(tk.END, f"  {p.stem}")

    def _on_archivo_select(self, _event=None):
        """
        Callback: el usuario seleccionó un archivo de área en el listbox.
        Carga el JSON correspondiente y refresca la lista de proyectos.
        """
        sel = self._lb_archivos.curselection()
        if not sel or sel[0] >= len(self._archivos_list):
            return
        self.archivo_actual = self._archivos_list[sel[0]]
        try:
            self.proyectos = cargar_json(self.archivo_actual)
        except Exception as ex:
            messagebox.showerror("Error al cargar JSON", str(ex))
            return
        self.idx_sel  = None
        self.modo_nuevo = False
        self._refresh_proyectos()
        self._editor.clear()
        self._status(f"Área: {self.archivo_actual.stem} - {len(self.proyectos)} proyecto(s)")

    def _abrir_json_externo(self):
        """
        Abre un selector de archivos del sistema para cargar un JSON externo.
        Útil para gestionar archivos fuera de assets/data/.
        """
        path = filedialog.askopenfilename(
            title="Seleccionar archivo JSON de proyectos",
            filetypes=[("JSON", "*.json"), ("Todos", "*.*")],
            initialdir=str(DATA_DIR) if DATA_DIR.exists() else "."
        )
        if not path:
            return
        self.archivo_actual = Path(path)
        try:
            self.proyectos = cargar_json(self.archivo_actual)
        except Exception as ex:
            messagebox.showerror("Error al cargar JSON", str(ex))
            return
        self._refresh_proyectos()
        self._editor.clear()
        self._status(f"Archivo externo: {self.archivo_actual.name} - {len(self.proyectos)} proyecto(s)")

    # ── Lógica de proyectos ────────────────────────────────────────────────────

    def _refresh_proyectos(self):
        """
        Recarga el listbox de proyectos con los datos de self.proyectos.
        Cada ítem muestra el badge de estado, ID y nombre truncado.
        """
        self._lb_proyectos.delete(0, tk.END)
        BADGE = {"active": "●", "risk": "⚠", "delivered": "✔", "paused": "⏸"}
        for p in self.proyectos:
            pid   = p.get("id", "?")
            name  = p.get("name", "(sin nombre)")[:30]
            badge = BADGE.get(p.get("status", ""), "·")
            self._lb_proyectos.insert(tk.END, f"  {badge} [{pid}] {name}")

    def _on_proyecto_select(self, _event=None):
        """
        Callback: el usuario seleccionó un proyecto en el listbox.
        Carga el proyecto seleccionado en el editor.
        """
        sel = self._lb_proyectos.curselection()
        if not sel or sel[0] >= len(self.proyectos):
            return
        self.idx_sel    = sel[0]
        self.modo_nuevo = False
        p = self.proyectos[self.idx_sel]
        self._editor.load_project(p)
        self._status(f"Editando: [{p.get('id')}] {p.get('name', '')[:50]}")

    def _nuevo_proyecto(self):
        """
        Prepara el editor para crear un proyecto nuevo.
        Limpia todos los campos y asigna un ID tentativo (confirmado al guardar).
        """
        if self.archivo_actual is None:
            messagebox.showwarning("Sin área", "Selecciona primero un archivo JSON de área.")
            return
        self.modo_nuevo = True
        self.idx_sel    = None
        self._lb_proyectos.selection_clear(0, tk.END)

        # Crear una plantilla con ID tentativo
        plantilla = copy.deepcopy(PROYECTO_TEMPLATE)
        plantilla["id"] = generar_id_proyecto(self.proyectos)
        self._editor.load_project(plantilla)
        self._status(f"Nuevo proyecto - ID tentativo: {plantilla['id']} (se confirma al guardar)")

    def _eliminar_proyecto(self):
        """
        Elimina el proyecto seleccionado tras confirmación del usuario.
        Guarda el archivo JSON inmediatamente tras la eliminación.
        """
        if self.idx_sel is None:
            messagebox.showwarning("Nada seleccionado", "Selecciona un proyecto para eliminar.")
            return
        p = self.proyectos[self.idx_sel]
        pid, nombre = p.get("id", "?"), p.get("name", "(sin nombre)")

        if not messagebox.askyesno("Confirmar eliminación",
                                   f"¿Eliminar permanentemente?\n\n[{pid}] {nombre}"):
            return

        self.proyectos.pop(self.idx_sel)
        guardar_json(self.archivo_actual, self.proyectos)
        self.idx_sel    = None
        self.modo_nuevo = False
        self._refresh_proyectos()
        self._editor.clear()
        self._status(f"Proyecto [{pid}] eliminado y guardado en {self.archivo_actual.name}")

    def _guardar_proyecto(self, datos: dict):
        """
        Recibe el diccionario del editor, asigna/confirma el ID, actualiza
        la lista en memoria y guarda el archivo JSON en disco.
        También registra una entrada en el historial del proyecto.

        Args:
            datos: Diccionario con todos los campos del proyecto obtenido de get_project().
        """
        # Registrar en historial la acción de guardar
        entrada_historial = {
            "date":   timestamp_ahora(),
            "author": "PANEL",
            "action": "Proyecto creado desde el panel." if self.modo_nuevo else "Proyecto actualizado desde el panel.",
            "detail": "",
        }
        datos.setdefault("history", []).append(entrada_historial)

        if self.modo_nuevo:
            # Confirmar el ID final (puede haber cambiado si se crearon otros proyectos)
            datos["id"] = generar_id_proyecto(self.proyectos)
            self.proyectos.append(datos)
            pid = datos["id"]
        else:
            if self.idx_sel is None or self.idx_sel >= len(self.proyectos):
                messagebox.showerror("Error", "No hay proyecto seleccionado para actualizar.")
                return
            # Preservar el ID original (no permitir que el usuario lo cambie)
            datos["id"] = self.proyectos[self.idx_sel]["id"]
            self.proyectos[self.idx_sel] = datos
            pid = datos["id"]

        # Guardar en disco
        guardar_json(self.archivo_actual, self.proyectos)

        # Actualizar lista y UI
        self.modo_nuevo = False
        self._refresh_proyectos()

        # Mantener la selección en el proyecto recién guardado
        for i, p in enumerate(self.proyectos):
            if p.get("id") == pid:
                self._lb_proyectos.selection_clear(0, tk.END)
                self._lb_proyectos.selection_set(i)
                self._lb_proyectos.see(i)
                self.idx_sel = i
                break

        self._status(f"✔  [{pid}] guardado correctamente en {self.archivo_actual.name}")
        messagebox.showinfo("Guardado", f"Proyecto [{pid}] guardado exitosamente.")

    def _cancelar_edicion(self):
        """
        Cancela la edición actual: limpia el editor y deselecciona la lista.
        """
        self.idx_sel    = None
        self.modo_nuevo = False
        self._lb_proyectos.selection_clear(0, tk.END)
        self._editor.clear()
        self._status("Edición cancelada.")

    # ── Utilidades UI ──────────────────────────────────────────────────────────

    def _mkbtn_small(self, parent, text: str, fg: str, command) -> tk.Button:
        """
        Crea un botón pequeño para las acciones de la columna izquierda.

        Args:
            parent:  Widget padre.
            text:    Texto del botón.
            fg:      Color del texto.
            command: Función a ejecutar al hacer clic.

        Returns:
            tk.Button configurado.
        """
        btn = tk.Button(
            parent, text=text, command=command,
            font=(C["mono"], 8), bg=C["bg3"], fg=fg,
            activebackground=C["border2"], activeforeground=fg,
            relief="flat", bd=0, cursor="hand2",
            padx=8, pady=5
        )
        btn.bind("<Enter>", lambda e: btn.config(bg=C["border"]))
        btn.bind("<Leave>", lambda e: btn.config(bg=C["bg3"]))
        return btn

    def _status(self, msg: str):
        """Actualiza el mensaje de la barra de estado inferior."""
        self._status_var.set(f"  {msg}")
