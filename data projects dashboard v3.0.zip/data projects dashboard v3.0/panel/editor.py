# panel/editor.py — Editor de proyectos con Notebook de 6 pestañas
import copy
import tkinter as tk
from tkinter import ttk, messagebox
from panel.config import C, STATUS_OPTS, IDIOM_OPTS, lista_desde_csv, DONE_OPTS, PROYECTO_TEMPLATE, generar_id_entregable, SEVERITY_OPTS
from panel.widgets import PlaceholderEntry, DynamicRowManager

# EDITOR DE PROYECTOS (Notebook con 6 pestañas)

class ProyectoEditor(tk.Frame):
    r"""
    Panel derecho del panel principal. Contiene un ttk.Notebook con 6 pestañas
    que permiten editar todos los campos de un proyecto JSON completo.

    Pestañas:
        1. General     - id, idiom, name, description, status, prioridades, fechas
        2. Equipo      - assignees, tech, dependencies (campos CSV + texto)
        3. Blockers    - lista dinámica de {text, severity}
        4. Timeline    - lista dinámica de {date, title, desc}
        5. Entregables - lista dinámica completa de deliverables
        6. Historia    - history, recentActivity, comments (listas dinámicas)
    """

    def __init__(self, parent, **kwargs):
        r"""
        Construye el Notebook y todas sus pestañas.
        Inicialmente vacío; llamar a load_project() para cargar datos.

        Args:
            parent: Widget padre (normalmente el panel principal).
        """
        super().__init__(parent, bg=C["card"], **kwargs)
        self._build_notebook()
        self._build_action_bar()

    # ── Construcción del Notebook ────────────────────────────────────────────

    def _build_notebook(self):
        """Crea el ttk.Notebook y construye cada pestaña."""

        # Estilo del Notebook (fondo oscuro, pestañas con acento naranja)
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "Dark.TNotebook",
            background=C["card"], borderwidth=0, tabmargins=[0,0,0,0]
        )
        style.configure(
            "Dark.TNotebook.Tab",
            background=C["bg2"], foreground=C["muted"],
            font=(C["mono"], 9), padding=[10, 6],
            borderwidth=0
        )
        style.map(
            "Dark.TNotebook.Tab",
            background=[("selected", C["card2"])],
            foreground=[("selected", C["orange"])],
            expand=[("selected", [0, 0, 0, 0])]
        )

        self._nb = ttk.Notebook(self, style="Dark.TNotebook")
        self._nb.pack(fill="both", expand=True, padx=0, pady=0)

        # Crear las 6 pestañas
        self._tab_general     = self._make_tab("🗂 General")
        self._tab_equipo      = self._make_tab("👥 Equipo")
        self._tab_blockers    = self._make_tab("🚧 Blockers")
        self._tab_timeline    = self._make_tab("📅 Timeline")
        self._tab_entregables = self._make_tab("📦 Entregables")
        self._tab_historia    = self._make_tab("📋 Historia")

        # Poblar cada pestaña con sus widgets
        self._build_tab_general()
        self._build_tab_equipo()
        self._build_tab_blockers()
        self._build_tab_timeline()
        self._build_tab_entregables()
        self._build_tab_historia()

    def _make_tab(self, title: str) -> tk.Frame:
        r"""
        Crea un Frame scrollable para una pestaña del Notebook.
        El Frame exterior tiene Canvas + Scrollbar para soportar contenido largo.

        Args:
            title: Texto de la pestaña.

        Returns:
            tk.Frame interior (donde se colocan los widgets de la pestaña).
        """
        outer = tk.Frame(self._nb, bg=C["card"])
        self._nb.add(outer, text=title)

        canvas = tk.Canvas(outer, bg=C["card"], bd=0, highlightthickness=0)
        sb = tk.Scrollbar(
            outer, orient="vertical", command=canvas.yview,
            bg=C["bg2"], troughcolor=C["bg"]
        )
        sb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        canvas.configure(yscrollcommand=sb.set)

        inner = tk.Frame(canvas, bg=C["card"])
        win = canvas.create_window((0, 0), window=inner, anchor="nw")

        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(win, width=e.width))
        canvas.bind_all("<MouseWheel>",
            lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

        return inner  # El usuario pone sus widgets en este frame

    def _build_tab_general(self):
        r"""
        Pestaña 1: Campos principales del proyecto.
        Incluye: id (readonly), idiom, name, description, status,
        businessPriority, technicalSeverity, urgency, dependencyCriticality,
        deadline, committedAt, actualAt.
        """
        f = self._tab_general
        self._g = {}  # Diccionario de widgets de General

        # Grupo: Identificación
        self._section_label(f, "IDENTIFICACIÓN")
        self._g["id"] = self._labeled_entry(
            f,
            "ID del proyecto",
            "(auto-generado al guardar)",
            readonly=True
        )
        self._g["idiom"] = self._labeled_combo(f, "Idioma",             IDIOM_OPTS,
                                                tip="Idioma principal del proyecto (En=inglés, Es=español)")
        self._g["name"]  = self._labeled_entry(f, "Nombre del proyecto",
                                                "Ej: Sistema OCR con LLM - nombre claro y descriptivo")
        self._g["description"] = self._labeled_text(
            f, "Descripción",
            "Descripción detallada del objetivo y alcance del proyecto...",
            height=4
        )
        # Grupo: Estado y Priorización
        self._section_label(f, "ESTADO Y PRIORIZACIÓN")
        self._g["status"] = self._labeled_combo(
            f, "Estado", STATUS_OPTS,
            tip="active | risk | delivered | paused"
        )
        self._g["businessPriority"]     = self._labeled_spin(
            f, "Prioridad de negocio (1-5)",
            "1=muy baja, 3=media, 5=crítica para el negocio")
        self._g["technicalSeverity"]    = self._labeled_spin(
            f, "Severidad técnica (1-5)",
            "1=simple, 5=complejidad técnica extrema"
        )
        self._g["urgency"]              = self._labeled_spin(
            f, "Urgencia (1-5)",
            "1=puede esperar, 5=bloqueante e inmediato"
        )
        self._g["dependencyCriticality"]= self._labeled_spin(
            f, "Criticidad de dependencias (1-5)",
            "1=sin dependencias, 5=muchas dependencias críticas"
        )
        # Grupo: Fechas
        self._section_label(f, "FECHAS")
        self._g["deadline"]    = self._labeled_entry(
            f, "Deadline",
            "YYYY-MM-DD  - fecha límite comprometida con el cliente"
        )
        self._g["committedAt"] = self._labeled_entry(
            f, "Fecha comprometida",
            "YYYY-MM-DD  - cuando se comprometió la entrega internamente"
        )
        self._g["actualAt"]    = self._labeled_entry(
            f, "Fecha real de entrega",
            "YYYY-MM-DD  - dejar vacío si aún no se ha entregado"
        )

    def _build_tab_equipo(self):
        r"""
        Pestaña 2: Personas involucradas, tecnologías y dependencias externas.
        assignees y tech son listas CSV (separadas por coma).
        dependencies es una lista separada por saltos de línea.
        """
        f = self._tab_equipo
        self._e = {}

        self._section_label(f, "PERSONAS")
        self._e["assignees"] = self._labeled_entry(
            f, "Asignados (CSV)", "Ej: SB, FQ, YS  - iniciales separadas por coma"
        )
        self._section_label(f, "TECNOLOGÍA")
        self._e["tech"] = self._labeled_entry(
            f, "Tech stack (CSV)", "Ej: Python, HTML, CSS, YAML, d3.js"
        )
        self._section_label(f, "DEPENDENCIAS EXTERNAS")
        self._e["dependencies"] = self._labeled_text(
            f, "Dependencias (una por línea)", "Poppler\nTesseract\nOllama\n...", height=5)

    def _build_tab_blockers(self):
        r"""
        Pestaña 3: Lista dinámica de bloqueantes del proyecto.
        Cada blocker tiene: text (descripción) y severity (crit/med/low).
        """
        f = self._tab_blockers

        # Leyenda de uso
        info = tk.Label(f, text="Cada fila es un bloqueo activo del proyecto. severity: crit=crítico, med=medio, low=bajo",
                        font=(C["mono"], 8), bg=C["card"], fg=C["soft"],
                        wraplength=500, justify="left", anchor="w")
        info.pack(fill="x", padx=10, pady=(8, 2))

        self._mgr_blockers = DynamicRowManager(
            f,
            field_defs=[
                ("text",     "Descripción del bloqueo",  "text",  "Ej: Falta acceso a la API de producción"),
                ("severity", "Severidad",                 "combo", SEVERITY_OPTS),
            ],
            section_title="BLOQUEANTES",
        )
        self._mgr_blockers.pack(fill="both", expand=True)

    def _build_tab_timeline(self):
        r"""
        Pestaña 4: Hitos y fechas del proyecto en orden cronológico.
        Cada evento tiene: date, title, desc.
        """
        f = self._tab_timeline

        info = tk.Label(f, text="Hitos del proyecto en orden cronológico. Cada fila = un evento o entrega relevante.",
                        font=(C["mono"], 8), bg=C["card"], fg=C["soft"],
                        wraplength=500, justify="left", anchor="w")
        info.pack(fill="x", padx=10, pady=(8, 2))

        self._mgr_timeline = DynamicRowManager(
            f,
            field_defs=[
                ("date",  "Fecha",   "entry", "YYYY-MM-DD"),
                ("title", "Título",  "entry", "Ej: Entrega v1.0 - nombre corto del hito"),
                ("desc",  "Detalle", "text",  "Descripción de lo logrado o el contexto del hito..."),
            ],
            section_title="HITOS DEL PROYECTO",
        )
        self._mgr_timeline.pack(fill="both", expand=True)

    def _build_tab_entregables(self):
        r"""
        Pestaña 5: Lista completa de entregables (deliverables).
        Cada entregable tiene todos sus campos: id (auto), text, done, owner,
        sla, committed, actual, goal, criteria, notes.
        El ID se genera automáticamente con el patrón dN.
        """
        f = self._tab_entregables

        info = tk.Label(f,
            text="Cada fila = un entregable. El ID (d1, d2, …) se genera automáticamente. "
                "done: true si está completado. sla/committed/actual = fechas YYYY-MM-DD.",
            font=(C["mono"], 8), bg=C["card"], fg=C["soft"],
            wraplength=500, justify="left", anchor="w")
        info.pack(fill="x", padx=10, pady=(8, 2))

        self._mgr_deliverables = DynamicRowManager(
            f,
            field_defs=[
                ("id",        "ID (auto)",       "readonly", "(auto)"),
                ("text",      "Descripción",     "text",     "Ej: Implementar módulo de extracción OCR"),
                ("done",      "¿Completado?",    "check",    DONE_OPTS),
                ("owner",     "Responsable",     "entry",    "Iniciales  Ej: SB"),
                ("sla",       "SLA (fecha)",     "entry",    "YYYY-MM-DD - fecha límite del entregable"),
                ("committed", "Comprometido",    "entry",    "YYYY-MM-DD - fecha de compromiso interno"),
                ("actual",    "Entrega real",    "entry",    "YYYY-MM-DD - dejar vacío si pendiente"),
                ("goal",      "Objetivo",        "text",     "¿Qué se quiere lograr con este entregable?"),
                ("criteria",  "Criterio de éxito","text",    "¿Cómo se valida que está completo?"),
                ("notes",     "Notas",           "text",     "Observaciones adicionales, dependencias internas..."),
            ],
            id_generator=generar_id_entregable,  # Genera d1, d2, d3, …
            id_field="id",
            section_title="ENTREGABLES",
        )
        self._mgr_deliverables.pack(fill="both", expand=True)

    def _build_tab_historia(self):
        r"""
        Pestaña 6: Registros históricos, actividad reciente y comentarios.
        Tres sub-secciones con gestores dinámicos independientes:
            - history:        Entradas formales de historial {date, author, action, detail}
            - recentActivity: Actividad informal {author, date, text}
            - comments:       Comentarios del equipo {author, date, text}
        """
        f = self._tab_historia

        # Historial formal
        info1 = tk.Label(
            f, text="HISTORIAL FORMAL - Cambios de estado, entregas y decisiones importantes.",
            font=(C["mono"], 8, "bold"), bg=C["card"], fg=C["muted"], anchor="w"
        )
        info1.pack(fill="x", padx=10, pady=(8, 1))

        self._mgr_history = DynamicRowManager(
            f,
            field_defs=[
                ("date",   "Fecha",   "entry", "YYYY-MM-DD HH:MM"),
                ("author", "Autor",   "entry", "Iniciales  Ej: SB"),
                ("action", "Acción",  "text",  "Descripción del cambio o acción realizada"),
                ("detail", "Detalle", "entry", "URL, referencia o nota adicional (opcional)"),
            ],
            section_title="HISTORIAL FORMAL",  # Sin título propio; ya tiene el Label arriba
        )
        self._mgr_history.pack(fill="x")

        tk.Frame(f, bg=C["border"], height=1).pack(fill="x", padx=10, pady=6)

        # Actividad reciente
        info2 = tk.Label(
            f, text="ACTIVIDAD RECIENTE - Entradas informales de log de trabajo diario.",
            font=(C["mono"], 8, "bold"), bg=C["card"], fg=C["muted"], anchor="w"
        )
        info2.pack(fill="x", padx=10, pady=(4, 1))

        self._mgr_activity = DynamicRowManager(
            f,
            field_defs=[
                ("author", "Autor",  "entry", "Iniciales  Ej: YS"),
                ("date",   "Fecha",  "entry", "YYYY-MM-DD HH:MM"),
                ("text",   "Texto",  "text",  "Descripción de la actividad realizada en este período"),
            ],
            section_title="ACTIVIDAD RECIENTE",
        )
        self._mgr_activity.pack(fill="x")

        tk.Frame(f, bg=C["border"], height=1).pack(fill="x", padx=10, pady=6)

        # Comentarios
        info3 = tk.Label(
            f, text="COMENTARIOS - Notas del equipo, sugerencias o pendientes no formales.",
            font=(C["mono"], 8, "bold"), bg=C["card"], fg=C["muted"], anchor="w"
        )
        info3.pack(fill="x", padx=10, pady=(4, 1))

        self._mgr_comments = DynamicRowManager(
            f,
            field_defs=[
                ("author", "Autor", "entry", "Iniciales  Ej: FQ"),
                ("date",   "Fecha", "entry", "YYYY-MM-DD o 'Apr 22'"),
                ("text",   "Texto", "text",  "Comentario o sugerencia del equipo..."),
            ],
            section_title="COMENTARIOS",
        )
        self._mgr_comments.pack(fill="x")

    # Barra de botones (Guardar / Cancelar)

    def _build_action_bar(self):
        r"""Construye la barra inferior con los botones de acción del editor."""
        bar = tk.Frame(self, bg=C["bg2"], height=44)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)

        # Botón Guardar
        self._btn_save = self._mkbtn(
            bar, "💾  Guardar cambios",
            fg=C["orange"], command=self._on_save
        )
        self._btn_save.pack(side="left", padx=(14, 8), pady=8)

        # Botón Cancelar
        self._btn_cancel = self._mkbtn(bar, "✕  Cancelar",
                                        fg=C["soft"], command=self._on_cancel)
        self._btn_cancel.pack(side="left", pady=8)

        # Callback externo: se asigna desde PanelProyectos
        self.on_save_callback   = None  # function(proyecto_dict) → None
        self.on_cancel_callback = None  # function() → None

    # API pública del editor

    def load_project(self, p: dict):
        r"""
        Carga un diccionario de proyecto en todos los campos del editor.
        Limpia primero los valores anteriores antes de cargar los nuevos.
        Es el punto de entrada único para mostrar un proyecto en edición.

        Args:
            p: Diccionario del proyecto con todos sus campos.
        """
        # Pestaña General
        g = self._g
        self._set_entry(g["id"],    p.get("id", ""))
        self._set_combo(g["idiom"], p.get("idiom", "En"))
        self._set_entry(g["name"],  p.get("name",  ""))
        self._set_text( g["description"], p.get("description", ""))
        self._set_combo(g["status"], p.get("status", "active"))
        self._set_spin(g["businessPriority"],      p.get("businessPriority", 3))
        self._set_spin(g["technicalSeverity"],     p.get("technicalSeverity", 3))
        self._set_spin(g["urgency"],               p.get("urgency", 3))
        self._set_spin(g["dependencyCriticality"], p.get("dependencyCriticality", 3))
        self._set_entry(g["deadline"],    p.get("deadline", ""))
        self._set_entry(g["committedAt"], p.get("committedAt", ""))
        self._set_entry(g["actualAt"],    p.get("actualAt", ""))

        # Pestaña Equipo
        e = self._e
        self._set_entry(e["assignees"],   ", ".join(p.get("assignees", []) or []))
        self._set_entry(e["tech"],        ", ".join(p.get("tech", []) or []))
        self._set_text( e["dependencies"],"\n".join(p.get("dependencies", []) or []))

        # Pestañas con gestores dinámicos
        self._mgr_blockers.load_data(     p.get("blockers", []))
        self._mgr_timeline.load_data(     p.get("timeline", []))
        self._mgr_deliverables.load_data( p.get("deliverables", []))
        self._mgr_history.load_data(      p.get("history", []))
        self._mgr_activity.load_data(     p.get("recentActivity", []))
        self._mgr_comments.load_data(     p.get("comments", []))

        # Ir a la primera pestaña al cargar
        self._nb.select(0)

    def get_project(self) -> dict:
        r"""
        Lee todos los campos del editor y retorna un diccionario de proyecto completo.
        Los valores numéricos (prioridades) se convierten a int.
        Los campos CSV (assignees, tech) se parsean a listas.
        Las secciones dinámicas se obtienen mediante get_data() de cada gestor.

        Returns:
            dict: Proyecto completo listo para serializar a JSON.
        """
        g = self._g
        e = self._e
        return {
            # Identificación
            "id":    self._get_entry(g["id"]),
            "idiom": self._get_combo(g["idiom"]),
            "name":  self._get_entry(g["name"]),
            "description": self._get_text(g["description"]),
            # Estado
            "status":               self._get_combo(g["status"]),
            "businessPriority":     int(g["businessPriority"].get()),
            "technicalSeverity":    int(g["technicalSeverity"].get()),
            "urgency":              int(g["urgency"].get()),
            "dependencyCriticality":int(g["dependencyCriticality"].get()),
            # Fechas
            "deadline":    self._get_entry(g["deadline"]),
            "committedAt": self._get_entry(g["committedAt"]),
            "actualAt":    self._get_entry(g["actualAt"]),
            # Equipo
            "assignees":    lista_desde_csv(self._get_entry(e["assignees"])),
            "tech":         lista_desde_csv(self._get_entry(e["tech"])),
            "dependencies": [x for x in self._get_text(e["dependencies"]).splitlines() if x.strip()],
            # Secciones dinámicas
            "blockers":      self._mgr_blockers.get_data(),
            "timeline":      self._mgr_timeline.get_data(),
            "deliverables":  self._mgr_deliverables.get_data(),
            "history":       self._mgr_history.get_data(),
            "recentActivity":self._mgr_activity.get_data(),
            "comments":      self._mgr_comments.get_data(),
        }

    def clear(self):
        r"""
        Limpia todos los campos del editor a sus valores vacíos/default.
        Usado al cancelar la edición o al preparar el formulario para un nuevo proyecto.
        """
        self.load_project(copy.deepcopy(PROYECTO_TEMPLATE))

    # Callbacks de los botones

    def _on_save(self):
        """Valida los campos mínimos y llama al callback on_save_callback."""
        p = self.get_project()
        if not p.get("name", "").strip():
            messagebox.showerror(
                "Campo requerido",
                "El campo 'Nombre del proyecto' es obligatorio."
            )
            self._nb.select(0)  # Navegar a la pestaña General donde está el campo
            return
        if self.on_save_callback:
            self.on_save_callback(p)

    def _on_cancel(self):
        """Llama al callback on_cancel_callback si está definido."""
        if self.on_cancel_callback:
            self.on_cancel_callback()

    # Helpers de widgets

    def _section_label(self, parent, text: str):
        """Crea una etiqueta de sección con separador visual en la pestaña."""
        frame = tk.Frame(parent, bg=C["card"])
        frame.pack(fill="x", padx=10, pady=(10, 2))
        tk.Label(
            frame, text=text, font=(C["mono"], 8, "bold"),
            bg=C["card"], fg=C["orange"], anchor="w"
        ).pack(side="left")
        tk.Frame(
                frame, bg=C["border"], height=1
        ).pack(side="left", fill="x",expand=True, padx=(8, 0))

    def _labeled_entry(
            self, parent, label: str, placeholder: str = "",
            readonly: bool = False
        ) -> PlaceholderEntry:
        r"""Crea una fila etiqueta + Entry con placeholder."""
        row = tk.Frame(parent, bg=C["card"])
        row.pack(fill="x", padx=10, pady=2)
        tk.Label(
            row, text=label, font=(C["mono"], 8), bg=C["card"],
            fg=C["muted"], width=26, anchor="w"
        ).pack(side="left")
        e = PlaceholderEntry(row, placeholder=placeholder, font=(C["mono"], 9))
        if readonly:
            e.config(state="readonly", readonlybackground=C["bg3"], fg=C["soft"])
        e.pack(side="left", fill="x", expand=True, ipady=4, padx=(4, 0))
        return e

    def _labeled_combo(
            self, parent, label: str, options: list,
            tip: str = ""
        ) -> ttk.Combobox:
        r"""Crea una fila etiqueta + Combobox readonly."""
        row = tk.Frame(parent, bg=C["card"])
        row.pack(fill="x", padx=10, pady=2)
        tk.Label(
            row, text=label, font=(C["mono"], 8), bg=C["card"],
            fg=C["muted"], width=26, anchor="w"
        ).pack(side="left")
        var = tk.StringVar(value=options[0] if options else "")
        cb = ttk.Combobox(
            row, textvariable=var, values=options,
            font=(C["mono"], 9), state="readonly", width=20
        )
        cb.pack(side="left", ipady=3)
        if tip:
            tk.Label(
                row, text=tip, font=(C["mono"], 7), bg=C["card"],
                fg=C["soft"], anchor="w"
            ).pack(side="left", padx=6)
        # Guardamos la StringVar como atributo del Combobox para acceso uniforme
        cb._var = var
        return cb

    def _labeled_spin(self, parent, label: str, tip: str = "") -> tk.Spinbox:
        r"""Crea una fila etiqueta + Spinbox (1-5) + descripción del rango."""
        row = tk.Frame(parent, bg=C["card"])
        row.pack(fill="x", padx=10, pady=2)
        tk.Label(
            row, text=label, font=(C["mono"], 8), bg=C["card"],
            fg=C["muted"], width=26, anchor="w"
        ).pack(side="left")
        sp = tk.Spinbox(row, from_=1, to=5, width=4, font=(C["mono"], 9),
                        bg=C["bg3"], fg=C["text"], insertbackground=C["accent"],
                        relief="flat", bd=0, buttonbackground=C["bg2"])
        sp.pack(side="left", ipady=3)
        if tip:
            tk.Label(
                row, text=tip, font=(C["mono"], 7), bg=C["card"],
                fg=C["soft"], anchor="w"
            ).pack(side="left", padx=6)
        return sp

    def _labeled_text(
            self, parent, label: str, placeholder: str = "",
            height: int = 3
        ) -> tk.Text:
        r"""Crea una fila etiqueta + área de texto multilínea con placeholder simulado."""
        frame = tk.Frame(parent, bg=C["card"])
        frame.pack(fill="x", padx=10, pady=2)
        tk.Label(
            frame, text=label, font=(C["mono"], 8), bg=C["card"],
            fg=C["muted"], anchor="w"
        ).pack(fill="x")
        txt = tk.Text(frame, bg=C["bg3"], fg=C["text"],
                        insertbackground=C["accent"],
                        font=(C["mono"], 9), relief="flat", bd=0,
                        wrap="word", height=height,
                        highlightthickness=1,
                        highlightbackground=C["border"],
                        highlightcolor=C["accent"])
        txt.pack(fill="x", ipady=4)
        # Placeholder simulado para tk.Text
        if placeholder:
            txt.insert("1.0", placeholder)
            txt.config(fg=C["ph"])
            def on_focus_in(e, t=txt, p=placeholder):
                if t.get("1.0", "end-1c") == p:
                    t.delete("1.0", tk.END)
                    t.config(fg=C["text"])
            def on_focus_out(e, t=txt, p=placeholder):
                if not t.get("1.0", "end-1c").strip():
                    t.insert("1.0", p)
                    t.config(fg=C["ph"])
            txt.bind("<FocusIn>",  on_focus_in)
            txt.bind("<FocusOut>", on_focus_out)
        return txt

    def _mkbtn(self, parent, text: str, fg: str, command) -> tk.Button:
        """Crea un botón de acción con el estilo del panel."""
        btn = tk.Button(parent, text=text, command=command,
                        font=(C["mono"], 9, "bold"),
                        bg=C["card2"], fg=fg,
                        activebackground=C["border2"], activeforeground=fg,
                        relief="flat", bd=0, cursor="hand2",
                        padx=14, pady=6)
        btn.bind("<Enter>", lambda e: btn.config(bg=C["border"]))
        btn.bind("<Leave>", lambda e: btn.config(bg=C["card2"]))
        return btn

    # Helpers get/set por tipo de widget 

    def _get_entry(self, w) -> str:
        r"""Lee un PlaceholderEntry devolviendo '' si es placeholder."""
        if hasattr(w, "get_value"):
            return w.get_value()
        return w.get().strip()

    def _get_combo(self, w) -> str:
        r"""Lee un Combobox. Accede a _var si existe (patrón de _labeled_combo)."""
        if hasattr(w, "_var"):
            return w._var.get()
        return w.get()

    def _get_text(self, w) -> str:
        r"""Lee un tk.Text limpiando el placeholder si aún está activo."""
        val = w.get("1.0", tk.END).strip()
        # Si el color es el del placeholder, el contenido es placeholder → ""
        if w.cget("fg") == C["ph"]:
            return ""
        return val

    def _set_entry(self, w, value: str):
        r"""Establece el valor de un PlaceholderEntry o Entry estándar."""
        if hasattr(w, "set_value"):
            was_readonly = str(w.cget("state")) == "readonly"
            if was_readonly:
                w.config(state="normal")
            w.set_value(str(value) if value is not None else "")
            if was_readonly:
                w.config(state="readonly")
        else:
            w.delete(0, tk.END)
            w.insert(0, str(value) if value is not None else "")

    def _set_combo(self, w, value: str):
        r"""Establece el valor de un Combobox gestionado por _var."""
        if hasattr(w, "_var"):
            w._var.set(str(value) if value else "")
        else:
            w.set(str(value) if value else "")

    def _set_spin(self, w, value):
        r"""Establece el valor de un Spinbox (clampea a rango 1-5)."""
        try:
            v = max(1, min(5, int(value)))
        except (ValueError, TypeError):
            v = 3
        w.delete(0, tk.END)
        w.insert(0, str(v))

    def _set_text(self, w, value: str):
        r"""Establece el contenido de un tk.Text limpiando el placeholder."""
        w.config(fg=C["text"])   # Resetear color antes de escribir
        w.delete("1.0", tk.END)
        if value:
            w.insert("1.0", value)
