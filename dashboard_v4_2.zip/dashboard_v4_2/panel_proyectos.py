#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════════╗
║         PANEL DE GESTIÓN DE PROYECTOS — Dashboard Data Team  v4.0              ║
╠══════════════════════════════════════════════════════════════════════════════════╣
║                                                                                  ║
║  Herramienta de escritorio para crear, editar y eliminar proyectos en los       ║
║  archivos JSON que alimentan el dashboard web del equipo de Data.               ║
║                                                                                  ║
║  ARQUITECTURA DE LA INTERFAZ                                                     ║
║  ─────────────────────────────                                                   ║
║  ┌──────────────┬────────────────────────────────────────────────────────────┐   ║
║  │  IZQUIERDA   │                    DERECHA (Notebook)                      │   ║
║  │              │  ┌──────────┬──────────┬──────────┬──────────┬──────────┐  │   ║
║  │  Selector    │  │ General  │  Equipo  │ Blockers │ Timeline │ Entreg.  │  │   ║
║  │  de área     │  ├──────────┴──────────┴──────────┴──────────┴──────────┤  │   ║
║  │              │  │                                                        │  │   ║
║  │  Lista de    │  │   Formulario con scroll vertical para cada pestaña    │  │   ║
║  │  proyectos   │  │   Filas dinámicas (+ / −) en secciones estructuradas  │  │   ║
║  │              │  │   Placeholders descriptivos en todos los campos       │  │   ║
║  │  [+ Nuevo]   │  │                                                        │  │   ║
║  │  [Eliminar]  │  └────────────────────────────────────────────────────────┘  │   ║
║  │              │  [  💾 Guardar  ]  [ ✕ Cancelar ]                           │   ║
║  └──────────────┴────────────────────────────────────────────────────────────┘   ║
║                                                                                  ║
║  ARCHIVOS QUE GESTIONA                                                           ║
║    assets/data/<Nombre_Area>.json  →  Ej: Data_Analysis.json                   ║
║                                                                                  ║
║  ESTRUCTURA JSON DE CADA PROYECTO (p1, p2, ...)                                 ║
║    id, idiom, name, description, status,                                        ║
║    businessPriority, technicalSeverity, urgency, dependencyCriticality,         ║
║    deadline, committedAt, actualAt,                                              ║
║    assignees[], tech[], blockers[{text,severity}], dependencies[],              ║
║    timeline[{date,title,desc}], history[{date,author,action,detail}],           ║
║    recentActivity[{author,date,text}], deliverables[{id,text,done,owner,        ║
║      sla,committed,actual,goal,criteria,notes}], comments[{author,date,text}]   ║
║                                                                                  ║
║  USO                                                                             ║
║    python panel_proyectos.py                                                     ║
║                                                                                  ║
║  REQUISITOS                                                                      ║
║    Python 3.8+  —  Solo usa la librería estándar (tkinter incluido)             ║
╚══════════════════════════════════════════════════════════════════════════════════╝
"""

# ─── Importaciones estándar ──────────────────────────────────────────────────────
import json          # Lectura y escritura de archivos JSON
import copy          # Copia profunda de diccionarios/listas (evita mutaciones accidentales)
import re            # Expresiones regulares (validación de fechas)
import tkinter as tk # GUI principal
from tkinter import (
    ttk,             # Widgets mejorados: Notebook, Combobox, Treeview, Scrollbar
    messagebox,      # Diálogos de confirmación y error
    filedialog,      # Selector de archivos del sistema operativo
)
from datetime import datetime  # Para registrar fechas en el historial automático
from pathlib import Path        # Manejo de rutas multiplataforma


# ═══════════════════════════════════════════════════════════════════════════════
# SECCIÓN 1 — CONSTANTES Y CONFIGURACIÓN
# ═══════════════════════════════════════════════════════════════════════════════

# Directorio raíz donde viven los archivos JSON de cada área.
# Se calcula relativo a la ubicación del propio script para portabilidad.
DATA_DIR = Path(__file__).parent / "assets" / "data"

# ── Paleta de colores oscura (coherente con el dashboard web) ────────────────
# Cada clave corresponde a un rol semántico en la interfaz.
C = {
    "bg":         "#0a1520",   # Fondo global más oscuro
    "bg2":        "#0f1e2e",   # Fondo de la barra superior y barra de estado
    "bg3":        "#111826",   # Fondo de inputs y areas de texto
    "card":       "#0d1a28",   # Fondo de los paneles (tarjetas)
    "card2":      "#111c2a",   # Fondo secundario dentro de tarjetas
    "border":     "#1a2e42",   # Borde exterior de tarjetas
    "border2":    "#1f3550",   # Borde de hover / activo
    "line":       "#162438",   # Línea separadora sutil
    "accent":     "#5bbdff",   # Azul cian — color principal de interacción
    "orange":     "#ff8a3d",   # Naranja — títulos y acciones primarias
    "red":        "#ff5c5c",   # Rojo — eliminación y errores
    "green":      "#2ee89a",   # Verde — confirmación y éxito
    "warn":       "#ffb547",   # Amarillo — advertencias
    "purple":     "#b47cff",   # Violeta — acciones secundarias
    "text":       "#ddeeff",   # Texto principal (casi blanco azulado)
    "muted":      "#7a9db8",   # Texto secundario (gris azulado)
    "soft":       "#3d5f7a",   # Texto terciario muy tenue
    "ph":         "#2a4a62",   # Color del placeholder (texto gris-azul)
    "mono":       "JetBrains Mono",   # Fuente monoespaciada para el panel
    "sans":       "Segoe UI",         # Fuente sans-serif del sistema
}

# ── Opciones para campos con valores predefinidos ────────────────────────────
STATUS_OPTS   = ["active", "risk", "delivered", "paused"]
SEVERITY_OPTS = ["crit", "med", "low"]
IDIOM_OPTS    = ["En", "Es"]
DONE_OPTS     = ["true", "false"]

# ── Plantilla vacía de un proyecto nuevo ─────────────────────────────────────
# Todos los campos que puede tener un proyecto; el id se genera automáticamente.
PROYECTO_TEMPLATE = {
    "id":                   "",         # Generado automáticamente (p1, p2, …)
    "idiom":                "En",       # Idioma del proyecto
    "name":                 "",
    "description":          "",
    "status":               "active",
    "businessPriority":     3,
    "technicalSeverity":    3,
    "urgency":              3,
    "dependencyCriticality":3,
    "deadline":             "",
    "committedAt":          "",
    "actualAt":             "",
    "assignees":            [],
    "tech":                 [],
    "blockers":             [],
    "dependencies":         [],
    "timeline":             [],
    "history":              [],
    "recentActivity":       [],
    "deliverables":         [],
    "comments":             [],
}

# ── Plantillas vacías para cada sub-elemento estructurado ────────────────────
BLOCKER_TEMPLATE     = {"text": "",  "severity": "med"}
TIMELINE_TEMPLATE    = {"date": "",  "title": "",    "desc": ""}
HISTORY_TEMPLATE     = {"date": "",  "author": "",   "action": "", "detail": ""}
ACTIVITY_TEMPLATE    = {"author": "","date": "",     "text": ""}
DELIVERABLE_TEMPLATE = {
    "id":        "",    # Generado automáticamente (d1, d2, …)
    "text":      "",    "done":      "false",
    "owner":     "",    "sla":       "",
    "committed": "",    "actual":    "",
    "goal":      "",    "criteria":  "",
    "notes":     "",
}
COMMENT_TEMPLATE = {"author": "", "date": "", "text": ""}


# ═══════════════════════════════════════════════════════════════════════════════
# SECCIÓN 2 — UTILIDADES JSON Y DE DATOS
# ═══════════════════════════════════════════════════════════════════════════════

def listar_archivos_json() -> list:
    """
    Devuelve una lista ordenada de rutas Path a todos los .json en DATA_DIR.
    Si el directorio no existe, retorna lista vacía (el panel mostrará aviso).
    """
    if not DATA_DIR.exists():
        return []
    return sorted(DATA_DIR.glob("*.json"))


def cargar_json(ruta: Path) -> list:
    """
    Carga y parsea el archivo JSON de proyectos indicado.
    Retorna lista vacía si el archivo no existe o está vacío.
    Lanza ValueError si el JSON es inválido (el llamador decide cómo manejarlo).
    """
    if not ruta.exists():
        return []
    with open(ruta, "r", encoding="utf-8") as f:
        texto = f.read().strip()
    if not texto:
        return []
    data = json.loads(texto)
    return data if isinstance(data, list) else []


def guardar_json(ruta: Path, proyectos: list) -> None:
    """
    Serializa la lista de proyectos como JSON indentado y la escribe en disco.
    Usa ensure_ascii=False para preservar caracteres especiales (tildes, ñ, etc.).
    """
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(proyectos, f, ensure_ascii=False, indent=2)


def generar_id_proyecto(proyectos: list) -> str:
    """
    Genera el siguiente ID de proyecto manteniendo el orden correlativo.
    Lee los IDs existentes del patrón 'pN', toma el máximo N y retorna p(N+1).
    Si no hay proyectos, retorna 'p1'.
    Ejemplo: proyectos con p1, p2, p4  →  retorna p5 (máximo + 1)
    """
    nums = []
    for p in proyectos:
        pid = str(p.get("id", ""))
        if pid.startswith("p") and pid[1:].isdigit():
            nums.append(int(pid[1:]))
    return f"p{max(nums) + 1}" if nums else "p1"


def generar_id_entregable(entregables: list) -> str:
    """
    Genera el siguiente ID de entregable con el patrón 'dN'.
    Mismo mecanismo que generar_id_proyecto pero con prefijo 'd'.
    Ejemplo: d1, d2, d5  →  retorna d6
    """
    nums = []
    for d in entregables:
        did = str(d.get("id", ""))
        if did.startswith("d") and did[1:].isdigit():
            nums.append(int(did[1:]))
    return f"d{max(nums) + 1}" if nums else "d1"


def timestamp_ahora() -> str:
    """Retorna el timestamp actual formateado como 'YYYY-MM-DD HH:MM'."""
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def lista_desde_csv(texto: str) -> list:
    """
    Convierte un string CSV a lista, limpiando espacios.
    Ejemplo: "SB, FQ, YS" → ["SB", "FQ", "YS"]
    Entradas vacías o de solo espacios se omiten.
    """
    return [x.strip() for x in texto.split(",") if x.strip()]


# ═══════════════════════════════════════════════════════════════════════════════
# SECCIÓN 3 — WIDGET AUXILIAR: ENTRY CON PLACEHOLDER
# ═══════════════════════════════════════════════════════════════════════════════

class PlaceholderEntry(tk.Entry):
    """
    Entry de tkinter con soporte de placeholder (texto descriptivo en gris
    que desaparece al enfocar el campo y vuelve si queda vacío al perder foco).

    Uso:
        e = PlaceholderEntry(parent, placeholder="YYYY-MM-DD", width=18)
        valor = e.get_value()  # devuelve "" si solo hay placeholder
    """

    def __init__(self, parent, placeholder: str = "", **kwargs):
        """
        Inicializa el Entry con el color de placeholder (C["ph"]) y texto gris.

        Args:
            parent:      Widget padre de tkinter.
            placeholder: Texto descriptivo a mostrar cuando el campo está vacío.
            **kwargs:    Argumentos adicionales para tk.Entry (width, font, etc.).
        """
        # Estilos base para el Entry oscuro del panel
        defaults = {
            "bg":              C["bg3"],
            "fg":              C["text"],
            "insertbackground":C["accent"],
            "relief":          "flat",
            "bd":              0,
            "font":           (C["mono"], 9),
            "highlightthickness": 1,
            "highlightcolor":  C["accent"],
            "highlightbackground": C["border"],
        }
        defaults.update(kwargs)  # Permite sobreescribir cualquier estilo desde el exterior
        super().__init__(parent, **defaults)

        self._placeholder = placeholder
        self._has_ph = False      # True cuando el campo muestra el placeholder
        self._normal_fg = defaults.get("fg", C["text"])

        # Mostrar placeholder inicial
        if placeholder:
            self._show_placeholder()

        # Vincular eventos de foco para gestionar el placeholder
        self.bind("<FocusIn>",  self._on_focus_in)
        self.bind("<FocusOut>", self._on_focus_out)

    def _show_placeholder(self):
        """Muestra el texto placeholder en color tenue."""
        self._has_ph = True
        self.config(fg=C["ph"])
        self.delete(0, tk.END)
        self.insert(0, self._placeholder)

    def _hide_placeholder(self):
        """Elimina el texto placeholder para permitir edición real."""
        if self._has_ph:
            self._has_ph = False
            self.config(fg=self._normal_fg)
            self.delete(0, tk.END)

    def _on_focus_in(self, _event):
        """Al ganar foco: ocultar placeholder si está activo."""
        if self._has_ph:
            self._hide_placeholder()

    def _on_focus_out(self, _event):
        """Al perder foco: si el campo quedó vacío, volver a mostrar placeholder."""
        if not self.get().strip():
            self._show_placeholder()

    def get_value(self) -> str:
        """
        Retorna el valor real del campo (cadena vacía si solo hay placeholder).
        Usar este método en lugar de .get() para evitar confundir placeholder con datos.
        """
        if self._has_ph:
            return ""
        return self.get().strip()

    def set_value(self, valor: str):
        """
        Establece un valor en el campo. Si el valor es vacío, muestra el placeholder.
        Usar este método en lugar de .insert() para mantener coherencia del estado.

        Args:
            valor: String a establecer en el campo.
        """
        self._has_ph = False
        self.config(fg=self._normal_fg)
        self.delete(0, tk.END)
        if valor:
            self.insert(0, str(valor))
        elif self._placeholder:
            self._show_placeholder()


# ═══════════════════════════════════════════════════════════════════════════════
# SECCIÓN 4 — WIDGET AUXILIAR: GESTOR DE FILAS DINÁMICAS
# ═══════════════════════════════════════════════════════════════════════════════

class DynamicRowManager(tk.Frame):
    """
    Panel scrollable que gestiona una lista dinámica de filas con campos de texto.
    Cada fila corresponde a un elemento de una sección estructurada del proyecto
    (blocker, timeline event, deliverable, etc.).

    Permite:
      - Agregar una nueva fila vacía con el botón "+"
      - Eliminar una fila específica con el botón "−" de esa fila
      - Leer todas las filas como una lista de diccionarios

    Los campos de cada fila se definen mediante la lista `field_defs`:
        [("clave", "Etiqueta", tipo, opciones_o_placeholder), ...]

    Tipos soportados:
        "entry"    → PlaceholderEntry (campo de texto de una línea)
        "combo"    → ttk.Combobox (selector con opciones predefinidas)
        "text"     → tk.Text     (área de texto de varias líneas, height=2)
        "readonly" → PlaceholderEntry deshabilitado (para IDs generados)
        "check"    → Combobox con opciones ["true", "false"] (para campo "done")
    """

    def __init__(self, parent, field_defs: list, id_generator=None,
                 id_field: str = None, section_title: str = "", **kwargs):
        """
        Args:
            parent:        Widget padre de tkinter.
            field_defs:    Lista de tuplas (key, label, type, opts) que definen los campos de cada fila.
            id_generator:  Función callable que recibe la lista actual de dicts y retorna un nuevo ID.
                           Si es None, no se generan IDs automáticos.
            id_field:      Nombre del campo que almacena el ID (ej: "id"). Usado con id_generator.
            section_title: Título de la sección (aparece como encabezado interno).
            **kwargs:      Argumentos adicionales para tk.Frame.
        """
        super().__init__(parent, bg=C["card"], **kwargs)
        self._field_defs   = field_defs     # Definición de los campos por fila
        self._id_generator = id_generator   # Generador de IDs para nuevas filas
        self._id_field     = id_field       # Nombre del campo ID (ej: "id")
        self._rows: list   = []             # Lista de dicts {campo: widget} por fila

        # ── Encabezado de la sección ─────────────────────────────────────────
        if section_title:
            hdr = tk.Frame(self, bg=C["card"])
            hdr.pack(fill="x", padx=6, pady=(6, 2))
            tk.Label(hdr, text=section_title, font=(C["mono"], 9, "bold"),
                     bg=C["card"], fg=C["orange"], anchor="w").pack(side="left")
            self._btn_add(hdr, "＋ Agregar", self._add_row).pack(side="right")

        # ── Canvas + Scrollbar para el área scrollable de filas ──────────────
        frame_outer = tk.Frame(self, bg=C["card"])
        frame_outer.pack(fill="both", expand=True, padx=4)

        self._canvas = tk.Canvas(frame_outer, bg=C["card"], bd=0,
                                 highlightthickness=0, height=260)
        sb = tk.Scrollbar(frame_outer, orient="vertical",
                          command=self._canvas.yview,
                          bg=C["bg2"], troughcolor=C["bg"])
        sb.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)
        self._canvas.configure(yscrollcommand=sb.set)

        # Frame interior que contiene todas las filas
        self._inner = tk.Frame(self._canvas, bg=C["card"])
        self._win_id = self._canvas.create_window((0, 0), window=self._inner, anchor="nw")

        # Actualizar scrollregion al cambiar el tamaño del frame interior
        self._inner.bind("<Configure>",
            lambda e: self._canvas.configure(scrollregion=self._canvas.bbox("all")))
        self._canvas.bind("<Configure>",
            lambda e: self._canvas.itemconfig(self._win_id, width=e.width))
        # Scroll con rueda del mouse
        self._canvas.bind_all("<MouseWheel>",
            lambda e: self._canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

    # ── API pública ──────────────────────────────────────────────────────────

    def load_data(self, data: list):
        """
        Carga una lista de diccionarios como filas en el gestor.
        Borra todas las filas existentes antes de cargar las nuevas.

        Args:
            data: Lista de dicts, cada uno corresponde a una fila del gestor.
        """
        self._clear_rows()
        for item in (data or []):
            self._add_row(initial_data=item)

    def get_data(self) -> list:
        """
        Lee todos los campos de todas las filas y retorna una lista de dicts.
        Los campos de tipo "check" se convierten a boolean (True/False).
        Los campos de tipo "text" se leen con .get("1.0", tk.END).strip().

        Returns:
            Lista de dicts con los valores actuales de cada fila.
        """
        result = []
        for row_widgets in self._rows:
            item = {}
            for key, _, tipo, _ in self._field_defs:
                w = row_widgets.get(key)
                if w is None:
                    item[key] = ""
                    continue
                if tipo == "text":
                    # tk.Text: leer todo el contenido
                    item[key] = w.get("1.0", tk.END).strip()
                elif tipo in ("entry", "readonly"):
                    # PlaceholderEntry: usar get_value() para evitar placeholder
                    item[key] = w.get_value() if hasattr(w, "get_value") else w.get().strip()
                elif tipo in ("combo", "check"):
                    # StringVar ligada al Combobox
                    raw = w.get()
                    if tipo == "check":
                        # Convertir "true"/"false" a bool de Python
                        item[key] = (raw.lower() == "true")
                    else:
                        item[key] = raw
                else:
                    item[key] = w.get().strip() if hasattr(w, "get") else ""
            result.append(item)
        return result

    # ── Métodos internos ─────────────────────────────────────────────────────

    def _clear_rows(self):
        """Elimina todos los widgets de fila del frame interior."""
        for child in self._inner.winfo_children():
            child.destroy()
        self._rows.clear()

    def _add_row(self, initial_data: dict = None):
        """
        Agrega una nueva fila de campos al gestor.
        Si se pasa initial_data, rellena los campos con esos valores.
        Si se tiene id_generator y la fila nueva no tiene ID, lo genera automáticamente.

        Args:
            initial_data: Dict con valores iniciales para la nueva fila (opcional).
        """
        if initial_data is None:
            initial_data = {}

        # Generar ID automático si aplica y la fila no tiene uno
        if self._id_generator and self._id_field and not initial_data.get(self._id_field):
            existing = self.get_data()
            initial_data = dict(initial_data)
            initial_data[self._id_field] = self._id_generator(existing)

        # Contenedor visual de la fila (borde sutil + separación)
        row_frame = tk.Frame(self._inner, bg=C["card2"],
                             highlightthickness=1, highlightbackground=C["border"])
        row_frame.pack(fill="x", padx=4, pady=3, ipady=4)

        # Botón "−" para eliminar esta fila (en la esquina superior derecha)
        btn_del = tk.Button(
            row_frame, text="−", font=(C["mono"], 8),
            bg=C["bg3"], fg=C["red"], relief="flat", bd=0,
            cursor="hand2", padx=6, pady=1,
            command=lambda f=row_frame, idx=len(self._rows): self._remove_row(f, idx)
        )
        btn_del.pack(side="right", anchor="ne", padx=4, pady=4)

        # Construir campos de la fila según field_defs
        row_widgets = {}
        for key, label, tipo, opts in self._field_defs:
            # Sub-frame para etiqueta + widget
            cell = tk.Frame(row_frame, bg=C["card2"])
            cell.pack(fill="x", padx=8, pady=1)

            tk.Label(cell, text=label, font=(C["mono"], 8),
                     bg=C["card2"], fg=C["muted"], anchor="w",
                     width=18).pack(side="left")

            val = str(initial_data.get(key, ""))
            # Normalizar booleanos a string para el display
            if isinstance(initial_data.get(key), bool):
                val = "true" if initial_data[key] else "false"

            if tipo == "entry":
                w = PlaceholderEntry(cell, placeholder=opts or "", width=28,
                                     font=(C["mono"], 9))
                w.pack(side="left", fill="x", expand=True, ipady=3)
                if val and val not in ("None", ""):
                    w.set_value(val)

            elif tipo == "readonly":
                # Campo de solo lectura para IDs generados automáticamente
                w = PlaceholderEntry(cell, placeholder="(auto)", width=10,
                                     font=(C["mono"], 9),
                                     state="readonly",
                                     readonlybackground=C["bg3"],
                                     fg=C["soft"])
                w.pack(side="left", ipady=3)
                if val and val not in ("None", ""):
                    w.config(state="normal")
                    w.set_value(val)
                    w.config(state="readonly")
                row_widgets[key] = w
                continue  # No sobrescribir con el set_value al final

            elif tipo == "combo" or tipo == "check":
                var = tk.StringVar(value=val if val else (opts[0] if opts else ""))
                w = ttk.Combobox(cell, textvariable=var,
                                 values=opts or [],
                                 font=(C["mono"], 9), width=14, state="readonly")
                # Styling del Combobox (no se puede personalizar mucho en ttk)
                w.pack(side="left", ipady=2)
                # Guardamos la StringVar, no el widget, para .get() consistente
                row_widgets[key] = var
                continue  # get_data() usará var.get()

            elif tipo == "text":
                w = tk.Text(cell, bg=C["bg3"], fg=C["text"],
                            insertbackground=C["accent"],
                            font=(C["mono"], 9),
                            relief="flat", bd=0, wrap="word",
                            height=2, width=30)
                w.pack(side="left", fill="x", expand=True, ipady=2)
                if val and val not in ("None", ""):
                    w.insert("1.0", val)
                row_widgets[key] = w
                continue

            row_widgets[key] = w

        # Registrar la fila
        self._rows.append(row_widgets)

        # Actualizar los comandos de eliminación con el índice correcto
        self._refresh_delete_commands()

    def _remove_row(self, frame: tk.Frame, idx: int):
        """
        Elimina la fila indicada por su frame widget y su posición en self._rows.
        Después de eliminar, refresca los comandos de los botones "−" restantes.

        Args:
            frame: Frame tkinter de la fila a eliminar.
            idx:   Índice de la fila en self._rows (puede estar desactualizado;
                   buscamos por widget para mayor seguridad).
        """
        # Buscar la fila por su frame (el frame está dentro de self._inner)
        children = list(self._inner.winfo_children())
        for i, child in enumerate(children):
            if child is frame:
                frame.destroy()
                if i < len(self._rows):
                    self._rows.pop(i)
                break
        self._refresh_delete_commands()

    def _refresh_delete_commands(self):
        """
        Reconstruye los comandos de los botones "−" de cada fila con
        sus índices y referencias de frame actualizados.
        Necesario después de cualquier adición o eliminación de filas.
        """
        children = list(self._inner.winfo_children())
        for i, child in enumerate(children):
            # Buscar el botón "−" dentro del frame de la fila
            for widget in child.winfo_children():
                if isinstance(widget, tk.Button) and widget.cget("text") == "−":
                    # Re-asignar el command con el frame e índice actuales
                    widget.config(command=lambda f=child, idx=i: self._remove_row(f, idx))

    def _btn_add(self, parent, text: str, cmd) -> tk.Button:
        """
        Crea el botón de agregar fila con el estilo del panel.

        Args:
            parent: Widget padre del botón.
            text:   Texto del botón (ej: "＋ Agregar").
            cmd:    Callback al hacer clic.

        Returns:
            tk.Button configurado.
        """
        btn = tk.Button(
            parent, text=text, command=cmd,
            font=(C["mono"], 8, "bold"),
            bg=C["bg3"], fg=C["green"],
            activebackground=C["border2"], activeforeground=C["green"],
            relief="flat", bd=0, cursor="hand2", padx=8, pady=3
        )
        btn.bind("<Enter>", lambda e: btn.config(bg=C["border"]))
        btn.bind("<Leave>", lambda e: btn.config(bg=C["bg3"]))
        return btn


# ═══════════════════════════════════════════════════════════════════════════════
# SECCIÓN 5 — EDITOR DE PROYECTOS (Notebook con 6 pestañas)
# ═══════════════════════════════════════════════════════════════════════════════

class ProyectoEditor(tk.Frame):
    """
    Panel derecho del panel principal. Contiene un ttk.Notebook con 6 pestañas
    que permiten editar todos los campos de un proyecto JSON completo.

    Pestañas:
        1. General     — id, idiom, name, description, status, prioridades, fechas
        2. Equipo      — assignees, tech, dependencies (campos CSV + texto)
        3. Blockers    — lista dinámica de {text, severity}
        4. Timeline    — lista dinámica de {date, title, desc}
        5. Entregables — lista dinámica completa de deliverables
        6. Historia    — history, recentActivity, comments (listas dinámicas)
    """

    def __init__(self, parent, **kwargs):
        """
        Construye el Notebook y todas sus pestañas.
        Inicialmente vacío; llamar a load_project() para cargar datos.

        Args:
            parent: Widget padre (normalmente el panel principal).
        """
        super().__init__(parent, bg=C["card"], **kwargs)
        self._build_notebook()
        self._build_action_bar()

    # ── Construcción del Notebook ────────────────────────────────────────────

    def _build_notebook(self):
        """Crea el ttk.Notebook y construye cada pestaña."""

        # Estilo del Notebook (fondo oscuro, pestañas con acento naranja)
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Dark.TNotebook",
                         background=C["card"], borderwidth=0, tabmargins=[0,0,0,0])
        style.configure("Dark.TNotebook.Tab",
                         background=C["bg2"], foreground=C["muted"],
                         font=(C["mono"], 9), padding=[10, 6],
                         borderwidth=0)
        style.map("Dark.TNotebook.Tab",
                  background=[("selected", C["card2"])],
                  foreground=[("selected", C["orange"])],
                  expand=[("selected", [0, 0, 0, 0])])

        self._nb = ttk.Notebook(self, style="Dark.TNotebook")
        self._nb.pack(fill="both", expand=True, padx=0, pady=0)

        # Crear las 6 pestañas
        self._tab_general     = self._make_tab("🗂 General")
        self._tab_equipo      = self._make_tab("👥 Equipo")
        self._tab_blockers    = self._make_tab("🚧 Blockers")
        self._tab_timeline    = self._make_tab("📅 Timeline")
        self._tab_entregables = self._make_tab("📦 Entregables")
        self._tab_historia    = self._make_tab("📋 Historia")

        # Poblar cada pestaña con sus widgets
        self._build_tab_general()
        self._build_tab_equipo()
        self._build_tab_blockers()
        self._build_tab_timeline()
        self._build_tab_entregables()
        self._build_tab_historia()

    def _make_tab(self, title: str) -> tk.Frame:
        """
        Crea un Frame scrollable para una pestaña del Notebook.
        El Frame exterior tiene Canvas + Scrollbar para soportar contenido largo.

        Args:
            title: Texto de la pestaña.

        Returns:
            tk.Frame interior (donde se colocan los widgets de la pestaña).
        """
        outer = tk.Frame(self._nb, bg=C["card"])
        self._nb.add(outer, text=title)

        canvas = tk.Canvas(outer, bg=C["card"], bd=0, highlightthickness=0)
        sb = tk.Scrollbar(outer, orient="vertical", command=canvas.yview,
                          bg=C["bg2"], troughcolor=C["bg"])
        sb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        canvas.configure(yscrollcommand=sb.set)

        inner = tk.Frame(canvas, bg=C["card"])
        win = canvas.create_window((0, 0), window=inner, anchor="nw")

        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(win, width=e.width))
        canvas.bind_all("<MouseWheel>",
            lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

        return inner  # El llamador pone sus widgets en este frame

    def _build_tab_general(self):
        """
        Pestaña 1: Campos principales del proyecto.
        Incluye: id (readonly), idiom, name, description, status,
        businessPriority, technicalSeverity, urgency, dependencyCriticality,
        deadline, committedAt, actualAt.
        """
        f = self._tab_general
        self._g = {}  # Diccionario de widgets de General

        # Grupo: Identificación
        self._section_label(f, "IDENTIFICACIÓN")
        self._g["id"] = self._labeled_entry(
            f,
            "ID del proyecto",
            "(auto-generado al guardar)",
            readonly=True
        )
        self._g["idiom"] = self._labeled_combo(f, "Idioma",             IDIOM_OPTS,
                                                tip="Idioma principal del proyecto (En=inglés, Es=español)")
        self._g["name"]  = self._labeled_entry(f, "Nombre del proyecto",
                                                "Ej: Sistema OCR con LLM — nombre claro y descriptivo")
        self._g["description"] = self._labeled_text(f, "Descripción",
                                                     "Descripción detallada del objetivo y alcance del proyecto...",
                                                     height=4)
        # Grupo: Estado y Priorización
        self._section_label(f, "ESTADO Y PRIORIZACIÓN")
        self._g["status"] = self._labeled_combo(f, "Estado",           STATUS_OPTS,
                                                 tip="active | risk | delivered | paused")
        self._g["businessPriority"]     = self._labeled_spin(f, "Prioridad de negocio (1–5)",
                                                              "1=muy baja, 3=media, 5=crítica para el negocio")
        self._g["technicalSeverity"]    = self._labeled_spin(f, "Severidad técnica (1–5)",
                                                              "1=simple, 5=complejidad técnica extrema")
        self._g["urgency"]              = self._labeled_spin(f, "Urgencia (1–5)",
                                                              "1=puede esperar, 5=bloqueante e inmediato")
        self._g["dependencyCriticality"]= self._labeled_spin(f, "Criticidad de dependencias (1–5)",
                                                              "1=sin dependencias, 5=muchas dependencias críticas")
        # Grupo: Fechas
        self._section_label(f, "FECHAS")
        self._g["deadline"]    = self._labeled_entry(f, "Deadline",
                                                     "YYYY-MM-DD  — fecha límite comprometida con el cliente")
        self._g["committedAt"] = self._labeled_entry(f, "Fecha comprometida",
                                                     "YYYY-MM-DD  — cuando se comprometió la entrega internamente")
        self._g["actualAt"]    = self._labeled_entry(f, "Fecha real de entrega",
                                                     "YYYY-MM-DD  — dejar vacío si aún no se ha entregado")

    def _build_tab_equipo(self):
        """
        Pestaña 2: Personas involucradas, tecnologías y dependencias externas.
        assignees y tech son listas CSV (separadas por coma).
        dependencies es una lista separada por saltos de línea.
        """
        f = self._tab_equipo
        self._e = {}

        self._section_label(f, "PERSONAS")
        self._e["assignees"] = self._labeled_entry(f, "Asignados (CSV)",
                                                   "Ej: SB, FQ, YS  — iniciales separadas por coma")
        self._section_label(f, "TECNOLOGÍA")
        self._e["tech"] = self._labeled_entry(f, "Tech stack (CSV)",
                                              "Ej: Python, HTML, CSS, YAML, d3.js")
        self._section_label(f, "DEPENDENCIAS EXTERNAS")
        self._e["dependencies"] = self._labeled_text(f, "Dependencias (una por línea)",
                                                      "Poppler\nTesseract\nOllama\n...",
                                                      height=5)

    def _build_tab_blockers(self):
        """
        Pestaña 3: Lista dinámica de bloqueantes del proyecto.
        Cada blocker tiene: text (descripción) y severity (crit/med/low).
        """
        f = self._tab_blockers

        # Leyenda de uso
        info = tk.Label(f, text="Cada fila es un bloqueo activo del proyecto. severity: crit=crítico, med=medio, low=bajo",
                        font=(C["mono"], 8), bg=C["card"], fg=C["soft"],
                        wraplength=500, justify="left", anchor="w")
        info.pack(fill="x", padx=10, pady=(8, 2))

        self._mgr_blockers = DynamicRowManager(
            f,
            field_defs=[
                ("text",     "Descripción del bloqueo",  "text",  "Ej: Falta acceso a la API de producción"),
                ("severity", "Severidad",                 "combo", SEVERITY_OPTS),
            ],
            section_title="BLOQUEANTES",
        )
        self._mgr_blockers.pack(fill="both", expand=True)

    def _build_tab_timeline(self):
        """
        Pestaña 4: Hitos y fechas del proyecto en orden cronológico.
        Cada evento tiene: date, title, desc.
        """
        f = self._tab_timeline

        info = tk.Label(f, text="Hitos del proyecto en orden cronológico. Cada fila = un evento o entrega relevante.",
                        font=(C["mono"], 8), bg=C["card"], fg=C["soft"],
                        wraplength=500, justify="left", anchor="w")
        info.pack(fill="x", padx=10, pady=(8, 2))

        self._mgr_timeline = DynamicRowManager(
            f,
            field_defs=[
                ("date",  "Fecha",   "entry", "YYYY-MM-DD"),
                ("title", "Título",  "entry", "Ej: Entrega v1.0 — nombre corto del hito"),
                ("desc",  "Detalle", "text",  "Descripción de lo logrado o el contexto del hito..."),
            ],
            section_title="HITOS DEL PROYECTO",
        )
        self._mgr_timeline.pack(fill="both", expand=True)

    def _build_tab_entregables(self):
        """
        Pestaña 5: Lista completa de entregables (deliverables).
        Cada entregable tiene todos sus campos: id (auto), text, done, owner,
        sla, committed, actual, goal, criteria, notes.
        El ID se genera automáticamente con el patrón dN.
        """
        f = self._tab_entregables

        info = tk.Label(f,
            text="Cada fila = un entregable. El ID (d1, d2, …) se genera automáticamente. "
                 "done: true si está completado. sla/committed/actual = fechas YYYY-MM-DD.",
            font=(C["mono"], 8), bg=C["card"], fg=C["soft"],
            wraplength=500, justify="left", anchor="w")
        info.pack(fill="x", padx=10, pady=(8, 2))

        self._mgr_deliverables = DynamicRowManager(
            f,
            field_defs=[
                ("id",        "ID (auto)",       "readonly", "(auto)"),
                ("text",      "Descripción",     "text",     "Ej: Implementar módulo de extracción OCR"),
                ("done",      "¿Completado?",    "check",    DONE_OPTS),
                ("owner",     "Responsable",     "entry",    "Iniciales  Ej: SB"),
                ("sla",       "SLA (fecha)",     "entry",    "YYYY-MM-DD — fecha límite del entregable"),
                ("committed", "Comprometido",    "entry",    "YYYY-MM-DD — fecha de compromiso interno"),
                ("actual",    "Entrega real",    "entry",    "YYYY-MM-DD — dejar vacío si pendiente"),
                ("goal",      "Objetivo",        "text",     "¿Qué se quiere lograr con este entregable?"),
                ("criteria",  "Criterio de éxito","text",    "¿Cómo se valida que está completo?"),
                ("notes",     "Notas",           "text",     "Observaciones adicionales, dependencias internas..."),
            ],
            id_generator=generar_id_entregable,  # Genera d1, d2, d3, …
            id_field="id",
            section_title="ENTREGABLES",
        )
        self._mgr_deliverables.pack(fill="both", expand=True)

    def _build_tab_historia(self):
        """
        Pestaña 6: Registros históricos, actividad reciente y comentarios.
        Tres sub-secciones con gestores dinámicos independientes:
          - history:        Entradas formales de historial {date, author, action, detail}
          - recentActivity: Actividad informal {author, date, text}
          - comments:       Comentarios del equipo {author, date, text}
        """
        f = self._tab_historia

        # ── Historial formal ─────────────────────────────────────────────────
        info1 = tk.Label(f, text="HISTORIAL FORMAL — Cambios de estado, entregas y decisiones importantes.",
                         font=(C["mono"], 8, "bold"), bg=C["card"], fg=C["muted"], anchor="w")
        info1.pack(fill="x", padx=10, pady=(8, 1))

        self._mgr_history = DynamicRowManager(
            f,
            field_defs=[
                ("date",   "Fecha",   "entry", "YYYY-MM-DD HH:MM"),
                ("author", "Autor",   "entry", "Iniciales  Ej: SB"),
                ("action", "Acción",  "text",  "Descripción del cambio o acción realizada"),
                ("detail", "Detalle", "entry", "URL, referencia o nota adicional (opcional)"),
            ],
            section_title="",  # Sin título propio; ya tiene el Label arriba
        )
        self._mgr_history.pack(fill="x")

        tk.Frame(f, bg=C["border"], height=1).pack(fill="x", padx=10, pady=6)

        # ── Actividad reciente ───────────────────────────────────────────────
        info2 = tk.Label(f, text="ACTIVIDAD RECIENTE — Entradas informales de log de trabajo diario.",
                         font=(C["mono"], 8, "bold"), bg=C["card"], fg=C["muted"], anchor="w")
        info2.pack(fill="x", padx=10, pady=(4, 1))

        self._mgr_activity = DynamicRowManager(
            f,
            field_defs=[
                ("author", "Autor",  "entry", "Iniciales  Ej: YS"),
                ("date",   "Fecha",  "entry", "YYYY-MM-DD HH:MM"),
                ("text",   "Texto",  "text",  "Descripción de la actividad realizada en este período"),
            ],
            section_title="",
        )
        self._mgr_activity.pack(fill="x")

        tk.Frame(f, bg=C["border"], height=1).pack(fill="x", padx=10, pady=6)

        # ── Comentarios ──────────────────────────────────────────────────────
        info3 = tk.Label(f, text="COMENTARIOS — Notas del equipo, sugerencias o pendientes no formales.",
                         font=(C["mono"], 8, "bold"), bg=C["card"], fg=C["muted"], anchor="w")
        info3.pack(fill="x", padx=10, pady=(4, 1))

        self._mgr_comments = DynamicRowManager(
            f,
            field_defs=[
                ("author", "Autor", "entry", "Iniciales  Ej: FQ"),
                ("date",   "Fecha", "entry", "YYYY-MM-DD o 'Apr 22'"),
                ("text",   "Texto", "text",  "Comentario o sugerencia del equipo..."),
            ],
            section_title="",
        )
        self._mgr_comments.pack(fill="x")

    # ── Barra de botones (Guardar / Cancelar) ────────────────────────────────

    def _build_action_bar(self):
        """Construye la barra inferior con los botones de acción del editor."""
        bar = tk.Frame(self, bg=C["bg2"], height=44)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)

        # Botón Guardar
        self._btn_save = self._mkbtn(bar, "💾  Guardar cambios",
                                     fg=C["orange"], command=self._on_save)
        self._btn_save.pack(side="left", padx=(14, 8), pady=8)

        # Botón Cancelar
        self._btn_cancel = self._mkbtn(bar, "✕  Cancelar",
                                        fg=C["soft"], command=self._on_cancel)
        self._btn_cancel.pack(side="left", pady=8)

        # Callback externo: se asigna desde PanelProyectos
        self.on_save_callback   = None  # function(proyecto_dict) → None
        self.on_cancel_callback = None  # function() → None

    # ── API pública del editor ────────────────────────────────────────────────

    def load_project(self, p: dict):
        """
        Carga un diccionario de proyecto en todos los campos del editor.
        Limpia primero los valores anteriores antes de cargar los nuevos.
        Es el punto de entrada único para mostrar un proyecto en edición.

        Args:
            p: Diccionario del proyecto con todos sus campos.
        """
        # ── Pestaña General ──────────────────────────────────────────────────
        g = self._g
        self._set_entry(g["id"],    p.get("id", ""))
        self._set_combo(g["idiom"], p.get("idiom", "En"))
        self._set_entry(g["name"],  p.get("name",  ""))
        self._set_text( g["description"], p.get("description", ""))
        self._set_combo(g["status"], p.get("status", "active"))
        self._set_spin(g["businessPriority"],      p.get("businessPriority", 3))
        self._set_spin(g["technicalSeverity"],     p.get("technicalSeverity", 3))
        self._set_spin(g["urgency"],               p.get("urgency", 3))
        self._set_spin(g["dependencyCriticality"], p.get("dependencyCriticality", 3))
        self._set_entry(g["deadline"],    p.get("deadline", ""))
        self._set_entry(g["committedAt"], p.get("committedAt", ""))
        self._set_entry(g["actualAt"],    p.get("actualAt", ""))

        # ── Pestaña Equipo ────────────────────────────────────────────────────
        e = self._e
        self._set_entry(e["assignees"],   ", ".join(p.get("assignees", []) or []))
        self._set_entry(e["tech"],        ", ".join(p.get("tech", []) or []))
        self._set_text( e["dependencies"],"\n".join(p.get("dependencies", []) or []))

        # ── Pestañas con gestores dinámicos ───────────────────────────────────
        self._mgr_blockers.load_data(     p.get("blockers", []))
        self._mgr_timeline.load_data(     p.get("timeline", []))
        self._mgr_deliverables.load_data( p.get("deliverables", []))
        self._mgr_history.load_data(      p.get("history", []))
        self._mgr_activity.load_data(     p.get("recentActivity", []))
        self._mgr_comments.load_data(     p.get("comments", []))

        # Ir a la primera pestaña al cargar
        self._nb.select(0)

    def get_project(self) -> dict:
        """
        Lee todos los campos del editor y retorna un diccionario de proyecto completo.
        Los valores numéricos (prioridades) se convierten a int.
        Los campos CSV (assignees, tech) se parsean a listas.
        Las secciones dinámicas se obtienen mediante get_data() de cada gestor.

        Returns:
            dict: Proyecto completo listo para serializar a JSON.
        """
        g = self._g
        e = self._e
        return {
            # ── Identificación ───────────────────────────────────────────────
            "id":    self._get_entry(g["id"]),
            "idiom": self._get_combo(g["idiom"]),
            "name":  self._get_entry(g["name"]),
            "description": self._get_text(g["description"]),
            # ── Estado ───────────────────────────────────────────────────────
            "status":               self._get_combo(g["status"]),
            "businessPriority":     int(g["businessPriority"].get()),
            "technicalSeverity":    int(g["technicalSeverity"].get()),
            "urgency":              int(g["urgency"].get()),
            "dependencyCriticality":int(g["dependencyCriticality"].get()),
            # ── Fechas ───────────────────────────────────────────────────────
            "deadline":    self._get_entry(g["deadline"]),
            "committedAt": self._get_entry(g["committedAt"]),
            "actualAt":    self._get_entry(g["actualAt"]),
            # ── Equipo ───────────────────────────────────────────────────────
            "assignees":    lista_desde_csv(self._get_entry(e["assignees"])),
            "tech":         lista_desde_csv(self._get_entry(e["tech"])),
            "dependencies": [x for x in self._get_text(e["dependencies"]).splitlines() if x.strip()],
            # ── Secciones dinámicas ──────────────────────────────────────────
            "blockers":      self._mgr_blockers.get_data(),
            "timeline":      self._mgr_timeline.get_data(),
            "deliverables":  self._mgr_deliverables.get_data(),
            "history":       self._mgr_history.get_data(),
            "recentActivity":self._mgr_activity.get_data(),
            "comments":      self._mgr_comments.get_data(),
        }

    def clear(self):
        """
        Limpia todos los campos del editor a sus valores vacíos/default.
        Usado al cancelar la edición o al preparar el formulario para un nuevo proyecto.
        """
        self.load_project(copy.deepcopy(PROYECTO_TEMPLATE))

    # ── Callbacks de los botones ─────────────────────────────────────────────

    def _on_save(self):
        """Valida los campos mínimos y llama al callback on_save_callback."""
        p = self.get_project()
        if not p.get("name", "").strip():
            messagebox.showerror("Campo requerido",
                                 "El campo 'Nombre del proyecto' es obligatorio.")
            self._nb.select(0)  # Navegar a la pestaña General donde está el campo
            return
        if self.on_save_callback:
            self.on_save_callback(p)

    def _on_cancel(self):
        """Llama al callback on_cancel_callback si está definido."""
        if self.on_cancel_callback:
            self.on_cancel_callback()

    # ── Helpers de widgets ────────────────────────────────────────────────────

    def _section_label(self, parent, text: str):
        """Crea una etiqueta de sección con separador visual en la pestaña."""
        frame = tk.Frame(parent, bg=C["card"])
        frame.pack(fill="x", padx=10, pady=(10, 2))
        tk.Label(frame, text=text, font=(C["mono"], 8, "bold"),
                 bg=C["card"], fg=C["orange"], anchor="w").pack(side="left")
        tk.Frame(frame, bg=C["border"], height=1).pack(side="left", fill="x",
                                                        expand=True, padx=(8, 0))

    def _labeled_entry(self, parent, label: str, placeholder: str = "",
                       readonly: bool = False) -> PlaceholderEntry:
        """Crea una fila etiqueta + Entry con placeholder."""
        row = tk.Frame(parent, bg=C["card"])
        row.pack(fill="x", padx=10, pady=2)
        tk.Label(row, text=label, font=(C["mono"], 8), bg=C["card"],
                 fg=C["muted"], width=26, anchor="w").pack(side="left")
        e = PlaceholderEntry(row, placeholder=placeholder, font=(C["mono"], 9))
        if readonly:
            e.config(state="readonly", readonlybackground=C["bg3"], fg=C["soft"])
        e.pack(side="left", fill="x", expand=True, ipady=4, padx=(4, 0))
        return e

    def _labeled_combo(self, parent, label: str, options: list,
                       tip: str = "") -> ttk.Combobox:
        """Crea una fila etiqueta + Combobox readonly."""
        row = tk.Frame(parent, bg=C["card"])
        row.pack(fill="x", padx=10, pady=2)
        tk.Label(row, text=label, font=(C["mono"], 8), bg=C["card"],
                 fg=C["muted"], width=26, anchor="w").pack(side="left")
        var = tk.StringVar(value=options[0] if options else "")
        cb = ttk.Combobox(row, textvariable=var, values=options,
                          font=(C["mono"], 9), state="readonly", width=20)
        cb.pack(side="left", ipady=3)
        if tip:
            tk.Label(row, text=tip, font=(C["mono"], 7), bg=C["card"],
                     fg=C["soft"], anchor="w").pack(side="left", padx=6)
        # Guardamos la StringVar como atributo del Combobox para acceso uniforme
        cb._var = var
        return cb

    def _labeled_spin(self, parent, label: str, tip: str = "") -> tk.Spinbox:
        """Crea una fila etiqueta + Spinbox (1-5) + descripción del rango."""
        row = tk.Frame(parent, bg=C["card"])
        row.pack(fill="x", padx=10, pady=2)
        tk.Label(row, text=label, font=(C["mono"], 8), bg=C["card"],
                 fg=C["muted"], width=26, anchor="w").pack(side="left")
        sp = tk.Spinbox(row, from_=1, to=5, width=4, font=(C["mono"], 9),
                        bg=C["bg3"], fg=C["text"], insertbackground=C["accent"],
                        relief="flat", bd=0, buttonbackground=C["bg2"])
        sp.pack(side="left", ipady=3)
        if tip:
            tk.Label(row, text=tip, font=(C["mono"], 7), bg=C["card"],
                     fg=C["soft"], anchor="w").pack(side="left", padx=6)
        return sp

    def _labeled_text(self, parent, label: str, placeholder: str = "",
                      height: int = 3) -> tk.Text:
        """Crea una fila etiqueta + área de texto multilínea con placeholder simulado."""
        frame = tk.Frame(parent, bg=C["card"])
        frame.pack(fill="x", padx=10, pady=2)
        tk.Label(frame, text=label, font=(C["mono"], 8), bg=C["card"],
                 fg=C["muted"], anchor="w").pack(fill="x")
        txt = tk.Text(frame, bg=C["bg3"], fg=C["text"],
                      insertbackground=C["accent"],
                      font=(C["mono"], 9), relief="flat", bd=0,
                      wrap="word", height=height,
                      highlightthickness=1,
                      highlightbackground=C["border"],
                      highlightcolor=C["accent"])
        txt.pack(fill="x", ipady=4)
        # Placeholder simulado para tk.Text
        if placeholder:
            txt.insert("1.0", placeholder)
            txt.config(fg=C["ph"])
            def on_focus_in(e, t=txt, p=placeholder):
                if t.get("1.0", "end-1c") == p:
                    t.delete("1.0", tk.END)
                    t.config(fg=C["text"])
            def on_focus_out(e, t=txt, p=placeholder):
                if not t.get("1.0", "end-1c").strip():
                    t.insert("1.0", p)
                    t.config(fg=C["ph"])
            txt.bind("<FocusIn>",  on_focus_in)
            txt.bind("<FocusOut>", on_focus_out)
        return txt

    def _mkbtn(self, parent, text: str, fg: str, command) -> tk.Button:
        """Crea un botón de acción con el estilo del panel."""
        btn = tk.Button(parent, text=text, command=command,
                        font=(C["mono"], 9, "bold"),
                        bg=C["card2"], fg=fg,
                        activebackground=C["border2"], activeforeground=fg,
                        relief="flat", bd=0, cursor="hand2",
                        padx=14, pady=6)
        btn.bind("<Enter>", lambda e: btn.config(bg=C["border"]))
        btn.bind("<Leave>", lambda e: btn.config(bg=C["card2"]))
        return btn

    # ── Helpers get/set por tipo de widget ────────────────────────────────────

    def _get_entry(self, w) -> str:
        """Lee un PlaceholderEntry devolviendo '' si es placeholder."""
        if hasattr(w, "get_value"):
            return w.get_value()
        return w.get().strip()

    def _get_combo(self, w) -> str:
        """Lee un Combobox. Accede a _var si existe (patrón de _labeled_combo)."""
        if hasattr(w, "_var"):
            return w._var.get()
        return w.get()

    def _get_text(self, w) -> str:
        """Lee un tk.Text limpiando el placeholder si aún está activo."""
        val = w.get("1.0", tk.END).strip()
        # Si el color es el del placeholder, el contenido es placeholder → ""
        if w.cget("fg") == C["ph"]:
            return ""
        return val

    def _set_entry(self, w, value: str):
        """Establece el valor de un PlaceholderEntry o Entry estándar."""
        if hasattr(w, "set_value"):
            was_readonly = str(w.cget("state")) == "readonly"
            if was_readonly:
                w.config(state="normal")
            w.set_value(str(value) if value is not None else "")
            if was_readonly:
                w.config(state="readonly")
        else:
            w.delete(0, tk.END)
            w.insert(0, str(value) if value is not None else "")

    def _set_combo(self, w, value: str):
        """Establece el valor de un Combobox gestionado por _var."""
        if hasattr(w, "_var"):
            w._var.set(str(value) if value else "")
        else:
            w.set(str(value) if value else "")

    def _set_spin(self, w, value):
        """Establece el valor de un Spinbox (clampea a rango 1-5)."""
        try:
            v = max(1, min(5, int(value)))
        except (ValueError, TypeError):
            v = 3
        w.delete(0, tk.END)
        w.insert(0, str(v))

    def _set_text(self, w, value: str):
        """Establece el contenido de un tk.Text limpiando el placeholder."""
        w.config(fg=C["text"])   # Resetear color antes de escribir
        w.delete("1.0", tk.END)
        if value:
            w.insert("1.0", value)


# ═══════════════════════════════════════════════════════════════════════════════
# SECCIÓN 6 — PANEL PRINCIPAL
# ═══════════════════════════════════════════════════════════════════════════════

class PanelProyectos:
    """
    Ventana principal del panel de gestión.
    Organiza la interfaz en dos zonas:
        - IZQUIERDA: selector de área JSON + lista de proyectos + botones de acción
        - DERECHA:   ProyectoEditor (Notebook con 6 pestañas)

    Flujo de uso:
        1. Usuario selecciona un archivo JSON de área (columna izquierda)
        2. Se carga la lista de proyectos del área
        3. Usuario selecciona un proyecto → se carga en el editor
        4. Usuario edita campos y guarda → se actualiza el JSON en disco
        5. O crea un nuevo proyecto con el botón "+" y guarda
    """

    def __init__(self, root: tk.Tk):
        """
        Inicializa la ventana principal y construye todos los componentes UI.

        Args:
            root: Ventana raíz de tkinter.
        """
        self.root = root
        root.title("◈  Panel de Proyectos — Data Team Dashboard  v4.0")
        root.geometry("1440x860")
        root.minsize(1100, 700)
        root.configure(bg=C["bg"])

        # Estado interno del panel
        self.archivo_actual: Path | None = None   # Archivo JSON abierto
        self.proyectos: list              = []     # Lista de proyectos en memoria
        self.idx_sel:   int  | None       = None   # Índice del proyecto seleccionado
        self.modo_nuevo: bool             = False  # True = creando nuevo proyecto

        # Construir la interfaz
        self._build_header()
        self._build_body()
        self._build_status_bar()

        # Cargar lista inicial de archivos JSON
        self._refresh_archivos()

    # ── Layout principal ──────────────────────────────────────────────────────

    def _build_header(self):
        """Construye la barra de título superior con nombre, versión e instrucción."""
        hdr = tk.Frame(self.root, bg=C["bg2"], height=52)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Frame(self.root, bg=C["border"], height=1).pack(fill="x")

        tk.Label(hdr, text="◈  PANEL DE GESTIÓN DE PROYECTOS",
                 font=(C["mono"], 14, "bold"),
                 bg=C["bg2"], fg=C["orange"]).pack(side="left", padx=18, pady=10)

        tk.Label(hdr, text="Data Team Dashboard · v4.0  |  Selecciona un área para comenzar",
                 font=(C["mono"], 9),
                 bg=C["bg2"], fg=C["soft"]).pack(side="right", padx=18)

    def _build_body(self):
        """Construye el cuerpo principal: columna izquierda + columna derecha."""
        body = tk.Frame(self.root, bg=C["bg"])
        body.pack(fill="both", expand=True, padx=10, pady=10)

        # ── Columna izquierda (fija, 270px) ─────────────────────────────────
        left = tk.Frame(body, bg=C["border"], width=270)
        left.pack(side="left", fill="y", padx=(0, 8))
        left.pack_propagate(False)

        left_inner = tk.Frame(left, bg=C["card"])
        left_inner.pack(fill="both", expand=True, padx=1, pady=1)

        self._build_col_archivos(left_inner)
        self._build_col_proyectos(left_inner)

        # ── Columna derecha (flexible) ───────────────────────────────────────
        right = tk.Frame(body, bg=C["border"])
        right.pack(side="left", fill="both", expand=True)

        right_inner = tk.Frame(right, bg=C["card"])
        right_inner.pack(fill="both", expand=True, padx=1, pady=1)

        self._editor = ProyectoEditor(right_inner)
        self._editor.pack(fill="both", expand=True)

        # Conectar callbacks del editor al panel
        self._editor.on_save_callback   = self._guardar_proyecto
        self._editor.on_cancel_callback = self._cancelar_edicion

    def _build_status_bar(self):
        """Construye la barra de estado inferior con mensajes del sistema."""
        tk.Frame(self.root, bg=C["border"], height=1).pack(fill="x")
        bar = tk.Frame(self.root, bg=C["bg2"], height=26)
        bar.pack(fill="x")
        bar.pack_propagate(False)

        self._status_var = tk.StringVar(value="  Listo. Selecciona un archivo JSON para comenzar.")
        tk.Label(bar, textvariable=self._status_var,
                 font=(C["mono"], 8), bg=C["bg2"], fg=C["muted"],
                 anchor="w").pack(fill="x", padx=14, pady=4)

    # ── Columna: selector de archivos JSON ───────────────────────────────────

    def _build_col_archivos(self, parent):
        """
        Construye la sección superior de la columna izquierda:
        título, listbox de archivos JSON disponibles en DATA_DIR,
        y botón para abrir archivo externo.
        """
        # Título de sección
        hdr = tk.Frame(parent, bg=C["card2"])
        hdr.pack(fill="x")
        tk.Label(hdr, text="📁  ÁREAS (JSON)",
                 font=(C["mono"], 9, "bold"),
                 bg=C["card2"], fg=C["accent"],
                 anchor="w", pady=6, padx=10).pack(fill="x")
        tk.Frame(parent, bg=C["border"], height=1).pack(fill="x")

        # Listbox + Scrollbar de archivos
        frame = tk.Frame(parent, bg=C["card"])
        frame.pack(fill="x", padx=6, pady=6)

        sb = tk.Scrollbar(frame, bg=C["bg2"], troughcolor=C["bg"])
        sb.pack(side="right", fill="y")

        self._lb_archivos = tk.Listbox(
            frame, bg=C["bg3"], fg=C["text"],
            selectbackground=C["orange"], selectforeground=C["bg"],
            font=(C["mono"], 9), bd=0, highlightthickness=0,
            activestyle="none", height=6, yscrollcommand=sb.set
        )
        self._lb_archivos.pack(side="left", fill="x", expand=True)
        sb.configure(command=self._lb_archivos.yview)
        self._lb_archivos.bind("<<ListboxSelect>>", self._on_archivo_select)

        # Botón abrir archivo externo
        self._mkbtn_small(parent, "＋ Abrir otro JSON",
                           C["muted"], self._abrir_json_externo).pack(fill="x", padx=6, pady=(0, 6))

    def _build_col_proyectos(self, parent):
        """
        Construye la sección inferior de la columna izquierda:
        título, listbox de proyectos del área seleccionada,
        y botones Nuevo + Eliminar.
        """
        tk.Frame(parent, bg=C["border"], height=1).pack(fill="x")
        hdr = tk.Frame(parent, bg=C["card2"])
        hdr.pack(fill="x")
        tk.Label(hdr, text="📋  PROYECTOS",
                 font=(C["mono"], 9, "bold"),
                 bg=C["card2"], fg=C["accent"],
                 anchor="w", pady=6, padx=10).pack(fill="x")
        tk.Frame(parent, bg=C["border"], height=1).pack(fill="x")

        # Listbox + Scrollbar de proyectos
        frame = tk.Frame(parent, bg=C["card"])
        frame.pack(fill="both", expand=True, padx=6, pady=6)

        sb = tk.Scrollbar(frame, bg=C["bg2"], troughcolor=C["bg"])
        sb.pack(side="right", fill="y")

        self._lb_proyectos = tk.Listbox(
            frame, bg=C["bg3"], fg=C["text"],
            selectbackground=C["accent"], selectforeground=C["bg"],
            font=(C["mono"], 9), bd=0, highlightthickness=0,
            activestyle="none", yscrollcommand=sb.set
        )
        self._lb_proyectos.pack(side="left", fill="both", expand=True)
        sb.configure(command=self._lb_proyectos.yview)
        self._lb_proyectos.bind("<<ListboxSelect>>", self._on_proyecto_select)

        # Botones de acción sobre proyectos
        btn_frame = tk.Frame(parent, bg=C["card"])
        btn_frame.pack(fill="x", padx=6, pady=(0, 8))

        self._mkbtn_small(btn_frame, "＋ Nuevo proyecto",
                           C["green"], self._nuevo_proyecto).pack(fill="x", pady=(0, 4))
        self._mkbtn_small(btn_frame, "🗑  Eliminar seleccionado",
                           C["red"], self._eliminar_proyecto).pack(fill="x")

    # ── Lógica de archivos ────────────────────────────────────────────────────

    def _refresh_archivos(self):
        """
        Recarga el listbox de archivos JSON con los archivos disponibles en DATA_DIR.
        Llama a listar_archivos_json() para obtener las rutas actualizadas.
        """
        self._lb_archivos.delete(0, tk.END)
        self._archivos_list = listar_archivos_json()
        if not self._archivos_list:
            self._lb_archivos.insert(tk.END, "  (sin archivos en assets/data/)")
        for p in self._archivos_list:
            self._lb_archivos.insert(tk.END, f"  {p.stem}")

    def _on_archivo_select(self, _event=None):
        """
        Callback: el usuario seleccionó un archivo de área en el listbox.
        Carga el JSON correspondiente y refresca la lista de proyectos.
        """
        sel = self._lb_archivos.curselection()
        if not sel or sel[0] >= len(self._archivos_list):
            return
        self.archivo_actual = self._archivos_list[sel[0]]
        try:
            self.proyectos = cargar_json(self.archivo_actual)
        except Exception as ex:
            messagebox.showerror("Error al cargar JSON", str(ex))
            return
        self.idx_sel  = None
        self.modo_nuevo = False
        self._refresh_proyectos()
        self._editor.clear()
        self._status(f"Área: {self.archivo_actual.stem} — {len(self.proyectos)} proyecto(s)")

    def _abrir_json_externo(self):
        """
        Abre un selector de archivos del sistema para cargar un JSON externo.
        Útil para gestionar archivos fuera de assets/data/.
        """
        path = filedialog.askopenfilename(
            title="Seleccionar archivo JSON de proyectos",
            filetypes=[("JSON", "*.json"), ("Todos", "*.*")],
            initialdir=str(DATA_DIR) if DATA_DIR.exists() else "."
        )
        if not path:
            return
        self.archivo_actual = Path(path)
        try:
            self.proyectos = cargar_json(self.archivo_actual)
        except Exception as ex:
            messagebox.showerror("Error al cargar JSON", str(ex))
            return
        self._refresh_proyectos()
        self._editor.clear()
        self._status(f"Archivo externo: {self.archivo_actual.name} — {len(self.proyectos)} proyecto(s)")

    # ── Lógica de proyectos ────────────────────────────────────────────────────

    def _refresh_proyectos(self):
        """
        Recarga el listbox de proyectos con los datos de self.proyectos.
        Cada ítem muestra el badge de estado, ID y nombre truncado.
        """
        self._lb_proyectos.delete(0, tk.END)
        BADGE = {"active": "●", "risk": "⚠", "delivered": "✔", "paused": "⏸"}
        for p in self.proyectos:
            pid   = p.get("id", "?")
            name  = p.get("name", "(sin nombre)")[:30]
            badge = BADGE.get(p.get("status", ""), "·")
            self._lb_proyectos.insert(tk.END, f"  {badge} [{pid}] {name}")

    def _on_proyecto_select(self, _event=None):
        """
        Callback: el usuario seleccionó un proyecto en el listbox.
        Carga el proyecto seleccionado en el editor.
        """
        sel = self._lb_proyectos.curselection()
        if not sel or sel[0] >= len(self.proyectos):
            return
        self.idx_sel    = sel[0]
        self.modo_nuevo = False
        p = self.proyectos[self.idx_sel]
        self._editor.load_project(p)
        self._status(f"Editando: [{p.get('id')}] {p.get('name', '')[:50]}")

    def _nuevo_proyecto(self):
        """
        Prepara el editor para crear un proyecto nuevo.
        Limpia todos los campos y asigna un ID tentativo (confirmado al guardar).
        """
        if self.archivo_actual is None:
            messagebox.showwarning("Sin área", "Selecciona primero un archivo JSON de área.")
            return
        self.modo_nuevo = True
        self.idx_sel    = None
        self._lb_proyectos.selection_clear(0, tk.END)

        # Crear una plantilla con ID tentativo
        plantilla = copy.deepcopy(PROYECTO_TEMPLATE)
        plantilla["id"] = generar_id_proyecto(self.proyectos)
        self._editor.load_project(plantilla)
        self._status(f"Nuevo proyecto — ID tentativo: {plantilla['id']} (se confirma al guardar)")

    def _eliminar_proyecto(self):
        """
        Elimina el proyecto seleccionado tras confirmación del usuario.
        Guarda el archivo JSON inmediatamente tras la eliminación.
        """
        if self.idx_sel is None:
            messagebox.showwarning("Nada seleccionado", "Selecciona un proyecto para eliminar.")
            return
        p = self.proyectos[self.idx_sel]
        pid, nombre = p.get("id", "?"), p.get("name", "(sin nombre)")

        if not messagebox.askyesno("Confirmar eliminación",
                                   f"¿Eliminar permanentemente?\n\n[{pid}] {nombre}"):
            return

        self.proyectos.pop(self.idx_sel)
        guardar_json(self.archivo_actual, self.proyectos)
        self.idx_sel    = None
        self.modo_nuevo = False
        self._refresh_proyectos()
        self._editor.clear()
        self._status(f"Proyecto [{pid}] eliminado y guardado en {self.archivo_actual.name}")

    def _guardar_proyecto(self, datos: dict):
        """
        Recibe el diccionario del editor, asigna/confirma el ID, actualiza
        la lista en memoria y guarda el archivo JSON en disco.
        También registra una entrada en el historial del proyecto.

        Args:
            datos: Diccionario con todos los campos del proyecto obtenido de get_project().
        """
        # Registrar en historial la acción de guardar
        entrada_historial = {
            "date":   timestamp_ahora(),
            "author": "PANEL",
            "action": "Proyecto creado desde el panel." if self.modo_nuevo else "Proyecto actualizado desde el panel.",
            "detail": "",
        }
        datos.setdefault("history", []).append(entrada_historial)

        if self.modo_nuevo:
            # Confirmar el ID final (puede haber cambiado si se crearon otros proyectos)
            datos["id"] = generar_id_proyecto(self.proyectos)
            self.proyectos.append(datos)
            pid = datos["id"]
        else:
            if self.idx_sel is None or self.idx_sel >= len(self.proyectos):
                messagebox.showerror("Error", "No hay proyecto seleccionado para actualizar.")
                return
            # Preservar el ID original (no permitir que el usuario lo cambie)
            datos["id"] = self.proyectos[self.idx_sel]["id"]
            self.proyectos[self.idx_sel] = datos
            pid = datos["id"]

        # Guardar en disco
        guardar_json(self.archivo_actual, self.proyectos)

        # Actualizar lista y UI
        self.modo_nuevo = False
        self._refresh_proyectos()

        # Mantener la selección en el proyecto recién guardado
        for i, p in enumerate(self.proyectos):
            if p.get("id") == pid:
                self._lb_proyectos.selection_clear(0, tk.END)
                self._lb_proyectos.selection_set(i)
                self._lb_proyectos.see(i)
                self.idx_sel = i
                break

        self._status(f"✔  [{pid}] guardado correctamente en {self.archivo_actual.name}")
        messagebox.showinfo("Guardado", f"Proyecto [{pid}] guardado exitosamente.")

    def _cancelar_edicion(self):
        """
        Cancela la edición actual: limpia el editor y deselecciona la lista.
        """
        self.idx_sel    = None
        self.modo_nuevo = False
        self._lb_proyectos.selection_clear(0, tk.END)
        self._editor.clear()
        self._status("Edición cancelada.")

    # ── Utilidades UI ──────────────────────────────────────────────────────────

    def _mkbtn_small(self, parent, text: str, fg: str, command) -> tk.Button:
        """
        Crea un botón pequeño para las acciones de la columna izquierda.

        Args:
            parent:  Widget padre.
            text:    Texto del botón.
            fg:      Color del texto.
            command: Función a ejecutar al hacer clic.

        Returns:
            tk.Button configurado.
        """
        btn = tk.Button(
            parent, text=text, command=command,
            font=(C["mono"], 8), bg=C["bg3"], fg=fg,
            activebackground=C["border2"], activeforeground=fg,
            relief="flat", bd=0, cursor="hand2",
            padx=8, pady=5
        )
        btn.bind("<Enter>", lambda e: btn.config(bg=C["border"]))
        btn.bind("<Leave>", lambda e: btn.config(bg=C["bg3"]))
        return btn

    def _status(self, msg: str):
        """Actualiza el mensaje de la barra de estado inferior."""
        self._status_var.set(f"  {msg}")


# ═══════════════════════════════════════════════════════════════════════════════
# SECCIÓN 7 — PUNTO DE ENTRADA
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    """
    Punto de entrada principal del panel.

    1. Verifica que DATA_DIR exista y avisa si no se encuentra.
    2. Crea la ventana raíz de tkinter con fondo oscuro.
    3. Instancia PanelProyectos y arranca el bucle principal.
    """
    # Advertencia si no se encuentra el directorio de datos
    if not DATA_DIR.exists():
        print(f"""
┌─ ADVERTENCIA ──────────────────────────────────────────────────┐
│  No se encontró el directorio de datos:                        │
│  {str(DATA_DIR):<62}│
│                                                                │
│  Asegúrate de ejecutar el script desde la raíz del proyecto.   │
│  Puedes usar el botón 'Abrir otro JSON' para cargar un archivo │
│  desde cualquier ubicación del sistema.                        │
└────────────────────────────────────────────────────────────────┘
        """)

    root = tk.Tk()
    root.configure(bg=C["bg"])

    # Suprimir el ícono de tkinter (no es crítico si falla)
    try:
        root.iconbitmap(default="")
    except Exception:
        pass

    # Iniciar la aplicación
    _app = PanelProyectos(root)
    root.mainloop()


if __name__ == "__main__":
    main()
