/* * Módulo 2 · utilidades
    * Colección de funciones puras y helpers reutilizables.
    * No dependen del estado global (salvo donde se indica).
    * Se usan para formato, sanitización y lógica auxiliar.
*/

/* * esc(v)
  * Escapa caracteres especiales para evitar inyección HTML.
  * Útil cuando se renderiza texto dinámico en el DOM.
  * 
  * @param {any} v - Valor a convertir y escapar
  * @return {string} texto seguro para HTML
*/
function esc(v){
  return String(v ?? '')
    // Evita doble interpretación de entidades HTML
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;')
    .replaceAll("'",'&#39;');
}

/* * fn(code)
  * Traduce un código interno a nombre amigable.
  * Usa el mapa MNAMES (definido en otro módulo).
  *
  * @param {string} code - Código identificador
  * @return {string} Nombre legible o el código original
*/
function fn(code){
  return MNAMES[code] || code;
}

/* * toDate(ds)
  * Convierte un string de fecha a objeto Date
  *
  * @param {string|null} ds - Fecha en formato compatible
  * @return {Date|null} Objeto Date o null
*/
function toDate(ds){
  return ds ? new Date(ds) : null;
}

/* * isVD(d)
  * Valida si un objeto Date es válido.
  * (VD = Valid Date)

  * @param {any} d
  * @return {boolean}
*/
function isVD(d){
  return d instanceof Date && !Number.isNaN(d.getTime());
}

/* * daysTo(ds)
  * Calcula cuántos días faltan (o han pasado) desde hoy hasta una fecha dada.
  *
  * @param {string} ds - Fecha objetivo
  * @return {number} Días restantes (negativo = vencido)
*/
function daysTo(ds){
  const d = toDate(ds);
  if(!isVD(d)) return 0;

  // Fecha actual normalizada (sin horas)
  const now = new Date();
  now.setHours(0,0,0,0);

  // Fecha objetivo normalizada
  d.setHours(0,0,0,0);

  // Diferencia en días
  return Math.ceil((d - now) / 864e5);
}

/* * fmtDAte(ds)
  * Devuelve una fecha formateada y su clase visual asociada.
  * Ideal para mostrar vencimientos.
  * 
  * @param {string} ds
  * @return {{s: string, c: string}}
*/
function fmtDate(ds){
  const d = toDate(ds);
  if(!isVD(d)) return { s: 'sin fecha', c: '' };

  const days = daysTo(ds);

  // Fecha corta en formato colombiano
  const s = d.toLocaleDateString('es-CO', { day:'numeric', month:'short' });

  // Clasificación por vencimiento
  if(days < 0) return { s: `${s} · vencido`, c: 'past' };
  if(days <= 7) return { s: `${s} · ${days}d`, c: 'soon' };

  return { s, c: '' };
}

/* * pct(p)
  * Calcula el porcentaje de entregables completados de un proyecto
  *
  * @param {object} p - Proyecto
  * @return {number} Porcentaje (0-100)
*/
function pct(p){
  if(!p.deliverables?.length) return 0;

  const done = p.deliverables.filter(d => d.done).length;
  return Math.round(done / p.deliverables.length * 100);
}

/* * pbCls(p)
  * Devuelve la clase CSS para la barra de progreso según estado o porcentaje.
  *
  * @param {Object} p - Proyecto
  * @return {string} Clase CSS
*/
function pbCls(p){
  if(p.status === 'delivered') return 'pb-info';
  if(p.status === 'risk') return 'pb-warn';
  const progress = pct(p);
  return progress >= 70 ? 'pb-ok' : progress >= 40 ? 'pb-warn' : 'pb-bad';
}

/* * sbadge(s)
  * Genera el HTML de un badge de estado.
  *
  * @param {string} s - Estado del proyecto
  * @return {string} HTML del badge
*/
function sbadge(s){
  const map = { active:'b-active', risk:'b-risk', delivered:'b-delivered', paused:'b-paused' };
  const label = { active:'activo', risk:'en riesgo', delivered:'entregado', paused:'pausado' };
  return `<span class="badge ${map[s] || 'b-paused'}">${label[s] || s}</span>`;
}

/* * isDark()
  * Detecta si el tema actual es oscuro
  *
  * @return {boolean}
*/
function isDark(){
  return document.documentElement.getAttribute('data-theme') === 'dark';
}

/* * setThemeLabel()
  * Actualiza el texto del indicador de tema en el botón de toggle.
*/
function setThemeLabel(){
  const lbl = document.getElementById('tog-lbl');
  if(lbl) lbl.textContent = isDark() ? '🌙' : '☀️'; 
}
