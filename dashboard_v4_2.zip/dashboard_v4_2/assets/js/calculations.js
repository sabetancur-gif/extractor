/* * Módulo 3 · cálculos ejecutivos
  * Métricas de negocio, indicadores de riesgo y agregaciones a nivel de portafolio de portafolio.
  *
  * Este módulo consume el estado global `S.projects` y funciones auxiliares del Módulo 2 (toDate, isVD, daysTO, pct).
*/

/* * statusCounts()
  * Cuenta la cantidad de proyectos por estado.
  *
  * @return {Object} { active, risk, delivered, paused }
*/
function statusCounts(){
  const counts = { active:0, risk:0, delivered:0, paused:0 };
  for(const p of S.projects) counts[p.status] = (counts[p.status] || 0) + 1;
  return counts;
}

/* *memberCounts()
  * Cuenta cuántos proyectos tiene asignado cada miembro.
  * Útil para ranking de carga individual.
  * 
  * @return {Array<[string, number]>} pares [miembro, cantidad]
*/
function memberCounts(){
  const map = new Map();
  for(const p of S.projects){
    for(const a of p.assignees || []) map.set(a, (map.get(a) || 0) + 1);
  }

  // Orden descendente por número de asignaciones
  return [...map.entries()].sort((a,b) => b[1] - a[1]);
}

/* * completionRate()
  * Porcentaje global de entregables completados en todo el portafolio.
  *
  * @return {number} porcentaje 0–100
*/
function completionRate(){
  const dels = S.projects.flatMap(p => p.deliverables || []);
  if(!dels.length) return 0;
  return Math.round(dels.filter(d => d.done).length / dels.length * 100);
}

/* * overdueDeliverablesCount()
  * Cuenta los entregables vencidos (no hechos y fuera de SLA).
  *
  * @return {number}
*/
function overdueDeliverablesCount(){
  const today = new Date();
  today.setHours(0,0,0,0);

  let c = 0;

  for(const p of S.projects){
    for(const d of p.deliverables || []){
      if(!d.done && d.sla){
        const dd = toDate(d.sla);
        if(isVD(dd)){
          dd.setHours(0,0,0,0);
          if(dd < today) c++;
        }
      }
    }
  }

  return c;
}
/* * blockedProjectsCount()
  * Cuenta proyectos bloqueados (con blockers activos)
  * excluyendo los ya entregados.
  * 
  * @return {number}
*/
function blockedProjectsCount(){
  return S.projects.filter(p => (p.blockers || []).length > 0 && p.status !== 'delivered').length;
}

/* *deliveredRecently()
  * Cuenta entregables cerrados en los últimos 14 días.
  * Sirve como base para la métrica de velocidad.
  * 
  * @return {number}
*/
function deliveredRecently(){
  const now = new Date();
  now.setHours(0,0,0,0);

  let count = 0;

  for(const p of S.projects){
    for(const d of p.deliverables || []){
      if(d.done && d.actual){
        const dd = toDate(d.actual);
        if(isVD(dd)){
          dd.setHours(0,0,0,0);
          const delta = Math.round((now - dd) / 864e5);
          if(delta >= 0 && delta <= 14) count++;
        }
      }
    }
  }
  return count;
}

/* *loadVsCapacity()
  * Calcula la carga total asignada vs la capacidad del equipo.
  *
  * MCAP define la capacidad máxima por miembro.
  * 
  * @return {Object} { assigned, cap, pct }
*/
function loadVsCapacity(){
  const load = new Map();

  // Conteo de asignaciones por persona
  for(const p of S.projects){
    for(const a of p.assignees || []) load.set(a, (load.get(a) || 0) + 1);
  }
  let assigned = 0, cap = 0;
  for(const [member, tasks] of load.entries()){
    assigned += tasks;
    cap += (MCAP[member] || 2);
  }
  return { assigned, cap, pct: cap ? Math.round((assigned / cap) * 100) : 0 };
}

/* * velocity()
  * Métrica simple de velocidad:
  * entregables cerrados en los últimos 14 días.
  * 
  * @return {number}
*/
function velocity(){
  // Cantidad de entregables cerrados en la ventana de 14 días.
  return deliveredRecently();
}

/* * riskScore(p)
  * Calcula un score numérico de riesgo (0-100) por proyecto.
  * Combina factores de negocio, técnicos, fechas y ejecución.
  * 
  * @param {Object} p - Proyecto
  * @return {number} Score normalizado
*/
function riskScore(p){
  // Factores estructurales
  const business = (p.businessPriority || 0) * 6;
  const technical = (p.technicalSeverity || 0) * 5;
  const urgency = (p.urgency || 0) * 5;
  const dependency = (p.dependencyCriticality || 0) * 4;

  // Penalización por fecha
  const overdue = Math.max(0, -daysTo(p.deadline)) * 5;
  const near = daysTo(p.deadline);
  const nearPenalty = near >= 0 && near <= 7 ? (8 - near) * 3 : 0;

  // Blockers
  const critBlockers = (p.blockers || []).filter(b => b.severity === 'crit').length;
  const medBlockers = (p.blockers || []).filter(b => b.severity !== 'crit').length;
  const blockers = Math.min((critBlockers * 10) + (medBlockers * 5), 25);

  // Ejecución
  const progressPenalty = Math.max(0, 60 - pct(p)) * 0.4;

  // Estado explícito
  const statusPenalty = p.status === 'risk' ? 14 : p.status === 'paused' ? 18 : 0;

  const score =
      business + technical + urgency + dependency +
      overdue + nearPenalty + blockers +
      progressPenalty + statusPenalty;

  return Math.max(0, Math.min(100, Math.round(score)));
}

/* * riskLabel(score)
  * Traduce el score númerico a un a etiqueta ejecutiva.
  *
  * @param {number} score
  * @return {string}
*/
function riskLabel(score){
  if(score >= 80) return 'Crítico';
  if(score >= 60) return 'Alto';
  if(score >= 35) return 'Medio';
  return 'Bajo';
}

/* * riskCls(score)
  * Devuelve la clase CSS asociada al nivel de riesgo.
  *
  * @param {number} score
  * @return {string}
*/
function riskCls(score){
  if(score >= 80) return 'crit';
  if(score >= 60) return 'high';
  if(score >= 35) return 'med';
  return 'low';
}

/* * execKpis()
  * Genera el set completo de KPIs ejecutivos del portafolio.
  * El resultado se usa directamente para dashboards.
  * 
  * @return {Array<Object>} KPIs
*/
function execKpis(){
  const cap = loadVsCapacity();
  const overdue = overdueDeliverablesCount();
  const blocked = blockedProjectsCount();

  const avgRisk = S.projects.length ? Math.round(S.projects.reduce((a,p) => a + riskScore(p), 0) / S.projects.length) : 0;

  const portfolioProgress = completionRate();
  const sprintVel = velocity();
  const riskProjects = S.projects.filter(p => riskScore(p) >= 60).length;
  const totalBlockers = S.projects.reduce((a,p) => a + (p.blockers || []).length, 0);

  return [
    { l: t('kpi_avance_titulo'), v:`${portfolioProgress}`, u:'%', s:`${S.projects.flatMap(p => p.deliverables || []).filter(d => d.done).length} ${t('kpi_avance_sub')}`, cls: portfolioProgress >= 75 ? 'ok' : portfolioProgress >= 45 ? 'warn' : 'bad', ico: `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/bar-chart.svg" style="filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">` },
    { l: t('kpi_riesgo_titulo'), v:`${avgRisk}`, u:'', s:`${riskProjects} ${t('kpi_riesgo_sub')}`, cls: avgRisk >= 60 ? 'bad' : avgRisk >= 35 ? 'warn' : 'ok', ico: `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/exclamation-triangle.svg" style="filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">` },
    { l: t('kpi_sla_titulo'), v:`${overdue}`, u:'', s: t('kpi_sla_sub'), cls: overdue ? 'bad' : 'ok', ico: `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/clock.svg" style="filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">` },
    { l: t('kpi_carga_titulo'), v:`${cap.pct}`, u:'%', s:`${cap.assigned}/${cap.cap} ${t('kpi_carga_sub')}`, cls: cap.pct >= 100 ? 'bad' : cap.pct >= 75 ? 'warn' : 'ok', ico: `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/people.svg" style="filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);"> ` },
    { l: t('kpi_velocidad_titulo'), v:`${sprintVel}`, u:'', s: t('kpi_velocidad_sub'), cls: sprintVel >= 4 ? 'ok' : sprintVel >= 2 ? 'warn' : 'bad', ico: `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/lightning.svg" style="filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">` },
    { l: t('kpi_blockers_titulo'), v:`${totalBlockers}`, u:'', s:`${blocked} ${t('kpi_blockers_sub')}`, cls: totalBlockers ? 'bad' : 'ok', ico: `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/cone-striped.svg" style="filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">` }
  ];
}

/* *deliverableStatusCounts()
  * Resumen del estado de entregables a nivel global.
  *
  * @return {Object}
*/
function deliverableStatusCounts(){
  const all = S.projects.flatMap(p => p.deliverables || []);

  const completed = all.filter(d => d.done).length;
  const overdue = all.filter(d => !d.done && d.sla && daysTo(d.sla) < 0).length;
  const pending = all.length - completed - overdue;

  return { completed, pending, overdue, total: all.length };
}
