/* Módulo 4 · renderizado de vistas
  * Responsabilidad:
    * - Generar HTML del dashboard ejecutivo
    * - Renderizar tarjetas, pestañas, gráficos y panel de detalle
    * - Montar y destruir instancias de Chart.js
 */

/**
 * Colores base usados en todos los charts del dashboard.
 * Centralizar aquí evita hardcode y facilita cambios de tema. 
 */
const CHART_COLORS = {
  blue:   '#5bbdff',
  green:  '#2ee89a',
  amber:  '#ffb547',
  red:    '#ff5c5c',
  purple: '#b47cff',
  cyan:   '#2de8d0',
  pink:   '#ff6fae',
  indigo: '#6c7cff',
  teal:   '#00bfae',
  lime:   '#a3e635',
  orange: '#ff8a3d',
  slate:  '#64748b',
  gold:   '#facc15',
  magenta:'#d946ef',
};

/**
 * Asigna un color consistente a un nombre
 */
function memberColor(name){
  // Lista de colores disponibles
  const colors = Object.values(CHART_COLORS)

  // Hash simple basado en el nombre (consistente siempre)
  // Inicializa el hash en 0
  let hash = 3381;

  // Recorre cada carácter del string 'name'
  for(let i = 0; i < name.length; i++){
    // Genera un hash usando el código ASCII del carácter
    // (hash << 5) - hash equivale a hash * 31
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  // Devuelve un color basado en el hash:
  // - Math.abs evita valores negativos
  // - % colors.length asegura que el índice sea válido
  return colors[Math.abs(hash) % colors.length];
}

/**
 * Funcion que genera un avatar en HTML
 */
function av(i){
  // Obtiene el color asignado al valor 'i'
  const color = memberColor(i);

  // Retorna un string HTML
  return `<div class="av" 
    style="background:${color}22;color:${color};border:1px solid ${color}" 
    title="${esc(fn(i))}" 
    aria-label="${esc(fn(i))}">
    ${esc(i)}
  </div>`;
}

/**
 * Destruye todas las instancias de gráficos activos.
 * Importante para evitar fugas de memoria al rerenderizar.
 */
function clearCharts(){
  if(window._charts){
    for(const ch of window._charts){
      try{ ch.destroy(); }catch(e){}
    }
    window._charts = [];
  }
}

/**
 * Registra una nueva instancia de Chart.js
 * @param {Chart} ch - Instancia del gráfico 
 */
function regCh(ch){
  if(!window._charts) window._charts = [];
  window._charts.push(ch);
}

/**
 * Estilo de tooltip adaptado al tema actual
 * @returns {Object} configuración Chart.js tooltip
 */
function ttStyle(){
  const dk = isDark();
  return {
    backgroundColor: dk ? '#101c2a' : '#fff',
    titleColor: dk ? '#ddeeff' : '#0a1f35',
    bodyColor: dk ? '#7a9db8' : '#3a6080',
    borderColor: dk ? '#1a2e42' : '#ccdaec',
    borderWidth: 1,
    padding: 10,
    cornerRadius: 8
  };
}

/** Grid común para ejes */
function gridStyle(){
  return { color: isDark() ? 'rgba(26,46,66,.7)' : 'rgba(204,218,236,.5)' };
}

/** Estilo estándar de ticks */
function tickStyle(){
  return { color: isDark() ? '#3d5f7a' : '#8aa8c4', font: { family: "'JetBrains Mono',monospace", size: 10 } };
}

/** Leyenda consistente entre gráficos */
function legendStyle(){
  return {
    display: true,
    position: 'bottom',
    labels: { color: isDark() ? '#7a9db8' : '#3a6080', font: { family: "'JetBrains Mono',monospace", size: 10 }, boxWidth: 10, padding: 12 }
  };
}

/**
 * Genera un SVG tipo donut para distribución ejecutiva
 * No usa canvas. Mejor performance en render inicial
 * 
 * @param {Object} data - Conteo por estado (active, risk, delivered, paused) 
 * @returns {string} SVG como string HTML
 */
function donutSVG(data){
  // Definición de segmentos visibles
  const items = [
    { k:'active', color: CHART_COLORS.green },
    { k:'risk', color: CHART_COLORS.amber },
    { k:'delivered', color: CHART_COLORS.blue },
    { k:'paused', color: '#7a9db8' }
  ];

  // Total con guard clause para evitar div/0
  const total = items.reduce((acc, x) => acc + (data[x.k] || 0), 0) || 1;

  // Parámetros geométricos
  let start = -90;
  const cx = 56, cy = 56, r = 38, sw = 13, circ = 2 * Math.PI * r;

  // Construcción de segmentos SVG 
  const parts = items.filter(x => (data[x.k] || 0) > 0).map(x => {
    const val = data[x.k] || 0;
    const len = circ * val / total;
    const off = circ * (start + 90) / 360;
    const angle = (val / total) * 360;
    const seg = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${x.color}" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${len} ${circ - len}" stroke-dashoffset="${-off}"></circle>`;
    start += angle;

    return seg;
  }).join('');

  const dk = isDark();

  // SVG final
  return `
    <svg viewBox="0 0 112 112" width="106" height="106" aria-label="Distribución ejecutiva">
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${dk ? '#1a2e42' : '#ccdaec'}" stroke-width="${sw}"></circle>
      ${parts}
      <circle cx="${cx}" cy="${cy}" r="24" fill="${dk ? '#0c1520' : '#fff'}"></circle>
      <text x="56" y="53" text-anchor="middle" fill="${dk ? '#ddeeff' : '#0a1f35'}" font-size="17" font-family="'JetBrains Mono',monospace" font-weight="700">${total}</text>
      <text x="56" y="67" text-anchor="middle" fill="#3d5f7a" font-size="8" font-family="'JetBrains Mono',monospace" letter-spacing=".1em">TOTAL</text>
    </svg>`;
}

/**
 * Renderiza el header principal del dashboard.
 * Incluye:
 * - Fecha actual localizada
 * - Título y descripción ejecutiva
 * - KPIs agregados del portafolio
 * - Riesgp promedio ponderado de proyectos
 * @returns {string} HTML del header
 */
function renderHeader(){
  const today = new Date().toLocaleDateString('es-CO', { weekday:'short', day:'numeric', month:'short', year:'numeric' });
  const avgR  = S.projects.length ? Math.round(S.projects.reduce((a,p) => a + riskScore(p), 0) / S.projects.length) : 0;
  const rCol  = avgR >= 60 ? 'var(--danger)' : avgR >= 35 ? 'var(--warn)' : 'var(--ok)';
  const userColor = WLC.user ? memberColor(WLC.user) : 'var(--accent)';

  return `
    <div class="hdr">
      <div>
        <p class="team-tag"><span class="pulse-dot"></span>${t('header_etiqueta')}</p>
        <p class="hdr-title">${t('titulo_principal')}</p>
        <p class="hdr-desc">${t('subtitulo')}</p>
      </div>
      <div class="hdr-right">
        <div class="ctrl-btns">
          <button class="tog tog-theme" onclick="toggleTheme()" aria-label="Cambiar tema">
            <span id="tog-lbl"></span>
          </button>
          <button id="btn-idioma" class="tog tog-lang" onclick="cambiarIdioma()" aria-label="Cambiar idioma"></button>
          ${WLC.user ? `
            <button class="tog tog-user" onclick="wlcLogout()" title="Cerrar sesión · ${esc(MNAMES[WLC.user]||WLC.user)}"
              style="border-color:${userColor};color:${userColor}">
              <span style="font-size:13px;font-weight:800">${esc(WLC.user)}</span>
              <span style="font-size:9px;opacity:.7">✕</span>
            </button>` : ''}
        </div>
        <div class="hdr-meta">
          <div>${esc(today)}</div>
          <div style="color:var(--accent);margin-top:3px">${t('sprint_activo')}</div>
          <div style="margin-top:5px">${t('riesgo_medio')}: <span style="color:${rCol};font-weight:700">${avgR}/100</span></div>
          <div style="margin-top:5px">${t('proyectos_activos_label')}</div>
        </div>
      </div>
    </div>
    <div class="kpis">
      ${execKpis().map(k => `
        <div class="kpi ${k.cls}">
          <div class="kpi-ico">${k.ico}</div>
          <p class="kpi-lbl">${esc(k.l)}</p>
          <p class="kpi-val">${esc(k.v)}<span style="font-size:13px;font-family:var(--mono);color:var(--soft)">${k.u}</span></p>
          <p class="kpi-sub">${esc(k.s)}</p>
        </div>
      `).join('')}
    </div>`;
}

/**
 * Renderiza la fila de analítica ejecutiva:
 * - Distribución de estados (donut SVG)
 * - Carga por miembro
 * - Próximos vencimientos
 * @returns {string} HTML analítico
 */
function renderAnalytics(){
  const counts = statusCounts();  // Conteo por estado
  const mem = memberCounts();     // Asignaciones por miembro

  // Próximos 4 deadlines más cercanos
  const deadlines = [...S.projects].sort((a,b) => daysTo(a.deadline) - daysTo(b.deadline)).slice(0,4);

  const cap = loadVsCapacity(); // Capacidad total vs asignada

  return `
    <div class="an-row">
      <div class="card">
        <p class="card-title"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/bullseye.svg" style="filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg); margin-right: .4rem;">${t('panel_distribucion')}</p>
        <div class="donut-wrap">
          ${donutSVG(counts)}
          <div class="donut-legend">
            <div class="leg"><span class="leg-left"><span class="dot" style="background:${CHART_COLORS.green}"></span>${t('estado_activos')}</span><span>${counts.active || 0}</span></div>
            <div class="leg"><span class="leg-left"><span class="dot" style="background:${CHART_COLORS.amber}"></span>${t('estado_riesgo')}</span><span>${counts.risk || 0}</span></div>
            <div class="leg"><span class="leg-left"><span class="dot" style="background:${CHART_COLORS.blue}"></span>${t('estado_entregados')}</span><span>${counts.delivered || 0}</span></div>
            <div class="leg"><span class="leg-left"><span class="dot" style="background:#7a9db8"></span>${t('estado_pausados')}</span><span>${counts.paused || 0}</span></div>
          </div>
        </div>
      </div>
      <div class="card">
        <p class="card-title"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/people.svg" style="width:1rem;height:1rem;vertical-align:-0.15em;margin-right:.35rem; filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">${t('panel_carga_miembro')}<span style="margin-left:auto;font-size:11px;color:var(--soft)">${cap.assigned}/${cap.cap}</span></p>
        <div class="mbars">
          ${mem.length ? mem.map(([m,c]) => {
            const color = memberColor(m);

            return `
              <div class="mbrow">
                <div class="mblbl">${esc(fn(m).split(' ')[0])}</div>
                <div class="mbtrack">
                  <div class="mbfill" style="
                    width:${Math.max(8, Math.round(c / Math.max(...mem.map(x => x[1]), 1) * 100))}%;
                    background:${color};
                  "></div>
                </div>
                <div class="mbnum">${c}</div>
              </div>
            `;
          }).join('') : '<div style="font-size:12px;color:var(--soft)">Sin asignaciones</div>'}
        </div>
      </div>
      <div class="card">
        <p class="card-title"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/calendar-event.svg" style="width:1rem;height:1rem;margin-right:.4rem;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">${t('panel_proximos')}</p>
        <div class="deadlist">
          ${deadlines.map(p => {
            const d = fmtDate(p.deadline);
            const pr = pct(p);
            return `
              <div class="deaditem">
                <div class="deadtop">
                  <p class="deadname">${esc(p.name.slice(0,44))}${p.name.length > 44 ? '…' : ''}</p>
                  <span class="deadmeta ${d.c}">${esc(d.s)}</span>
                </div>
                <div class="deadprog"><div class="${pbCls(p)} pb" style="width:${pr}%"></div></div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    </div>`;
}

/**
 * Renderiza los contenedores HTML de los gráficos principales.
 * NOTA: no cregráficos, solo canvas.
 */
function renderChartsRow1(){
  return `
    <div class="sec3">
      <div class="card">
        <p class="card-title"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/fire.svg" style="width:14px;height:14px;vertical-align:-2px; filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">${t('chart_radar_titulo')}</p>
        <div class="chart-wrap" style="height:260px"><canvas id="ch-radar" role="img" aria-label="Radar de riesgo por proyecto"></canvas></div>
      </div>
      <div class="card">
        <p class="card-title"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/graph-up.svg" style="filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg); margin-right:.4rem;">${t('chart_burndown_titulo')}</p>
        <div class="chart-wrap" style="height:260px"><canvas id="ch-burn" role="img" aria-label="Burndown de entregables"></canvas></div>
      </div>
      <div class="card">
        <p class="card-title"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/bar-chart-line.svg" style="filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg); margin-right:.4rem;">${t('chart_estados_titulo')}</p>
        <div class="chart-wrap" style="height:260px"><canvas id="ch-dough" role="img" aria-label="Entregables por estado"></canvas></div>
      </div>
    </div>`;
}

/**
 * Inicializa los gráficos Chart.js de la primera fila analítica.
 * - Radar de riesgo por proyecto
 * - Burndown de entregables
 * - Donut de entregables por estado
 * 
 * Se ejecuta tras el render (requestAnimationFrame).
 * Usa la bandera `_mounted` en cada canvas para evitar recrear gráficos existentes y generar fugas de memoria.
 */
function mountChartsRow1(){
  // Estilos reutilizables dependientes del tema (dark / light)
  const tt = ttStyle();
  const grid = gridStyle();
  const ticks = tickStyle();
  const legend = legendStyle();

  /** Radar de riesgo por royecto
   * Visualiza, por proyecto, los principales factores de riesgo:
   * - Prioridad de negocio
   * - Severidad técnica
   * - Urgencia
   * - Dependencias críticas
   * - Blockers activos (normalizados)
   * - progreso general (normalizado)
   * 
   * Se limita a los primeros 3 proyectos para mantener legibilidad.
   */
  const rCtx = document.getElementById('ch-radar');
  if(rCtx && !rCtx._mounted){
    rCtx._mounted = true;
    const ch = new Chart(rCtx, {
      type: 'radar',
      data: {
        labels: [t('eje_prioridad'), t('eje_severidad'), t('eje_urgencia'), t('eje_dependencia'), t('eje_blockers'), t('eje_progreso')],
        datasets: S.projects.slice(0,3).map((p, i) => ({
          label: `${p.name.slice(0,16)}…`,
          data: [
            p.businessPriority || 0,
            p.technicalSeverity || 0,
            p.urgency || 0,
            p.dependencyCriticality || 0,
            // Blockers limitados a 5 para evitar picos extremos
            Math.min((p.blockers || []).length, 5),
            // Progreso normalizado a escala 0-5
            Math.round(pct(p) / 20)
          ],
          borderColor: [CHART_COLORS.blue, CHART_COLORS.green, CHART_COLORS.amber][i],
          backgroundColor: [CHART_COLORS.blue + '22', CHART_COLORS.green + '22', CHART_COLORS.amber + '22'][i],
          borderWidth: 2,
          pointBackgroundColor: [CHART_COLORS.blue, CHART_COLORS.green, CHART_COLORS.amber][i],
          pointRadius: 4
        }))
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend, tooltip: { ...tt } },
        scales: {
          r: {
            grid: { color: isDark() ? 'rgba(26,46,66,.9)' : 'rgba(204,218,236,.5)' },
            angleLines: { color: isDark() ? 'rgba(26,46,66,.9)' : 'rgba(204,218,236,.5)' },
            ticks: { color: isDark() ? '#3d5f7a' : '#8aa8c4', font: { size: 9 }, backdropColor: 'transparent' },
            pointLabels: { color: isDark() ? '#7a9db8' : '#3a6080', font: { family: "'JetBrains Mono',monospace", size: 10 } },
            min: 0,
            max: 5
          }
        }
      }
    });
    regCh(ch);
  }

  /** Burndown de entregables
   * Compara la curva ideal de quema de entregables
   * contra la curva real basada en entregables completados.
   * 
   * - Ideal: Línea descendente uniforme
   * - Real: progreso observado del equipo
   */
  const bCtx = document.getElementById('ch-burn');
  if(bCtx && !bCtx._mounted){
    bCtx._mounted = true;

    // Total de entregables del portafolio (guard clause incluida)
    const totalD = S.projects.flatMap(p => p.deliverables || []).length || 1;
    // Entregables marcados como completados
    const doneD = S.projects.flatMap(p => p.deliverables || []).filter(d => d.done).length;
    // Etiquetas temporales simuladas (sprints / semanas)
    const labels = ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4', 'Sem 5', 'Sem 6', 'Actual'];
    // Curva ideal: disminución lineal
    const ideal = labels.map((_, i) => Math.round(totalD - (totalD / 6) * i));
    // Curva real: aproximación basada en progreso actual
    const actual = [
      totalD,
      ...Array(5).fill(null).map((_, i) => Math.max(0, totalD - Math.round(doneD / 2 * (i / 4)))),
      totalD - doneD
    ];
    const ch = new Chart(bCtx, {
      type: 'line',
      data: {
        labels,
        datasets: [
          { label: 'Ideal', data: ideal, borderColor: CHART_COLORS.blue + '88', borderDash: [6,3], borderWidth: 1.5, pointRadius: 0, fill: false },
          { label: 'Real', data: actual, borderColor: CHART_COLORS.green, backgroundColor: CHART_COLORS.green + '18', borderWidth: 2.5, pointBackgroundColor: CHART_COLORS.green, pointRadius: 4, fill: true, tension: .3 }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend, tooltip: { ...tt } },
        scales: {
          x: { grid, ticks },
          y: { grid, ticks, title: { display: true, text: 'Pendientes', color: isDark() ? '#3d5f7a' : '#8aa8c4', font: { size: 10 } } }
        }
      }
    });
    regCh(ch);
  }

  /** Donut de entregables por estado
   * Muestra la distribución actual:
   * - Completados
   * - Pendientes
   * - Vencidos
   */
  const dCtx = document.getElementById('ch-dough');
  if(dCtx && !dCtx._mounted){
    dCtx._mounted = true;
    const { completed, pending, overdue } = deliverableStatusCounts();
    const dk = isDark();
    const ch = new Chart(dCtx, {
      type: 'doughnut',
      data: {
        labels: [t('chart_completados'), t('chart_pendientes'), t('chart_vencidos')],
        datasets: [{ data: [completed, pending, overdue], backgroundColor: [CHART_COLORS.green + 'cc', CHART_COLORS.blue + 'cc', CHART_COLORS.red + 'cc'], borderColor: dk ? '#0c1520' : '#fff', borderWidth: 3, hoverOffset: 6 }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        plugins: { legend: legendStyle(), tooltip: { ...ttStyle() } }
      }
    });
    regCh(ch);
  }
}

/** Renderiza el panel global de blockers activos del portafolio.
 * - Consolida blockers de todos los proyectos NO entregados
 * - Distingue entre críticos y medios
 * - Permite navegación directa al proyecto afectado
 * - Se muestra como sección colapsable para no saturar la vista
 * 
 * @returns {string} HTML del panel del blockers o string vacío si no hay blockers
 */
function renderBlockers(){
  // Recolecta todos los blockers de proyectos activos / en riesgo / pausados
  // Se enriquece cada blocker con nombre e id del proyecto 
  const all = S.projects
    .filter(p => p.status !== 'delivered')
    .flatMap(p => (p.blockers || []).map(b => ({ ...b, proj: p.name, projId: p.id })));

  // Si no hay blockers activos, no se renderiza la sección
  if(!all.length) return '';

  // Clasificación por severidad
  const crits = all.filter(b => b.severity === 'crit');
  const meds = all.filter(b => b.severity !== 'crit');

  return `
    <div class="sec-full">
      <details class="card collapsible" open>
        <summary>
          <div class="collapsible-head">
            <div class="collapsible-title">
              <span style="display:inline-flex;align-items:center;"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/cone-striped.svg" style="width:16px;height:16px;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);"alt="En progreso"></span>
              <span>${t('blockers_titulo')}</span>
              <span style="font-size:10px;padding:3px 9px;border-radius:999px;background:rgba(255,92,92,.12);color:var(--danger);border:1px solid rgba(255,92,92,.2)">${crits.length} ${t('blockers_criticos')}</span>
              <span style="font-size:10px;padding:3px 9px;border-radius:999px;background:rgba(255,181,71,.1);color:var(--warn);border:1px solid rgba(255,181,71,.2)">${meds.length} ${t('blockers_medios')}</span>
            </div>
            <span class="collapse-arrow" style="font-family:var(--mono);color:var(--soft)">▾</span>
          </div>
        </summary>
        <div class="collapsible-body">
          <div class="blocker-grid">
            ${
              // Renderizado de cada blocker como tarjeta clicable
              all.map(b => `
              <div class="blocker-item ${b.severity !== 'crit' ? 'warn-blk' : ''}" onclick="pick('${esc(b.projId)}')">
                <div class="bl-top">
                  <p class="bl-name">${esc(b.text)}</p>
                  <span class="bl-badge ${b.severity === 'crit' ? 'crit' : 'med'}">${b.severity === 'crit' ? t('badge_critico') : t('badge_medio')}</span>
                </div>
                <p class="bl-proj">↗ ${esc(b.proj.slice(0,58))}${b.proj.length > 58 ? '…' : ''}</p>
              </div>
            `).join('')}
          </div>
        </div>
      </details>
    </div>`;
}

/** Renderiza la tarjeta resumida de un proyecto en la grilla principal.
 * La tarjeta muestra información clave de estado:
 * - Nombre, descripción y estado actual
 * - Progreso visual y fecha límite 
 * - Stack tecnológico
 * - Blockers relevantes
 * - Métricas rápidas (risk score, notas, blockers)
 * 
 * La tarjeta es clicable y permite seleccionar el proyecto
 * para mostrar el panel de detalle.
 * 
 * @param {Object} p - Proyecto a renderizar
 * @returns {string} HTML de la tarjeta del proyecto
 */
function renderCard(p){
  // Fecha de deadline formateada y clasificada visualmente
  const dl = fmtDate(p.deadline);
  // Porcentaje de avance calculado a partir de entregables
  const pc = pct(p);
  // Indica si la tarjeta Corresponde al proyecto actualmente seleccionado
  const sel = S.sel === p.id;
  // Risk score agregado del proyecto (0-100)
  const rs = riskScore(p);

  /** Renderizado compacto de blockers
   * - Se muestran máximo 2
   * - El resto se resume con un contador
   * - Diferente color según severidad
   */
  const blkHtml = (p.blockers || []).length ? `
    <div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:11px">
      ${
        // Primeros dos blockers visibles
        (p.blockers || []).slice(0,2).map(b => `
        <span style="font-size:10px;font-family:var(--mono);padding:3px 8px;border-radius:999px;background:rgba(255,${b.severity === 'crit' ? '92,92' : '181,71'},.1);color:var(--${b.severity === 'crit' ? 'danger' : 'warn'});border:1px solid rgba(255,${b.severity === 'crit' ? '92,92' : '181,71'},.2)">⚠ ${esc(b.text.slice(0,28))}${b.text.length > 28 ? '…' : ''}</span>
      `).join('')}
      ${
        // Indicador de blockers adicionales no visibles
        (p.blockers || []).length > 2 ? `<span style="font-size:10px;font-family:var(--mono);padding:3px 8px;border-radius:999px;color:var(--soft)">+${(p.blockers || []).length - 2} más</span>` : ''}
    </div>` : '';

  return `
    <div class="pcard${sel ? ' sel' : ''}" onclick="pick('${p.id}')">
      <div class="pc-top"><p class="pc-name">${esc(p.name)}</p>${sbadge(p.status)}</div>
      <p class="pc-desc">${esc(p.description.slice(0,100))}${p.description.length > 100 ? '…' : ''}</p>
      <div class="tech-row">${(p.tech || []).map(t => `<span class="tt">${esc(t)}</span>`).join('')}</div>
      <div class="prog-bar"><div class="${pbCls(p)} pb" style="width:${pc}%"></div></div>
      <div class="pc-meta"><span class="dl ${dl.c}">${esc(dl.s)}</span><span style="font-size:11px;color:var(--soft);font-family:var(--mono)">${pc}%</span></div>
      ${blkHtml}
      <div class="pc-foot">
        <div class="avs">${(p.assignees || []).map(a => av(a)).join('')}</div>
        <div class="pill-row"><span class="rpill ${riskCls(rs)}">RS ${rs}</span><span class="rpill">${(p.comments || []).length} ${t('label_notas')}</span><span class="rpill">${(p.blockers || []).length} ${t('label_blockers')}</span></div>
      </div>
    </div>`;
}

/** Renderiza la pestaña ejecutiva del detalle del proyecto.
 * 
 * Está pensada para stakeholders y toma de decisiones rápidas.
 * Resume:
 * - Progreso general
 * - Risk score y factores que lo componen
 * - Fechas clave (deadline, SLA, enntrega real)
 * - Capacidad, blockers y dependencias
 * 
 * @param {Object} p - Proyecto seleccionado
 * @returns {string} HTML de la vista ejecutiva
 */
function tabExec(p){
  // Risk score agregado del proyecto
  const rs = riskScore(p);
  return `
    <div class="exec-grid">
      <div class="mcard">
        <p class="mcard-title">${t('Resumen general')}</p>
        <p class="mcard-val">${pct(p)}<span>% ${t('avance')}</span></p>
        <p class="mcard-desc">${riskLabel(rs)} · ${t('combinación de prioridad, severidad, urgencia, dependencias, blockers y vencimiento.')}</p>
        <div class="badge-stack">
          <span class="rpill ${riskCls(rs)}">RS ${rs}</span>
          <span class="rpill">${Math.max(0, daysTo(p.deadline))}d ${t('para deadline')}</span>
          <span class="rpill">${p.deliverables.filter(d => d.done).length}/${p.deliverables.length} ${t('entregables')}</span>
        </div>
        <div class="mrows">
          <div class="mrow"><span>${t('Estado')}</span>${sbadge(p.status)}</div>
          <div class="mrow"><span>${t('Deadline')}</span><strong>${esc(fmtDate(p.deadline).s)}</strong></div>
          <div class="mrow"><span>${t('SLA comprometido')}</span><strong>${esc(p.committedAt || t('nd'))}</strong></div>
          <div class="mrow"><span>${t('Entrega real')}</span><strong>${esc(p.actualAt || t('entregable_pendiente'))}</strong></div>
        </div>
      </div>
      <div class="mcard">
        <p class="mcard-title">${t('Factor de riesgo')}</p>
        <div class="score-bars">
          ${[
            [t('Prioridad negocio'), p.businessPriority || 0, 5],
            [t('Severidad técnica'), p.technicalSeverity || 0, 5],
            [t('Urgencia'), p.urgency || 0, 5],
            [t('Dependencia crítica'), p.dependencyCriticality || 0, 5]
          ].map(([lbl, val, max]) => `
            <div class="sbar-row">
              <div class="sbar-lbl">${lbl}</div>
              <div class="sbar-track"><div class="sbar-fill" style="width:${Math.round((val / max) * 100)}%;background:linear-gradient(90deg,var(--accent),var(--purple))"></div></div>
              <div class="sbar-num">${val}</div>
            </div>
          `).join('')}
        </div>
      </div>
      <div class="mcard">
        <p class="mcard-title">${t('Capacidad y bloqueo')}</p>
        <p class="mcard-val">${(p.blockers || []).length}<span> ${t('label_blockers')}</span></p>
        <p class="mcard-desc">${t('Blockers activos, dependencias y señales de riesgo operativo para priorizar decisiones.')}</p>
        <div class="mrows">
          <div class="mrow"><span>${t('Miembros')}</span><strong>${(p.assignees || []).map(a => fn(a)).join(', ')}</strong></div>
          <div class="mrow"><span>${t('Tech')}</span><strong>${(p.tech || []).join(', ')}</strong></div>
          <div class="mrow"><span>${t('Dependencias')}</span><strong>${(p.dependencies || []).join(', ') || t('Ninguna')}</strong></div>
        </div>
      </div>
    </div>`;
}

function tabDelivs(p){
  /**
   * Renderiza la pestaña de entregables de un proyecto.
   * 
   * Permite:
   * - Ver el estado global (completados / pendientes / vencidos)
   * - Marcar entregables como completados
   * - Consultar detalle de cada entregable (SLA, responsable, notas)
   * - Añadir nuevos entregables rápidamente
   * 
   * @param {Object} p -Proyecto seleccionado
   * @returns {string} HTML de la pestaña de entregables
   */
  const done = p.deliverables.filter(d => d.done).length;
  const total = p.deliverables.length;
  return `
    <div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap">
      <div style="background:rgba(46,232,154,.08);border:1px solid rgba(46,232,154,.2);padding:8px 11px;border-radius:999px;font-family:var(--mono);font-size:11px;color:var(--ok)">${done} ${t('chart_completados').toLowerCase()}</div>
      <div style="background:rgba(91,189,255,.08);border:1px solid rgba(91,189,255,.2);padding:8px 11px;border-radius:999px;font-family:var(--mono);font-size:11px;color:var(--info)">${total - done} ${t('chart_pendientes').toLowerCase()}</div>
      <div style="background:rgba(255,181,71,.08);border:1px solid rgba(255,181,71,.2);padding:8px 11px;border-radius:999px;font-family:var(--mono);font-size:11px;color:var(--warn)">${p.deliverables.filter(d => !d.done && d.sla && daysTo(d.sla) < 0).length} ${t('chart_vencidos').toLowerCase()}</div>
    </div>
    <div style="display:grid;gap:9px">
      ${p.deliverables.map(d => {
        const sl = d.sla ? fmtDate(d.sla) : { s:t('sin_sla'), c:'' };
        const ddlClass = d.done ? 'soon' : (daysTo(d.sla) < 0 ? 'past' : '');
        return `
          <details class="deliv-item">
            <summary class="deliv-sum">
              <input type="checkbox" ${d.done ? 'checked' : ''} onclick="event.stopPropagation()" onchange="toggleD('${p.id}','${d.id}')">
              <div class="deliv-main">
                <span class="dt ${d.done ? 'done' : ''}">${esc(d.text)}</span>
                <div class="dhint">${d.done ? t('entregable_completado') : t('entregable_pendiente')} · ${t('responsable').toLowerCase()} ${esc(fn(d.owner || ''))}</div>
              </div>
              <span class="darrow">▾</span>
            </summary>
            <div class="dextra">
              <div class="kv"><span class="kv-k">${t('responsable')}</span><span>${esc(d.owner ? fn(d.owner) : t('sin_definir'))}</span></div>
              <div class="kv"><span class="kv-k">${t('objetivo')}</span><span>${esc(d.goal || t('no_definido'))}</span></div>
              <div class="kv"><span class="kv-k">${t('criterio')}</span><span>${esc(d.criteria || t('no_definido'))}</span></div>
              <div class="kv"><span class="kv-k">${t('notas')}</span><span>${esc(d.notes || t('sin_notas'))}</span></div>
              <div class="kv"><span class="kv-k">SLA</span><span class="${ddlClass}">${esc(sl.s || t('nd'))}</span></div>
              <div class="kv"><span class="kv-k">${t('compromiso')}</span><span>${esc(d.committed || t('nd'))}</span></div>
              <div class="kv"><span class="kv-k">${t('real')}</span><span>${esc(d.actual || t('nd'))}</span></div>
            </div>
          </details>
        `;
      }).join('')}
      <div style="margin-top:12px">
        <input id="nd" placeholder="${t('agregar_entregable')}" onkeydown="if(event.key==='Enter')addDel('${p.id}')">
      </div>
    </div>`;
}

/** Renderiza la pestaña de comentarios del proyecto.
 * 
 * Muestra:
 * - Historial de comentarios
 * - Autor y fecha
 * - Input para añadir nuevos comentarios
 * 
 * @param {Object} p - Proyecto seleccionado
 * @returns {string} HTML de la pestaña de comentarios
 */
function tabComments(p){
  return `
    ${p.comments.length ? p.comments.map(c => `
      <div class="cmt">
        <div class="cmt-hd"><span class="cmt-a">${esc(c.author)}</span><span class="cmt-d">${esc(c.date)}</span></div>
        <p class="cmt-t">${esc(c.text)}</p>
      </div>
    `).join('') : '<p style="font-size:12px;color:var(--soft);font-family:var(--mono)">' + t('sin_comentarios') + '</p>'}
    <div class="add-cmt">
      <input id="nc" placeholder="${t('anadir_comentario')}" onkeydown="if(event.key==='Enter')addCmt('${p.id}')">
      <button class="btn-p" onclick="addCmt('${p.id}')">${t('enviar')}</button>
    </div>`;
}

/** Renderiza la pestaña de timeline del proyecto.
 * 
 * Renderiza la pestaña de timeline del proyecto.
 *
 * Combina tres vistas complementarias:
 * 1. Gantt simplificado para distribución temporal de hitos
 * 2. Timeline visual animado
 * 3. Panel lateral con historial y actividad reciente
 *
 * El objetivo es dar contexto temporal completo del proyecto
 * (planificado + ejecutado + eventos humanos).
 *
 * @param {Object} p - Proyecto seleccionado
 * @returns {string} HTML del timeline
*/
function tabTimeline(p){
  const tl = p.timeline || [];
  // Si no hay hitos definidos, se informa explícitamente
  if(!tl.length) return `<div class="empty">${t('sin_hitos')}</div>`;

  // Normalización temporal para cálculo de posiciones
  const dates = tl.map(t => new Date(t.date)).filter(d => isVD(d));
  const minD = dates.length ? Math.min(...dates) : Date.now();
  const maxD = dates.length ? Math.max(...dates, Date.now()) : Date.now();
  const rng = (maxD - minD) || 1;
  // Paleta rotativa para diferenciar nodos temporalmente
  const nodeColors = [CHART_COLORS.blue, CHART_COLORS.green, CHART_COLORS.amber, CHART_COLORS.purple, CHART_COLORS.cyan, CHART_COLORS.red];
  
  // Gantt simplificado
  const ganttRows = tl.map((t, i) => {
    const d = new Date(t.date);
    // Posicion horizontal (0-85%) según fecha relativa
    const pos = isVD(d) ? Math.round((d - minD) / rng * 85) : 0;
    // Ancho estimado hasta el siguiente hito o mínimo visual
    const w = Math.max(10, i < tl.length - 1 ? Math.round(((new Date(tl[i + 1].date)) - d) / rng * 75) : 12);
    const c = nodeColors[i % nodeColors.length];
    return `<div class="gantt-row"><div class="gantt-lbl">${esc(t.title.slice(0,11))}…</div><div class="gantt-track"><div class="gantt-bar" style="left:${pos}%;width:${Math.min(w,100-pos)}%;background:${c}22;border-left:3px solid ${c}"><span class="gantt-bar-txt">${esc(t.date.slice(5))}</span></div></div></div>`;
  }).join('');

  /** Timeline visual animado
   * Representa eventos como nodos consecutivos con animaciones secuencial.
   */
  const items = tl.map((t, i) => {
    const c = nodeColors[i % nodeColors.length];
    return `<div class="tl-item" style="animation-delay:${i * .08}s"><div class="tl-node" style="background:${c}20;border-color:${c}"><div class="tl-dot-inner" style="background:${c}"></div></div><div class="tl-box"><div class="tl-bhead"><p class="tl-bname">${esc(t.title)}</p><span class="tl-date">${esc(t.date)}</span></div><p class="tl-bdesc">${esc(t.desc)}</p></div></div>`;
  }).join('');
  return `
    <div class="gantt-wrap"><p class="gantt-title">${t('distribucion_temporal')}</p>${ganttRows}</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="tl-wrap"><div class="tl-axis"></div>${items}</div>
      <div>
        <p style="font-size:10px;font-family:var(--mono);color:var(--soft);text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px">${t('historial')}</p>
        <div style="display:grid;gap:9px">${(p.history || []).map(h => `
          <div style="border:1px solid var(--line);border-radius:var(--rsm);background:var(--s2);padding:11px 13px">
            <div style="display:flex;justify-content:space-between;gap:8px;margin-bottom:5px"><p style="font-size:12px;font-weight:600;color:var(--text)">${esc(h.action)}</p><span style="font-size:10px;font-family:var(--mono);color:var(--soft);white-space:nowrap">${esc(h.date)}</span></div>
            <p style="font-size:11px;color:var(--muted);line-height:1.4"><strong>${esc(h.author)}</strong> · ${esc(h.detail)}</p>
          </div>
        `).join('') || '<p style="font-size:12px;color:var(--soft)">' + t('sin_historial') + '</p>'}</div>
        <p style="font-size:10px;font-family:var(--mono);color:var(--soft);text-transform:uppercase;letter-spacing:.08em;margin:14px 0 10px">${t('actividad_reciente')}</p>
        <div style="display:grid;gap:9px">${(p.recentActivity || []).map(r => `
          <div style="border:1px solid var(--line);border-radius:var(--rsm);background:var(--s2);padding:11px 13px">
            <div style="display:flex;justify-content:space-between;gap:8px;margin-bottom:5px"><p style="font-size:12px;font-weight:600;color:var(--text)">${esc(r.author)}</p><span style="font-size:10px;font-family:var(--mono);color:var(--soft)">${esc(r.date)}</span></div>
            <p style="font-size:11px;color:var(--muted)">${esc(r.text)}</p>
          </div>
        `).join('') || '<p style="font-size:12px;color:var(--soft)">' + t('sin_actividad') + '</p>'}</div>
      </div>
    </div>`;
}

/**
 * Renderiza la pestaña de SLA del proyecto.
 * 
 * Está orientada al control de compromisos y cumplimiento.
 * PAra cada entregable muestra:
 * - Estado (en curso / entregado)
 * - Diferencia en días respecto al SLA
 * - Texto descriptivo del SLA (vencido, hoy, en plazo)
 * - Responsable y fecha comprometida
 * 
 * @param {Object} p - Proyecto seleccionado 
 * @returns {string} HTML de la pestaña SLA 
 */
/**
 * Genera el SVG de una dona (donut) para visualizar el SLA de un entregable.
 */
function slaDonutSVG(d) {
  const diff   = d.sla ? daysTo(d.sla) : null;
  const total  = (d.committed && d.sla) ? Math.max(1, Math.round((new Date(d.sla) - new Date(d.committed)) / 86400000)) : 30;
  const elapsed = diff !== null ? Math.max(0, total - diff) : total;
  const pct    = Math.min(100, Math.round(elapsed / total * 100));
  const colHex = d.done ? '#2ee89a' : diff === null ? '#3d5f7a' : diff < 0 ? '#ff5c5c' : diff <= 3 ? '#ffb547' : '#2ee89a';
  const cx = 36, cy = 36, r = 28, sw = 8;
  const circ = 2 * Math.PI * r;
  const filled = circ * pct / 100;
  const dk = isDark();
  const label = d.done ? t('sla_entregado') : diff === null ? t('nd') : diff < 0 ? t('sla_vencido') : diff === 0 ? t('sla_hoy') : `${diff}d`;
  return `<svg viewBox="0 0 72 72" width="72" height="72" style="flex-shrink:0">
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${dk ? '#1a2e42' : '#ddeeff'}" stroke-width="${sw}"/>
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${colHex}" stroke-width="${sw}" stroke-linecap="round"
        stroke-dasharray="${filled} ${circ - filled}" stroke-dashoffset="${circ * 0.25}" style="transition:stroke-dasharray .6s ease"/>
      <circle cx="${cx}" cy="${cy}" r="17" fill="${dk ? '#0c1520' : '#fff'}"/>
      <text x="${cx}" y="${cy - 3}" text-anchor="middle" fill="${colHex}" font-size="9" font-family="'JetBrains Mono',monospace" font-weight="700">${pct}%</text>
      <text x="${cx}" y="${cy + 9}" text-anchor="middle" fill="${dk ? '#3d5f7a' : '#8aa8c4'}" font-size="7" font-family="'JetBrains Mono',monospace">${esc(label)}</text>
    </svg>`;
}

/** Genera un heatmap calendario de los SLA del proyecto. */

/**
 * Genera el heatmap de calendario SLA compacto (estilo GitHub contribution graph).
 * Organiza 8 semanas de datos agrupados por día de la semana (filas) y semana (columnas).
 * @param {Object} p         - Proyecto con campo deliverables
 * @param {string} filterDate - Fecha ISO activa en el filtro (o null)
 * @returns {string} HTML del heatmap
 */
function slaHeatmapHTML(p, filterDate) {
  const deliverables = p.deliverables || [];
  // Construir mapa fecha → cantidad de SLAs
  const dateMap = {};
  deliverables.forEach(d => { if (d.sla) dateMap[d.sla] = (dateMap[d.sla] || 0) + 1; });

  const today = new Date(); today.setHours(0,0,0,0);
  // Inicio: retroceder al lunes de hace 7 semanas
  const startDate = new Date(today);
  startDate.setDate(today.getDate() - 7 * 7);
  const dow = (startDate.getDay() + 6) % 7; // 0=Lun
  startDate.setDate(startDate.getDate() - dow);

  const WEEKS = 8;
  const DAYS  = ['L','M','X','J','V','S','D'];
  const maxCount = Math.max(1, ...Object.values(dateMap));

  // Construir la grilla de 7 filas × 8 cols
  const grid = []; // grid[dayOfWeek][weekIdx] = { iso, count }
  for (let d = 0; d < 7; d++) {
    grid[d] = [];
    for (let w = 0; w < WEEKS; w++) {
      const date = new Date(startDate);
      date.setDate(startDate.getDate() + d + w * 7);
      const iso = date.toISOString().slice(0, 10);
      grid[d][w] = { iso, count: dateMap[iso] || 0 };
    }
  }

  // Etiquetas de meses sobre las columnas
  const monthLabels = [];
  for (let w = 0; w < WEEKS; w++) {
    const date = new Date(startDate);
    date.setDate(startDate.getDate() + w * 7);
    const lbl = (w === 0 || date.getDate() <= 7) ? date.toLocaleString('default', { month: 'short' }) : '';
    monthLabels.push(lbl);
  }

  const monthRow = `<div class="shm-month-row">
    ${monthLabels.map(l => `<div class="shm-month-lbl">${l}</div>`).join('')}
  </div>`;

  // Construir filas (una por día de semana)
  const rows = grid.map((weekData, di) => {
    const cells = weekData.map(({ iso, count }) => {
      const pct = count / maxCount;
      let bg;
      if      (count === 0)  bg = isDark() ? '#0f1a27' : '#e8f0fa';
      else if (pct < 0.34)   bg = '#ff8a3d55';
      else if (pct < 0.67)   bg = '#ff5c3a99';
      else                   bg = '#ff2020cc';

      const isToday    = iso === today.toISOString().slice(0, 10);
      const isFiltered = filterDate && iso === filterDate;
      const border = isFiltered ? '2px solid #5bbdff' : isToday ? '2px solid #2ee89a' : 'none';
      const dlvs = deliverables.filter(d2 => d2.sla === iso);
      const tip  = dlvs.length ? `${iso}: ${dlvs.length} SLA(s)` : iso;

      return `<div class="shm-cell-sm" style="background:${bg};border:${border}"
        title="${esc(tip)}" onclick="slaHeatmapFilter('${p.id}','${iso}')"></div>`;
    }).join('');
    return `<div class="shm-dayrow"><span class="shm-daylabel">${DAYS[di]}</span>${cells}</div>`;
  }).join('');

  const legend = `<div class="shm-legend" style="margin-top:6px">
    <span style="color:var(--soft);font-size:8px;font-family:var(--mono)">Menos</span>
    <div class="shm-cell-sm" style="background:${isDark()?'#0f1a27':'#e8f0fa'}"></div>
    <div class="shm-cell-sm" style="background:#ff8a3d55"></div>
    <div class="shm-cell-sm" style="background:#ff5c3a99"></div>
    <div class="shm-cell-sm" style="background:#ff2020cc"></div>
    <span style="color:var(--danger);font-size:8px;font-family:var(--mono)">Más SLA</span>
    ${filterDate ? `<button class="shm-clear" style="margin-left:8px" onclick="slaHeatmapFilter('${p.id}','')">✕ ${filterDate}</button>` : ''}
  </div>`;

  return `<div class="shm-wrap-compact">
    ${monthRow}
    ${rows}
    ${legend}
  </div>`;
}


function slaHeatmapFilter(pid, date) {
  if (!S._slaFilter) S._slaFilter = {};
  S._slaFilter[pid] = date || null;
  render();
}


/**
 * Navega el carrusel de tarjetas SLA hacia adelante.
 * @param {string} pid - ID del proyecto
 * @param {number} total - Total de tarjetas
 */
function slaCflowNext(pid, total) {
  if (!S._slaCarousel) S._slaCarousel = {};
  const cur = S._slaCarousel[pid] || 0;
  S._slaCarousel[pid] = (cur + 4) >= total ? 0 : cur + 1;
  slaCflowLayout(pid, total);
}

/**
 * Navega el carrusel de tarjetas SLA hacia atrás.
 * @param {string} pid - ID del proyecto
 * @param {number} total - Total de tarjetas
 */
function slaCflowPrev(pid, total) {
  if (!S._slaCarousel) S._slaCarousel = {};
  const cur = S._slaCarousel[pid] || 0;
  S._slaCarousel[pid] = cur <= 0 ? Math.max(0, total - 4) : cur - 1;
  slaCflowLayout(pid, total);
}

/**
 * Actualiza la posición visual del carrusel SLA sin re-renderizar el DOM completo.
 * Mueve el track con CSS transform para simular movimiento circular.
 * @param {string} pid   - ID del proyecto
 * @param {number} total - Total de tarjetas (para calcular dots)
 */
function slaCflowLayout(pid, total) {
  if (!S._slaCarousel) S._slaCarousel = {};
  const idx   = S._slaCarousel[pid] || 0;
  const inner = document.getElementById('sla-cinner-' + pid);
  const dotsEl= document.getElementById('sla-cdots-' + pid);
  if (!inner) return;

  // Cada tarjeta ocupa 25% del track; el gap es 10px
  const cardW = inner.parentElement.offsetWidth / 4 - 8;
  inner.style.transform = `translateX(-${idx * (cardW + 10)}px)`;

  // Actualizar dots
  if (dotsEl) {
    const maxDots = Math.max(1, total - 3);
    dotsEl.querySelectorAll('.sla-cdot').forEach((d, i) => {
      d.classList.toggle('active', i === idx);
    });
  }
}

/**
 * Renderiza el tab de SLA con:
 *   1. Fila de 4 donuts resumen (completados / en plazo / vencidos / sin fecha)
 *   2. Heatmap compacto de 8 semanas con filtro por clic
 *   3. Carrusel de tarjetas de entregables (4 visibles, navegación circular)
 * @param {Object} p - Proyecto con deliverables, id, etc.
 * @returns {string} HTML del tab SLA
 */
function tabSla(p) {
  if (!S._slaCarousel) S._slaCarousel = {};
  const filterDate = S._slaFilter && S._slaFilter[p.id];
  const allDels    = p.deliverables || [];
  const deliverables = filterDate ? allDels.filter(d => d.sla === filterDate) : allDels;

  const total   = allDels.length || 1;
  const done    = allDels.filter(d => d.done).length;
  const overdue = allDels.filter(d => !d.done && d.sla && daysTo(d.sla) < 0).length;
  const onTrack = allDels.filter(d => !d.done && d.sla && daysTo(d.sla) >= 0).length;
  const noDate  = allDels.filter(d => !d.sla).length;
  const dk      = isDark();

  // ── 1. Fila de donuts resumen ─────────────────────────────────────────────
  const summaryDonuts = [
    { label: t('entregable_completado') || 'Completados', count: done,    color: '#2ee89a', pct: done/total },
    { label: t('sla_en_plazo')          || 'En plazo',    count: onTrack, color: '#ffb547', pct: onTrack/total },
    { label: t('sla_vencido')           || 'Vencidos',    count: overdue, color: '#ff5c5c', pct: overdue/total },
    { label: t('nd')                    || 'Sin fecha',   count: noDate,  color: '#3d5f7a', pct: noDate/total },
  ];
  const summaryRow = summaryDonuts.map(item => {
    const cx = 22, cy = 22, r = 16, sw = 5;
    const circ = 2 * Math.PI * r, filled = circ * item.pct;
    return `<div class="sla-sum-card">
      <svg viewBox="0 0 44 44" width="44" height="44">
        <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${dk?'#1a2e42':'#ddeeff'}" stroke-width="${sw}"/>
        <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${item.color}" stroke-width="${sw}"
          stroke-linecap="round" stroke-dasharray="${filled} ${circ-filled}" stroke-dashoffset="${circ*0.25}"/>
        <text x="${cx}" y="${cy+4}" text-anchor="middle" fill="${item.color}"
          font-size="9" font-family="'JetBrains Mono',monospace" font-weight="700">${item.count}</text>
      </svg>
      <p class="sla-sum-lbl">${item.label}</p>
    </div>`;
  }).join('');

  // ── 2. Heatmap compacto ───────────────────────────────────────────────────
  const heatmap = slaHeatmapHTML(p, filterDate);

  // ── 3. Carrusel de tarjetas ───────────────────────────────────────────────
  const cardItems = deliverables.map(d => {
    const diff    = d.sla ? daysTo(d.sla) : null;
    const slaText = diff === null ? (t('sla_sin_fecha')||'Sin fecha')
                  : diff < 0     ? (t('sla_vencido')||'Vencido')
                  : diff === 0   ? (t('sla_hoy')||'Hoy')
                  :                (t('sla_en_plazo')||'En plazo');
    const col = d.done ? 'var(--ok)'
              : diff !== null && diff < 0  ? 'var(--danger)'
              : diff !== null && diff <= 3 ? 'var(--warn)'
              : 'var(--soft)';
    return `<div class="sla-card sla-card-v2">
      <div class="sla-card-top">
        ${slaDonutSVG(d)}
        <div class="sla-card-info">
          <p class="sla-k">${d.done?(t('sla_entregado')||'Entregado'):(t('sla_en_curso')||'En curso')}</p>
          <p class="sla-s">${esc(d.text.slice(0,52))}${d.text.length>52?'…':''}</p>
          <div class="badge-stack" style="margin-top:5px">
            <span class="rpill">👤 ${esc(fn(d.owner||''))}</span>
            <span class="rpill">SLA ${esc(d.sla||t('nd')||'—')}</span>
            <span class="rpill" style="color:${col}">${esc(slaText)}</span>
          </div>
        </div>
      </div>
    </div>`;
  }).join('');

  // Dots para el carrusel (uno por página de 4)
  const numDots = Math.max(1, deliverables.length - 3);
  const curIdx  = S._slaCarousel[p.id] || 0;
  const dots    = Array.from({ length: numDots }, (_, i) =>
    `<div class="sla-cdot${i===curIdx?' active':''}" onclick="S._slaCarousel['${p.id}']=${i};slaCflowLayout('${p.id}',${deliverables.length})"></div>`
  ).join('');

  const carouselHTML = deliverables.length === 0
    ? `<div class="cflow-empty">// No hay entregables en esta vista</div>`
    : `<div class="sla-carousel-wrap">
        <button class="sla-cbtn prev" onclick="slaCflowPrev('${p.id}',${deliverables.length})">&#8249;</button>
        <div class="sla-carousel-track">
          <div class="sla-carousel-inner" id="sla-cinner-${p.id}">${cardItems}</div>
        </div>
        <button class="sla-cbtn next" onclick="slaCflowNext('${p.id}',${deliverables.length})">&#8250;</button>
      </div>
      <div class="sla-cdots" id="sla-cdots-${p.id}">${dots}</div>`;

  return `<div class="sla-tab-wrap">
    <div class="sla-summary-row">${summaryRow}</div>
    <div class="sla-heatmap-section">
      <p class="sla-section-title">📅 ${t('sla_calendario_titulo')||'Calendario SLA'}</p>
      ${heatmap}
    </div>
    <p class="sla-section-title" style="margin-top:14px">⬤ ${t('SLA')||'SLA'} <span style="color:var(--soft);font-size:9px">(${deliverables.length})</span></p>
    ${carouselHTML}
  </div>`;
}



/** Renderiza la pestaña de información general del proyecto.
 * Se organiza en acordeones para agrupar:
 * - Resumen del estado y alertas
 * - Equipo y stack tecnológico
 * - Información de gestión (comentarios, blockers, acciones)
 * 
 * @param {Object} p - Proyecto seleccionado 
 * @returns {string} HTML de la pestaña de información
 */
function tabInfo(p){
  // Proyecto vencido si la fecha límite ya pasó
  const ov = daysTo(p.deadline) < 0;
  // Proyecto en ventana crítica (<= 7 días)
  const near = daysTo(p.deadline) >= 0 && daysTo(p.deadline) <= 7;
  return `
    <details class="acc" open>
      <summary>${t('Resumen general')}</summary>
      <div class="acc-body">
        <div class="kv"><span class="kv-k">${t('info_estado')}</span>${sbadge(p.status)}</div>
        <div class="kv"><span class="kv-k">${t('info_progreso')}</span><span>${pct(p)}% (${p.deliverables.filter(d => d.done).length}/${p.deliverables.length})</span></div>
        <div class="kv"><span class="kv-k">${t('info_deadline')}</span><span style="font-family:var(--mono)">${esc(p.deadline)}</span></div>
        <div class="kv"><span class="kv-k">${t('info_alerta')}</span><span style="color:${ov ? 'var(--danger)' : near ? 'var(--warn)' : 'var(--ok)'}">${ov ? t('info_vencido') : near ? t('info_proximo') : t('info_ok')}</span></div>
        <div class="kv"><span class="kv-k">${t('info_riesgo')}</span><span>${riskScore(p)} · ${riskLabel(riskScore(p))}</span></div>
      </div>
    </details>
    <details class="acc">
      <summary>${t('info_equipo')}</summary>
      <div class="acc-body">
        <div class="kv"><span class="kv-k">${t('info_miembros')}</span><span>${(p.assignees || []).map(a => fn(a)).join(', ')}</span></div>
        <div class="kv"><span class="kv-k">${t('info_tech')}</span><div style="display:flex;gap:5px;flex-wrap:wrap">${(p.tech || []).map(t => `<span class="tt">${esc(t)}</span>`).join('')}</div></div>
      </div>
    </details>
    <details class="acc">
      <summary>${t('gestion')}</summary>
      <div class="acc-body">
        <div class="kv"><span class="kv-k">${t('Comentarios')}</span><span>${p.comments.length}</span></div>
        <div class="kv"><span class="kv-k">${t('Blockers')}</span><span style="color:${(p.blockers || []).length ? 'var(--danger)' : 'var(--ok)'}">${(p.blockers || []).length}</span></div>
        <div class="kv"><span class="kv-k">${t('Dependencias')}</span><span>${(p.dependencies || []).join(', ') || t('blocker_ninguno')}</span></div>
        <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
          <button class="btn-p" onclick="editP('${p.id}')">${t('editar_proyecto')}</button>
          <button class="btn-s btn-d" onclick="delP('${p.id}')">${t('eliminar_proyecto')}</button>
        </div>
      </div>
    </details>`;
}

/** Renderiza el panel lateral de detalle del proyecto  seleccionado.
 * Incluye:
 * - Header con nombre, descripción y estado
 * - Navegación por pestañas
 * - Contenido dinámico según la pestaña activa
 * 
 * Si no hay proyecto seleccionado, no renderiza nada.
 * 
 * @returns {string} HTML del panel de detalle
*/
function renderDetail(){
  // Proyecto actualmente seleccionado
  const p = S.projects.find(x => x.id === S.sel);
  if(!p) return '';

  // DEfinición centralizada de pestañas
  const tabs = [
    ['executive', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/bullseye.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('Ejecutivo')}"> ${t('Ejecutivo')}`],
    ['deliverables', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/box-seam.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('Entregables')}"> ${t('Entregables')}`],
    ['timeline', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/calendar.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('Timeline')}"> ${t('Timeline')}`],
    ['blockers', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/cone-striped.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('Blockers')}"> ${t('Blockers')}`],
    ['comments', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/chat-dots.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('Comentarios')}"> ${t('Comentarios')}`],
    ['sla', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/list-check.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('SLA')}"> ${t('SLA')}`],
    ['info', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/info-circle.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('Info')}"> ${t('Info')}`]
  ];

  // Resolución del cpntenido según la pestaña activa
  let body = '';
  if(S.tab === 'executive') body = tabExec(p);
  else if(S.tab === 'deliverables') body = tabDelivs(p);
  else if(S.tab === 'timeline') body = tabTimeline(p);
  else if(S.tab === 'blockers') body = tabBlockers(p);
  else if(S.tab === 'comments') body = tabComments(p);
  else if(S.tab === 'sla') body = tabSla(p);
  else body = tabInfo(p);

  return `
    <div class="detail">
      <div class="dp-hdr">
        <div style="flex:1;min-width:0">
          <p class="dp-title">${esc(p.name)}</p>
          <p class="dp-sub">${esc(p.description.slice(0,130))}${p.description.length > 130 ? '…' : ''}</p>
        </div>
        <div style="display:flex;gap:8px;align-items:center;flex-shrink:0">${sbadge(p.status)}<button onclick="pick(null)" class="tiny-btn">✕</button></div>
      </div>
      <div class="dp-tabs">
        ${tabs.map(([k,l]) => `<div class="dpt ${S.tab === k ? 'on' : ''}" onclick="setTab('${k}')">${l}</div>`).join('')}
      </div>
      ${body}
    </div>`;
}

/** Renderiza la pestaña de blockers de un proyecto específico.
 * 
 * Clasifica los blockers en:
 * - Críticos: impacto directo en producción/entrega
 * - Medios: impacto en velocidad/calidad
 * 
 * Adicionalmente muestra:
 * - Dependencias externas del proyecto
 * 
 * @param {Object} p - Proyecto seleccionado
 * @returns {string} HTML de la pestaña de blockers 
 */
function tabBlockers(p){
  // Separación por severidad
  const crit = (p.blockers || []).filter(b => b.severity === 'crit');
  const med = (p.blockers || []).filter(b => b.severity !== 'crit');
  return `
    <p style="font-size:10px;font-family:var(--mono);color:var(--danger);text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px">${t('blocker_critico_titulo')}</p>
    <div class="blocker-grid">
      ${crit.map(b => `<div class="blocker-item"><div class="bl-top"><p class="bl-name">${esc(b.text)}</p><span class="bl-badge crit">${t('blocker_critico_badge')}</span></div><p class="bl-proj">${t('blocker_impacto_critico')}</p></div>`).join('') || '<p style="font-size:12px;color:var(--soft)">' + t('blocker_ninguno') + '</p>'}
    </div>
    <p style="font-size:10px;font-family:var(--mono);color:var(--warn);text-transform:uppercase;letter-spacing:.08em;margin:16px 0 10px">${t('blocker_medio_titulo')}</p>
    <div class="blocker-grid">
      ${med.map(b => `<div class="blocker-item warn-blk"><div class="bl-top"><p class="bl-name">${esc(b.text)}</p><span class="bl-badge med">${t('blocker_medio_badge')}</span></div><p class="bl-proj">${t('blocker_impacto_medio')}</p></div>`).join('') || '<p style="font-size:12px;color:var(--soft)">' + t('blocker_ninguno') + '</p>'}
    </div>
    <p style="font-size:10px;font-family:var(--mono);color:var(--soft);text-transform:uppercase;letter-spacing:.08em;margin:16px 0 10px">${t('blocker_dependencias')}</p>
    <div style="display:flex;gap:7px;flex-wrap:wrap">${(p.dependencies || []).map(d => `<span style="font-size:11px;font-family:var(--mono);padding:5px 12px;border-radius:999px;background:rgba(180,124,255,.1);border:1px solid rgba(180,124,255,.2);color:var(--purple)">${esc(d)}</span>`).join('') || '<span style="font-size:12px;color:var(--soft)">' + t('blocker_sin_dependencias') + '</span>'}</div>`;
}

/** Renderiza el formulario de creación o edición de proyectos.
 * 
 * Comportamiento:
 * - Si S.showForm = false, entonces no renderiza
 * - Si S.editId existe, entonces modo edición
 * - Si no, entonces modo creación
 * 
 * Soporta edición completa de:
 * - Metadata del proyecto
 * - Factores de riesgo
 * - Fechas
 * - Equipo
 * - Stack
 * - Blockers, dependencias y entregables
 * 
 * @returns {string} HTML del formulario o vacío
 */
function renderForm(){
  // Si el formulario está ocsulto, no0 se renderiza
  if(!S.showForm) return '';

  // Proyecto en edición (si existe)
  const ed = S.editId ? S.projects.find(p => p.id === S.editId) : null;

  // Estado actual del formulario
  const f = S.form || {};
  return `
    <div class="fs">
      <p style="font-size:11px;font-family:var(--mono);text-transform:uppercase;letter-spacing:.08em;color:var(--accent);margin-bottom:18px">${ed ? t('form_editar_modo') : t('form_nuevo_modo')}</p>
      <div class="fg">
        <div class="full"><label class="flabel">${t('form_nombre')}</label><input id="fn" value="${esc(f.name || '')}" placeholder="${t('form_nombre_placeholder')}"></div>
        <div class="full"><label class="flabel">${t('form_descripcion')}</label><textarea id="fd" placeholder="${t('form_descripcion_placeholder')}">${esc(f.description || '')}</textarea></div>
        <div><label class="flabel">${t('form_estado')}</label><select id="fst"><option value="active" ${(f.status || 'active') === 'active' ? 'selected' : ''}>${t('form_estado_activo')}</option><option value="risk" ${f.status === 'risk' ? 'selected' : ''}>${t('form_estado_riesgo')}</option><option value="delivered" ${f.status === 'delivered' ? 'selected' : ''}>${t('form_estado_entregado')}</option><option value="paused" ${f.status === 'paused' ? 'selected' : ''}>${t('form_estado_pausado')}</option></select></div>
        <div><label class="flabel">${t('form_prioridad_negocio')}</label><select id="fbp">${[5,4,3,2,1].map(n => `<option value="${n}" ${String(f.businessPriority || 3) === String(n) ? 'selected' : ''}>${n}/5</option>`).join('')}</select></div>
        <div><label class="flabel">${t('form_severidad_tecnica')}</label><select id="fts">${[5,4,3,2,1].map(n => `<option value="${n}" ${String(f.technicalSeverity || 3) === String(n) ? 'selected' : ''}>${n}/5</option>`).join('')}</select></div>
        <div><label class="flabel">${t('form_urgencia')}</label><select id="fur">${[5,4,3,2,1].map(n => `<option value="${n}" ${String(f.urgency || 3) === String(n) ? 'selected' : ''}>${n}/5</option>`).join('')}</select></div>
        <div><label class="flabel">${t('form_dependencia_critica')}</label><select id="fdc">${[5,4,3,2,1].map(n => `<option value="${n}" ${String(f.dependencyCriticality || 3) === String(n) ? 'selected' : ''}>${n}/5</option>`).join('')}</select></div>
        <div><label class="flabel">${t('form_fecha_entrega')}</label><input type="date" id="fdl" value="${esc(f.deadline || '')}"></div>
        <div><label class="flabel">${t('form_sla_comprometido')}</label><input type="date" id="fca" value="${esc(f.committedAt || '')}"></div>
        <div><label class="flabel">${t('form_fecha_real')}</label><input type="date" id="fra" value="${esc(f.actualAt || '')}"></div>
        <div><label class="flabel">${t('form_miembros')}</label><input id="fass" value="${esc(f.assignees || '')}" placeholder="${t('form_miembros_placeholder')}"></div>
        <div class="full"><label class="flabel">${t('form_tech_stack')}</label><input id="ftc" value="${esc(f.tech || '')}" placeholder="${t('form_tech_stack_placeholder')}"></div>
        <div class="full"><label class="flabel">${t('form_blockers')}</label><textarea id="fblk" placeholder="${t('form_blockers_placeholder')}">${esc(f.blockers || '')}</textarea></div>
        <div class="full"><label class="flabel">${t('form_dependencias')}</label><textarea id="fdep" placeholder="${t('form_dependencias_placeholder')}">${esc(f.dependencies || '')}</textarea></div>
        <div class="full"><label class="flabel">${t('form_entregables')}</label><textarea id="fdels" placeholder="${t('form_entregables_placeholder')}">${esc(f.deliverables || '')}</textarea></div>
      </div>
      <div class="fa">
        <button class="btn-s" onclick="cancelF()">${t('form_cancelar')}</button>
        <button class="btn-p" onclick="saveP()">${ed ? t('form_guardar_cambios') : t('form_crear_proyecto')}</button>
      </div>
    </div>`;
}

/**
 * Renderiza las tarjetas en un carrusel tipo coverflow.
 * @param {Array} projects - Lista de proyectos filtrados
 */
function renderCarousel(projects) {
  if (!projects.length) return `<div class="cflow-empty">// no hay proyectos en esta vista</div>`;

  const cards = projects.map(renderCard).join('');
  const dots  = projects.map((_, i) =>
    `<div class="cflow-dot${i === S.cflowIdx ? ' active' : ''}" onclick="cflowGoto(${i})"></div>`
  ).join('');

  return `
    <div class="cflow-wrap">
      <button class="cflow-btn prev" onclick="cflowPrev()" aria-label="Anterior">&#8249;</button>
      <div class="cflow-track">
        <div class="cflow-inner" id="cflow-inner">${cards}</div>
      </div>
      <button class="cflow-btn next" onclick="cflowNext()" aria-label="Siguiente">&#8250;</button>
    </div>
    <div class="cflow-dots" id="cflow-dots">${dots}</div>
  `;
}

/** Función principal de render del dashboard.
 * Responsabilidades:
 * - Limpiar gráficos existentes
 * - Filtrar Proyectos según el estado activo
 * - Renderizar todas las secciones principales:
 *   Header, analytics, charts, blockers, form, grid y detalle
 * - Montar gráficos despues del render (next frame)
 * 
 * Es el punto central de actualizacion del UI.
*/
function render(){
  clearCharts();

  const fil = S.projects.filter(p => {
    const statusOk = S.filter === 'all' || p.status === S.filter;
    if (S.personQuery) {
      const q = S.personQuery;
      return (p.assignees||[]).some(a =>
        a.toUpperCase().includes(q) ||
        (MNAMES[a]||'').toUpperCase().includes(q)
      );
    }
    return statusOk;
  });

  const root = document.getElementById('root');
  if (!root) return;
  root.style.marginTop = '';

  const idxGuard = S.cflowIdx;  // preservar índice

  root.innerHTML = `
    ${renderHeader()}
    ${renderAnalytics()}
    ${renderChartsRow1()}
    <div class="fbar">
      <div class="filters">
        ${[['all','Todos'],['active','Activos'],['risk','En riesgo'],['delivered','Entregados'],['paused','Pausados']].map(
          ([k,l]) => `<button class="fb ${S.filter===k && !S.personQuery ? 'on' : ''}" onclick="setF('${k}')">${l}</button>`
        ).join('')}
        <span class="fb-person-wrap">
          <button class="fb ${S.personQuery ? 'on' : ''}" onclick="togglePersonFilter()">👤 Personas</button>
          ${S.showPersonInput ? `<input class="person-input" id="person-filter-input" type="text"
            maxlength="4" placeholder="Ej: SB" value="${esc(S.personQuery)}"
            oninput="applyPersonFilter(this.value)" autofocus />` : ''}
        </span>
      </div>
      <button class="add-btn" onclick="tgForm()">${S.showForm && !S.editId ? '✕ Cancelar' : '+ Nuevo proyecto'}</button>
    </div>
    ${renderForm()}
    <div class="proj-grid" id="proj-grid-wrap">${renderCarousel(fil)}</div>
    ${renderDetail()}
  `;

  requestAnimationFrame(() => {
    mountChartsRow1();
    setThemeLabel();
    S.cflowIdx = idxGuard;   // restaurar índice antes de layout
    cflowLayout();
    const idioma = localStorage.getItem('idioma') || 'es';
    if (typeof aplicarIdioma === 'function') aplicarIdioma(idioma);
    updateLangBtn(idioma);
  });
}

/** Pantalla de bienvenida.
 * Grafo 3D + Selector de usuario
 */
function renderWelcome() {
  const root = document.getElementById('root');
  if (!root) return;
  root.style.marginTop = '0';
  clearCharts();

  root.innerHTML = WLC.stage === 1
    ? buildWelcomeStage1()
    : buildWelcomeStage2();

  requestAnimationFrame(() => {
    setThemeLabel();
    const idioma = localStorage.getItem('idioma') || 'es';
    updateLangBtn(idioma);
    if (WLC.stage === 1) initOrgChart3D();
    else                  initUserCards3D();
  });
}

/* ── Barra de control (botones tema/idioma) reutilizable ── */
function ctrlBar() {
  const userColor = WLC.user ? memberColor(WLC.user) : null;
  return `
    <div class="ctrl-btns ctrl-btns-wlc">
      <button class="tog tog-theme" onclick="toggleTheme()" aria-label="Cambiar tema">
        <span id="tog-lbl"></span>
      </button>
      <button id="btn-idioma" class="tog tog-lang" onclick="cambiarIdioma()" aria-label="Cambiar idioma"></button>
    </div>`;
}

/*  ETAPA 1 — Org-chart 3D: selectores + grafo */

function buildWelcomeStage1() {
  const depts = Object.keys(ORG);
  const selDept = WLC.dept || '';
  const areas = selDept ? Object.keys(ORG[selDept].areas) : [];

  return `
    <div class="wlc-wrap" id="wlc-wrap">

      ${ctrlBar()}

      <!-- Encabezado animado -->
      <div class="wlc-hero">
        <div class="wlc-orb" aria-hidden="true"></div>
        <p class="wlc-tag"><span class="pulse-dot"></span> DATA TEAM · PORTFOLIO</p>
        <h1 class="wlc-title">
          <span class="wlc-line wlc-line1">${t('wlc_selecciona')}</span>
          <span class="wlc-line wlc-line2 wlc-grad">${t('wlc_departamento')}</span>
        </h1>
        <p class="wlc-sub">${t('wlc_elige_sub')}</p>
      </div>

      <!-- Selectores en píldoras -->
      <div class="wlc-selectors">
        <div class="wlc-sel-group">
          <p class="wlc-sel-label">${t('wlc_dept_label')}</p>
          <div class="wlc-pills" id="dept-pills">
            ${depts.map(k => `
              <button class="wlc-pill ${selDept===k?'active':''}"
                onclick="wlcPickDept('${k}')"
                style="${selDept===k?`--pc:${ORG[k].color}`:''}">
                <span class="wlc-pill-icon">${ORG[k].icon}</span>
                <span>${k}</span>
              </button>`).join('')}
          </div>
        </div>

        ${selDept ? `
        <div class="wlc-sel-group wlc-sel-area" id="area-group">
          <p class="wlc-sel-label">${t('wlc_area_label')} — <span style="color:${ORG[selDept].color}">${selDept}</span></p>
          <div class="wlc-pills" id="area-pills">
            ${areas.map(a => `
              <button class="wlc-pill ${WLC.area===a?'active':''}"
                onclick="wlcSelectArea('${selDept}','${a}')"
                style="${WLC.area===a?`--pc:${ORG[selDept].color}`:''}">
                <span class="wlc-pill-icon">${ORG[selDept].areas[a].icon}</span>
                <span>${a}</span>
              </button>`).join('')}
          </div>
        </div>` : ''}
      </div>

      <!-- Grafo 3D org-chart -->
      <div class="wlc-graph-outer">
        <p class="wlc-graph-hint">${t('wlc_graph_hint')}</p>
        <div class="wlc-graph-scene" id="wlc-scene">
          <svg id="wlc-svg" class="wlc-svg" xmlns="http://www.w3.org/2000/svg"></svg>
          <div id="wlc-tooltip" class="wlc-tooltip" style="display:none"></div>
        </div>
      </div>

    </div>`;
}

/* ETAPA 2 — Selector de usuario con tarjetas flotantes 3D */

function buildWelcomeStage2() {
  const deptObj = ORG[WLC.dept] || {};
  const areaObj = deptObj.areas?.[WLC.area] || {};
  const members = (areaObj.members || []).filter(m => MNAMES[m]);

  return `
    <div class="wlc-wrap wlc-stage2" id="wlc-wrap">

      ${ctrlBar()}

      <div class="wlc-hero">
        <div class="wlc-orb wlc-orb2" aria-hidden="true"></div>
        <p class="wlc-tag">
          <span class="pulse-dot"></span>
          ${esc(WLC.dept)} &nbsp;·&nbsp; ${esc(WLC.area)}
        </p>
        <h1 class="wlc-title">
          <span class="wlc-line wlc-line1">${t('wlc_quien')}</span>
          <span class="wlc-line wlc-line2 wlc-grad">${t('wlc_eres_tu')}</span>
        </h1>
        <p class="wlc-sub">${t('wlc_arrastra_sub')}</p>
      </div>

      <div class="wlc-stage2-scene" id="wlc-stage2-scene">
        <div class="wlc-cards-ring" id="wlc-cards-ring">
          ${members.length
            ? members.map((m,i) => {
                const color = memberColor(m);
                const [bg]  = AVC[i % AVC.length];
                return `
                  <div class="wlc-mcard" data-idx="${i}" onclick="wlcSelectMember('${esc(m)}')">
                    <div class="wlc-mcard-glow" style="background:${color}"></div>
                    <div class="wlc-mcard-body">
                      <div class="wlc-mcard-av" style="background:${color}22;color:${color};border:2px solid ${color}40">${esc(m)}</div>
                      <p class="wlc-mcard-name">${esc(MNAMES[m])}</p>
                      <p class="wlc-mcard-area" style="color:${color}">${esc(WLC.area)}</p>
                      <p class="wlc-mcard-dept">${esc(WLC.dept)}</p>
                    </div>
                    <div class="wlc-mcard-shine"></div>
                  </div>`;
              }).join('')
            : `<div class="wlc-empty">${t('wlc_sin_miembros')}</div>`}
        </div>
      </div>

      <button class="wlc-back-btn" onclick="wlcBack()">← ${t('wlc_cambiar_area')}</button>
    </div>`;
}

/* MOTOR ORG-CHART 3D — Canvas 3D con perspectiva real y rotación continua */


/**
 * ORG-CHART 3D v2 — Inspirado en bumbeishvili/org-chart
 *
 * Implementación basada en:
 *   - SVG para los nodos y aristas (nodos rectangulares con bordes redondeados)
 *   - d3-force para el layout automático (separación natural de nodos)
 *   - CSS perspective + rotateX/Y para la ilusión de profundidad 3D real
 *   - Drag para rotar el grafo con inercia
 *   - Tooltip flotante al hacer hover sobre cualquier nodo
 *   - Click en dept → resalta sus áreas; click en área → navega
 */
function initOrgChart3D() {
  /*
   * ORG-CHART 3D v5 — Canvas 2D con proyección perspectiva matemática real
   *
   * Por qué canvas y no SVG+CSS:
   *   Los navegadores NO aplican CSS perspective a elementos <svg>.
   *   rotateX/Y en un SVG solo hace shear 2D, no perspectiva real.
   *   Con canvas calculamos la proyección Z manualmente:
   *     sx = cx + (x3d * cos(rotY) + z3d * sin(rotY)) * fov / (fov + zCam)
   *   Esto produce profundidad genuina: los nodos lejanos se ven pequeños
   *   y los cercanos grandes, con parallax real al arrastrar.
   *
   * Características:
   *   - Nodos rectangulares estilo bumbeishvili con bordes redondeados
   *   - Líneas conectoras curvas (bezier quadratic)
   *   - Proyección perspectiva Z real
   *   - Profundidad visible: nodos delanteros más grandes y opacos
   *   - Rotación X/Y con drag + inercia + auto-rotate
   *   - Hover con hit-test en espacio 2D proyectado
   *   - Click limpio separado de drag (flag didMove)
   *   - Tooltip flotante en HTML overlay
   */
  const scene = document.getElementById('wlc-scene');
  if (!scene) return;

  if (window._orgAnim) { cancelAnimationFrame(window._orgAnim); window._orgAnim = null; }

  // ── Reemplazar contenido del scene con canvas + tooltip ──────────────
  scene.style.perspective = '';        // limpiar cualquier perspective CSS previo
  scene.style.cursor      = 'grab';
  scene.innerHTML = `
    <canvas id="oc-canvas" style="display:block;width:100%;height:100%;cursor:inherit"></canvas>
    <div id="oc-tip" style="
      position:absolute;pointer-events:none;display:none;z-index:50;
      background:rgba(8,18,30,0.95);border:1px solid rgba(91,189,255,0.35);
      border-radius:9px;padding:8px 13px;backdrop-filter:blur(8px);
      box-shadow:0 4px 24px rgba(0,0,0,0.5);min-width:120px;
    "></div>`;

  const canvas = document.getElementById('oc-canvas');
  const tip    = document.getElementById('oc-tip');
  const ctx    = canvas.getContext('2d');

  // ── Dimensiones ──────────────────────────────────────────────────────
  function resize() {
    canvas.width  = scene.offsetWidth  || 760;
    canvas.height = scene.offsetHeight || 400;
  }
  resize();
  const W = () => canvas.width;
  const H = () => canvas.height;

  const dk = isDark();

  // ── Construir grafo ──────────────────────────────────────────────────
  const nodes = [];
  const edges = [];

  // Posición 3D inicial: raíz al centro, depts en órbita, áreas más abajo
  nodes.push({
    id:'root', type:'root', label:'DATA\nTEAM', sub:'Portfolio', icon:'◈',
    color:'#5bbdff', fillA:'rgba(91,189,255,0.15)', stroke:'#5bbdff',
    x3:0, y3:-60, z3:0, w:110, h:50
  });

  const dkeys = Object.keys(ORG);
  dkeys.forEach((dkey, di) => {
    const d     = ORG[dkey];
    const angle = (di / dkeys.length) * Math.PI * 2;
    const R     = 220;
    const dId   = 'dept::' + dkey;
    const dx3   = Math.cos(angle) * R;
    const dz3   = Math.sin(angle) * R;
    nodes.push({
      id:dId, type:'dept', fullKey:dkey,
      label: dkey.split(' - ')[1] || dkey,
      sub:   Object.keys(d.areas).length + ' área(s)',
      icon:  d.icon || '▸',
      color: d.color, fillA: d.color + '22', stroke: d.color,
      x3: dx3, y3: 30, z3: dz3, w:128, h:50
    });
    edges.push({ a:'root', b:dId, color: d.color + 'aa' });

    const akeys = Object.keys(d.areas);
    akeys.forEach((akey, ai) => {
      const aId    = 'area::' + dkey + '::' + akey;
      const spread = (ai - (akeys.length - 1) / 2) * 130;
      // Perpendicular al vector dept-raíz para separar áreas del mismo dept
      const px = -Math.sin(angle), pz = Math.cos(angle);
      const mem = (d.areas[akey].members || []).length;
      nodes.push({
        id:aId, type:'area', fullKey:dkey, areaKey:akey,
        label: akey, sub: mem + ' miembro(s)',
        icon:  d.areas[akey].icon || '→',
        color: d.color, fillA: d.color + '12', stroke: d.color + 'cc',
        x3: dx3 + px * spread, y3: 130, z3: dz3 + pz * spread * 0.5,
        w:116, h:44
      });
      edges.push({ a: dId, b: aId, color: d.color + '66' });
    });
  });

  const nodeMap = {};
  nodes.forEach(n => { nodeMap[n.id] = n; });

  // ── Proyección perspectiva ────────────────────────────────────────────
  // rotX: inclinación vertical (mirar desde arriba/abajo)
  // rotY: giro horizontal
  // Retorna { sx, sy, scale, zCam } — coordenadas de pantalla + escala de profundidad
  function project(x3, y3, z3, rotX, rotY) {
    // Rotar en Y (yaw)
    const cosY = Math.cos(rotY), sinY = Math.sin(rotY);
    const rx   = x3 * cosY + z3 * sinY;
    const rz   = -x3 * sinY + z3 * cosY;
    // Rotar en X (pitch)
    const cosX = Math.cos(rotX), sinX = Math.sin(rotX);
    const ry   = y3 * cosX - rz * sinX;
    const rzf  = y3 * sinX + rz * cosX;
    // Proyección perspectiva
    const fov   = 650;
    const depth = fov + rzf + 350;   // distancia Z a la cámara
    const scale = fov / Math.max(depth, 1);
    return {
      sx:    W() / 2 + rx * scale,
      sy:    H() / 2 + ry * scale,
      scale,
      zCam: rzf
    };
  }

  // ── Estado de rotación ────────────────────────────────────────────────
  let rotX = -0.22, rotY = 0;          // radianes
  let autoY = 0;                        // auto-rotate acumulado
  let vx = 0, vy = 0;                  // inercia
  let isDrag = false, didMove = false;
  let lastMx = 0, lastMy = 0;
  let hoveredNode = null;

  // ── Dibujar rectángulo con bordes redondeados en canvas ───────────────
  function roundRect(cx, cy, w, h, r) {
    const x = cx - w/2, y = cy - h/2;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  // ── Frame de render ────────────────────────────────────────────────────
  function draw() {
    ctx.clearRect(0, 0, W(), H());

    const rX = rotX;
    const rY = rotY + autoY;

    // Proyectar todos los nodos
    const proj = nodes.map(n => {
      const p = project(n.x3, n.y3, n.z3, rX, rY);
      return { n, ...p };
    });

    // Ordenar por Z (más lejos primero → pintar detrás)
    proj.sort((a, b) => a.zCam - b.zCam);

    // ── Dibujar aristas ────────────────────────────────────────────────
    edges.forEach(e => {
      const pa = proj.find(p => p.n.id === e.a);
      const pb = proj.find(p => p.n.id === e.b);
      if (!pa || !pb) return;
      // Punto de control elevado para curva bezier
      const mcx = (pa.sx + pb.sx) / 2;
      const mcy = (pa.sy + pb.sy) / 2 - Math.abs(pb.sx - pa.sx) * 0.12;
      ctx.beginPath();
      ctx.moveTo(pa.sx, pa.sy);
      ctx.quadraticCurveTo(mcx, mcy, pb.sx, pb.sy);
      ctx.strokeStyle = e.color;
      ctx.lineWidth   = 1.2;
      ctx.setLineDash([5, 5]);
      ctx.stroke();
      ctx.setLineDash([]);
    });

    // ── Dibujar nodos ──────────────────────────────────────────────────
    proj.forEach(({ n, sx, sy, scale, zCam }) => {
      const isHov = hoveredNode && hoveredNode.id === n.id;
      const w = n.w * scale * (isHov ? 1.12 : 1);
      const h = n.h * scale * (isHov ? 1.12 : 1);
      const r = (n.type === 'root' ? 14 : 10) * scale;

      // Opacidad basada en profundidad: nodos más adelante = más opacos
      const depth01 = Math.max(0, Math.min(1, (zCam + 350) / 700));
      const opacity = 0.45 + 0.55 * depth01;

      // Glow en hover
      if (isHov && n.type !== 'root') {
        ctx.save();
        ctx.shadowColor = n.color;
        ctx.shadowBlur  = 18 * scale;
      }

      // Fondo del nodo
      roundRect(sx, sy, w, h, r);
      ctx.fillStyle   = n.fillA;
      ctx.globalAlpha = opacity;
      ctx.fill();
      ctx.globalAlpha = 1;

      // Borde
      roundRect(sx, sy, w, h, r);
      ctx.strokeStyle = isHov ? n.color : n.stroke;
      ctx.lineWidth   = (isHov ? 2.5 : 1.5) * scale;
      ctx.globalAlpha = opacity + 0.15;
      ctx.stroke();
      ctx.globalAlpha = 1;

      if (isHov) ctx.restore();

      // ── Texto ────────────────────────────────────────────────────────
      const fs    = Math.max(7, (n.type === 'root' ? 12 : 10) * scale);
      const fsSub = Math.max(6, 8 * scale);

      ctx.globalAlpha = Math.min(1, opacity + 0.25);

      // Icono
      ctx.font         = `${Math.max(8, 13 * scale)}px serif`;
      ctx.fillStyle    = n.color;
      ctx.textAlign    = n.type === 'root' ? 'center' : 'left';
      ctx.textBaseline = 'middle';
      const ix = n.type === 'root' ? sx : sx - w/2 + 12 * scale;
      const iy = sy - h * 0.18;
      ctx.fillText(n.icon, ix, iy);

      // Nombre principal (puede ser multilínea con \n)
      ctx.font      = `700 ${fs}px 'JetBrains Mono', monospace`;
      ctx.fillStyle = dk ? '#ddeeff' : '#0a1f35';
      const nameLines = n.label.split('\n');
      const nx = n.type === 'root' ? sx : sx - w/2 + 28 * scale;
      ctx.textAlign = n.type === 'root' ? 'center' : 'left';
      if (nameLines.length === 1) {
        ctx.fillText(nameLines[0].slice(0, 16), nx, sy - h * 0.06);
      } else {
        nameLines.forEach((line, li) => {
          ctx.fillText(line.slice(0, 12), nx,
            sy - h * 0.12 + li * fs * 1.25);
        });
      }

      // Subtítulo
      ctx.font      = `${fsSub}px 'JetBrains Mono', monospace`;
      ctx.fillStyle = n.color;
      ctx.textAlign = n.type === 'root' ? 'center' : 'left';
      const subX = n.type === 'root' ? sx : sx - w/2 + 28 * scale;
      ctx.fillText(n.sub.slice(0, 18), subX, sy + h * 0.25);

      ctx.globalAlpha = 1;
    });
  }

  // ── Animación ─────────────────────────────────────────────────────────
  function rafLoop() {
    if (!isDrag) {
      autoY += 0.004;                   // auto-rotate lento
      vx *= 0.92; vy *= 0.92;          // inercia
      rotY += vx;
      rotX = Math.max(-0.65, Math.min(0.65, rotX + vy));
    }
    draw();
    window._orgAnim = requestAnimationFrame(rafLoop);
  }
  if (window._orgAnim) cancelAnimationFrame(window._orgAnim);
  rafLoop();

  // ── Hit-test: ¿qué nodo está bajo (mx, my)? ──────────────────────────
  function hitTest(mx, my) {
    const rX = rotX, rY = rotY + autoY;
    let best = null, bestZ = -Infinity;
    nodes.forEach(n => {
      const { sx, sy, scale, zCam } = project(n.x3, n.y3, n.z3, rX, rY);
      const hw = (n.w * scale) / 2 + 4;
      const hh = (n.h * scale) / 2 + 4;
      if (mx >= sx - hw && mx <= sx + hw && my >= sy - hh && my <= sy + hh) {
        if (zCam > bestZ) { best = n; bestZ = zCam; }
      }
    });
    return best;
  }

  // ── Eventos de mouse ──────────────────────────────────────────────────
  function getXY(e) {
    const r = canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  canvas.addEventListener('mousemove', e => {
    const { x, y } = getXY(e);
    if (isDrag) {
      const dx = e.clientX - lastMx, dy = e.clientY - lastMy;
      if (Math.abs(dx) > 2 || Math.abs(dy) > 2) didMove = true;
      vx = dx * 0.008; vy = -dy * 0.006;
      rotY += dx * 0.008;
      rotX = Math.max(-0.65, Math.min(0.65, rotX - dy * 0.006));
      autoY = 0;
      lastMx = e.clientX; lastMy = e.clientY;
    } else {
      const hit = hitTest(x, y);
      hoveredNode = hit;
      canvas.style.cursor = hit && hit.type !== 'root' ? 'pointer' : 'grab';

      if (hit && hit.type !== 'root') {
        const r = scene.getBoundingClientRect();
        tip.style.left    = (e.clientX - r.left + 14) + 'px';
        tip.style.top     = (e.clientY - r.top  - 56) + 'px';
        tip.style.display = 'block';
        tip.innerHTML = `
          <div style="font-size:8px;color:#3d5f7a;font-family:'JetBrains Mono',monospace;text-transform:uppercase;letter-spacing:.1em;margin-bottom:3px">
            ${hit.type === 'dept' ? 'Departamento' : 'Área'}
          </div>
          <div style="color:${hit.color};font-weight:700;font-family:'JetBrains Mono',monospace;font-size:12px">
            ${hit.label}
          </div>
          <div style="color:#ff8a3d;font-size:9px;font-family:'JetBrains Mono',monospace;margin-top:3px">
            ${hit.type === 'area' ? '→ Clic para entrar' : '→ Clic para ver áreas'}
          </div>`;
      } else {
        tip.style.display = 'none';
      }
    }
  });

  canvas.addEventListener('mousedown', e => {
    isDrag = true; didMove = false;
    lastMx = e.clientX; lastMy = e.clientY;
    vx = 0; vy = 0;
    scene.style.cursor = 'grabbing';
  });

  window.addEventListener('mouseup', () => {
    isDrag = false;
    scene.style.cursor = 'grab';
  });

  canvas.addEventListener('mouseleave', () => {
    hoveredNode = null;
    tip.style.display = 'none';
  });

  // Click: solo si no fue drag
  canvas.addEventListener('click', e => {
    if (didMove) { didMove = false; return; }
    const { x, y } = getXY(e);
    const n = hitTest(x, y);
    if (!n) return;
    tip.style.display = 'none';
    if (n.type === 'dept') {
      WLC.dept = n.fullKey; WLC.area = null;
      renderWelcome();
    } else if (n.type === 'area') {
      wlcSelectArea(n.fullKey, n.areaKey);
    }
  });

  // Touch
  canvas.addEventListener('touchstart', e => {
    const t = e.touches[0];
    isDrag = true; didMove = false;
    lastMx = t.clientX; lastMy = t.clientY; vx = 0; vy = 0;
  }, { passive: true });

  canvas.addEventListener('touchmove', e => {
    if (!isDrag) return;
    const t = e.touches[0];
    const dx = t.clientX - lastMx, dy = t.clientY - lastMy;
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) didMove = true;
    vx = dx * 0.009; vy = -dy * 0.007;
    rotY += dx * 0.009; rotX = Math.max(-0.65, Math.min(0.65, rotX - dy * 0.007));
    autoY = 0; lastMx = t.clientX; lastMy = t.clientY;
  }, { passive: true });

  canvas.addEventListener('touchend', e => {
    isDrag = false;
    if (!didMove && e.changedTouches.length > 0) {
      const t = e.changedTouches[0];
      const r = canvas.getBoundingClientRect();
      const n = hitTest(t.clientX - r.left, t.clientY - r.top);
      if (n && n.type === 'dept') { WLC.dept = n.fullKey; WLC.area = null; renderWelcome(); }
      else if (n && n.type === 'area') wlcSelectArea(n.fullKey, n.areaKey);
    }
  });

  // Resize
  window.addEventListener('resize', () => { resize(); });
}





// Selección de dept desde botones píldora (refresca sin cambiar etapa)
function wlcPickDept(key) {
  WLC.dept = key;
  WLC.area = null;
  renderWelcome();
}

/* MOTOR TARJETAS 3D — Anillo giratorio (stage 2) */

function initUserCards3D() {
  const ring = document.getElementById('wlc-cards-ring');
  if (!ring) return;
  const cards = Array.from(ring.querySelectorAll('.wlc-mcard'));
  const total = cards.length;
  if (!total) return;

  let rotY = 0;
  let vel  = 0;
  let dragging = false;
  let lastX = 0;
  let rafId = null;

  function layout() {
    const radius = Math.max(180, total * 72);
    cards.forEach((c,i) => {
      const angle = (i/total)*360 + rotY;
      const rad   = angle * Math.PI / 180;
      const x     = Math.sin(rad) * radius;
      const z     = Math.cos(rad) * radius;
      const norm  = (z + radius)/(2*radius); // 0..1
      const scale = 0.62 + 0.38*norm;
      const opa   = 0.28 + 0.72*norm;
      c.style.transform = `translateX(${x}px) translateZ(${z}px) scale(${scale})`;
      c.style.opacity   = opa;
      c.style.zIndex    = Math.round(scale*100);
      c.style.pointerEvents = z > 0 ? 'auto' : 'none';
    });
  }

  function inertia() {
    if (Math.abs(vel) < 0.05) return;
    rotY += vel;
    vel  *= 0.93;
    layout();
    rafId = requestAnimationFrame(inertia);
  }

  // Mouse
  ring.addEventListener('mousedown', e => {
    dragging=true; lastX=e.clientX; vel=0;
    cancelAnimationFrame(rafId);
  });
  document.addEventListener('mousemove', e => {
    if(!dragging) return;
    const dx = e.clientX-lastX;
    rotY += dx*0.35; vel=dx*0.35; lastX=e.clientX;
    layout();
  });
  document.addEventListener('mouseup', () => {
    if(!dragging) return;
    dragging=false;
    rafId = requestAnimationFrame(inertia);
  });

  // Touch
  ring.addEventListener('touchstart', e=>{dragging=true;lastX=e.touches[0].clientX;vel=0;cancelAnimationFrame(rafId);},{passive:true});
  ring.addEventListener('touchmove', e=>{
    if(!dragging) return;
    const dx=e.touches[0].clientX-lastX;
    rotY+=dx*0.4;vel=dx*0.4;lastX=e.touches[0].clientX;
    layout();
  },{passive:true});
  ring.addEventListener('touchend',()=>{dragging=false;rafId=requestAnimationFrame(inertia);});

  layout();

  // Animación de entrada — las tarjetas aparecen con fade+slide
  cards.forEach((c,i) => {
    c.style.opacity = '0';
    c.style.transform += ' translateY(40px)';
    setTimeout(()=>{ c.style.transition='opacity 0.55s cubic-bezier(.22,1,.36,1), transform 0.55s cubic-bezier(.22,1,.36,1)'; layout(); },60+i*90);
  });
}