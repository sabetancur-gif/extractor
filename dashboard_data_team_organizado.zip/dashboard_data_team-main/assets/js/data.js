/* Módulo 1 · datos base y estado
Aquí viven las constantes, el estado global de la interfaz y la capa de almacenamiento local.
*/

const AV_COLORS = [
  ['#1D9E75','#E1F5EE'],
  ['#378ADD','#E6F1FB'],
  ['#D85A30','#FAECE7'],
  ['#D4537E','#FBEAF0'],
  ['#BA7517','#FAEEDA'],
  ['#7F77DD','#EEEDFE']
];

const MEMBER_NAMES = {
  SB: 'Santiago Betancur',
  FQ: 'Fernanda Quintero',
  YS: 'Yoryam Sanchez'
};

const MEMBER_CAPACITY = {
  SB: 3,
  FQ: 3,
  YS: 7
};

const DEFAULTS = [
  {
    // Identificación básica del proyecto 
    id:'p1',
    name:'Sistema de Ingesta, Extracción, OCR, Clasificación y Análisis Documental Asistido por LLM',
    description:'Este proyecto consiste en una plataforma integral de inteligencia documental que permite cargar documentos en distintos formatos, ya sean nativos o escaneados, para extraer, clasificar y analizar automáticamente su contenido mediante técnicas de OCR, procesamiento de lenguaje natural e inteligencia artificial basada en LLM.',

    // Estado y priorización
    status:'active', // Estado actual del proyecto (valores típicos: active, risk, completed, etc).
    businessPriority:5, // Prioridad desde el punto de vista del negocio (cuanto mayor, más impacto comercial o estratégico).
    technicalSeverity:4, // Complejidad o riesgo técnico del proyecto (valores altos indican desafios arquitectónicos o tecnológicos relevantes).
    urgency:5, // Que tan rápido debe completarse el proyecto.
    dependencyCriticality:5, // Nivel de dependencia del proyecto frente a otros sistemas (un valor alto = muchas dependencias críticas).

    // Fechas claves
    deadline:'2026-07-15', // Fecha límite objetivo para finalizar el proyecto.
    committedAt:'2026-06-10', // Fecha que el equipo se comprometió fromalmente a entregar.
    actualAt:'', // Fecha real de finalización (si ya ocurrió).

    // Personas y tecnología
    assignees:['YS','SB'], // Personas responsables del proyecto (iniciales o IDs de usuario).
    tech:['Python','HTML','CSS','YAML','TOON'], // Stack tecnológico utilizado (lenguajes, formatos o herramientas).

    // Riesgos y dependencias
    blockers:[
      'Capacidad de la memoria RAM para el uso del LLM',
      'Ajuste final de los umbrales en el procesamiento OCR',
      'Interfaz de usuario desordenada y excesivamente codificada',
      'Uso prioritario de JSON para estructurar las peticiones al LLM'
    ], // Obstáculos activos que impiden el avance del proyecto. Normalmente serán problemas técnicos aún no resueltos.
    dependencies:['Poppler','Tesseract','Ollama'], // Sistemas o servicios externos de los que depende el proyecto para funcionar correctamente.

    // Línea de tiempo (eventos clave) - Cómo ha evolucionado el proyecto
    timeline:[
      {date:'2025-12-15', title:'Primer acercamiento', desc:'Primer acercamiento a la petición e idea de Yoryam.'},
      {date:'2026-02-09', title:'Extracción', desc:'Integración inical del OCR; extracción mediante dos motores externos.'},
      {date:'2026-02-18', title:'Entrega versión 1.0 ', desc:'Presentación de la interfaz y operatividad de los tabs de upload, extracción inicial, OCR Processing y PDF Analysis.'},
      {date:'2026-04-22', title:'Entrega Versión 2.0', desc:'Cambios en la UI, modificaciones en lo tabs ya funcionales e incorporación de lo tabs asociados al LLM.'}
    ], // Lista de hitos importantes del proyecto. Cada elemento incluye; date: cuándo ocurrió, title: título del evento, desc: descripción del hito.

    // Historial de cambios - Útilidad sobre auditoría y trazabilidad
    history:[
      {date:'2026-04-22 16:11', author:'SB', action:'En progreso - Se actualiza el repositorio privado correspondiente al proyecto.', detail:'Uso de Git; modificación sobre https://github.com/MontoyaSantiago/pdf '},
    ], // Registro detallado de acciones relevantes realizadas sobre el proyecto. Cada entrada incluye; date: fecha-hora, author: quién realizó la acción, action: qué hizo, detail: contexto adicional.

    // Actividad reciente - Vista rapida del estado actual
    recentActivity:[
      {author:'SB', date:'2026-04-22 19:47', text:'Se ajustó la estructura completa del proyecto para acoplar vacíos en la lógica.'},
      {author:'SB', date:'2026-04-22 21:33', text:'Se Integró, dado el modelo descargado y su posible uso con Ollama el chatbot sobre el documento cargado.'}
    ], // Comentarios o eventos más recientes, enfocados en lo operativo.

    // Entregables - Nos va a permitir seguir 
    deliverables:[
      {id:'d1', text:'Mejorar estructura y lógica del backend', done:false, owner:'SB', sla:'2026-05-05', committed:'2026-05-04', actual:'', goal:'Remover vacíos en la lógica actual y organizar la carpeta del proyecto', criteria:'Pruebas e informe sobre cohesión y acoplamiento en todos los módulos', notes:'Pendiente de revisar posibles nuevos huecos en la lógica'},
      {id:'d2', text:'Organizar la UI para facilitar la comprensión del usuario', done:false, owner:'SB', sla:'2026-05-05', committed:'2026-05-04', actual:'', goal:'Mejorar la interfaz de usuario para reducir la codificación excesiva', criteria:'Acercamiento sobre el público al cual va dirigido', notes:'Priorizar el enfoque de mejora sobre los tabs "PDF Analysis", "LLM Enrichment" y "Chatbot"'},
      {id:'d3', text:'Realizar una mejor versión de los procesos que integran el LLM', done:false, owner:'SB', sla:'2026-05-05', committed:'2026-05-04', actual:'', goal:'Las sugerencias del LLM son coherentes y se integran perfectamente con la lógica. ', criteria:'En el tab "LLM Enrichment", la medida asociada a los cambios sugeridos por el LLM debe ser diferente de 0', notes:'El chatbot tiene en cuenta todos los documentos cargados'},
    ], // Lista de resultados concretos que el proyecto debe producir.
    /* Cada entregable tiene:
      id: identificador, text: qué se entrega, done: si ya está completado
      owner: responsable, sla: fecha objetivo (acordada por contrato/proceso)
      committed: fecha comprometida, actual: fecha real, goal: propósito del entregable
      criteria: cómo se valida que esté completo, notes: observaciones adicionales.
    */

    // Comentarios - Avancces, problemas detectados o referencias tecnicas
    comments:[
      {author:'SB',date:'Apr 22',text:'Mejorar considerablemente la clasificación del texto extraído reconociendo en el documento firmas, tablas, imágenes, expresiones matemáticas, etc.'},
      {author:'YS',date:'Apr 22',text:'Integrar TOON para realizar las peticiones al LLM (https://dev.to/sreeni5018/toon-vs-json-a-modern-data-format-showdown-2ooc).'}
    ] // Conversaciones o notas informales del equipo.
    },

  {
    id:'p2',
    name:'Automation: PEO License Manager',
    description:'Es una solución de automatización diseñada para gestionar de manera eficiente los procesos de alta (addition) y baja (termination) de licencias PEO en los distintos estados de los Estados Unidos. El proyecto centraliza y estandariza un proceso tradicionalmente manual, reduciendo errores, tiempos operativos y mejorando la trazabilidad y el control del ciclo completo. La automatización parte de una fuente de datos estructurada, desde la cual se generan registros según el estado y el tipo de proceso requerido.',
    status:'active',

    businessPriority:5,
    technicalSeverity:3,
    urgency:5,
    dependencyCriticality:4,

    deadline:'2026-05-21',
    committedAt:'2026-05-20',
    actualAt:'',

    assignees:['YS','SB'],

    tech:['JS','HTML','Python','xlsm','CSS','JSON'],
    blockers:[
      'Ausencia de una base de datos persistente para el almacenamiento, trazabilidad y consulta centralizada de la información del proceso.',
      'Restricciones de IT sobre la instalación y ejecución de aplicativos que impiden operar el proyecto de forma local por usuario.'
    ],
    dependencies:['xlsm'],

    timeline:[
      {date:'2026-03-02', title:'Acercamiento con el equipo de ADD/TERM Compliance', desc:'Primer encuentro con el proceso manual que realiza el equpo para completar los formularios'},
      {date:'2026-04-10', title:'Versión 1.0 - Propuesta inicial. ', desc:'La idea no escalo por la falta de permisos para elaborar una API.'},
      {date:'2026-04-16', title:'Version 1.1 - Power Automate.', desc:'Se inicio a implementar el flujo en Power Automate, pero la licencia existente tiene varias limitaciones.'},
      {date:'2026-04-16', title:'Version 1.2 - xlsm.', desc:'Estructuración del flujo y dashboard para realizar el proceso mediante una macro, pero la nueva politica de IT impide el desarrollo de esta idea.'},
      {date:'2026-04-17', title:'Version 2.1 - Localhost.', desc:'Volvemos a la idea inicial de construir una pagina para realizar el proyecto, pero minimizando el uso de herramientas externas diferentes a Python.'},
      {date:'2026-04-22', title:'Entrega versión 2.1', desc:'Presentamos la estructura de la pagina y el flujo estructural del proceso TERM para el estado de Arkansas.'},
      {date:'2026-04-22', title:'Versión 2.2 - Mejoras circustanciales', desc:'Renovamos la visual de la pagina y algunos aspectos lógicos.'},
    ],

    history:[
      {date:'2026-04-22 10:30', author:'SB', action:'En progreso - Concluimos la primera entrega reproducible del proceso', detail:'Integrado solo hasta el momento el proceso de TERM en Arkansas.'},
      {date:'2026-04-27 12:17', author:'YS', action:'En progreso - Renovación total de la UI', detail:'Mejoras en el Front-End manteniendo la funcionalidades del Back-End.'},
    ],

    recentActivity:[
      {author:'SB', date:'2026-04-22 11:00', text:'Se priorizó la vinculación de la totalidad de los templates, es decir, normalizar el archivo .xlsm para terner acceso a más procesos en diferentes estados.'},
      {author:'YS', date:'2026-04-27 09:55', text:'Cambio significativo en la propuesta del mapa, se opta por una versión más util para el flujo.'}
    ],

    deliverables:[
      {id:'d1', text:'Articular la mejor opcion para realizar el proyecto', done:true, owner:'SB', sla:'2026-03-17', committed:'2026-03-16', actual:'2026-03-16', goal:'Encontrar la mejor herramienta disponible para los usuarios para ejecutar la automatización', criteria:'Aprobación formal de la idea por Yoryam', notes:'Se prioriza construir una vista funcionable con un solo proceso'},
      {id:'d2', text:'Elaboración del archivo fuente del proyecto', done:true, owner:'SB', sla:'2026-04-01', committed:'2026-03-31', actual:'2026-03-31', goal:'Desarrollar el archivo xlsm fuente del proyecto', criteria:'Implementación reutilizable de los modulos creados, trazabilidad de los archivos registrados y pendientes para su creación', notes:'Al agregar nuevo estados se debe normalizar respecto a la data existente'},
      {id:'d3', text:'Acoplamiento del Back-End y Front-End con el archivo fuente del proceso', done:true, owner:'SB', sla:'2026-04-22', committed:'2026-04-21', actual:'2026-04-16', goal:'Realizar la primera version funcional de la UI', criteria:'Logs y debugs para la trazabilidad de las diferentes interaciones', notes:'Se prioriza la funcionalidad sobre un único proceso para un único estado'},
      {id:'d4', text:'Mejoras en la UI', done:false, owner:'SB', sla:'2026-05-01', committed:'2026-05-01', actual:'', goal:'Mejorar algunos aspectos logicos y de interación', criteria:'Validar todas las aristas disponibles en la visual', notes:'Enfoque sobre la ventana emergente para editar los formularios'},
      {id:'d4', text:'Integracion de estados al proceso', done:false, owner:'SB', sla:'2026-05-15', committed:'2026-05-14', actual:'', goal:'Integración de +7 estados con ambos procesos ', criteria:'Validar el proceso con el departamento que realiza el proceso', notes:'Validar la normalizacion de campos con las personas adecuadas'}

    ],
    comments:[
      {author:'SB',date:'Apr 27',text:'Revisé la visual; Falta un scroll vertical en la ventana emergente asociada a editar los campos del PDF.'},
      {author:'RG',date:'Apr 28',text:'Revisé el código; Comprobar la estructura interna de cada módulo.'}
    ]
  },

  /*
  {
    id:'p3',
    name:'Mobile SDK iOS/Android',
    description:'SDK nativo multiplataforma para integración de pagos y autenticación biométrica en apps de terceros.',
    status:'active',
    businessPriority:4,
    technicalSeverity:5,
    urgency:3,
    dependencyCriticality:4,
    deadline:'2026-06-30',
    committedAt:'2026-06-20',
    actualAt:'2026-06-30',
    assignees:['JP','VK','CR'],
    tech:['Swift','Kotlin','Rust','C FFI'],
    blockers:[
      'Revisión de interoperabilidad en bindings nativos',
      'Definición final de callbacks en iOS'
    ],
    dependencies:['Payments Core','Identity Provider','Crypto Module'],
    timeline:[
      {date:'2026-04-12', title:'API pública definida', desc:'Se cerró el contrato base del SDK y el versionado.'},
      {date:'2026-04-18', title:'Core en Rust iniciado', desc:'Se compartió la lógica crítica para ambas plataformas.'},
      {date:'2026-04-24', title:'Biometría en evaluación', desc:'Se revisan políticas de Face ID / Touch ID / Android biometrics.'}
    ],
    history:[
      {date:'2026-04-24 12:20', author:'VK', action:'Documentó riesgos de FFI', detail:'Se requiere revisar manejo de memoria en bindings.'},
      {date:'2026-04-21 15:15', author:'JP', action:'Aprobó arquitectura del SDK', detail:'Se validó Rust como core compartido.'},
      {date:'2026-04-19 10:00', author:'CR', action:'Publicó ejemplos de integración', detail:'Se agregaron snippets para iOS y Android.'}
    ],
    recentActivity:[
      {author:'JP', date:'Hoy 09:10', text:'Se definieron contratos para callbacks de pago y error handling.'},
      {author:'VK', date:'Ayer 18:25', text:'Se probó el bridge nativo con un payload mínimo sin crashes.'}
    ],
    deliverables:[
      {id:'d1', text:'Arquitectura del SDK y API pública', done:true, owner:'JP', sla:'2026-04-14', committed:'2026-04-14', actual:'2026-04-13', goal:'Definir contratos y estructura base del SDK', criteria:'Documento aprobado por el equipo', notes:'Incluye consideraciones de versionado'},
      {id:'d2', text:'Core en Rust con bindings C', done:false, owner:'VK', sla:'2026-05-10', committed:'2026-05-09', actual:'', goal:'Compartir lógica crítica entre plataformas', criteria:'Compila y consume desde iOS y Android', notes:'Revisar interoperabilidad'},
      {id:'d3', text:'Módulo de pagos iOS (Swift)', done:false, owner:'CR', sla:'2026-05-18', committed:'2026-05-16', actual:'', goal:'Exponer pagos en apps iOS', criteria:'Flujo de pago completado en demo', notes:'Pendiente integración de callbacks'},
      {id:'d4', text:'Módulo de pagos Android (Kotlin)', done:false, owner:'JP', sla:'2026-05-22', committed:'2026-05-20', actual:'', goal:'Exponer pagos en apps Android', criteria:'Flujo de pago completado en demo', notes:'Sincronizar con el core'},
      {id:'d5', text:'Autenticación biométrica multiplataforma', done:false, owner:'VK', sla:'2026-06-05', committed:'2026-06-03', actual:'', goal:'Unificar el acceso biométrico', criteria:'Face ID / Touch ID / biometría Android funcionando', notes:'Depende de políticas de cada plataforma'},
      {id:'d6', text:'Documentación y ejemplos de integración', done:false, owner:'CR', sla:'2026-06-12', committed:'2026-06-11', actual:'', goal:'Facilitar adopción por terceros', criteria:'README y quickstart listos', notes:'Agregar snippets y guías de error'}
    ],
    comments:[
      {author:'JP',date:'Apr 18',text:'Arquitectura definida. Core en Rust es la decisión correcta para compartir lógica crítica.'}
    ]
  },
  {
    id:'p4',
    name:'Security Audit Q1/2026',
    description:'Auditoría de seguridad completa: OWASP Top 10, pentesting de APIs, rotación de secretos y hardening de infraestructura.',
    status:'delivered',
    businessPriority:5,
    technicalSeverity:5,
    urgency:2,
    dependencyCriticality:5,
    deadline:'2026-04-10',
    committedAt:'2026-04-10',
    actualAt:'2026-04-08',
    assignees:['ML','CR','SA'],
    tech:['Vault','Snyk','Trivy','Burp'],
    blockers:[],
    dependencies:['IAM','Container Registry','Secrets Manager'],
    timeline:[
      {date:'2026-03-29', title:'Inicio del audit', desc:'Se definió alcance, superficies y sistema de evidencias.'},
      {date:'2026-04-04', title:'Hallazgos medios resueltos', desc:'Las vulnerabilidades intermedias quedaron mitigadas.'},
      {date:'2026-04-08', title:'Informe final entregado', desc:'Se consolidó el remediación plan y la versión ejecutiva.'}
    ],
    history:[
      {date:'2026-04-08 15:00', author:'ML', action:'Cerró la auditoría', detail:'0 vulnerabilidades críticas, 3 medias resueltas.'},
      {date:'2026-04-06 11:30', author:'CR', action:'Ejecutó pentest final', detail:'Cobertura REST/gRPC completada y documentada.'},
      {date:'2026-04-04 09:45', author:'SA', action:'Rotó secretos', detail:'Vault actualizado en entornos clave.'}
    ],
    recentActivity:[
      {author:'ML', date:'Cerrado', text:'Informe ejecutivo enviado al CISO con remediación y trazabilidad.'}
    ],
    deliverables:[
      {id:'d1', text:'Escaneo de dependencias — CVEs', done:true, owner:'ML', sla:'2026-04-02', committed:'2026-04-01', actual:'2026-04-02', goal:'Detectar vulnerabilidades de terceros', criteria:'Reporte generado y clasificado', notes:'Sin hallazgos críticos'},
      {id:'d2', text:'Pentesting de APIs REST/gRPC', done:true, owner:'CR', sla:'2026-04-05', committed:'2026-04-04', actual:'2026-04-05', goal:'Validar superficie de ataque', criteria:'Pruebas ejecutadas y documentadas', notes:'Hallazgos resueltos'},
      {id:'d3', text:'Rotación de secretos en Vault', done:true, owner:'SA', sla:'2026-04-07', committed:'2026-04-06', actual:'2026-04-07', goal:'Eliminar secretos expuestos', criteria:'Rotación completada en entornos clave', notes:'Tokens renovados'},
      {id:'d4', text:'Informe ejecutivo para CISO', done:true, owner:'ML', sla:'2026-04-10', committed:'2026-04-09', actual:'2026-04-08', goal:'Consolidar resultados y riesgos', criteria:'Informe entregado', notes:'Incluye plan de remediación'}
    ],
    comments:[
      {author:'ML',date:'Apr 8',text:'Completado. 0 vulnerabilidades críticas. 3 medias resueltas. Informe enviado al CISO.'}
    ]
  }
  */
];

const storage = (window.storage && typeof window.storage.get === 'function')
  ? window.storage
  : {
      async get(key){ const v = localStorage.getItem(key); return v ? {value:v} : null; },
      async set(key, value){ localStorage.setItem(key, value); }
    };

const S = {
  projects: [],
  filter: 'all',
  sel: null,
  tab: 'executive',
  showForm: false,
  editId: null,
  form: {}
};
