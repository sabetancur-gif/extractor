"""
scheduler.py — Sincronización automática periódica
Usa APScheduler para sync en background sin bloquear el servidor
"""
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from typing import Callable, Optional
import logging

logger = logging.getLogger(__name__)


class SyncScheduler:
    def __init__(self):
        self.scheduler = AsyncIOScheduler(timezone="America/Bogota")
        self.jobs: dict = {}

    def start(self):
        if not self.scheduler.running:
            self.scheduler.start()
            logger.info("✅ Scheduler iniciado")

    def stop(self):
        if self.scheduler.running:
            self.scheduler.shutdown()

    def schedule_account(self, account_id: int, sync_fn: Callable, interval_minutes: int = 30):
        """Programar sync periódico para una cuenta"""
        job_id = f"sync_account_{account_id}"

        if job_id in self.jobs:
            self.scheduler.remove_job(job_id)

        job = self.scheduler.add_job(
            sync_fn,
            trigger=IntervalTrigger(minutes=interval_minutes),
            id=job_id,
            args=[account_id],
            misfire_grace_time=60,
            replace_existing=True
        )
        self.jobs[job_id] = job
        logger.info(f"📅 Sync programado para cuenta {account_id} cada {interval_minutes} min")
        return job_id

    def remove_account(self, account_id: int):
        job_id = f"sync_account_{account_id}"
        if job_id in self.jobs:
            try:
                self.scheduler.remove_job(job_id)
                del self.jobs[job_id]
                logger.info(f"🗑 Sync removido para cuenta {account_id}")
            except Exception as e:
                logger.error(f"Error removiendo job: {e}")

    def get_jobs_status(self) -> list:
        return [
            {
                "id": job.id,
                "next_run": job.next_run_time.isoformat() if job.next_run_time else None,
                "trigger": str(job.trigger)
            }
            for job in self.scheduler.get_jobs()
        ]
