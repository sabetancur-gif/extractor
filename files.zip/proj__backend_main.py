"""
=============================================================
backend/main.py — API FastAPI Completa MailAI Panel
=============================================================
Endpoints:
  /health              → Estado del sistema
  /accounts            → Cuentas de Outlook detectadas
  /sync                → Clasificación de todos los emails
  /emails              → Lista con filtros avanzados
  /stats               → Estadísticas completas del panel
  /danibot/chat        → Chat con DaniBot (IA conversacional)
  /danibot/reset       → Reiniciar historial de DaniBot
  /danibot/suggestions → Sugerencias de preguntas
  /patterns            → Patrones e anomalías detectadas
  /digest              → Digest semanal generado por IA
  /quick-reply/{id}    → Abrir respuesta en Outlook (COM)
  /ws                  → WebSocket tiempo real
=============================================================
"""

import asyncio
from contextlib import asynccontextmanager
from typing import List, Optional
from datetime import datetime

from fastapi import FastAPI, BackgroundTasks, HTTPException, WebSocket, WebSocketDisconnect, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

# Módulos del proyecto
from outlook_reader    import OutlookMultiAccountReader
from classifier        import EmailClassifier
from database          import PanelDatabase
from danibot           import DaniBot
from pattern_detector  import PatternDetector
from digest_generator  import DigestGenerator
from config            import Settings

# ─────────────────────────────────────────────────────────────
# Instancias globales
# ─────────────────────────────────────────────────────────────
settings   = Settings()
db         = PanelDatabase(settings.database_url)
classifier = EmailClassifier(
    ollama_url = settings.ollama_base_url,
    model      = settings.ollama_model,
    timeout    = settings.ollama_timeout,
)
danibot          = DaniBot(settings.database_url, settings.ollama_base_url, settings.ollama_model, settings.ollama_timeout)
pattern_detector = PatternDetector(settings.database_url)
digest_gen       = DigestGenerator(settings.database_url, settings.ollama_base_url, settings.ollama_model, settings.ollama_timeout)


# ─────────────────────────────────────────────────────────────
# WebSocket Manager
# ─────────────────────────────────────────────────────────────
class WSManager:
    def __init__(self):
        self.connections: List[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.connections.append(ws)

    def disconnect(self, ws: WebSocket):
        if ws in self.connections:
            self.connections.remove(ws)

    async def broadcast(self, data: dict):
        dead = []
        for ws in self.connections:
            try:
                await ws.send_json(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)

ws_manager = WSManager()


# ─────────────────────────────────────────────────────────────
# Lifespan
# ─────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    db.initialize()

    # Verificar Ollama
    ollama_ok = classifier.health_check()
    if not ollama_ok.get("ollama_running"):
        print(f"⚠️  Ollama no disponible en {settings.ollama_base_url}")
    else:
        print(f"✅ Ollama → modelo {settings.ollama_model}")

    # Verificar Outlook
    try:
        reader      = OutlookMultiAccountReader()
        outlook_inf = reader.test_connection()
        print(f"✅ Outlook → {outlook_inf['accounts_count']} cuenta(s)")
    except Exception as e:
        print(f"⚠️  Outlook no disponible: {e}")

    print("🚀 MailAI Panel API iniciado")
    yield


# ─────────────────────────────────────────────────────────────
# App
# ─────────────────────────────────────────────────────────────
app = FastAPI(
    title       = "MailAI Panel API",
    version     = "2.0.0",
    description = "Panel clasificador multi-cuenta con DaniBot, patrones y digest",
    lifespan    = lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins  = ["http://localhost:3000", "http://localhost:5173"],
    allow_methods  = ["*"],
    allow_headers  = ["*"],
    allow_credentials = True,
)


# ─────────────────────────────────────────────────────────────
# Modelos Pydantic
# ─────────────────────────────────────────────────────────────
class SyncRequest(BaseModel):
    days_back:         int        = 14
    limit_per_account: int        = 100
    include_read:      bool       = True
    folders:           List[str]  = ["Bandeja de entrada", "Inbox"]

class DaniBotRequest(BaseModel):
    message:    str
    account_id: Optional[int] = None

class KanbanMoveRequest(BaseModel):
    email_id:        int
    new_urgency:     str
    new_importance:  Optional[str] = None


# ─────────────────────────────────────────────────────────────
# HEALTH
# ─────────────────────────────────────────────────────────────
@app.get("/health")
async def health():
    ollama = classifier.health_check()
    try:
        reader  = OutlookMultiAccountReader()
        outlook = reader.test_connection()
    except Exception as e:
        outlook = {"outlook_available": False, "error": str(e), "accounts_count": 0}
    return {
        "status":    "healthy" if (ollama.get("ollama_running") and outlook.get("outlook_available")) else "degraded",
        "timestamp": datetime.now().isoformat(),
        "ollama":    ollama,
        "outlook":   outlook,
    }


# ─────────────────────────────────────────────────────────────
# CUENTAS
# ─────────────────────────────────────────────────────────────
@app.get("/accounts")
async def get_accounts():
    """Lista las cuentas de Outlook abiertas y sus estadísticas en la DB."""
    try:
        reader   = OutlookMultiAccountReader()
        accounts = reader.get_accounts()
        db_accs  = db.get_accounts()
        return {
            "outlook_accounts": [{"name": a.name, "email": a.email} for a in accounts],
            "db_accounts":      db_accs,
        }
    except Exception as e:
        raise HTTPException(503, f"Outlook no disponible: {e}")


# ─────────────────────────────────────────────────────────────
# SINCRONIZACIÓN
# ─────────────────────────────────────────────────────────────
@app.post("/sync")
async def sync(req: SyncRequest, background_tasks: BackgroundTasks):
    """Inicia la lectura de Outlook y clasificación en background."""
    background_tasks.add_task(_sync_task, req)
    return {"status": "started", "message": "Sincronización iniciada"}

async def _sync_task(req: SyncRequest):
    """Tarea background: Outlook → clasificar → DB → notificar WS."""
    try:
        await ws_manager.broadcast({"type": "sync_start", "message": "📂 Conectando con Outlook..."})

        reader = OutlookMultiAccountReader()
        emails_raw, accounts = reader.fetch_all_emails(
            days_back=req.days_back, limit_per_account=req.limit_per_account,
            folders=req.folders, include_read=req.include_read,
        )

        # Guardar cuentas en DB
        acc_id_map = {}
        for acc in accounts:
            aid = db.save_account(acc.name, acc.email)
            acc_id_map[acc.name] = aid

        await ws_manager.broadcast({
            "type": "sync_reading_done",
            "total": len(emails_raw), "accounts": len(accounts),
            "message": f"📬 {len(emails_raw)} emails en {len(accounts)} cuenta(s). Clasificando...",
        })

        classified = skipped = errors = 0

        for i, raw in enumerate(emails_raw):
            email_dict = {
                "message_id": raw.message_id, "thread_key": raw.thread_key,
                "account_name": raw.account_name, "account_email": raw.account_email,
                "sender_name": raw.sender_name, "sender_email": raw.sender_email,
                "to_recipients": raw.to_recipients, "subject": raw.subject,
                "body": raw.body, "date": raw.date,
                "has_attachments": raw.has_attachments, "outlook_folder": raw.outlook_folder,
                "importance": raw.importance, "is_read": raw.is_read,
            }
            if db.email_exists(raw.message_id):
                skipped += 1
                continue
            try:
                clf      = classifier.classify(email_dict)
                acc_id   = acc_id_map.get(raw.account_name, 1)
                email_id = db.save_email(email_dict, clf, acc_id)
                classified += 1

                await ws_manager.broadcast({
                    "type": "email_classified",
                    "progress": round((i + 1) / len(emails_raw) * 100),
                    "classified": classified,
                    "data": {
                        "id": email_id, "subject": raw.subject,
                        "sender_name": raw.sender_name, "account_name": raw.account_name,
                        "importance_score": clf.importance.score,
                        "importance_label": clf.importance.label,
                        "importance_color": clf.importance.color,
                        "sentiment_label":  clf.sentiment.label,
                        "sentiment_emoji":  clf.sentiment.emoji,
                        "sender_profile":   clf.sender.profile,
                        "sender_is_vip":    clf.sender.is_vip,
                        "urgency_level":    clf.urgency.level,
                        "urgency_color":    clf.urgency.color,
                        "summary":          clf.summary,
                    },
                })
                await asyncio.sleep(0.15)
            except Exception as e:
                errors += 1
                print(f"❌ Error: {e}")

        for acc in accounts:
            db.update_account_sync(acc_id_map.get(acc.name, 1), acc.total_emails)

        # Detectar patrones tras la clasificación
        patterns = pattern_detector.detect_all()
        for p in patterns:
            await ws_manager.broadcast({"type": "pattern_detected", "pattern": p})

        await ws_manager.broadcast({
            "type": "sync_complete", "classified": classified,
            "skipped": skipped, "errors": errors, "total": len(emails_raw),
            "message": f"✅ {classified} clasificados | {skipped} ya existían | {errors} errores",
        })
    except Exception as e:
        await ws_manager.broadcast({"type": "sync_error", "message": f"❌ {e}"})


# ─────────────────────────────────────────────────────────────
# EMAILS
# ─────────────────────────────────────────────────────────────
@app.get("/emails")
async def get_emails(
    account_id:       Optional[int]  = None,
    importance_label: Optional[str]  = None,
    sentiment_label:  Optional[str]  = None,
    urgency_level:    Optional[str]  = None,
    sender_profile:   Optional[str]  = None,
    is_vip:           Optional[bool] = None,
    search:           Optional[str]  = None,
    sort:             str            = "date",
    limit:            int            = Query(100, ge=1, le=500),
    offset:           int            = 0,
):
    filters = {k: v for k, v in {
        "account_id": account_id, "importance_label": importance_label,
        "sentiment_label": sentiment_label, "urgency_level": urgency_level,
        "sender_profile": sender_profile, "is_vip": is_vip,
        "search": search, "sort": sort,
    }.items() if v is not None}
    return db.get_emails(filters, limit, offset)

@app.patch("/emails/{email_id}/urgency")
async def move_kanban(email_id: int, req: KanbanMoveRequest):
    """Mueve un email en el tablero Kanban actualizando su urgencia."""
    success = db.update_email_urgency(email_id, req.new_urgency)
    if not success:
        raise HTTPException(404, "Email no encontrado")
    return {"status": "updated", "new_urgency": req.new_urgency}

@app.patch("/emails/{email_id}/action-done")
async def mark_action_done(email_id: int, action_index: int = 0):
    """Marca una acción como completada."""
    success = db.mark_action_done(email_id, action_index)
    return {"status": "ok" if success else "not_found"}


# ─────────────────────────────────────────────────────────────
# ESTADÍSTICAS
# ─────────────────────────────────────────────────────────────
@app.get("/stats")
async def get_stats(account_id: Optional[int] = None):
    return db.get_panel_stats(account_id)


# ─────────────────────────────────────────────────────────────
# DANIBOT
# ─────────────────────────────────────────────────────────────
@app.post("/danibot/chat")
async def danibot_chat(req: DaniBotRequest):
    """Envía un mensaje a DaniBot y recibe su respuesta."""
    if not req.message.strip():
        raise HTTPException(400, "El mensaje no puede estar vacío")
    response = danibot.chat(req.message, req.account_id)
    return response

@app.post("/danibot/reset")
async def danibot_reset():
    """Reinicia el historial de conversación de DaniBot."""
    danibot.reset_history()
    return {"status": "reset", "message": "Historial limpiado"}

@app.get("/danibot/suggestions")
async def danibot_suggestions():
    """Devuelve sugerencias de preguntas para el chat."""
    return {"suggestions": DaniBot.get_suggestions()}


# ─────────────────────────────────────────────────────────────
# PATRONES
# ─────────────────────────────────────────────────────────────
@app.get("/patterns")
async def get_patterns(account_id: Optional[int] = None):
    """Detecta y devuelve los patrones e anomalías del inbox."""
    patterns = pattern_detector.detect_all(account_id)
    return {"patterns": patterns, "count": len(patterns)}


# ─────────────────────────────────────────────────────────────
# DIGEST SEMANAL
# ─────────────────────────────────────────────────────────────
@app.get("/digest")
async def get_digest(account_id: Optional[int] = None):
    """Genera y devuelve el digest semanal."""
    digest = digest_gen.generate(account_id)
    return digest


# ─────────────────────────────────────────────────────────────
# RESPUESTA RÁPIDA (abre en Outlook via COM)
# ─────────────────────────────────────────────────────────────
@app.post("/quick-reply/{email_id}")
async def quick_reply(email_id: int):
    """
    Abre Outlook con un email de respuesta pre-redactado.
    Usa win32com para crear el MailItem con el borrador de DaniBot.
    """
    email = db.get_email_by_id(email_id)
    if not email:
        raise HTTPException(404, "Email no encontrado")
    try:
        import win32com.client
        outlook = win32com.client.Dispatch("Outlook.Application")
        mail    = outlook.CreateItem(0)   # 0 = olMailItem
        mail.To      = email.get("sender_email", "")
        mail.Subject = f"Re: {email.get('subject','')}"
        mail.Body    = email.get("urgency_reply", "") + "\n\n---\nEnviado desde MailAI Panel"
        mail.Display(True)  # True = modal (False = en background)
        return {"status": "opened", "to": email.get("sender_email")}
    except ImportError:
        return {"status": "error", "message": "pywin32 no instalado"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ─────────────────────────────────────────────────────────────
# WEBSOCKET
# ─────────────────────────────────────────────────────────────
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
