// =============================================================
// src/types/index.ts
// Definiciones de tipos TypeScript para todo el proyecto.
// Centralizar aquí evita importaciones cruzadas y mantiene
// la consistencia de datos entre frontend y backend.
// =============================================================

// ─────────────────────────────────────────────────────────────
// CUENTAS DE OUTLOOK
// ─────────────────────────────────────────────────────────────

/** Cuenta de Outlook detectada (un Store/buzon) */
export interface OutlookAccount {
  id:           number;
  name:         string;   // Nombre visible en Outlook
  email:        string;   // Dirección de email
  total_emails: number;   // Emails clasificados
  last_sync:    string | null;
}

// ─────────────────────────────────────────────────────────────
// LAS 4 DIMENSIONES DE CLASIFICACIÓN
// ─────────────────────────────────────────────────────────────

export type ImportanceLabel = 'critica' | 'alta' | 'media' | 'baja' | 'info';
export type SentimentLabel  = 'positivo' | 'negativo' | 'neutral' | 'mixto';
export type SentimentTone   = 'formal' | 'informal' | 'agresivo' | 'urgente' | 'amigable' | 'neutro' | 'corporativo';
export type SenderProfile   = 'cliente' | 'proveedor' | 'colega' | 'jefe' | 'externo' | 'interno' | 'desconocido';
export type UrgencyLevel    = 'critica' | 'alta' | 'media' | 'baja' | 'ninguna';
export type EmailCategory   = 'trabajo' | 'finanzas' | 'legal' | 'soporte' | 'personal' | 'marketing' | 'educacion' | 'redes' | 'spam' | 'otro';

// ─────────────────────────────────────────────────────────────
// EMAIL CLASIFICADO (tal como llega de la API)
// ─────────────────────────────────────────────────────────────

export interface Email {
  id:              number;
  message_id:      string;
  thread_key:      string;
  account_id:      number;
  account_name:    string;

  // Datos del email
  sender_name:     string;
  sender_email:    string;
  to_recipients:   string;
  subject:         string;
  body:            string;
  date:            string;   // ISO 8601
  has_attachments: boolean;
  outlook_folder:  string;
  is_read:         boolean;

  // Dimensión 1: Importancia
  importance_score:  number;          // 1-100
  importance_label:  ImportanceLabel;
  importance_reason: string;
  importance_color:  string;          // hex

  // Dimensión 2: Sentimiento
  sentiment_label: SentimentLabel;
  sentiment_score: number;            // -1.0 a 1.0
  sentiment_tone:  SentimentTone;
  sentiment_emoji: string;

  // Dimensión 3: Remitente
  sender_profile:  SenderProfile;
  sender_trust:    number;            // 0-100
  sender_is_vip:   boolean;
  sender_company:  string;
  sender_relation: string;

  // Dimensión 4: Urgencia
  urgency_level:    UrgencyLevel;
  urgency_deadline: string;
  urgency_actions:  string[];
  urgency_reply:    string;
  urgency_color:    string;           // hex

  // General
  summary:    string;
  category:   EmailCategory;
  language:   string;
  key_topics: string[];
  spam_score: number;
  confidence: number;
}

// ─────────────────────────────────────────────────────────────
// ESTADÍSTICAS DEL PANEL
// ─────────────────────────────────────────────────────────────

export interface DistItem {
  [key: string]: string | number;
  c: number;
}

export interface TopSender {
  sender_email:   string;
  sender_name:    string;
  sender_profile: SenderProfile;
  sender_trust:   number;
  sender_is_vip:  boolean;
  c:              number;
  avg_imp:        number;
}

export interface DayData {
  day:     string;
  c:       number;
  avg_imp: number;
}

export interface CriticalEmail {
  id:               number;
  sender_name:      string;
  subject:          string;
  importance_score: number;
  urgency_level:    UrgencyLevel;
  urgency_deadline: string;
  urgency_actions:  string;
  sentiment_emoji:  string;
}

export interface AccountStat {
  name:  string;
  email: string;
  c:     number;
}

export interface PanelStats {
  total:           number;
  vip_count:       number;
  avg_importance:  number;
  by_importance:   Array<{ importance_label: ImportanceLabel; c: number }>;
  by_sentiment:    Array<{ sentiment_label: SentimentLabel; c: number }>;
  by_urgency:      Array<{ urgency_level: UrgencyLevel; c: number }>;
  by_profile:      Array<{ sender_profile: SenderProfile; c: number }>;
  by_tone:         Array<{ sentiment_tone: SentimentTone; c: number }>;
  critical_emails: CriticalEmail[];
  top_senders:     TopSender[];
  by_day:          DayData[];
  accounts:        AccountStat[];
}

// ─────────────────────────────────────────────────────────────
// DANIBOT - CHAT CONVERSACIONAL
// ─────────────────────────────────────────────────────────────

export type MessageRole = 'user' | 'assistant' | 'system';

export interface ChatMessage {
  id:        string;        // UUID local
  role:      MessageRole;
  content:   string;
  timestamp: Date;
  loading?:  boolean;       // true mientras espera respuesta
  error?:    boolean;       // true si hubo error
  data?:     DaniBotData;   // datos estructurados para visualizar
}

/** Datos opcionales que DaniBot puede devolver junto al texto */
export interface DaniBotData {
  type:    'emails' | 'stats' | 'sender' | 'pattern' | 'digest';
  payload: unknown;         // varía según el tipo
}

export interface DaniBotResponse {
  answer:     string;       // respuesta en lenguaje natural
  data?:      DaniBotData;  // datos complementarios
  queries?:   string[];     // consultas SQL ejecutadas (debug)
}

// ─────────────────────────────────────────────────────────────
// PATRONES DETECTADOS
// ─────────────────────────────────────────────────────────────

export interface Pattern {
  id:          string;
  type:        'volume_spike' | 'anomaly' | 'deadline' | 'trend' | 'recurring';
  title:       string;
  description: string;
  severity:    'info' | 'warning' | 'critical';
  icon:        string;
  action?:     string;    // acción sugerida
  data?:       unknown;
}

// ─────────────────────────────────────────────────────────────
// DIGEST SEMANAL
// ─────────────────────────────────────────────────────────────

export interface WeeklyDigest {
  week_start:       string;
  week_end:         string;
  total_emails:     number;
  critical_count:   number;
  pending_actions:  number;
  top_sender:       string;
  dominant_category:string;
  sentiment_summary:string;
  narrative:        string;     // texto generado por Ollama
  key_insights:     string[];   // puntos clave
}

// ─────────────────────────────────────────────────────────────
// FILTROS DE BANDEJA
// ─────────────────────────────────────────────────────────────

export interface EmailFilters {
  importance_label?: ImportanceLabel;
  sentiment_label?:  SentimentLabel;
  urgency_level?:    UrgencyLevel;
  sender_profile?:   SenderProfile;
  is_vip?:           boolean;
  search?:           string;
  sort?:             'date' | 'importance' | 'urgency' | 'trust';
  account_id?:       number;
}

// ─────────────────────────────────────────────────────────────
// WEBSOCKET EVENTS
// ─────────────────────────────────────────────────────────────

export type WSEventType =
  | 'sync_start'
  | 'sync_reading_done'
  | 'email_classified'
  | 'sync_complete'
  | 'sync_error'
  | 'pattern_detected';

export interface WSEvent {
  type:        WSEventType;
  message?:    string;
  progress?:   number;
  classified?: number;
  total?:      number;
  accounts?:   number;
  errors?:     number;
  skipped?:    number;
  data?:       Partial<Email>;
  pattern?:    Pattern;
}

// ─────────────────────────────────────────────────────────────
// HEALTH CHECK
// ─────────────────────────────────────────────────────────────

export interface HealthStatus {
  status:    'healthy' | 'degraded' | 'error';
  timestamp: string;
  ollama: {
    ollama_running:   boolean;
    model:            string;
    model_available:  boolean;
    installed_models: string[];
  };
  outlook: {
    outlook_available: boolean;
    accounts_count:    number;
    accounts:          Array<{ name: string; email: string }>;
    error?:            string;
  };
}

// ─────────────────────────────────────────────────────────────
// UI STATE
// ─────────────────────────────────────────────────────────────

export type Page = 'dashboard' | 'kanban' | 'inbox' | 'analytics' | 'contacts' | 'settings';

export interface Toast {
  id:      string;
  message: string;
  type:    'success' | 'error' | 'info' | 'warning';
}
