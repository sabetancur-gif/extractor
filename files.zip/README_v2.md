# MailAI Pro v2.0 — Clasificador Inteligente de Emails

Sistema profesional para clasificar, analizar y gestionar emails con Claude AI.
10+ dimensiones de análisis, reglas automáticas, analytics avanzado y CRM de contactos.

## Estructura completa

```
mailai-pro/
├── backend/
│   ├── main.py              ← API FastAPI + WebSocket tiempo real
│   ├── classifier.py        ← IA con 10+ dimensiones de análisis
│   ├── database.py          ← SQLite multi-cuenta, schema completo
│   ├── email_fetcher.py     ← Conexión IMAP (Gmail, Outlook, Yahoo)
│   ├── rules_engine.py      ← Motor de reglas IF/THEN automáticas
│   ├── scheduler.py         ← Sync periódico con APScheduler
│   ├── config.py            ← Variables de entorno
│   └── requirements.txt
└── frontend/
    ├── index.html
    ├── vite.config.js
    ├── package.json
    └── src/
        ├── main.jsx
        ├── App.jsx           ← Root + WebSocket + routing
        ├── index.css         ← Sistema de estilos completo
        ├── store/index.js    ← Estado global con Zustand
        ├── services/api.js   ← HTTP + WebSocket client
        ├── pages/
        │   ├── Dashboard.jsx
        │   ├── Inbox.jsx
        │   ├── Analytics.jsx
        │   ├── Contacts.jsx
        │   └── Settings.jsx
        └── components/
            ├── Sidebar.jsx
            ├── Topbar.jsx
            ├── Toast.jsx
            ├── CommandPalette.jsx
            └── AIInsights.jsx
```

## Archivos en este paquete

Cada archivo descargado tiene el prefijo con su ubicación en el proyecto:
- backend__main.py          → backend/main.py
- backend__classifier.py    → backend/classifier.py
- backend__database.py      → backend/database.py
- backend__rules_engine.py  → backend/rules_engine.py
- backend__scheduler.py     → backend/scheduler.py
- backend__config.py        → backend/config.py
- backend__requirements_and_env.txt → backend/requirements.txt + .env.example
- frontend__store.js        → frontend/src/store/index.js
- frontend__api.js          → frontend/src/services/api.js
- frontend__App.jsx         → frontend/src/App.jsx
- frontend__components_core.jsx → Sidebar + Topbar + Toast + CommandPalette
- frontend__AIInsights.jsx  → frontend/src/components/AIInsights.jsx
- frontend__Inbox.jsx       → frontend/src/pages/Inbox.jsx
- frontend__Dashboard.jsx   → frontend/src/pages/Dashboard.jsx
- frontend__Analytics_Settings.jsx → Analytics.jsx + Settings.jsx
- frontend__Contacts.jsx    → frontend/src/pages/Contacts.jsx
- frontend__index.css       → frontend/src/index.css
- frontend__package_vite_main.txt → package.json + vite.config.js + main.jsx + index.html

## Instalacion rapida

### Backend
```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install fastapi uvicorn anthropic pydantic pydantic-settings apscheduler chardet python-multipart websockets python-dotenv
echo "ANTHROPIC_API_KEY=sk-ant-xxx" > .env
uvicorn main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## Configurar Gmail
1. Ir a myaccount.google.com/apppasswords
2. Crear App Password para Mail (requiere 2FA activo)
3. Usar los 16 caracteres como password en el formulario
4. Activar IMAP: Gmail → Configuracion → Reenvio e IMAP

## Analisis IA por email
category, subcategory, priority_score (1-100), priority_label,
sentiment (label + score + tone), urgency (level + reason + deadline),
entities (people + companies + dates + amounts + locations),
action_items[], suggested_reply, key_topics[], language,
spam_score, thread_type, summary, requires_action, confidence

## Dimensiones del motor de reglas
Condiciones: sender_email, sender_name, sender_domain, subject, body,
category, subcategory, priority_label, priority_score, sentiment, tone,
urgency_level, language, spam_score, has_attachments, requires_action,
thread_type, entity_person, entity_company

Operadores: equals, contains, starts_with, ends_with, regex, gte, lte, gt, is_true

Acciones: set_category, set_priority, set_starred, set_archived, mark_read, mark_deleted

## Endpoints principales
POST /accounts/connect    - Conectar cuenta de email
POST /sync                - Iniciar sync y clasificacion
GET  /emails              - Listar emails con filtros
GET  /stats               - 15+ metricas analiticas
GET  /contacts            - CRM de contactos
GET  /rules               - Reglas automaticas
POST /rules               - Crear nueva regla
POST /rules/{id}/test     - Testear regla
GET  /export/csv          - Exportar a CSV
WS   /ws                  - Eventos en tiempo real
