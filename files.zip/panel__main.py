"""
=============================================================
MÓDULO 4: main.py
Panel Clasificador MailAI — API FastAPI + WebSocket
=============================================================
Endpoints REST para el panel de visualización.
WebSocket para actualizaciones en tiempo real durante el sync.
=============================================================
"""
import asyncio
from contextlib import asynccontextmanager
from typing import List, Optional, Dict
from datetime import datetime

from fastapi import FastAPI, BackgroundTasks, HTTPException, WebSocket, WebSocketDisconnect, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from outlook_reader import OutlookMultiAccountReader
from classifier    import EmailClassifier
from database      import PanelDatabase
from config        import Settings

settings   = Settings()
db         = PanelDatabase(settings.database_url)
classifier = EmailClassifier(
    ollama_url = settings.ollama_base_url,
    model      = settings.ollama_model,
    timeout    = settings.ollama_timeout,
)


# ── WebSocket Manager ─────────────────────────────────────────
class WSManager:
    def __init__(self):
        self.connections: List[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.connections.append(ws)

    def disconnect(self, ws: WebSocket):
        if ws in self.connections:
            self.connections.remove(ws)

    async def broadcast(self, data: dict):
        dead = []
        for ws in self.connections:
            try:
                await ws.send_json(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)

ws = WSManager()


# ── Lifespan ──────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    db.initialize()
    ollama_ok = classifier.health_check()
    if not ollama_ok.get("ollama_running"):
        print(f"⚠️  Ollama no está corriendo en {settings.ollama_base_url}")
        print(f"   Ejecuta: ollama serve")
    elif not ollama_ok.get("model_available"):
        print(f"⚠️  Modelo '{settings.ollama_model}' no disponible")
        print(f"   Ejecuta: ollama pull {settings.ollama_model}")
    else:
        print(f"✅ Ollama listo con modelo {settings.ollama_model}")

    # Verificar Outlook
    try:
        reader = OutlookMultiAccountReader()
        outlook_info = reader.test_connection()
        print(f"✅ Outlook: {outlook_info['accounts_count']} cuenta(s) detectada(s)")
    except Exception as e:
        print(f"⚠️  Outlook no disponible: {e}")

    print("🚀 Panel Clasificador MailAI iniciado")
    yield


# ── App ───────────────────────────────────────────────────────
app = FastAPI(
    title       = "MailAI Panel Clasificador",
    version     = "1.0.0",
    description = "Panel de clasificación de emails con 4 dimensiones IA + Outlook local",
    lifespan    = lifespan,
)

app.add_middleware(CORSMiddleware,
    allow_origins=["http://localhost:3000","http://localhost:5173"],
    allow_methods=["*"], allow_headers=["*"], allow_credentials=True,
)


# ── Modelos Pydantic ──────────────────────────────────────────
class SyncRequest(BaseModel):
    days_back:          int   = 14
    limit_per_account:  int   = 100
    include_read:       bool  = True
    outlook_folders:    List[str] = ["Bandeja de entrada", "Inbox"]


# ── Endpoints ─────────────────────────────────────────────────

@app.get("/health")
async def health():
    ollama   = classifier.health_check()
    try:
        reader   = OutlookMultiAccountReader()
        outlook  = reader.test_connection()
    except Exception as e:
        outlook = {"outlook_available": False, "error": str(e)}
    return {
        "status":    "healthy" if (ollama.get("ollama_running") and outlook.get("outlook_available")) else "degraded",
        "timestamp": datetime.now().isoformat(),
        "ollama":    ollama,
        "outlook":   outlook,
    }

@app.get("/accounts")
async def get_accounts():
    """Lista las cuentas de Outlook abiertas."""
    try:
        reader   = OutlookMultiAccountReader()
        accounts = reader.get_accounts()
        return [{"name": a.name, "email": a.email, "index": a.store_index} for a in accounts]
    except Exception as e:
        raise HTTPException(503, f"Outlook no disponible: {e}")

@app.post("/sync")
async def sync(req: SyncRequest, background_tasks: BackgroundTasks):
    """Inicia la lectura y clasificación de todas las cuentas."""
    background_tasks.add_task(_sync_task, req)
    return {"status": "started", "message": "Clasificación iniciada en background"}

async def _sync_task(req: SyncRequest):
    """Tarea background: lee Outlook → clasifica con Ollama → guarda → notifica WS."""
    try:
        await ws.broadcast({"type": "sync_start", "message": "📂 Leyendo cuentas de Outlook..."})

        # ── Leer de Outlook ──────────────────────────────────
        reader = OutlookMultiAccountReader()
        emails_raw, accounts = reader.fetch_all_emails(
            days_back         = req.days_back,
            limit_per_account = req.limit_per_account,
            folders           = req.outlook_folders,
            include_read      = req.include_read,
        )

        # Guardar cuentas en DB
        account_id_map = {}
        for acc in accounts:
            aid = db.save_account(acc.name, acc.email)
            account_id_map[acc.name] = aid

        await ws.broadcast({
            "type":    "sync_reading_done",
            "total":   len(emails_raw),
            "accounts": len(accounts),
            "message": f"📬 {len(emails_raw)} emails encontrados en {len(accounts)} cuenta(s). Clasificando con Ollama..."
        })

        classified = 0
        skipped    = 0
        errors     = 0

        for i, raw in enumerate(emails_raw):
            # Convertir dataclass a dict para la DB y el clasificador
            email_dict = {
                "message_id":      raw.message_id,
                "thread_key":      raw.thread_key,
                "account_name":    raw.account_name,
                "account_email":   raw.account_email,
                "sender_name":     raw.sender_name,
                "sender_email":    raw.sender_email,
                "to_recipients":   raw.to_recipients,
                "subject":         raw.subject,
                "body":            raw.body,
                "date":            raw.date,
                "has_attachments": raw.has_attachments,
                "outlook_folder":  raw.outlook_folder,
                "importance":      raw.importance,
                "is_read":         raw.is_read,
            }

            # Si ya está en la DB, saltar
            if db.email_exists(raw.message_id):
                skipped += 1
                continue

            try:
                # ── Clasificar con Ollama ────────────────────
                clf = classifier.classify(email_dict)

                # ── Guardar en DB ────────────────────────────
                account_id = account_id_map.get(raw.account_name, 1)
                db.save_email(email_dict, clf, account_id)
                classified += 1

                # ── Notificar al frontend via WebSocket ──────
                await ws.broadcast({
                    "type":     "email_classified",
                    "progress": round((i + 1) / len(emails_raw) * 100),
                    "classified": classified,
                    "data": {
                        "subject":          raw.subject,
                        "sender_name":      raw.sender_name,
                        "account_name":     raw.account_name,
                        "importance_score": clf.importance.score,
                        "importance_label": clf.importance.label,
                        "importance_color": clf.importance.color,
                        "sentiment_label":  clf.sentiment.label,
                        "sentiment_emoji":  clf.sentiment.emoji,
                        "sender_profile":   clf.sender.profile,
                        "sender_is_vip":    clf.sender.is_vip,
                        "urgency_level":    clf.urgency.level,
                        "urgency_color":    clf.urgency.color,
                        "summary":          clf.summary,
                    }
                })

                # Pequeña pausa para no saturar Ollama
                await asyncio.sleep(0.2)

            except Exception as e:
                errors += 1
                print(f"   ❌ Error en email '{raw.subject[:40]}': {e}")

        # Actualizar totales de cada cuenta
        for acc in accounts:
            aid = account_id_map.get(acc.name, 1)
            db.update_account_sync(aid, acc.total_emails)

        await ws.broadcast({
            "type":       "sync_complete",
            "classified": classified,
            "skipped":    skipped,
            "errors":     errors,
            "total":      len(emails_raw),
            "message":    f"✅ {classified} emails clasificados | {skipped} ya existían | {errors} errores",
        })

    except Exception as e:
        await ws.broadcast({"type": "sync_error", "message": f"❌ {e}"})


@app.get("/emails")
async def get_emails(
    account_id:       Optional[int]  = None,
    importance_label: Optional[str]  = None,
    sentiment_label:  Optional[str]  = None,
    urgency_level:    Optional[str]  = None,
    sender_profile:   Optional[str]  = None,
    is_vip:           Optional[bool] = None,
    search:           Optional[str]  = None,
    sort:             str            = "date",
    limit:            int            = Query(50, ge=1, le=500),
    offset:           int            = 0,
):
    """Lista emails con filtros por las 4 dimensiones."""
    filters = {k: v for k, v in {
        "account_id": account_id, "importance_label": importance_label,
        "sentiment_label": sentiment_label, "urgency_level": urgency_level,
        "sender_profile": sender_profile, "is_vip": is_vip,
        "search": search, "sort": sort,
    }.items() if v is not None}
    return db.get_emails(filters, limit, offset)

@app.get("/stats")
async def get_stats(account_id: Optional[int] = None):
    """Estadísticas completas para el panel: las 4 dimensiones + top senders + tendencias."""
    return db.get_panel_stats(account_id)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await ws.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws.disconnect(websocket)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
