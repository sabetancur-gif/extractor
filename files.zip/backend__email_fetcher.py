"""
email_fetcher.py — Conexión IMAP multi-proveedor
Soporta: Gmail, Outlook, Yahoo, iCloud, Zoho y cualquier servidor IMAP genérico
Maneja: encoding, adjuntos, hilos, folders, búsqueda por fecha
"""
import imaplib
import email
from email.header import decode_header
from email.utils import parseaddr, parsedate_to_datetime, getaddresses
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
import re
import chardet
import hashlib


IMAP_SERVERS = {
    "gmail":    {"server": "imap.gmail.com",           "port": 993},
    "googlemail":{"server":"imap.gmail.com",           "port": 993},
    "outlook":  {"server": "imap-mail.outlook.com",    "port": 993},
    "hotmail":  {"server": "imap-mail.outlook.com",    "port": 993},
    "live":     {"server": "imap-mail.outlook.com",    "port": 993},
    "msn":      {"server": "imap-mail.outlook.com",    "port": 993},
    "yahoo":    {"server": "imap.mail.yahoo.com",      "port": 993},
    "icloud":   {"server": "imap.mail.me.com",         "port": 993},
    "me":       {"server": "imap.mail.me.com",         "port": 993},
    "zoho":     {"server": "imap.zoho.com",            "port": 993},
    "protonmail":{"server":"imap.protonmail.ch",       "port": 993},
    "fastmail": {"server": "imap.fastmail.com",        "port": 993},
}


class EmailFetcher:
    def __init__(
        self,
        email: str,
        password: str,
        imap_server: Optional[str] = None,
        imap_port: int = 993
    ):
        self.email_address = email
        self.password = password
        self.imap_port = imap_port
        self.connection: Optional[imaplib.IMAP4_SSL] = None

        if not imap_server:
            domain = email.split("@")[-1].lower()
            subdomain = domain.split(".")[0]
            srv = IMAP_SERVERS.get(subdomain) or IMAP_SERVERS.get(domain)
            self.imap_server = srv["server"] if srv else f"imap.{domain}"
            self.imap_port = srv["port"] if srv else 993
        else:
            self.imap_server = imap_server

    # ─── CONNECTION ──────────────────────────────────────────────────────────

    def connect(self) -> None:
        try:
            self.connection = imaplib.IMAP4_SSL(self.imap_server, self.imap_port)
            self.connection.login(self.email_address, self.password)
        except imaplib.IMAP4.error as e:
            raise ConnectionError(
                f"Autenticación fallida en {self.imap_server}: {e}. "
                "Para Gmail usa una App Password de 16 caracteres."
            )
        except OSError as e:
            raise ConnectionError(f"No se pudo conectar a {self.imap_server}:{self.imap_port} — {e}")

    def disconnect(self) -> None:
        if self.connection:
            try:
                self.connection.logout()
            except Exception:
                pass
            self.connection = None

    def test_connection(self) -> bool:
        try:
            self.connect()
            self.disconnect()
            return True
        except ConnectionError:
            return False

    # ─── FOLDER LIST ─────────────────────────────────────────────────────────

    def list_folders(self) -> List[str]:
        if not self.connection:
            self.connect()
        _, raw = self.connection.list()
        folders = []
        for item in raw:
            if item:
                decoded = item.decode() if isinstance(item, bytes) else item
                # Strip flags and delimiters
                parts = decoded.split('"/"')
                name = parts[-1].strip().strip('"').strip()
                if name:
                    folders.append(name)
        return folders

    # ─── FETCH EMAILS ────────────────────────────────────────────────────────

    def fetch_emails(
        self,
        folder: str = "INBOX",
        limit: int = 100,
        days_back: int = 14,
        search_criteria: Optional[str] = None,
        only_unseen: bool = False,
    ) -> List[Dict]:
        """
        Obtiene emails de una carpeta.

        Args:
            folder: Carpeta IMAP ("INBOX", "SENT", etc.)
            limit: Máximo de emails a obtener (más recientes primero)
            days_back: Cuántos días hacia atrás buscar
            search_criteria: Criterio IMAP manual (sobreescribe days_back)
            only_unseen: Si True, solo trae emails no leídos

        Returns:
            Lista de dicts con datos del email + thread_key
        """
        if not self.connection:
            self.connect()

        try:
            status, _ = self.connection.select(f'"{folder}"', readonly=True)
            if status != "OK":
                # Intento sin comillas
                status, _ = self.connection.select(folder, readonly=True)
                if status != "OK":
                    raise ValueError(f"No se puede abrir la carpeta '{folder}'")

            # Construir criterio de búsqueda
            if search_criteria:
                criteria = search_criteria
            else:
                since = (datetime.now() - timedelta(days=days_back)).strftime("%d-%b-%Y")
                if only_unseen:
                    criteria = f'(UNSEEN SINCE {since})'
                else:
                    criteria = f'(SINCE {since})'

            _, msg_numbers = self.connection.search(None, criteria)
            ids = msg_numbers[0].split()

            # Más recientes primero, limitar
            ids = list(reversed(ids))[:limit]

            emails = []
            for msg_id in ids:
                try:
                    parsed = self._fetch_one(msg_id)
                    if parsed:
                        emails.append(parsed)
                except Exception as e:
                    print(f"⚠️  Error en msg {msg_id}: {e}")

            return emails

        finally:
            self.disconnect()

    def _fetch_one(self, msg_id: bytes) -> Optional[Dict]:
        _, data = self.connection.fetch(msg_id, "(RFC822)")
        if not data or not data[0]:
            return None

        raw = data[0][1]
        msg = email.message_from_bytes(raw)

        # ── IDs y referencias ──────────────────────────────────
        message_id = self._clean(msg.get("Message-ID", ""))
        if not message_id:
            # Generar ID determinístico
            message_id = "gen-" + hashlib.md5(raw[:200]).hexdigest()

        in_reply_to = self._clean(msg.get("In-Reply-To", ""))
        references = self._clean(msg.get("References", ""))

        # Thread key: usar el primer message-id de la cadena de referencias
        if references:
            thread_key = references.split()[0].strip("<>")
        elif in_reply_to:
            thread_key = in_reply_to.strip("<>")
        else:
            thread_key = message_id.strip("<>")

        # ── Remitente ──────────────────────────────────────────
        from_raw = msg.get("From", "")
        sender_name, sender_email = parseaddr(from_raw)
        sender_name = self._decode_header(sender_name)
        sender_email = sender_email.lower().strip()

        # ── Destinatarios ──────────────────────────────────────
        to_raw = self._decode_header(msg.get("To", ""))
        cc_raw = self._decode_header(msg.get("CC", ""))
        reply_to = self._decode_header(msg.get("Reply-To", ""))

        # ── Asunto ─────────────────────────────────────────────
        subject = self._decode_header(msg.get("Subject", "(Sin asunto)"))

        # ── Fecha ──────────────────────────────────────────────
        date_str = msg.get("Date", "")
        try:
            date = parsedate_to_datetime(date_str).isoformat()
        except Exception:
            date = datetime.now().isoformat()

        # ── Cuerpo ─────────────────────────────────────────────
        body, html_body = self._extract_body(msg)

        # ── Adjuntos ───────────────────────────────────────────
        attachments = self._list_attachments(msg)

        return {
            "message_id":      message_id,
            "thread_key":      thread_key,
            "in_reply_to":     in_reply_to,
            "sender_name":     sender_name or sender_email.split("@")[0],
            "sender_email":    sender_email,
            "to":              to_raw,
            "cc":              cc_raw,
            "reply_to":        reply_to,
            "subject":         subject,
            "body":            body,
            "html_body":       html_body,
            "date":            date,
            "has_attachments": len(attachments) > 0,
            "attachment_names":attachments,
            "folder":          "INBOX",
        }

    # ─── DECODE HELPERS ──────────────────────────────────────────────────────

    def _decode_header(self, value: str) -> str:
        if not value:
            return ""
        parts, result = decode_header(value), []
        for part, enc in parts:
            if isinstance(part, bytes):
                enc = enc or self._detect_encoding(part) or "utf-8"
                try:
                    result.append(part.decode(enc, errors="replace"))
                except (LookupError, UnicodeDecodeError):
                    result.append(part.decode("utf-8", errors="replace"))
            else:
                result.append(str(part))
        return " ".join(result).strip()

    def _detect_encoding(self, data: bytes) -> str:
        detected = chardet.detect(data)
        return detected.get("encoding") or "utf-8"

    def _clean(self, value: str) -> str:
        return (value or "").strip()

    # ─── BODY EXTRACTION ─────────────────────────────────────────────────────

    def _extract_body(self, msg) -> Tuple[str, str]:
        text_parts, html_parts = [], []

        if msg.is_multipart():
            for part in msg.walk():
                ct = part.get_content_type()
                disp = str(part.get("Content-Disposition", ""))
                if "attachment" in disp:
                    continue
                payload = part.get_payload(decode=True)
                if not payload:
                    continue
                charset = part.get_content_charset() or "utf-8"
                try:
                    text = payload.decode(charset, errors="replace")
                except (LookupError, UnicodeDecodeError):
                    text = payload.decode("utf-8", errors="replace")

                if ct == "text/plain":
                    text_parts.append(text)
                elif ct == "text/html":
                    html_parts.append(text)
        else:
            payload = msg.get_payload(decode=True)
            if payload:
                charset = msg.get_content_charset() or "utf-8"
                try:
                    text = payload.decode(charset, errors="replace")
                except Exception:
                    text = payload.decode("utf-8", errors="replace")
                if msg.get_content_type() == "text/html":
                    html_parts.append(text)
                else:
                    text_parts.append(text)

        raw_text = "\n".join(text_parts)
        raw_html = "\n".join(html_parts)

        # Si no hay texto plano, extraerlo del HTML
        if not raw_text.strip() and raw_html:
            raw_text = self._html_to_text(raw_html)

        return self._clean_text(raw_text)[:6000], raw_html[:12000]

    def _clean_text(self, text: str) -> str:
        text = re.sub(r"\r\n", "\n", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        # Eliminar quoted text excesivo
        lines = text.split("\n")
        non_quoted = [l for l in lines if not l.strip().startswith(">")]
        if len(non_quoted) > 5:
            text = "\n".join(non_quoted)
        return text.strip()

    def _html_to_text(self, html: str) -> str:
        # Remover scripts y estilos
        html = re.sub(r"<(script|style)[^>]*>.*?</(script|style)>", "", html,
                      flags=re.DOTALL | re.IGNORECASE)
        # Reemplazar etiquetas de bloque con saltos
        html = re.sub(r"<(br|p|div|tr|li)[^>]*>", "\n", html, flags=re.IGNORECASE)
        # Remover todas las etiquetas restantes
        text = re.sub(r"<[^>]+>", " ", html)
        # Limpiar entidades HTML básicas
        text = text.replace("&nbsp;", " ").replace("&amp;", "&") \
                   .replace("&lt;", "<").replace("&gt;", ">") \
                   .replace("&quot;", '"').replace("&#39;", "'")
        return re.sub(r"[ \t]+", " ", text).strip()

    # ─── ATTACHMENTS ─────────────────────────────────────────────────────────

    def _list_attachments(self, msg) -> List[str]:
        names = []
        if not msg.is_multipart():
            return names
        for part in msg.walk():
            disp = str(part.get("Content-Disposition", ""))
            if "attachment" not in disp:
                continue
            fn = part.get_filename()
            if fn:
                names.append(self._decode_header(fn))
        return names[:20]  # límite razonable
