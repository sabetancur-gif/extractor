// src/pages/Contacts.jsx
import { useEffect, useState } from 'react'
import { useStore } from '../store'

function ContactRow({ contact, isSelected, onClick }) {
  const initials = (contact.name || contact.email || '?')
    .split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase()

  return (
    <div className={`contact-row ${isSelected ? 'selected' : ''}`} onClick={onClick}>
      <div className="contact-avatar" data-vip={contact.is_vip ? 'true' : 'false'}>
        {initials}
      </div>
      <div className="contact-info">
        <div className="contact-name">{contact.name || contact.email}</div>
        <div className="contact-email">{contact.email}</div>
        {contact.company && <div className="contact-company">🏢 {contact.company}</div>}
      </div>
      <div className="contact-stats">
        <div className="contact-count">{contact.email_count || contact.total_emails || 0}</div>
        <div className="contact-count-label">emails</div>
        {contact.is_vip && <span className="vip-badge">VIP</span>}
      </div>
    </div>
  )
}

function ContactDetail({ contact, onUpdate }) {
  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState({
    name: contact.name || '',
    company: contact.company || '',
    role: contact.role || '',
    notes: contact.notes || '',
    is_vip: contact.is_vip || false,
  })

  const handleSave = async () => {
    await onUpdate(contact.id, form)
    setEditing(false)
  }

  const recentEmails = contact.recent_emails || []

  return (
    <div className="contact-detail">
      <div className="cd-header">
        <div className="cd-avatar">
          {(contact.name || contact.email || '?').split(' ').slice(0,2).map(w=>w[0]).join('').toUpperCase()}
        </div>
        <div className="cd-identity">
          <h2>{contact.name || contact.email}</h2>
          <div className="cd-email">{contact.email}</div>
          {contact.company && <div className="cd-company">{contact.company}</div>}
        </div>
        <button className="btn-secondary" onClick={() => setEditing(!editing)}>
          {editing ? 'Cancelar' : '✏ Editar'}
        </button>
      </div>

      {editing ? (
        <div className="cd-edit-form">
          <div className="field-row">
            <div className="field-group">
              <label>Nombre</label>
              <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
            </div>
            <div className="field-group">
              <label>Empresa</label>
              <input value={form.company} onChange={e => setForm({...form, company: e.target.value})} />
            </div>
          </div>
          <div className="field-group">
            <label>Cargo / Rol</label>
            <input value={form.role} onChange={e => setForm({...form, role: e.target.value})} />
          </div>
          <div className="field-group">
            <label>Notas</label>
            <textarea rows={3} value={form.notes}
              onChange={e => setForm({...form, notes: e.target.value})} />
          </div>
          <div className="field-group">
            <label className="checkbox-label">
              <input type="checkbox" checked={form.is_vip}
                onChange={e => setForm({...form, is_vip: e.target.checked})} />
              Marcar como VIP
            </label>
          </div>
          <div className="cd-edit-actions">
            <button className="btn-secondary" onClick={() => setEditing(false)}>Cancelar</button>
            <button className="btn-primary" onClick={handleSave}>Guardar cambios</button>
          </div>
        </div>
      ) : (
        <div className="cd-meta-grid">
          <div className="cd-meta-item">
            <div className="cd-meta-label">Total emails</div>
            <div className="cd-meta-value">{contact.email_count || 0}</div>
          </div>
          {contact.role && (
            <div className="cd-meta-item">
              <div className="cd-meta-label">Cargo</div>
              <div className="cd-meta-value">{contact.role}</div>
            </div>
          )}
          {contact.last_email && (
            <div className="cd-meta-item">
              <div className="cd-meta-label">Último email</div>
              <div className="cd-meta-value">
                {new Date(contact.last_email).toLocaleDateString('es-CO')}
              </div>
            </div>
          )}
          {contact.is_vip && (
            <div className="cd-meta-item">
              <div className="cd-meta-label">Estado</div>
              <div className="cd-meta-value vip-text">⭐ Contacto VIP</div>
            </div>
          )}
          {contact.notes && (
            <div className="cd-meta-item cd-meta-full">
              <div className="cd-meta-label">Notas</div>
              <div className="cd-meta-value cd-notes">{contact.notes}</div>
            </div>
          )}
        </div>
      )}

      <div className="cd-emails-section">
        <h3 className="cd-section-title">Emails recientes</h3>
        {recentEmails.length === 0 ? (
          <div className="empty-tab">Sin emails recientes</div>
        ) : (
          <div className="cd-email-list">
            {recentEmails.map(email => (
              <div key={email.id} className="cd-email-row">
                <div className="cde-top">
                  <span className="cde-subject">{email.subject || '(Sin asunto)'}</span>
                  <span className="cde-date">
                    {email.date ? new Date(email.date).toLocaleDateString('es-CO') : ''}
                  </span>
                </div>
                {email.summary && <div className="cde-summary">{email.summary}</div>}
                <div className="cde-tags">
                  <span className="cde-cat">{email.category?.replace('_',' ')}</span>
                  <span className="cde-pri"
                    style={{ color: {urgente:'#ef4444',alta:'#f97316',media:'#eab308',baja:'#22c55e'}[email.priority_label] }}>
                    {email.priority_label}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default function Contacts() {
  const { contacts, contactsLoading, fetchContacts, selectContact, selectedContact,
          updateEmail, addToast } = useStore()
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(null)

  useEffect(() => { fetchContacts() }, [])

  const handleSearch = (q) => {
    setSearch(q)
    fetchContacts(q || null)
  }

  const handleSelect = async (contact) => {
    setSelected(contact)
    await selectContact(contact.id)
  }

  const handleUpdate = async (contactId, updates) => {
    try {
      const { api } = await import('../services/api')
      await api.patch(`/contacts/${contactId}`, updates)
      addToast('Contacto actualizado', 'success')
      fetchContacts(search || null)
    } catch (e) {
      addToast('Error actualizando contacto', 'error')
    }
  }

  return (
    <div className="contacts-layout">
      <div className="contacts-list-col">
        <div className="contacts-search">
          <span className="cs-icon">⌕</span>
          <input
            type="text"
            placeholder="Buscar contactos..."
            value={search}
            onChange={e => handleSearch(e.target.value)}
          />
        </div>
        <div className="contacts-count">
          {contacts.length} contacto{contacts.length !== 1 ? 's' : ''}
        </div>
        <div className="contacts-list">
          {contactsLoading ? (
            [1,2,3].map(i => (
              <div key={i} className="skeleton-row">
                <div className="sk-avatar" />
                <div className="sk-body">
                  <div className="sk-line sk-line-sm" />
                  <div className="sk-line sk-line-md" />
                </div>
              </div>
            ))
          ) : contacts.length === 0 ? (
            <div className="empty-inbox">
              <div className="empty-icon">◉</div>
              <p>No hay contactos aún</p>
              <p>Se agregan automáticamente al clasificar emails</p>
            </div>
          ) : (
            contacts.map(contact => (
              <ContactRow
                key={contact.id}
                contact={contact}
                isSelected={selected?.id === contact.id}
                onClick={() => handleSelect(contact)}
              />
            ))
          )}
        </div>
      </div>

      <div className="contact-detail-col">
        {useStore.getState().selectedContact && selected ? (
          <ContactDetail
            contact={useStore.getState().selectedContact}
            onUpdate={handleUpdate}
          />
        ) : (
          <div className="contact-empty-state">
            <div className="ces-icon">◉</div>
            <p>Selecciona un contacto para ver su perfil y emails</p>
          </div>
        )}
      </div>
    </div>
  )
}
