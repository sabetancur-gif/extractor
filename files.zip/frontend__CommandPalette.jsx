// frontend/src/components/CommandPalette.jsx
import { useState, useEffect, useRef } from 'react'
import { useStore } from '../store'

const COMMANDS = [
  { id: 'goto-dashboard', label: 'Ir a Dashboard',           icon: '▦', action: 'navigate', target: 'dashboard' },
  { id: 'goto-inbox',     label: 'Ir a Bandeja de entrada',  icon: '✉', action: 'navigate', target: 'inbox' },
  { id: 'goto-analytics', label: 'Ir a Analytics',           icon: '↗', action: 'navigate', target: 'analytics' },
  { id: 'goto-contacts',  label: 'Ver Contactos',            icon: '◉', action: 'navigate', target: 'contacts' },
  { id: 'goto-settings',  label: 'Abrir Ajustes / Reglas',  icon: '⚙', action: 'navigate', target: 'settings' },

  { id: 'filter-urgente', label: 'Filtrar: Urgentes',        icon: '🔴', action: 'filter', filter: { priority_label: 'urgente' } },
  { id: 'filter-accion',  label: 'Filtrar: Requieren acción',icon: '⚡', action: 'filter', filter: { requires_action: true } },
  { id: 'filter-starred', label: 'Filtrar: Destacados',      icon: '★',  action: 'filter', filter: { is_starred: true } },
  { id: 'filter-trabajo', label: 'Filtrar: Trabajo',         icon: '💼', action: 'filter', filter: { category: 'trabajo' } },
  { id: 'filter-finanzas',label: 'Filtrar: Finanzas',        icon: '💰', action: 'filter', filter: { category: 'finanzas' } },
  { id: 'filter-legal',   label: 'Filtrar: Legal',           icon: '⚖',  action: 'filter', filter: { category: 'legal' } },
  { id: 'filter-spam',    label: 'Filtrar: Spam detectado',  icon: '🚫', action: 'filter', filter: { spam: true } },
  { id: 'filter-all',     label: 'Ver todos los emails',     icon: '📋', action: 'filter', filter: { sort: 'date_desc' } },
]

export default function CommandPalette() {
  const { setCommandOpen, setActivePage, setEmailFilters } = useStore()
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState(0)
  const inputRef = useRef(null)

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  const filtered = query.trim()
    ? COMMANDS.filter(c =>
        c.label.toLowerCase().includes(query.toLowerCase())
      )
    : COMMANDS

  // Reset selection when query changes
  useEffect(() => { setSelected(0) }, [query])

  const execute = (cmd) => {
    setCommandOpen(false)
    if (cmd.action === 'navigate') {
      setActivePage(cmd.target)
    } else if (cmd.action === 'filter') {
      setActivePage('inbox')
      setEmailFilters(cmd.filter)
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setSelected(s => Math.min(s + 1, filtered.length - 1))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setSelected(s => Math.max(s - 1, 0))
    } else if (e.key === 'Enter') {
      if (filtered[selected]) execute(filtered[selected])
    } else if (e.key === 'Escape') {
      setCommandOpen(false)
    }
  }

  return (
    <div
      className="cmd-backdrop"
      onClick={() => setCommandOpen(false)}
    >
      <div
        className="cmd-palette"
        onClick={e => e.stopPropagation()}
        onKeyDown={handleKeyDown}
      >
        <div className="cmd-search">
          <span className="cmd-search-icon">⌕</span>
          <input
            ref={inputRef}
            type="text"
            placeholder="Buscar comandos, filtros, páginas..."
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
          <kbd onClick={() => setCommandOpen(false)}>ESC</kbd>
        </div>

        <div className="cmd-results">
          {filtered.length === 0 ? (
            <div className="cmd-empty">
              Sin resultados para &ldquo;{query}&rdquo;
            </div>
          ) : (
            filtered.map((cmd, i) => (
              <button
                key={cmd.id}
                className={`cmd-item ${i === selected ? 'cmd-item-active' : ''}`}
                onClick={() => execute(cmd)}
                onMouseEnter={() => setSelected(i)}
              >
                <span className="cmd-icon">{cmd.icon}</span>
                <span className="cmd-label">{cmd.label}</span>
                {i === selected && (
                  <kbd style={{ marginLeft: 'auto', opacity: 0.5 }}>↵</kbd>
                )}
              </button>
            ))
          )}
        </div>

        <div style={{
          padding: '8px 12px',
          borderTop: '1px solid var(--border)',
          fontSize: '10px',
          color: 'var(--text3)',
          display: 'flex',
          gap: '16px'
        }}>
          <span><kbd>↑↓</kbd> Navegar</span>
          <span><kbd>↵</kbd> Ejecutar</span>
          <span><kbd>ESC</kbd> Cerrar</span>
        </div>
      </div>
    </div>
  )
}
