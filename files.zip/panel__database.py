"""
=============================================================
MÓDULO 3: database.py
Panel Clasificador MailAI — Base de datos SQLite local
=============================================================
Guarda emails clasificados con las 4 dimensiones.
Schema optimizado para consultas del panel de visualización.
=============================================================
"""
import sqlite3, json
from datetime import datetime
from typing import List, Dict, Optional
from pathlib import Path


class PanelDatabase:
    def __init__(self, db_path: str = "panel.db"):
        self.db_path = db_path

    def conn(self) -> sqlite3.Connection:
        c = sqlite3.connect(self.db_path, timeout=30)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        return c

    def initialize(self):
        """Crea todas las tablas si no existen."""
        with self.conn() as db:
            db.executescript("""
-- Cuentas de Outlook detectadas
CREATE TABLE IF NOT EXISTS accounts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    email        TEXT NOT NULL,
    total_emails INTEGER DEFAULT 0,
    last_sync    TEXT,
    created_at   TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Emails clasificados con las 4 dimensiones
CREATE TABLE IF NOT EXISTS emails (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id      TEXT UNIQUE NOT NULL,
    thread_key      TEXT,
    account_id      INTEGER REFERENCES accounts(id),
    account_name    TEXT,

    -- Datos del email
    sender_name     TEXT,
    sender_email    TEXT,
    to_recipients   TEXT,
    subject         TEXT,
    body            TEXT,
    date            TEXT,
    has_attachments BOOLEAN DEFAULT 0,
    outlook_folder  TEXT DEFAULT 'INBOX',
    is_read         BOOLEAN DEFAULT 0,

    -- DIMENSIÓN 1: IMPORTANCIA
    importance_score  INTEGER DEFAULT 50,
    importance_label  TEXT DEFAULT 'media',
    importance_reason TEXT,
    importance_color  TEXT DEFAULT '#eab308',

    -- DIMENSIÓN 2: SENTIMIENTO
    sentiment_label TEXT DEFAULT 'neutral',
    sentiment_score REAL DEFAULT 0.0,
    sentiment_tone  TEXT DEFAULT 'neutro',
    sentiment_emoji TEXT DEFAULT '😐',

    -- DIMENSIÓN 3: REMITENTE
    sender_profile  TEXT DEFAULT 'desconocido',
    sender_trust    INTEGER DEFAULT 50,
    sender_is_vip   BOOLEAN DEFAULT 0,
    sender_company  TEXT,
    sender_relation TEXT,

    -- DIMENSIÓN 4: URGENCIA
    urgency_level    TEXT DEFAULT 'ninguna',
    urgency_deadline TEXT,
    urgency_actions  TEXT DEFAULT '[]',
    urgency_reply    TEXT,
    urgency_color    TEXT DEFAULT '#6b7280',

    -- General
    summary     TEXT,
    category    TEXT DEFAULT 'otro',
    language    TEXT DEFAULT 'es',
    key_topics  TEXT DEFAULT '[]',
    spam_score  REAL DEFAULT 0.0,
    confidence  REAL DEFAULT 0.0,

    created_at  TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Índices para consultas del panel
CREATE INDEX IF NOT EXISTS idx_emails_account    ON emails(account_id);
CREATE INDEX IF NOT EXISTS idx_emails_importance ON emails(importance_score DESC);
CREATE INDEX IF NOT EXISTS idx_emails_urgency    ON emails(urgency_level);
CREATE INDEX IF NOT EXISTS idx_emails_sender     ON emails(sender_email);
CREATE INDEX IF NOT EXISTS idx_emails_date       ON emails(date DESC);
CREATE INDEX IF NOT EXISTS idx_emails_vip        ON emails(sender_is_vip);
CREATE INDEX IF NOT EXISTS idx_emails_sentiment  ON emails(sentiment_label);
""")
        print("✅ Base de datos inicializada")

    def save_account(self, name: str, email: str) -> int:
        with self.conn() as db:
            cur = db.execute("""
                INSERT INTO accounts (name, email, last_sync)
                VALUES (?, ?, ?)
                ON CONFLICT DO NOTHING
            """, (name, email, datetime.now().isoformat()))
            if cur.lastrowid:
                return cur.lastrowid
            row = db.execute("SELECT id FROM accounts WHERE name=?", (name,)).fetchone()
            return row['id'] if row else 1

    def email_exists(self, message_id: str) -> bool:
        with self.conn() as db:
            return db.execute("SELECT 1 FROM emails WHERE message_id=?",
                              (message_id,)).fetchone() is not None

    def save_email(self, email_data: Dict, clf, account_id: int) -> int:
        """Guarda un email con su clasificación completa."""
        with self.conn() as db:
            cur = db.execute("""
                INSERT OR REPLACE INTO emails (
                    message_id, thread_key, account_id, account_name,
                    sender_name, sender_email, to_recipients, subject, body,
                    date, has_attachments, outlook_folder, is_read,
                    importance_score, importance_label, importance_reason, importance_color,
                    sentiment_label, sentiment_score, sentiment_tone, sentiment_emoji,
                    sender_profile, sender_trust, sender_is_vip, sender_company, sender_relation,
                    urgency_level, urgency_deadline, urgency_actions, urgency_reply, urgency_color,
                    summary, category, language, key_topics, spam_score, confidence
                ) VALUES (
                    ?,?,?,?,?,?,?,?,?,?,?,?,?,
                    ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
                )
            """, (
                email_data['message_id'], email_data.get('thread_key',''),
                account_id, email_data.get('account_name',''),
                email_data.get('sender_name',''), email_data.get('sender_email',''),
                email_data.get('to_recipients',''), email_data.get('subject',''),
                email_data.get('body',''), email_data.get('date',''),
                email_data.get('has_attachments', False),
                email_data.get('outlook_folder','INBOX'),
                email_data.get('is_read', False),
                # Importancia
                clf.importance.score, clf.importance.label,
                clf.importance.reason, clf.importance.color,
                # Sentimiento
                clf.sentiment.label, clf.sentiment.score,
                clf.sentiment.tone,  clf.sentiment.emoji,
                # Remitente
                clf.sender.profile, clf.sender.trust,
                clf.sender.is_vip,  clf.sender.company, clf.sender.relation,
                # Urgencia
                clf.urgency.level, clf.urgency.deadline,
                json.dumps(clf.urgency.actions), clf.urgency.reply, clf.urgency.color,
                # General
                clf.summary, clf.category, clf.language,
                json.dumps(clf.key_topics), clf.spam_score, clf.confidence,
            ))
            return cur.lastrowid

    def get_emails(self, filters: Dict = None, limit: int = 100, offset: int = 0) -> List[Dict]:
        filters = filters or {}
        where, params = ["1=1"], []
        if filters.get('account_id'):
            where.append("account_id=?"); params.append(filters['account_id'])
        if filters.get('importance_label'):
            where.append("importance_label=?"); params.append(filters['importance_label'])
        if filters.get('sentiment_label'):
            where.append("sentiment_label=?"); params.append(filters['sentiment_label'])
        if filters.get('urgency_level'):
            where.append("urgency_level=?"); params.append(filters['urgency_level'])
        if filters.get('sender_profile'):
            where.append("sender_profile=?"); params.append(filters['sender_profile'])
        if filters.get('is_vip'):
            where.append("sender_is_vip=1")
        if filters.get('search'):
            s = f"%{filters['search']}%"
            where.append("(subject LIKE ? OR sender_name LIKE ? OR body LIKE ?)")
            params += [s, s, s]
        sort = {"importance": "importance_score DESC",
                "date":       "date DESC",
                "urgency":    "urgency_level DESC",
                "trust":      "sender_trust DESC"}.get(filters.get('sort','date'), "date DESC")
        params += [limit, offset]
        with self.conn() as db:
            rows = db.execute(
                f"SELECT * FROM emails WHERE {' AND '.join(where)} ORDER BY {sort} LIMIT ? OFFSET ?",
                params).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            for f in ('urgency_actions', 'key_topics'):
                try: d[f] = json.loads(d.get(f) or '[]')
                except: d[f] = []
            result.append(d)
        return result

    def get_panel_stats(self, account_id: int = None) -> Dict:
        """Estadísticas completas para el panel de visualización."""
        flt = "AND account_id=?" if account_id else ""
        p   = [account_id] if account_id else []
        with self.conn() as db:
            total         = db.execute(f"SELECT COUNT(*) FROM emails WHERE 1=1 {flt}", p).fetchone()[0]
            by_importance = db.execute(f"SELECT importance_label, COUNT(*) c FROM emails WHERE 1=1 {flt} GROUP BY importance_label", p).fetchall()
            by_sentiment  = db.execute(f"SELECT sentiment_label, COUNT(*) c FROM emails WHERE 1=1 {flt} GROUP BY sentiment_label", p).fetchall()
            by_urgency    = db.execute(f"SELECT urgency_level, COUNT(*) c FROM emails WHERE 1=1 {flt} GROUP BY urgency_level", p).fetchall()
            by_profile    = db.execute(f"SELECT sender_profile, COUNT(*) c FROM emails WHERE 1=1 {flt} GROUP BY sender_profile ORDER BY c DESC", p).fetchall()
            vip_count     = db.execute(f"SELECT COUNT(*) FROM emails WHERE sender_is_vip=1 {flt}", p).fetchone()[0]
            avg_imp       = db.execute(f"SELECT AVG(importance_score) FROM emails WHERE 1=1 {flt}", p).fetchone()[0] or 0
            critical      = db.execute(f"SELECT id,sender_name,subject,importance_score,urgency_level,urgency_deadline,urgency_actions,sentiment_emoji FROM emails WHERE importance_label='critica' {flt} ORDER BY importance_score DESC LIMIT 10", p).fetchall()
            top_senders   = db.execute(f"SELECT sender_email,sender_name,sender_profile,sender_trust,sender_is_vip,COUNT(*) c,AVG(importance_score) avg_imp FROM emails WHERE 1=1 {flt} GROUP BY sender_email ORDER BY c DESC LIMIT 10", p).fetchall()
            by_day        = db.execute(f"SELECT DATE(date) day, COUNT(*) c, AVG(importance_score) avg_imp FROM emails WHERE date >= DATE('now','-30 days') {flt} GROUP BY DATE(date) ORDER BY day", p).fetchall()
            by_tone       = db.execute(f"SELECT sentiment_tone, COUNT(*) c FROM emails WHERE 1=1 {flt} GROUP BY sentiment_tone ORDER BY c DESC LIMIT 6", p).fetchall()
            accounts_stat = db.execute("SELECT a.name, a.email, COUNT(e.id) c FROM accounts a LEFT JOIN emails e ON e.account_id=a.id GROUP BY a.id").fetchall()
        return {
            "total": total, "vip_count": vip_count, "avg_importance": round(avg_imp, 1),
            "by_importance": [dict(r) for r in by_importance],
            "by_sentiment":  [dict(r) for r in by_sentiment],
            "by_urgency":    [dict(r) for r in by_urgency],
            "by_profile":    [dict(r) for r in by_profile],
            "by_tone":       [dict(r) for r in by_tone],
            "critical_emails":[dict(r) for r in critical],
            "top_senders":   [dict(r) for r in top_senders],
            "by_day":        [dict(r) for r in by_day],
            "accounts":      [dict(r) for r in accounts_stat],
        }

    def update_account_sync(self, account_id: int, total: int):
        with self.conn() as db:
            db.execute("UPDATE accounts SET last_sync=?, total_emails=total_emails+? WHERE id=?",
                       (datetime.now().isoformat(), total, account_id))
