#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
#  setup.sh — Script de instalación automática MailAI Pro
#  Uso: chmod +x setup.sh && ./setup.sh
# ═══════════════════════════════════════════════════════════════
set -euo pipefail

# ─── Colores ──────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${BLUE}ℹ  $*${RESET}"; }
success() { echo -e "${GREEN}✓  $*${RESET}"; }
warn()    { echo -e "${YELLOW}⚠  $*${RESET}"; }
error()   { echo -e "${RED}✗  $*${RESET}" >&2; exit 1; }
header()  { echo -e "\n${BOLD}${CYAN}$*${RESET}"; echo "$(printf '─%.0s' {1..50})"; }

# ─── Banner ───────────────────────────────────────────────────
echo -e "${BOLD}${CYAN}"
cat <<'EOF'
  __  __       _ _   _    _____   _____
 |  \/  | __ _(_) | /_\  |_ _| | |  _ \ _ __ ___
 | |\/| |/ _` | | |/ _ \  | |  |_| |_) | '__/ _ \
 | |  | | (_| | | / ___ \ | | |_ |  __/| | | (_) |
 |_|  |_|\__,_|_|_/_/   \_\___(_)|_|   |_|  \___/
                                          v2.0
EOF
echo -e "${RESET}"

# ─── Verificar dependencias ───────────────────────────────────
header "Verificando dependencias del sistema"

check_cmd() {
    if command -v "$1" &>/dev/null; then
        success "$1 encontrado: $(command -v "$1")"
    else
        error "$1 no encontrado. Instálalo antes de continuar."
    fi
}

check_cmd python3
check_cmd pip3
check_cmd node
check_cmd npm

PYTHON_VERSION=$(python3 --version | awk '{print $2}')
NODE_VERSION=$(node --version)
info "Python: $PYTHON_VERSION | Node: $NODE_VERSION"

# Verificar Python >= 3.10
PYTHON_MAJOR=$(python3 -c "import sys; print(sys.version_info.major)")
PYTHON_MINOR=$(python3 -c "import sys; print(sys.version_info.minor)")
if [[ "$PYTHON_MAJOR" -lt 3 || ("$PYTHON_MAJOR" -eq 3 && "$PYTHON_MINOR" -lt 10) ]]; then
    error "Se requiere Python 3.10 o superior. Tienes $PYTHON_VERSION"
fi

success "Todas las dependencias del sistema están disponibles"

# ─── Estructura del proyecto ──────────────────────────────────
header "Creando estructura del proyecto"

PROJECT_DIR="mailai-pro"
BACKEND_DIR="$PROJECT_DIR/backend"
FRONTEND_DIR="$PROJECT_DIR/frontend/src"

mkdir -p "$BACKEND_DIR"
mkdir -p "$PROJECT_DIR/frontend/src/pages"
mkdir -p "$PROJECT_DIR/frontend/src/components"
mkdir -p "$PROJECT_DIR/frontend/src/services"
mkdir -p "$PROJECT_DIR/frontend/src/store"
mkdir -p "$PROJECT_DIR/data"

success "Estructura de carpetas creada en ./$PROJECT_DIR/"

# ─── Variables de entorno ─────────────────────────────────────
header "Configurando variables de entorno"

if [[ -f "$PROJECT_DIR/.env" ]]; then
    warn ".env ya existe. No se sobreescribirá."
else
    echo "Necesitas tu API Key de Anthropic."
    echo "Consíguela en: https://console.anthropic.com/settings/keys"
    echo ""
    read -rp "  Pega tu ANTHROPIC_API_KEY: " API_KEY
    if [[ -z "$API_KEY" ]]; then
        warn "No ingresaste una API Key. Puedes editarla después en $PROJECT_DIR/.env"
        API_KEY="sk-ant-AQUI_TU_API_KEY"
    fi

    cat > "$PROJECT_DIR/.env" <<EOF
# MailAI Pro — Variables de entorno
ANTHROPIC_API_KEY=$API_KEY
DATABASE_URL=/app/data/emails.db
DEBUG=false
SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
EOF
    success ".env creado"
fi

# ─── Backend ──────────────────────────────────────────────────
header "Configurando Backend Python"

cd "$PROJECT_DIR/backend"

# Crear entorno virtual
if [[ ! -d "venv" ]]; then
    info "Creando entorno virtual Python..."
    python3 -m venv venv
    success "Entorno virtual creado"
else
    info "Entorno virtual ya existe, reutilizando"
fi

# Activar y instalar dependencias
source venv/bin/activate
info "Instalando dependencias Python..."
pip install --quiet --upgrade pip
pip install --quiet \
    "fastapi==0.115.0" \
    "uvicorn[standard]==0.30.6" \
    "anthropic==0.34.2" \
    "pydantic==2.9.2" \
    "pydantic-settings==2.5.2" \
    "apscheduler==3.10.4" \
    "chardet==5.2.0" \
    "python-multipart==0.0.12" \
    "websockets==13.1" \
    "python-dotenv==1.0.1"

success "Dependencias Python instaladas"

# Guardar requirements.txt
pip freeze > requirements.txt
deactivate

cd ../..

# ─── Frontend ─────────────────────────────────────────────────
header "Configurando Frontend React"

cd "$PROJECT_DIR/frontend"

# Crear package.json si no existe
if [[ ! -f "package.json" ]]; then
cat > package.json <<'PKGJSON'
{
  "name": "mailai-pro",
  "version": "2.0.0",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "recharts": "^2.12.7",
    "zustand": "^5.0.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.3.1",
    "vite": "^5.4.8"
  }
}
PKGJSON
fi

# Crear vite.config.js si no existe
if [[ ! -f "vite.config.js" ]]; then
cat > vite.config.js <<'VITECONF'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '')
      },
      '/ws': {
        target: 'ws://localhost:8000',
        ws: true,
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/ws/, '/ws')
      }
    }
  }
})
VITECONF
fi

# Crear index.html si no existe
if [[ ! -f "index.html" ]]; then
cat > index.html <<'HTMLEOF'
<!DOCTYPE html>
<html lang="es" data-theme="dark">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MailAI Pro</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
HTMLEOF
fi

# Crear main.jsx si no existe
if [[ ! -f "src/main.jsx" ]]; then
cat > src/main.jsx <<'MAINJSX'
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode><App /></React.StrictMode>
)
MAINJSX
fi

info "Instalando dependencias Node.js..."
npm install --silent
success "Dependencias frontend instaladas"

cd ../..

# ─── Scripts de inicio ────────────────────────────────────────
header "Creando scripts de inicio"

# Script para levantar todo en desarrollo
cat > "$PROJECT_DIR/start-dev.sh" <<'STARTSH'
#!/usr/bin/env bash
# Iniciar MailAI Pro en modo desarrollo
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "🚀 Iniciando MailAI Pro en modo desarrollo..."

# Backend en background
cd "$SCRIPT_DIR/backend"
source venv/bin/activate
echo "⚙  Backend iniciando en http://localhost:8000"
uvicorn main:app --reload --port 8000 &
BACKEND_PID=$!
deactivate

# Frontend
cd "$SCRIPT_DIR/frontend"
echo "⚙  Frontend iniciando en http://localhost:3000"
npm run dev &
FRONTEND_PID=$!

echo ""
echo "✅ MailAI Pro corriendo:"
echo "   Frontend: http://localhost:3000"
echo "   Backend:  http://localhost:8000"
echo "   API Docs: http://localhost:8000/docs"
echo ""
echo "Presiona Ctrl+C para detener todo."

trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; echo '⛔ Detenido.'" EXIT INT TERM
wait
STARTSH
chmod +x "$PROJECT_DIR/start-dev.sh"

# Script solo backend
cat > "$PROJECT_DIR/start-backend.sh" <<'BACKSH'
#!/usr/bin/env bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR/backend"
source venv/bin/activate
uvicorn main:app --reload --port 8000
BACKSH
chmod +x "$PROJECT_DIR/start-backend.sh"

# Script solo frontend
cat > "$PROJECT_DIR/start-frontend.sh" <<'FRONTSH'
#!/usr/bin/env bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR/frontend"
npm run dev
FRONTSH
chmod +x "$PROJECT_DIR/start-frontend.sh"

success "Scripts de inicio creados"

# ─── Recordatorio de archivos ─────────────────────────────────
header "Próximos pasos"

echo -e "${BOLD}1. Copia los archivos del proyecto:${RESET}"
echo "   Cada archivo descargado lleva el prefijo de su ubicación."
echo "   Por ejemplo: backend__main.py → mailai-pro/backend/main.py"
echo ""
echo -e "${BOLD}2. Inicia en modo desarrollo:${RESET}"
echo "   cd mailai-pro && ./start-dev.sh"
echo ""
echo -e "${BOLD}3. O con Docker:${RESET}"
echo "   cd mailai-pro && docker compose up -d"
echo ""
echo -e "${BOLD}4. Abre la app:${RESET}"
echo "   http://localhost:3000"
echo ""
echo -e "${BOLD}5. Configura tu email:${RESET}"
echo "   En la app: Ajustes → Sincronizar → ingresa email y App Password"
echo ""
echo -e "${GREEN}${BOLD}¡Instalación completada!${RESET}"
