# ==============================================================
# backend/config.py
# ==============================================================
from pydantic_settings import BaseSettings
import os

class Settings(BaseSettings):
    ollama_base_url: str   = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    ollama_model:    str   = os.getenv("OLLAMA_MODEL",    "llama3.2:3b")
    ollama_timeout:  float = float(os.getenv("OLLAMA_TIMEOUT", "120"))
    database_url:    str   = os.getenv("DATABASE_URL",    "panel.db")
    debug:           bool  = os.getenv("DEBUG", "false").lower() == "true"
    port:            int   = int(os.getenv("PORT", "8000"))
    class Config:
        env_file = ".env"


# ==============================================================
# backend/requirements.txt
# ==============================================================
# fastapi==0.115.0
# uvicorn[standard]==0.30.6
# httpx==0.27.2
# pydantic==2.9.2
# pydantic-settings==2.5.2
# python-dotenv==1.0.1
# pywin32==308


# ==============================================================
# backend/.env
# ==============================================================
# OLLAMA_BASE_URL=http://localhost:11434
# OLLAMA_MODEL=llama3.2:3b
# OLLAMA_TIMEOUT=120
# DATABASE_URL=panel.db
# DEBUG=false
# PORT=8000
