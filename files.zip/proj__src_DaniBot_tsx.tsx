// ============================================================
// src/components/DaniBot/DaniBot.tsx
// Panel conversacional DaniBot — IA sobre tu bandeja de entrada
// Prioridad #1 del proyecto según especificación del usuario
// ============================================================

import { useState, useEffect, useRef, useCallback } from 'react';
import { useStore } from '@/store/useStore';
import { api } from '@/services/api';
import type { ChatMessage, DaniBotResponse } from '@/types';
import './DaniBot.css';

// Formatea la hora del mensaje
const formatTime = (date: Date) =>
  date.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' });

// Genera ID único local para cada mensaje
const uid = () => crypto.randomUUID();

export default function DaniBot() {
  const { setDanibotOpen, activeAccountId, addToast } = useStore();

  const [messages,    setMessages]    = useState<ChatMessage[]>([]);
  const [input,       setInput]       = useState('');
  const [loading,     setLoading]     = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef    = useRef<HTMLTextAreaElement>(null);

  // ── Cargar sugerencias al montar ──────────────────────────
  useEffect(() => {
    api.danibot.suggestions()
      .then(({ suggestions }) => setSuggestions(suggestions))
      .catch(() => {});
    textareaRef.current?.focus();
  }, []);

  // ── Scroll al último mensaje ──────────────────────────────
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // ── Auto-resize del textarea ──────────────────────────────
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = `${Math.min(e.target.scrollHeight, 120)}px`;
  };

  // ── Enviar mensaje ────────────────────────────────────────
  const sendMessage = useCallback(async (text: string) => {
    const msgText = text.trim();
    if (!msgText || loading) return;

    // Agregar mensaje del usuario a la UI
    const userMsg: ChatMessage = {
      id: uid(), role: 'user',
      content: msgText, timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';

    // Agregar placeholder de respuesta con loading
    const loadingId = uid();
    setMessages(prev => [...prev, {
      id: loadingId, role: 'assistant',
      content: '', timestamp: new Date(), loading: true,
    }]);
    setLoading(true);

    try {
      // Llamar al backend DaniBot
      const response: DaniBotResponse = await api.danibot.chat(msgText, activeAccountId ?? undefined);

      // Reemplazar placeholder con la respuesta real
      setMessages(prev => prev.map(m =>
        m.id === loadingId ? {
          id: loadingId, role: 'assistant' as const,
          content:   response.answer,
          timestamp: new Date(),
          loading:   false,
          data:      response.data,
          // Adjuntar insights si existen
          ...(response.insights?.length ? { insights: response.insights } : {}),
        } : m
      ));
    } catch (err) {
      setMessages(prev => prev.map(m =>
        m.id === loadingId ? {
          id: loadingId, role: 'assistant' as const,
          content: 'Lo siento, hubo un error al procesar tu pregunta. Verifica que Ollama esté corriendo.',
          timestamp: new Date(), error: true,
        } : m
      ));
      addToast('Error al contactar DaniBot', 'error');
    } finally {
      setLoading(false);
    }
  }, [loading, activeAccountId, addToast]);

  // ── Enviar con Enter (Shift+Enter = nueva línea) ──────────
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  // ── Resetear conversación ────────────────────────────────
  const handleReset = async () => {
    await api.danibot.reset().catch(() => {});
    setMessages([]);
    addToast('Conversación reiniciada', 'info');
  };

  const showWelcome = messages.length === 0;

  return (
    <div className="danibot-overlay">
      <div className="danibot-panel" role="dialog" aria-label="DaniBot - Asistente de bandeja">

        {/* ── Header ── */}
        <div className="danibot-header">
          <div className="danibot-avatar" aria-hidden="true">🤖</div>
          <div className="danibot-info">
            <div className="danibot-name">DaniBot</div>
            <div className="danibot-status">
              <span className="danibot-status-dot" />
              {loading ? 'Procesando...' : 'Listo para ayudarte'}
            </div>
          </div>
          <div className="danibot-header-actions">
            <button
              className="btn-icon"
              onClick={handleReset}
              title="Nueva conversación"
              aria-label="Reiniciar conversación"
            >
              ↺
            </button>
            <button
              className="btn-icon"
              onClick={() => setDanibotOpen(false)}
              title="Cerrar DaniBot"
              aria-label="Cerrar DaniBot"
            >
              ✕
            </button>
          </div>
        </div>

        {/* ── Mensajes ── */}
        <div className="danibot-messages" role="log" aria-live="polite">

          {/* Pantalla de bienvenida */}
          {showWelcome && (
            <div className="danibot-welcome">
              <div className="danibot-welcome-avatar" aria-hidden="true">🤖</div>
              <div className="danibot-welcome-title">Hola, soy DaniBot</div>
              <p className="danibot-welcome-sub">
                Puedo responder preguntas sobre tu bandeja de entrada.
                Pregúntame sobre emails urgentes, relaciones con contactos,
                tendencias de sentimiento y más.
              </p>
              {suggestions.length > 0 && (
                <div className="danibot-suggestions">
                  {suggestions.slice(0, 5).map((s, i) => (
                    <button
                      key={i}
                      className="danibot-suggestion-btn"
                      onClick={() => sendMessage(s)}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Lista de mensajes */}
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`danibot-bubble-wrap ${msg.role}`}
            >
              <div className={`danibot-bubble ${msg.role} ${msg.error ? 'error' : ''}`}>
                {msg.loading ? (
                  /* Indicador de escritura */
                  <div className="danibot-typing" aria-label="DaniBot está escribiendo">
                    <span /><span /><span />
                  </div>
                ) : (
                  /* Contenido del mensaje */
                  <>
                    <span style={{ whiteSpace: 'pre-wrap' }}>{msg.content}</span>

                    {/* Insights adicionales */}
                    {(msg as ChatMessage & { insights?: string[] }).insights?.length > 0 && (
                      <div className="danibot-insights">
                        {(msg as ChatMessage & { insights?: string[] }).insights!.map((ins, i) => (
                          <div key={i} className="danibot-insight">
                            💡 {ins}
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
              <span className="danibot-time">{formatTime(msg.timestamp)}</span>
            </div>
          ))}

          <div ref={messagesEndRef} />
        </div>

        {/* ── Input ── */}
        <div className="danibot-input-area">
          <div className="danibot-input-row">
            <textarea
              ref={textareaRef}
              className="danibot-textarea"
              placeholder="Pregunta algo sobre tu bandeja..."
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              rows={1}
              disabled={loading}
              aria-label="Mensaje para DaniBot"
            />
            <button
              className="danibot-send-btn"
              onClick={() => sendMessage(input)}
              disabled={loading || !input.trim()}
              aria-label="Enviar mensaje"
            >
              ➤
            </button>
          </div>
          <div className="danibot-footer">
            <span className="danibot-hint">↵ Enviar · Shift+↵ Nueva línea</span>
            <span>Impulsado por Ollama</span>
          </div>
        </div>

      </div>
    </div>
  );
}
