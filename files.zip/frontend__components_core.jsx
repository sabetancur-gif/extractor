// ════════════════════════════════════════
// src/components/Sidebar.jsx
// ════════════════════════════════════════
import { useStore } from '../store'

const NAV = [
  { id: 'dashboard', icon: '▦', label: 'Dashboard' },
  { id: 'inbox', icon: '✉', label: 'Bandeja', badgeKey: 'action' },
  { id: 'analytics', icon: '↗', label: 'Analytics' },
  { id: 'contacts', icon: '◉', label: 'Contactos' },
  { id: 'settings', icon: '⚙', label: 'Ajustes' },
]

export default function Sidebar() {
  const { activePage, setActivePage, stats, accounts, activeAccountId, setActiveAccount, syncing } = useStore()

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="logo">
          <div className="logo-mark">M</div>
          <div>
            <div className="logo-name">MailAI</div>
            <div className="logo-version">Pro v2.0</div>
          </div>
        </div>
      </div>

      {accounts.length > 1 && (
        <div className="account-switcher">
          {accounts.map(acc => (
            <button
              key={acc.id}
              className={`account-pill ${acc.id === activeAccountId ? 'active' : ''}`}
              onClick={() => setActiveAccount(acc.id)}
              title={acc.email}
            >
              <span className="account-avatar">
                {(acc.display_name || acc.email)[0].toUpperCase()}
              </span>
            </button>
          ))}
        </div>
      )}

      <nav className="nav">
        {NAV.map(item => {
          const badge = item.badgeKey === 'action' ? stats?.requires_action : null
          return (
            <button
              key={item.id}
              className={`nav-btn ${activePage === item.id ? 'active' : ''}`}
              onClick={() => setActivePage(item.id)}
            >
              <span className="nav-icon">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
              {badge > 0 && <span className="nav-badge">{badge > 99 ? '99+' : badge}</span>}
            </button>
          )
        })}
      </nav>

      <div className="sidebar-footer">
        <div className="sync-status">
          <div className={`status-dot ${syncing ? 'syncing' : 'idle'}`} />
          <span className="status-text">{syncing ? 'Sincronizando...' : 'En tiempo real'}</span>
        </div>
        <div className="kbd-hint">
          <kbd>⌘K</kbd> Command palette
        </div>
      </div>
    </aside>
  )
}

// ════════════════════════════════════════
// src/components/Topbar.jsx
// ════════════════════════════════════════
import { useState } from 'react'

const PAGE_LABELS = {
  dashboard: 'Dashboard',
  inbox: 'Bandeja de Entrada',
  analytics: 'Analytics',
  contacts: 'Contactos',
  settings: 'Configuración',
}

export function Topbar() {
  const {
    activePage, syncing, syncProgress, syncMessage,
    emailFilters, setEmailFilters, stats,
    setCommandOpen, accounts
  } = useStore()
  const [showSync, setShowSync] = useState(false)
  const [form, setForm] = useState({ email: '', password: '', folder: 'INBOX', limit: 100, days_back: 14 })

  const handleSync = async () => {
    setShowSync(false)
    const { addToast, setSyncing } = useStore.getState()
    try {
      const { api } = await import('../services/api')
      await api.post('/sync', form)
      addToast('Sincronización iniciada', 'info')
    } catch (e) {
      addToast(e.message, 'error')
    }
  }

  return (
    <header className="topbar">
      <div className="topbar-left">
        <h1 className="page-title">{PAGE_LABELS[activePage]}</h1>
        {stats && (
          <span className="topbar-stat">{stats.total.toLocaleString()} emails</span>
        )}
      </div>

      <div className="topbar-center">
        {syncing && (
          <div className="sync-bar">
            <div className="sync-bar-track">
              <div className="sync-bar-fill" style={{ width: `${syncProgress || 0}%` }} />
            </div>
            <span className="sync-bar-label">{syncMessage || 'Procesando...'}</span>
          </div>
        )}
      </div>

      <div className="topbar-right">
        <button className="topbar-search-btn" onClick={() => setCommandOpen(true)}>
          <span>Buscar...</span>
          <kbd>⌘K</kbd>
        </button>
        <button
          className={`btn-sync ${syncing ? 'loading' : ''}`}
          onClick={() => setShowSync(true)}
          disabled={syncing}
        >
          {syncing ? (
            <><span className="spin">⟳</span> Sync...</>
          ) : (
            <><span>⟳</span> Sincronizar</>
          )}
        </button>
      </div>

      {showSync && (
        <div className="modal-backdrop" onClick={() => setShowSync(false)}>
          <div className="sync-modal" onClick={e => e.stopPropagation()}>
            <div className="modal-head">
              <h2>Sincronizar emails</h2>
              <button className="close-btn" onClick={() => setShowSync(false)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="field-group">
                <label>Email</label>
                <input type="email" placeholder="tu@gmail.com"
                  value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
              </div>
              <div className="field-group">
                <label>App Password <a href="https://myaccount.google.com/apppasswords" target="_blank" rel="noreferrer">¿Cómo obtenerla?</a></label>
                <input type="password" placeholder="xxxx xxxx xxxx xxxx"
                  value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
              </div>
              <div className="field-row">
                <div className="field-group">
                  <label>Carpeta</label>
                  <select value={form.folder} onChange={e => setForm({ ...form, folder: e.target.value })}>
                    <option value="INBOX">Recibidos</option>
                    <option value="SENT">Enviados</option>
                    <option value="Spam">Spam</option>
                  </select>
                </div>
                <div className="field-group">
                  <label>Máx. emails</label>
                  <input type="number" min="1" max="500" value={form.limit}
                    onChange={e => setForm({ ...form, limit: +e.target.value })} />
                </div>
                <div className="field-group">
                  <label>Días atrás</label>
                  <input type="number" min="1" max="90" value={form.days_back}
                    onChange={e => setForm({ ...form, days_back: +e.target.value })} />
                </div>
              </div>
            </div>
            <div className="modal-actions">
              <button className="btn-secondary" onClick={() => setShowSync(false)}>Cancelar</button>
              <button className="btn-primary" onClick={handleSync}
                disabled={!form.email || !form.password}>
                Conectar y Clasificar
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}

// ════════════════════════════════════════
// src/components/Toast.jsx
// ════════════════════════════════════════
export function Toast({ message, type }) {
  const icons = { success: '✓', error: '✕', info: 'ℹ', warning: '⚠' }
  return (
    <div className={`toast toast-${type}`}>
      <span className="toast-icon">{icons[type] || 'ℹ'}</span>
      <span className="toast-msg">{message}</span>
    </div>
  )
}

export default function ToastContainer() {
  const { toasts } = useStore()
  return (
    <div className="toast-container">
      {toasts.map(t => <Toast key={t.id} {...t} />)}
    </div>
  )
}

// ════════════════════════════════════════
// src/components/CommandPalette.jsx
// ════════════════════════════════════════
import { useState, useEffect, useRef } from 'react'

const COMMANDS = [
  { id: 'goto-dashboard', label: 'Ir a Dashboard', icon: '▦', action: 'navigate', target: 'dashboard' },
  { id: 'goto-inbox', label: 'Ir a Bandeja', icon: '✉', action: 'navigate', target: 'inbox' },
  { id: 'goto-analytics', label: 'Ir a Analytics', icon: '↗', action: 'navigate', target: 'analytics' },
  { id: 'goto-contacts', label: 'Ver Contactos', icon: '◉', action: 'navigate', target: 'contacts' },
  { id: 'filter-urgente', label: 'Filtrar: Urgentes', icon: '🔴', action: 'filter', filter: { priority_label: 'urgente' } },
  { id: 'filter-accion', label: 'Filtrar: Requieren acción', icon: '⚡', action: 'filter', filter: { requires_action: true } },
  { id: 'filter-starred', label: 'Filtrar: Destacados', icon: '★', action: 'filter', filter: { is_starred: true } },
  { id: 'filter-trabajo', label: 'Filtrar: Trabajo', icon: '💼', action: 'filter', filter: { category: 'trabajo' } },
  { id: 'filter-finanzas', label: 'Filtrar: Finanzas', icon: '💰', action: 'filter', filter: { category: 'finanzas' } },
  { id: 'filter-spam', label: 'Filtrar: Spam', icon: '🚫', action: 'filter', filter: { spam: true } },
  { id: 'sync', label: 'Abrir sincronización', icon: '⟳', action: 'sync' },
]

export function CommandPalette() {
  const { setCommandOpen, setActivePage, setEmailFilters } = useStore()
  const [query, setQuery] = useState('')
  const inputRef = useRef(null)

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  const filtered = query
    ? COMMANDS.filter(c => c.label.toLowerCase().includes(query.toLowerCase()))
    : COMMANDS

  const execute = (cmd) => {
    setCommandOpen(false)
    if (cmd.action === 'navigate') { setActivePage(cmd.target) }
    else if (cmd.action === 'filter') {
      setActivePage('inbox')
      setEmailFilters(cmd.filter)
    }
  }

  return (
    <div className="cmd-backdrop" onClick={() => setCommandOpen(false)}>
      <div className="cmd-palette" onClick={e => e.stopPropagation()}>
        <div className="cmd-search">
          <span className="cmd-search-icon">⌕</span>
          <input
            ref={inputRef}
            type="text"
            placeholder="Buscar comandos, emails, contactos..."
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
          <kbd onClick={() => setCommandOpen(false)}>ESC</kbd>
        </div>
        <div className="cmd-results">
          {filtered.map((cmd, i) => (
            <button key={cmd.id} className={`cmd-item ${i === 0 && query ? 'cmd-item-active' : ''}`}
              onClick={() => execute(cmd)}>
              <span className="cmd-icon">{cmd.icon}</span>
              <span className="cmd-label">{cmd.label}</span>
            </button>
          ))}
          {filtered.length === 0 && (
            <div className="cmd-empty">Sin resultados para "{query}"</div>
          )}
        </div>
      </div>
    </div>
  )
}
