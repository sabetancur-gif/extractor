// frontend/src/components/Topbar.jsx
import { useState } from 'react'
import { useStore } from '../store'
import { api } from '../services/api'

const PAGE_LABELS = {
  dashboard: 'Dashboard',
  inbox:     'Bandeja de Entrada',
  analytics: 'Analytics',
  contacts:  'Contactos',
  settings:  'Configuración',
}

export default function Topbar() {
  const {
    activePage, syncing, syncProgress, syncMessage,
    setCommandOpen, stats, addToast, setSyncing
  } = useStore()

  const [showSync, setShowSync] = useState(false)
  const [form, setForm] = useState({
    email: '', password: '', folder: 'INBOX', limit: 100, days_back: 14
  })

  const handleSync = async () => {
    setShowSync(false)
    try {
      await api.post('/sync', form)
      addToast('Sincronización iniciada', 'info')
    } catch (e) {
      addToast(e.message, 'error')
    }
  }

  return (
    <header className="topbar">
      <div className="topbar-left">
        <h1 className="page-title">{PAGE_LABELS[activePage]}</h1>
        {stats && (
          <span className="topbar-stat">
            {stats.total.toLocaleString()} emails
          </span>
        )}
      </div>

      <div className="topbar-center">
        {syncing && (
          <div className="sync-bar">
            <div className="sync-bar-track">
              <div
                className="sync-bar-fill"
                style={{ width: `${syncProgress || 0}%` }}
              />
            </div>
            <span className="sync-bar-label">
              {syncMessage || 'Procesando...'}
            </span>
          </div>
        )}
      </div>

      <div className="topbar-right">
        <button
          className="topbar-search-btn"
          onClick={() => setCommandOpen(true)}
        >
          <span>Buscar...</span>
          <kbd>⌘K</kbd>
        </button>
        <button
          className={`btn-sync ${syncing ? 'loading' : ''}`}
          onClick={() => setShowSync(true)}
          disabled={syncing}
        >
          {syncing
            ? <><span className="spin">⟳</span> Sync...</>
            : <><span>⟳</span> Sincronizar</>
          }
        </button>
      </div>

      {showSync && (
        <div className="modal-backdrop" onClick={() => setShowSync(false)}>
          <div className="sync-modal" onClick={e => e.stopPropagation()}>
            <div className="modal-head">
              <h2>Sincronizar emails</h2>
              <button className="close-btn" onClick={() => setShowSync(false)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="field-group">
                <label>Email</label>
                <input
                  type="email"
                  placeholder="tu@gmail.com"
                  value={form.email}
                  onChange={e => setForm({ ...form, email: e.target.value })}
                />
              </div>
              <div className="field-group">
                <label>
                  App Password{' '}
                  <a
                    href="https://myaccount.google.com/apppasswords"
                    target="_blank"
                    rel="noreferrer"
                  >
                    ¿Cómo obtenerla?
                  </a>
                </label>
                <input
                  type="password"
                  placeholder="xxxx xxxx xxxx xxxx"
                  value={form.password}
                  onChange={e => setForm({ ...form, password: e.target.value })}
                />
              </div>
              <div className="field-row">
                <div className="field-group">
                  <label>Carpeta</label>
                  <select
                    value={form.folder}
                    onChange={e => setForm({ ...form, folder: e.target.value })}
                  >
                    <option value="INBOX">Recibidos</option>
                    <option value="SENT">Enviados</option>
                    <option value="Spam">Spam</option>
                  </select>
                </div>
                <div className="field-group">
                  <label>Máx. emails</label>
                  <input
                    type="number" min="1" max="500"
                    value={form.limit}
                    onChange={e => setForm({ ...form, limit: +e.target.value })}
                  />
                </div>
                <div className="field-group">
                  <label>Días atrás</label>
                  <input
                    type="number" min="1" max="90"
                    value={form.days_back}
                    onChange={e => setForm({ ...form, days_back: +e.target.value })}
                  />
                </div>
              </div>
            </div>
            <div className="modal-actions">
              <button
                className="btn-secondary"
                onClick={() => setShowSync(false)}
              >
                Cancelar
              </button>
              <button
                className="btn-primary"
                onClick={handleSync}
                disabled={!form.email || !form.password}
              >
                Conectar y Clasificar
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
