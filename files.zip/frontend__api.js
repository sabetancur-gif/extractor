// src/services/api.js
const BASE = '/api'

async function request(method, path, body = null, params = null) {
  let url = `${BASE}${path}`
  if (params) {
    const search = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== null && v !== undefined)
    )
    if (search.toString()) url += `?${search}`
  }
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
  }
  if (body) opts.body = JSON.stringify(body)
  const res = await fetch(url, opts)
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || `HTTP ${res.status}`)
  }
  if (res.status === 204) return null
  return res.json()
}

export const api = {
  get: (path, params) => request('GET', path, null, params),
  post: (path, body) => request('POST', path, body),
  patch: (path, body) => request('PATCH', path, body),
  put: (path, body) => request('PUT', path, body),
  delete: (path) => request('DELETE', path),
}

// ─── WEBSOCKET ─────────────────────────────────────────────────
export class EmailWebSocket {
  constructor(onMessage) {
    this.onMessage = onMessage
    this.ws = null
    this.reconnectDelay = 1000
    this.maxDelay = 30000
    this.shouldReconnect = true
  }

  connect() {
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    const host = window.location.host
    this.ws = new WebSocket(`${proto}//${host}/ws`)

    this.ws.onopen = () => {
      this.reconnectDelay = 1000
      this.onMessage({ type: 'ws_connected' })
    }

    this.ws.onmessage = (event) => {
      try {
        this.onMessage(JSON.parse(event.data))
      } catch (e) {
        console.error('WS parse error:', e)
      }
    }

    this.ws.onclose = () => {
      this.onMessage({ type: 'ws_disconnected' })
      if (this.shouldReconnect) {
        setTimeout(() => this.connect(), this.reconnectDelay)
        this.reconnectDelay = Math.min(this.reconnectDelay * 2, this.maxDelay)
      }
    }

    this.ws.onerror = () => {
      this.onMessage({ type: 'ws_error' })
    }
  }

  disconnect() {
    this.shouldReconnect = false
    this.ws?.close()
  }
}

// ─── QUERY KEYS ────────────────────────────────────────────────
export const KEYS = {
  emails: (filters) => ['emails', filters],
  email: (id) => ['email', id],
  stats: (accountId) => ['stats', accountId],
  contacts: (search) => ['contacts', search],
  contact: (id) => ['contact', id],
  accounts: ['accounts'],
  rules: ['rules'],
}
