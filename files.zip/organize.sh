#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
#  organize.sh — Organiza los archivos descargados en la
#  estructura final del proyecto mailai-pro/
#
#  Uso:
#    1. Pon TODOS los archivos descargados en una carpeta (ej: ~/Downloads/mailai/)
#    2. Ejecuta: bash organize.sh ~/Downloads/mailai/
#    3. El proyecto quedará en ./mailai-pro/
# ═══════════════════════════════════════════════════════════════
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[1;36m'; RESET='\033[0m'
ok()   { echo -e "${GREEN}✓${RESET} $*"; }
skip() { echo -e "${YELLOW}⚠${RESET} $* (no encontrado — cópialo manualmente)"; }
hdr()  { echo -e "\n${CYAN}── $* ──${RESET}"; }

SRC="${1:-.}"          # carpeta con los archivos descargados
DST="./mailai-pro"     # destino del proyecto

echo -e "${CYAN}"
echo "  MailAI Pro — Organizador de archivos"
echo "  Origen : $SRC"
echo "  Destino: $DST"
echo -e "${RESET}"

# ─── Crear estructura ─────────────────────────────────────────
mkdir -p "$DST/backend"
mkdir -p "$DST/frontend/src/pages"
mkdir -p "$DST/frontend/src/components"
mkdir -p "$DST/frontend/src/services"
mkdir -p "$DST/frontend/src/store"
mkdir -p "$DST/data"

# ─── Función de copia segura ──────────────────────────────────
copy_if_exists() {
    local src_file="$SRC/$1"
    local dst_file="$DST/$2"
    if [[ -f "$src_file" ]]; then
        cp "$src_file" "$dst_file"
        ok "$1 → $2"
    else
        skip "$1"
    fi
}

# ═══════════════════════════════════════════════════════════════
hdr "BACKEND"
# ═══════════════════════════════════════════════════════════════

copy_if_exists "backend__main.py"           "backend/main.py"
copy_if_exists "backend__classifier.py"     "backend/classifier.py"
copy_if_exists "backend__database.py"       "backend/database.py"
copy_if_exists "backend__email_fetcher.py"  "backend/email_fetcher.py"
copy_if_exists "backend__rules_engine.py"   "backend/rules_engine.py"
copy_if_exists "backend__scheduler.py"      "backend/scheduler.py"
copy_if_exists "backend__config.py"         "backend/config.py"
copy_if_exists "backend__Dockerfile"        "backend/Dockerfile"

# requirements.txt y .env.example están combinados en uno
REQ_SRC="$SRC/backend__requirements_and_env.txt"
if [[ -f "$REQ_SRC" ]]; then
    # Extraer requirements.txt (hasta la línea en blanco antes de .env.example)
    awk '/^# ===== \.env\.example =====/{exit} !/^# ===== requirements/{print}' \
        "$REQ_SRC" | grep -v '^$' | head -n 20 > "$DST/backend/requirements.txt" 2>/dev/null || true
    # Extraer .env.example
    awk '/^# ===== \.env\.example =====/{found=1; next} found{print}' \
        "$REQ_SRC" > "$DST/backend/.env.example" 2>/dev/null || true
    ok "backend__requirements_and_env.txt → backend/requirements.txt + backend/.env.example"
else
    skip "backend__requirements_and_env.txt"
fi

# ═══════════════════════════════════════════════════════════════
hdr "FRONTEND — Configuración"
# ═══════════════════════════════════════════════════════════════

copy_if_exists "frontend__nginx.conf"       "frontend/nginx.conf"
copy_if_exists "frontend__Dockerfile"       "frontend/Dockerfile"
copy_if_exists "frontend__index.css"        "frontend/src/index.css"

# package.json, vite.config.js, main.jsx e index.html están en un txt combinado
# Los usuarios deben separarlos manualmente o usar el setup.sh que los genera
PKG_SRC="$SRC/frontend__package_vite_main.txt"
if [[ -f "$PKG_SRC" ]]; then
    echo "" > "$DST/frontend/LEER_package_vite_main.txt"
    cp "$PKG_SRC" "$DST/frontend/LEER_package_vite_main.txt"
    ok "frontend__package_vite_main.txt → frontend/LEER_package_vite_main.txt (separa manualmente)"
else
    skip "frontend__package_vite_main.txt"
fi

# ═══════════════════════════════════════════════════════════════
hdr "FRONTEND — Servicios y Store"
# ═══════════════════════════════════════════════════════════════

copy_if_exists "frontend__api.js"           "frontend/src/services/api.js"
copy_if_exists "frontend__store.js"         "frontend/src/store/index.js"

# ═══════════════════════════════════════════════════════════════
hdr "FRONTEND — App Root"
# ═══════════════════════════════════════════════════════════════

copy_if_exists "frontend__App.jsx"          "frontend/src/App.jsx"

# ═══════════════════════════════════════════════════════════════
hdr "FRONTEND — Componentes"
# ═══════════════════════════════════════════════════════════════

copy_if_exists "frontend__AIInsights.jsx"   "frontend/src/components/AIInsights.jsx"

# El archivo core tiene Sidebar, Topbar, Toast, CommandPalette juntos
# Se copia como referencia y se indica cómo separar
CORE_SRC="$SRC/frontend__components_core.jsx"
if [[ -f "$CORE_SRC" ]]; then
    cp "$CORE_SRC" "$DST/frontend/src/components/LEER_components_core.jsx"
    # Crear archivos individuales vacíos con instrucción
    for COMP in Sidebar Topbar Toast CommandPalette; do
        if [[ ! -f "$DST/frontend/src/components/${COMP}.jsx" ]]; then
            echo "// Extrae el componente $COMP del archivo LEER_components_core.jsx" \
                 > "$DST/frontend/src/components/${COMP}.jsx"
        fi
    done
    ok "frontend__components_core.jsx → components/ (ver LEER_components_core.jsx)"
else
    skip "frontend__components_core.jsx"
fi

# ═══════════════════════════════════════════════════════════════
hdr "FRONTEND — Páginas"
# ═══════════════════════════════════════════════════════════════

copy_if_exists "frontend__Dashboard.jsx"    "frontend/src/pages/Dashboard.jsx"
copy_if_exists "frontend__Inbox.jsx"        "frontend/src/pages/Inbox.jsx"
copy_if_exists "frontend__Contacts.jsx"     "frontend/src/pages/Contacts.jsx"

# Analytics y Settings están combinados
ANSET_SRC="$SRC/frontend__Analytics_Settings.jsx"
if [[ -f "$ANSET_SRC" ]]; then
    cp "$ANSET_SRC" "$DST/frontend/src/pages/LEER_Analytics_Settings.jsx"
    echo "// Extrae Analytics del archivo LEER_Analytics_Settings.jsx" \
         > "$DST/frontend/src/pages/Analytics.jsx"
    echo "// Extrae Settings del archivo LEER_Analytics_Settings.jsx" \
         > "$DST/frontend/src/pages/Settings.jsx"
    ok "frontend__Analytics_Settings.jsx → pages/ (ver LEER_Analytics_Settings.jsx)"
else
    skip "frontend__Analytics_Settings.jsx"
fi

# ═══════════════════════════════════════════════════════════════
hdr "RAÍZ DEL PROYECTO"
# ═══════════════════════════════════════════════════════════════

copy_if_exists "docker-compose.yml"         "docker-compose.yml"
copy_if_exists "setup.sh"                   "setup.sh"

# .gitignore viene como dot_gitignore.txt
if [[ -f "$SRC/dot_gitignore.txt" ]]; then
    cp "$SRC/dot_gitignore.txt" "$DST/.gitignore"
    ok "dot_gitignore.txt → .gitignore"
else
    skip "dot_gitignore.txt"
fi

# README
for readme in "README_v2.md" "README.md"; do
    if [[ -f "$SRC/$readme" ]]; then
        cp "$SRC/$readme" "$DST/README.md"
        ok "$readme → README.md"
        break
    fi
done

# ─── .env ─────────────────────────────────────────────────────
if [[ ! -f "$DST/.env" ]]; then
    if [[ -f "$DST/backend/.env.example" ]]; then
        cp "$DST/backend/.env.example" "$DST/.env"
        warn ".env creado desde .env.example — EDITA tu ANTHROPIC_API_KEY"
    fi
fi

# ─── Resumen final ────────────────────────────────────────────
echo ""
echo -e "${CYAN}═══════════════════════════════════════════${RESET}"
echo -e "${GREEN}${CYAN}  Proyecto organizado en: $DST/${RESET}"
echo -e "${CYAN}═══════════════════════════════════════════${RESET}"
echo ""
echo "📋 Estructura resultante:"
find "$DST" -not -path '*/node_modules/*' -not -path '*/.git/*' \
    -not -path '*/venv/*' -not -path '*/dist/*' \
    | sort | head -60 | sed "s|$DST/||" | sed 's|[^/]*/|  |g'
echo ""
echo "▶  Próximos pasos:"
echo "   1. Edita $DST/.env con tu ANTHROPIC_API_KEY"
echo "   2. Separa los archivos LEER_*.jsx en sus componentes (ver README)"
echo "   3. Ejecuta: cd $DST && bash setup.sh"
echo "   4. O con Docker: cd $DST && docker compose up -d"
echo ""
