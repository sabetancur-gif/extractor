// src/components/AIInsights.jsx
// Panel de detalle con las 10+ dimensiones de análisis IA
import { useState } from 'react'

const URGENCY_COLORS = {
  critica: '#ef4444', alta: '#f97316', media: '#eab308', baja: '#22c55e', ninguna: '#6b7280'
}
const SENTIMENT_ICONS = {
  positivo: '😊', negativo: '😟', neutral: '😐', mixto: '🤔'
}
const THREAD_LABELS = {
  nuevo: 'Nuevo', necesita_respuesta: 'Responder', esperando_respuesta: 'Esperando',
  informativo: 'Info', seguimiento: 'Seguimiento', resuelto: 'Resuelto'
}
const CATS = ['trabajo','ventas_marketing','finanzas','soporte_tecnico',
              'personal','legal','educacion','redes_sociales','spam','otro']
const PRIS = ['urgente','alta','media','baja']

function ScoreMeter({ value, max = 100, color }) {
  const pct = Math.round((value / max) * 100)
  return (
    <div className="score-meter">
      <div className="score-track">
        <div className="score-fill" style={{ width: `${pct}%`, background: color }} />
      </div>
      <span className="score-val">{value}/{max}</span>
    </div>
  )
}

function EntityTag({ value }) {
  return <span className="entity-tag">{value}</span>
}

function ActionItem({ text, index }) {
  const [done, setDone] = useState(false)
  return (
    <div className={`action-item-row ${done ? 'done' : ''}`} onClick={() => setDone(!done)}>
      <div className={`action-checkbox ${done ? 'checked' : ''}`}>
        {done && '✓'}
      </div>
      <span>{text}</span>
    </div>
  )
}

export default function AIInsights({ email, onClose, onUpdate, onReclassify, catColors, priColors }) {
  const [tab, setTab] = useState('overview')
  const [editCat, setEditCat] = useState(false)
  const [editPri, setEditPri] = useState(false)
  const [reclassifying, setReclassifying] = useState(false)
  const [showReply, setShowReply] = useState(false)

  const entities = email.entities || {}
  const hasEntities = Object.values(entities).some(arr => Array.isArray(arr) && arr.length > 0)
  const actionItems = email.action_items || []
  const keyTopics = email.key_topics || []

  const handleReclassify = async () => {
    setReclassifying(true)
    await onReclassify(email.id)
    setReclassifying(false)
  }

  const priorityColor = email.priority_score > 75 ? '#ef4444'
    : email.priority_score > 50 ? '#f97316'
    : email.priority_score > 25 ? '#eab308' : '#22c55e'

  const confidenceColor = email.ai_confidence > 0.8 ? '#10b981'
    : email.ai_confidence > 0.5 ? '#eab308' : '#ef4444'

  return (
    <div className="ai-insights">
      <div className="ai-insights-header">
        <div className="ai-header-top">
          <button className="close-panel" onClick={onClose}>←</button>
          <div className="ai-header-actions">
            <button
              className={`action-btn ${email.is_starred ? 'starred' : ''}`}
              onClick={() => onUpdate(email.id, { is_starred: !email.is_starred })}
              title="Destacar"
            >★</button>
            <button
              className="action-btn"
              onClick={() => onUpdate(email.id, { is_archived: true })}
              title="Archivar"
            >⊡</button>
            <button
              className={`action-btn reclassify-btn ${reclassifying ? 'loading' : ''}`}
              onClick={handleReclassify}
              title="Re-clasificar con IA"
            >
              {reclassifying ? '⟳' : '🤖'} IA
            </button>
          </div>
        </div>

        <h2 className="email-subject-title">{email.subject || '(Sin asunto)'}</h2>
        <div className="email-from-info">
          <div className="sender-avatar">
            {(email.sender_name || email.sender_email || '?')[0].toUpperCase()}
          </div>
          <div>
            <div className="sender-name">{email.sender_name}</div>
            <div className="sender-email">{email.sender_email}</div>
            <div className="email-date-full">{email.date ? new Date(email.date).toLocaleString('es-CO') : ''}</div>
          </div>
        </div>
      </div>

      {/* Quick stats row */}
      <div className="quick-stats">
        <div className="qs-item">
          <span className="qs-label">Prioridad</span>
          <div className="qs-value">
            {editPri ? (
              <select autoFocus value={email.priority_label}
                onChange={e => { onUpdate(email.id, { priority_label: e.target.value }); setEditPri(false) }}
                onBlur={() => setEditPri(false)}>
                {PRIS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            ) : (
              <span className="priority-chip" style={{ '--pc': priColors[email.priority_label] }}
                onClick={() => setEditPri(true)}>
                {email.priority_label}
              </span>
            )}
          </div>
        </div>
        <div className="qs-item">
          <span className="qs-label">Score</span>
          <ScoreMeter value={email.priority_score || 50} color={priorityColor} />
        </div>
        <div className="qs-item">
          <span className="qs-label">Categoría</span>
          <div className="qs-value">
            {editCat ? (
              <select autoFocus value={email.category}
                onChange={e => { onUpdate(email.id, { category: e.target.value }); setEditCat(false) }}
                onBlur={() => setEditCat(false)}>
                {CATS.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            ) : (
              <span className="cat-chip-sm" style={{ '--cc': catColors[email.category] }}
                onClick={() => setEditCat(true)}>
                {email.category?.replace('_',' ')}
              </span>
            )}
          </div>
        </div>
        <div className="qs-item">
          <span className="qs-label">Sentimiento</span>
          <span className="qs-value">
            {SENTIMENT_ICONS[email.sentiment_label]} {email.sentiment_label}
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div className="insight-tabs">
        {['overview','body','entities','actions','reply'].map(t => (
          <button key={t} className={`itab ${tab === t ? 'active' : ''}`} onClick={() => setTab(t)}>
            {{ overview:'Resumen', body:'Cuerpo', entities:'Entidades', actions:'Acciones', reply:'Respuesta IA' }[t]}
            {t === 'actions' && actionItems.length > 0 && <span className="itab-count">{actionItems.length}</span>}
          </button>
        ))}
      </div>

      <div className="insight-body">
        {tab === 'overview' && (
          <div className="tab-content">
            {email.summary && (
              <div className="summary-block">
                <div className="block-label">📝 Resumen IA</div>
                <p>{email.summary}</p>
              </div>
            )}

            <div className="insight-grid">
              <div className="ig-item">
                <div className="ig-label">Urgencia</div>
                <div className="ig-value">
                  <span className="urgency-badge"
                    style={{ '--uc': URGENCY_COLORS[email.urgency_level] || '#6b7280' }}>
                    {email.urgency_level}
                  </span>
                  {email.urgency_reason && <p className="urgency-reason">{email.urgency_reason}</p>}
                  {email.urgency_deadline && <p className="deadline">📅 Fecha límite: {email.urgency_deadline}</p>}
                </div>
              </div>

              <div className="ig-item">
                <div className="ig-label">Tono</div>
                <div className="ig-value"><span className="tone-chip">{email.tone}</span></div>
              </div>

              <div className="ig-item">
                <div className="ig-label">Tipo de hilo</div>
                <div className="ig-value">
                  <span className="thread-chip">{THREAD_LABELS[email.thread_type] || email.thread_type}</span>
                </div>
              </div>

              <div className="ig-item">
                <div className="ig-label">Idioma</div>
                <div className="ig-value">
                  {email.language === 'es' ? '🇨🇴 Español'
                    : email.language === 'en' ? '🇺🇸 Inglés'
                    : email.language === 'pt' ? '🇧🇷 Portugués'
                    : email.language || 'N/A'}
                </div>
              </div>

              <div className="ig-item">
                <div className="ig-label">Spam Score</div>
                <ScoreMeter
                  value={Math.round((email.spam_score || 0) * 100)}
                  color={email.spam_score > 0.6 ? '#ef4444' : '#22c55e'}
                />
              </div>

              <div className="ig-item">
                <div className="ig-label">Confianza IA</div>
                <ScoreMeter
                  value={Math.round((email.ai_confidence || 0) * 100)}
                  color={confidenceColor}
                />
              </div>
            </div>

            {keyTopics.length > 0 && (
              <div className="topics-block">
                <div className="block-label">🏷 Temas clave</div>
                <div className="topics-list">
                  {keyTopics.map(t => <span key={t} className="topic-tag">{t}</span>)}
                </div>
              </div>
            )}

            {email.subcategory && email.subcategory !== 'general' && (
              <div className="subcategory-block">
                <div className="block-label">Subcategoría</div>
                <span className="subcategory-tag">{email.subcategory}</span>
              </div>
            )}
          </div>
        )}

        {tab === 'body' && (
          <div className="tab-content">
            <pre className="email-body-pre">{email.body || 'Sin contenido de texto'}</pre>
          </div>
        )}

        {tab === 'entities' && (
          <div className="tab-content">
            {!hasEntities ? (
              <div className="empty-tab">No se detectaron entidades en este email</div>
            ) : (
              <div className="entities-grid">
                {[
                  { key: 'people', label: '👤 Personas', icon: '👤' },
                  { key: 'companies', label: '🏢 Empresas', icon: '🏢' },
                  { key: 'dates', label: '📅 Fechas', icon: '📅' },
                  { key: 'amounts', label: '💰 Montos', icon: '💰' },
                  { key: 'locations', label: '📍 Lugares', icon: '📍' },
                ].map(({ key, label }) => {
                  const items = entities[key] || []
                  if (!items.length) return null
                  return (
                    <div key={key} className="entity-group">
                      <div className="entity-group-label">{label}</div>
                      <div className="entity-tags">
                        {items.map((item, i) => <EntityTag key={i} value={item} />)}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        )}

        {tab === 'actions' && (
          <div className="tab-content">
            {actionItems.length === 0 ? (
              <div className="empty-tab">No se detectaron ítems de acción</div>
            ) : (
              <div className="action-items-list">
                <div className="block-label">✅ Ítems de acción detectados por IA</div>
                {actionItems.map((item, i) => <ActionItem key={i} text={item} index={i} />)}
              </div>
            )}
          </div>
        )}

        {tab === 'reply' && (
          <div className="tab-content">
            {email.suggested_reply ? (
              <div className="reply-block">
                <div className="block-label">🤖 Borrador de respuesta sugerido por IA</div>
                <div className="reply-text">{email.suggested_reply}</div>
                <button className="copy-btn" onClick={() => {
                  navigator.clipboard.writeText(email.suggested_reply)
                }}>
                  📋 Copiar al portapapeles
                </button>
              </div>
            ) : (
              <div className="empty-tab">
                Este email no requiere respuesta según el análisis IA
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
