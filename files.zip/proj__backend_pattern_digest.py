"""
=============================================================
backend/pattern_detector.py
Detector de Patrones e Anomalías en el Inbox
=============================================================
Analiza el historial de emails para detectar:
  - Picos de volumen inusuales
  - Anomalías en remitentes (cambian comportamiento)
  - Deadlines próximos detectados por IA
  - Tendencias negativas en relaciones
  - Patrones recurrentes (ej: lunes = más urgentes)
=============================================================
"""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import List, Dict
from dataclasses import dataclass, field


@dataclass
class Pattern:
    """Patrón o anomalía detectada."""
    id:          str
    type:        str    # volume_spike | anomaly | deadline | trend | recurring
    title:       str
    description: str
    severity:    str    # info | warning | critical
    icon:        str
    action:      str = ""


class PatternDetector:
    """Detecta patrones e anomalías en el inbox sin llamar a Ollama (análisis estadístico)."""

    def __init__(self, db_path: str):
        self.db_path = db_path

    def detect_all(self, account_id: int = None) -> List[Dict]:
        """Ejecuta todos los detectores y devuelve la lista de patrones."""
        patterns = []
        f = f"AND account_id={account_id}" if account_id else ""

        with sqlite3.connect(self.db_path) as db:
            db.row_factory = sqlite3.Row

            patterns += self._detect_volume_spike(db, f)
            patterns += self._detect_deadline_urgency(db, f)
            patterns += self._detect_sender_anomaly(db, f)
            patterns += self._detect_negative_trend(db, f)
            patterns += self._detect_day_pattern(db, f)

        return [self._to_dict(p) for p in patterns[:6]]  # Máximo 6 patrones

    def _detect_volume_spike(self, db, f) -> List[Pattern]:
        """Detecta si hoy hay más emails de lo normal."""
        today_count = db.execute(
            f"SELECT COUNT(*) FROM emails WHERE DATE(date)=DATE('now') {f}"
        ).fetchone()[0]

        avg_daily = db.execute(f"""
            SELECT AVG(c) FROM (
                SELECT DATE(date) d, COUNT(*) c
                FROM emails WHERE date >= DATE('now','-14 days') {f}
                GROUP BY DATE(date)
            )
        """).fetchone()[0] or 0

        if avg_daily > 0 and today_count > avg_daily * 1.8:
            return [Pattern(
                id="volume_spike", type="volume_spike",
                title=f"Pico de volumen hoy",
                description=f"Recibiste {today_count} emails hoy vs un promedio de {int(avg_daily)} diarios. Un {int((today_count/avg_daily-1)*100)}% más de lo normal.",
                severity="warning", icon="📈",
                action="Activa el Modo Foco para procesar solo lo crítico.",
            )]
        return []

    def _detect_deadline_urgency(self, db, f) -> List[Pattern]:
        """Detecta emails con deadlines en los próximos 3 días."""
        urgent = db.execute(f"""
            SELECT COUNT(*) FROM emails
            WHERE urgency_level IN ('critica','alta')
            AND urgency_deadline != '' AND urgency_deadline IS NOT NULL {f}
        """).fetchone()[0]

        if urgent > 0:
            return [Pattern(
                id="deadline_alert", type="deadline",
                title=f"{urgent} deadline{'s' if urgent>1 else ''} detectado{'s' if urgent>1 else ''}",
                description=f"Ollama detectó {urgent} email{'s' if urgent>1 else ''} con fecha límite explícita pendiente de acción.",
                severity="critical" if urgent > 2 else "warning",
                icon="📅",
                action="Revisa el Centro de Acciones para ver los plazos.",
            )]
        return []

    def _detect_sender_anomaly(self, db, f) -> List[Pattern]:
        """Detecta si un remitente habitual cambió su tono habitual."""
        # Remitentes que normalmente son neutros/positivos pero hoy son negativos
        anomaly = db.execute(f"""
            SELECT e.sender_name, e.sentiment_label, h.usual_sentiment
            FROM emails e
            JOIN (
                SELECT sender_email,
                       (CASE WHEN AVG(CASE sentiment_label WHEN 'positivo' THEN 1
                                       WHEN 'neutral' THEN 0 ELSE -1 END) > 0
                              THEN 'positivo' ELSE 'neutral' END) as usual_sentiment
                FROM emails
                WHERE date < DATE('now','-3 days') {f}
                GROUP BY sender_email HAVING COUNT(*) >= 3
            ) h ON e.sender_email = h.sender_email
            WHERE DATE(e.date) >= DATE('now','-2 days')
            AND e.sentiment_label = 'negativo'
            AND h.usual_sentiment IN ('positivo','neutral') {f}
            LIMIT 1
        """).fetchone()

        if anomaly:
            return [Pattern(
                id="sender_anomaly", type="anomaly",
                title=f"Cambio de tono: {anomaly[0]}",
                description=f"{anomaly[0]} generalmente escribe con tono {anomaly[2]}, pero sus últimos emails son negativos. Algo puede haber cambiado.",
                severity="warning", icon="⚠️",
                action="Revisa sus últimos emails para entender el cambio.",
            )]
        return []

    def _detect_negative_trend(self, db, f) -> List[Pattern]:
        """Detecta si el sentimiento general empeoró esta semana."""
        this_week = db.execute(f"""
            SELECT AVG(CASE sentiment_label WHEN 'positivo' THEN 1 WHEN 'neutral' THEN 0 ELSE -1 END)
            FROM emails WHERE date >= DATE('now','-7 days') {f}
        """).fetchone()[0] or 0

        last_week = db.execute(f"""
            SELECT AVG(CASE sentiment_label WHEN 'positivo' THEN 1 WHEN 'neutral' THEN 0 ELSE -1 END)
            FROM emails WHERE date BETWEEN DATE('now','-14 days') AND DATE('now','-7 days') {f}
        """).fetchone()[0] or 0

        if last_week != 0 and this_week < last_week - 0.3:
            return [Pattern(
                id="neg_trend", type="trend",
                title="Tendencia negativa esta semana",
                description=f"El sentimiento promedio bajó un {abs(int((this_week-last_week)*100))}% respecto a la semana anterior. Más emails negativos o tensos.",
                severity="warning", icon="📉",
                action="Usa Analytics para identificar qué contacto o tema lo causa.",
            )]
        return []

    def _detect_day_pattern(self, db, f) -> List[Pattern]:
        """Detecta si el día actual tiene patrones históricos inusuales."""
        today_dow = datetime.now().weekday()  # 0=Lunes
        day_names = ["lunes","martes","miércoles","jueves","viernes","sábado","domingo"]

        avg_by_day = db.execute(f"""
            SELECT strftime('%w', date) as dow, AVG(importance_score) as avg_imp, COUNT(*) as c
            FROM emails WHERE date >= DATE('now','-30 days') {f}
            GROUP BY dow
        """).fetchall()

        if not avg_by_day:
            return []

        # Convertir a dict (strftime %w: 0=domingo, 1=lunes...)
        day_map = {int(r[0]): {"avg_imp": r[1], "c": r[2]} for r in avg_by_day}
        # Convertir weekday (0=lunes) a strftime (1=lunes)
        strftime_dow = (today_dow + 1) % 7

        if strftime_dow in day_map and day_map[strftime_dow]["avg_imp"] > 70:
            return [Pattern(
                id="day_pattern", type="recurring",
                title=f"Los {day_names[today_dow]}s son intensos",
                description=f"Históricamente, los {day_names[today_dow]}s tienes emails con importancia promedio de {int(day_map[strftime_dow]['avg_imp'])}/100. Prepárate.",
                severity="info", icon="🔄",
            )]
        return []

    def _to_dict(self, p: Pattern) -> Dict:
        return {"id":p.id,"type":p.type,"title":p.title,"description":p.description,
                "severity":p.severity,"icon":p.icon,"action":p.action}


# =============================================================
# backend/digest_generator.py
# Generador de Digest Semanal con Ollama
# =============================================================

class DigestGenerator:
    """Genera un resumen semanal narrativo usando Ollama."""

    def __init__(self, db_path: str, ollama_url: str, model: str, timeout: float = 120.0):
        self.db_path    = db_path
        self.ollama_url = ollama_url.rstrip("/")
        self.model      = model
        self.timeout    = timeout

    def generate(self, account_id: int = None) -> Dict:
        """Genera el digest de la semana actual."""
        f = f"AND account_id={account_id}" if account_id else ""
        stats = self._gather_stats(f)
        narrative = self._generate_narrative(stats)
        return {
            "week_start":        (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d"),
            "week_end":          datetime.now().strftime("%Y-%m-%d"),
            "total_emails":      stats.get("total", 0),
            "critical_count":    stats.get("critical", 0),
            "pending_actions":   stats.get("pending_actions", 0),
            "top_sender":        stats.get("top_sender", ""),
            "dominant_category": stats.get("dominant_category", ""),
            "sentiment_summary": stats.get("sentiment_summary", ""),
            "narrative":         narrative,
            "key_insights":      stats.get("insights", []),
        }

    def _gather_stats(self, f: str) -> Dict:
        with sqlite3.connect(self.db_path) as db:
            db.row_factory = sqlite3.Row
            row = db.execute(f"""
                SELECT COUNT(*) total,
                  SUM(CASE WHEN importance_label='critica' THEN 1 ELSE 0 END) critical,
                  SUM(CASE WHEN urgency_level!='ninguna' AND urgency_actions!='[]' THEN 1 ELSE 0 END) pending_actions,
                  (SELECT sender_name FROM emails WHERE date>=DATE('now','-7 days') {f}
                   GROUP BY sender_email ORDER BY COUNT(*) DESC LIMIT 1) top_sender,
                  (SELECT category FROM emails WHERE date>=DATE('now','-7 days') {f}
                   GROUP BY category ORDER BY COUNT(*) DESC LIMIT 1) dominant_category
                FROM emails WHERE date>=DATE('now','-7 days') {f}
            """).fetchone()
            stats = dict(row) if row else {}

            sent = db.execute(f"""
                SELECT sentiment_label, COUNT(*) c FROM emails
                WHERE date>=DATE('now','-7 days') {f}
                GROUP BY sentiment_label ORDER BY c DESC LIMIT 1
            """).fetchone()
            stats["sentiment_summary"] = sent["sentiment_label"] if sent else "neutral"

            stats["insights"] = [
                f"{stats.get('total',0)} emails procesados esta semana",
                f"{stats.get('critical',0)} emails de importancia crítica",
                f"Categoría dominante: {stats.get('dominant_category','N/A')}",
            ]
        return stats

    def _generate_narrative(self, stats: Dict) -> str:
        prompt = f"""Genera un resumen ejecutivo profesional de la semana de emails en 2-3 párrafos cortos.
Usa estos datos: {json.dumps(stats, ensure_ascii=False)}
Sé directo, profesional y útil. Sin saludos. Solo el resumen."""
        try:
            import httpx
            with httpx.Client(timeout=self.timeout) as client:
                resp = client.post(f"{self.ollama_url}/api/generate",
                    json={"model":self.model,"prompt":prompt,"stream":False,
                          "options":{"temperature":0.5,"num_predict":400}})
                return resp.json().get("response","Sin resumen disponible.")
        except Exception:
            total = stats.get('total', 0)
            critical = stats.get('critical', 0)
            return f"Esta semana procesaste {total} emails, de los cuales {critical} fueron de importancia crítica. La categoría dominante fue {stats.get('dominant_category','general')}."
