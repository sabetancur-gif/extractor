"""
classifier.py — Clasificador avanzado con 10+ dimensiones de análisis IA
Analiza: categoría, prioridad, sentimiento, entidades, ítems de acción,
respuesta sugerida, urgencia, idioma, spam score, tono, hilo, temas clave
"""
import anthropic
import json
import re
from typing import Dict, List, Optional
from config import Settings

settings = Settings()

CATEGORIES = {
    "trabajo": {
        "desc": "Emails laborales, proyectos, reuniones, reportes",
        "subcategories": ["reuniones", "proyectos", "reportes", "contratos", "reclutamiento", "general"]
    },
    "ventas_marketing": {
        "desc": "Ofertas, newsletters, campañas, promociones",
        "subcategories": ["promocion", "newsletter", "oferta", "publicidad"]
    },
    "finanzas": {
        "desc": "Facturas, pagos, extractos, transacciones bancarias",
        "subcategories": ["factura", "pago", "extracto", "cobranza", "recibo"]
    },
    "soporte_tecnico": {
        "desc": "Tickets de soporte, errores, incidentes técnicos",
        "subcategories": ["ticket", "error", "incidente", "mantenimiento"]
    },
    "personal": {
        "desc": "Mensajes personales de amigos, familia",
        "subcategories": ["familia", "amigos", "social"]
    },
    "legal": {
        "desc": "Contratos, notificaciones legales, DIAN, gobierno",
        "subcategories": ["contrato", "notificacion", "demanda", "gobierno", "tributario"]
    },
    "educacion": {
        "desc": "Cursos, certificados, universidades, capacitaciones",
        "subcategories": ["curso", "certificado", "universidad", "taller"]
    },
    "redes_sociales": {
        "desc": "Notificaciones de LinkedIn, Twitter, Instagram, etc.",
        "subcategories": ["linkedin", "twitter", "instagram", "facebook"]
    },
    "spam": {
        "desc": "Spam, phishing, emails no solicitados",
        "subcategories": ["phishing", "spam", "scam"]
    },
    "otro": {
        "desc": "No encaja claramente en otra categoría",
        "subcategories": ["general"]
    }
}

TONES = ["formal", "informal", "agresivo", "urgente", "amigable", "neutral", "corporativo", "tecnico"]
THREAD_TYPES = ["nuevo", "necesita_respuesta", "esperando_respuesta", "informativo", "seguimiento", "resuelto"]


class EmailClassifier:
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
        self.model = "claude-sonnet-4-20250514"

    def classify_email(self, email_data: Dict) -> Dict:
        """Clasificación completa con 10+ dimensiones de análisis"""
        prompt = self._build_prompt(email_data)
        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=1200,
                messages=[{"role": "user", "content": prompt}]
            )
            return self._parse(response.content[0].text, email_data)
        except Exception as e:
            print(f"⚠️ Classifier error: {e}")
            return self._default(email_data)

    def _build_prompt(self, e: Dict) -> str:
        body = (e.get("body") or "")[:1200]
        thread_ctx = ""
        if e.get("thread_context"):
            thread_ctx = f"\nContexto del hilo anterior:\n{e['thread_context'][:400]}"

        cats = "\n".join(f"  - {k}: {v['desc']}" for k, v in CATEGORIES.items())

        return f"""Analiza este email y devuelve ÚNICAMENTE un objeto JSON válido sin texto adicional, sin bloques de código, sin explicaciones.

EMAIL:
De: {e.get("sender_name", "")} <{e.get("sender_email", "")}>
Para: {e.get("to", "")}
Asunto: {e.get("subject", "")}
Fecha: {e.get("date", "")}
Adjuntos: {e.get("has_attachments", False)}
{thread_ctx}

Cuerpo:
{body}

CATEGORÍAS DISPONIBLES:
{cats}

Responde con este JSON exacto (sin texto extra):
{{
  "category": "una categoría de la lista",
  "subcategory": "subcategoría específica",
  "priority_score": 1-100,
  "priority_label": "urgente|alta|media|baja",
  "sentiment": {{
    "label": "positivo|negativo|neutral|mixto",
    "score": -1.0 a 1.0,
    "tone": "formal|informal|agresivo|urgente|amigable|neutral|corporativo|tecnico"
  }},
  "urgency": {{
    "level": "critica|alta|media|baja|ninguna",
    "reason": "breve justificación",
    "deadline": "fecha ISO si hay plazo o null"
  }},
  "entities": {{
    "people": ["lista de personas mencionadas"],
    "companies": ["empresas mencionadas"],
    "dates": ["fechas y plazos mencionados"],
    "amounts": ["montos, precios mencionados"],
    "locations": ["lugares mencionados"]
  }},
  "action_items": ["ítem de acción 1", "ítem de acción 2"],
  "suggested_reply": "borrador de respuesta profesional en el mismo idioma del email, máx 3 oraciones, o null si no se necesita respuesta",
  "key_topics": ["tema1", "tema2", "tema3"],
  "language": "es|en|fr|pt|otro",
  "spam_score": 0.0-1.0,
  "thread_type": "nuevo|necesita_respuesta|esperando_respuesta|informativo|seguimiento|resuelto",
  "summary": "resumen de 1-2 oraciones",
  "requires_action": true|false,
  "confidence": 0.0-1.0
}}"""

    def _parse(self, text: str, email_data: Dict) -> Dict:
        try:
            match = re.search(r'\{.*\}', text, re.DOTALL)
            if not match:
                return self._default(email_data)
            data = json.loads(match.group())
            return {
                "category": self._valid_cat(data.get("category", "otro")),
                "subcategory": str(data.get("subcategory", "general"))[:50],
                "priority_score": max(1, min(100, int(data.get("priority_score", 50)))),
                "priority_label": self._valid_priority(data.get("priority_label", "media")),
                "sentiment": {
                    "label": data.get("sentiment", {}).get("label", "neutral"),
                    "score": float(data.get("sentiment", {}).get("score", 0.0)),
                    "tone": data.get("sentiment", {}).get("tone", "neutral")
                },
                "urgency": {
                    "level": data.get("urgency", {}).get("level", "ninguna"),
                    "reason": str(data.get("urgency", {}).get("reason", ""))[:200],
                    "deadline": data.get("urgency", {}).get("deadline")
                },
                "entities": {
                    "people": list(data.get("entities", {}).get("people", []))[:10],
                    "companies": list(data.get("entities", {}).get("companies", []))[:10],
                    "dates": list(data.get("entities", {}).get("dates", []))[:10],
                    "amounts": list(data.get("entities", {}).get("amounts", []))[:10],
                    "locations": list(data.get("entities", {}).get("locations", []))[:10],
                },
                "action_items": list(data.get("action_items", []))[:10],
                "suggested_reply": str(data.get("suggested_reply") or "")[:800] or None,
                "key_topics": list(data.get("key_topics", []))[:8],
                "language": str(data.get("language", "es"))[:10],
                "spam_score": max(0.0, min(1.0, float(data.get("spam_score", 0.0)))),
                "thread_type": data.get("thread_type", "nuevo"),
                "summary": str(data.get("summary", ""))[:500],
                "requires_action": bool(data.get("requires_action", False)),
                "confidence": max(0.0, min(1.0, float(data.get("confidence", 0.8)))),
            }
        except Exception as ex:
            print(f"⚠️ Parse error: {ex}\n{text[:200]}")
            return self._default(email_data)

    def _valid_cat(self, cat: str) -> str:
        if cat in CATEGORIES:
            return cat
        for k in CATEGORIES:
            if k in cat.lower():
                return k
        return "otro"

    def _valid_priority(self, p: str) -> str:
        return p if p in ("urgente", "alta", "media", "baja") else "media"

    def _default(self, email_data: Dict = None) -> Dict:
        return {
            "category": "otro", "subcategory": "general",
            "priority_score": 50, "priority_label": "media",
            "sentiment": {"label": "neutral", "score": 0.0, "tone": "neutral"},
            "urgency": {"level": "ninguna", "reason": "", "deadline": None},
            "entities": {"people": [], "companies": [], "dates": [], "amounts": [], "locations": []},
            "action_items": [], "suggested_reply": None, "key_topics": [],
            "language": "es", "spam_score": 0.0, "thread_type": "nuevo",
            "summary": "No clasificado automáticamente",
            "requires_action": False, "confidence": 0.0
        }
