"""
=============================================================
MÓDULO 1: outlook_reader.py
Panel Clasificador MailAI — Lector Multi-Cuenta Outlook
=============================================================
Lee TODOS los buzones abiertos en Outlook simultáneamente
usando la API COM de Windows (win32com).

No necesita contraseñas, IMAP ni Azure AD.
Solo requiere que Outlook esté abierto en el PC.

Prerequisito: pip install pywin32
=============================================================
"""

import win32com.client
import hashlib
import re
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, field


# ─────────────────────────────────────────────────────────────
# Constantes de tipos de elementos en Outlook COM
# ─────────────────────────────────────────────────────────────
OL_MAIL_ITEM      = 43   # Email normal
OL_FOLDER_INBOX   = 6    # Bandeja de entrada
OL_FOLDER_SENT    = 5    # Enviados
OL_FOLDER_DRAFTS  = 16   # Borradores
OL_FOLDER_DELETED = 3    # Elementos eliminados
OL_FOLDER_JUNK    = 23   # Correo no deseado


@dataclass
class OutlookAccount:
    """Representa una cuenta de correo abierta en Outlook."""
    name:         str           # Nombre visible (ej: "juan@empresa.com")
    email:        str           # Dirección de email
    store_index:  int           # Índice en namespace.Stores
    total_emails: int = 0       # Total de emails leídos


@dataclass
class RawEmail:
    """Email crudo leído de Outlook antes de clasificar."""
    message_id:      str
    thread_key:      str
    account_name:    str         # A qué cuenta pertenece
    account_email:   str
    sender_name:     str
    sender_email:    str
    to_recipients:   str
    cc_recipients:   str
    subject:         str
    body:            str
    html_body:       str
    date:            str         # ISO format
    has_attachments: bool
    attachment_names: List[str]  = field(default_factory=list)
    outlook_folder:  str         = "INBOX"
    importance:      int         = 1   # 0=Baja, 1=Normal, 2=Alta (nativo Outlook)
    is_read:         bool        = False
    categories:      str         = ""  # Categorías asignadas en Outlook


class OutlookMultiAccountReader:
    """
    Lee emails de TODAS las cuentas abiertas en Outlook al mismo tiempo.

    Ejemplo de uso:
        reader = OutlookMultiAccountReader()
        accounts = reader.get_accounts()
        for acc in accounts:
            print(acc.name)

        emails = reader.fetch_all_emails(days_back=14, limit_per_account=100)
    """

    def __init__(self):
        """Conecta con la instancia de Outlook abierta en el PC."""
        try:
            # Dispatch se conecta al Outlook ya abierto (no crea uno nuevo)
            self._app       = win32com.client.Dispatch("Outlook.Application")
            self._namespace = self._app.GetNamespace("MAPI")
            print(f"✅ Conectado a Outlook COM")
        except Exception as e:
            raise RuntimeError(
                f"No se puede conectar a Outlook: {e}\n"
                "Asegúrate de que Outlook esté abierto en el PC."
            )

    # ──────────────────────────────────────────────────────────
    # 1. LISTAR CUENTAS
    # ──────────────────────────────────────────────────────────

    def get_accounts(self) -> List[OutlookAccount]:
        """
        Devuelve todas las cuentas (buzones) abiertos en Outlook.
        Cada Store de Outlook corresponde a una cuenta.
        """
        accounts = []
        try:
            for idx in range(1, self._namespace.Stores.Count + 1):
                store = self._namespace.Stores.Item(idx)
                name  = store.DisplayName or f"Cuenta {idx}"

                # Intentar extraer el email de las propiedades del store
                email = self._extract_email_from_store(store, name)

                accounts.append(OutlookAccount(
                    name        = name,
                    email       = email,
                    store_index = idx,
                ))

        except Exception as e:
            print(f"⚠️  Error listando cuentas: {e}")

        print(f"📋 {len(accounts)} cuenta(s) encontrada(s) en Outlook")
        for acc in accounts:
            print(f"   • {acc.name} ({acc.email})")

        return accounts

    def _extract_email_from_store(self, store, display_name: str) -> str:
        """Intenta obtener el email real del store."""
        # Algunos stores exponen el email directamente
        try:
            return store.ExchangeStoreType and store.DisplayName or display_name
        except Exception:
            pass
        # Buscar en las cuentas de Outlook
        try:
            for i in range(1, self._namespace.Accounts.Count + 1):
                acc = self._namespace.Accounts.Item(i)
                if acc.DisplayName == display_name or display_name in acc.SmtpAddress:
                    return acc.SmtpAddress
        except Exception:
            pass
        return display_name

    # ──────────────────────────────────────────────────────────
    # 2. LEER EMAILS DE TODAS LAS CUENTAS
    # ──────────────────────────────────────────────────────────

    def fetch_all_emails(
        self,
        days_back:          int  = 14,
        limit_per_account:  int  = 100,
        folders:            List[str] = None,
        include_read:       bool = True,
    ) -> Tuple[List[RawEmail], List[OutlookAccount]]:
        """
        Lee emails de TODAS las cuentas abiertas en Outlook.

        Args:
            days_back:          Cuántos días hacia atrás buscar
            limit_per_account:  Máximo de emails por cuenta
            folders:            Lista de nombres de carpeta (None = solo Inbox)
            include_read:       Si incluir emails ya leídos

        Returns:
            (lista de emails, lista de cuentas con estadísticas)
        """
        if folders is None:
            folders = ["Bandeja de entrada", "Inbox"]

        accounts    = self.get_accounts()
        all_emails  = []
        cutoff_date = datetime.now() - timedelta(days=days_back)

        for account in accounts:
            print(f"\n📬 Leyendo cuenta: {account.name}")
            try:
                store = self._namespace.Stores.Item(account.store_index)
                root  = store.GetRootFolder()

                # Buscar la carpeta Inbox en esta cuenta
                inbox = self._find_folder(root, folders)
                if inbox is None:
                    # Si no encuentra por nombre, usar el Inbox por defecto
                    inbox = self._get_default_inbox(account.store_index)

                if inbox is None:
                    print(f"   ⚠️  No se encontró bandeja de entrada")
                    continue

                # Leer emails de esta cuenta
                emails = self._read_folder(
                    folder       = inbox,
                    account      = account,
                    cutoff_date  = cutoff_date,
                    limit        = limit_per_account,
                    include_read = include_read,
                )

                account.total_emails = len(emails)
                all_emails.extend(emails)
                print(f"   ✅ {len(emails)} emails leídos")

            except Exception as e:
                print(f"   ❌ Error en cuenta {account.name}: {e}")
                continue

        # Ordenar todos los emails por fecha descendente
        all_emails.sort(
            key=lambda e: e.date,
            reverse=True
        )

        print(f"\n📊 Total: {len(all_emails)} emails de {len(accounts)} cuenta(s)")
        return all_emails, accounts

    def _find_folder(self, root_folder, folder_names: List[str]):
        """
        Busca una carpeta por nombre en el árbol de carpetas.
        Prueba cada nombre de la lista hasta encontrar una.
        """
        for name in folder_names:
            result = self._search_folder_recursive(root_folder, name)
            if result:
                return result
        return None

    def _search_folder_recursive(self, parent, target_name: str):
        """Búsqueda recursiva de carpeta por nombre (sin distinción may/min)."""
        try:
            for i in range(1, parent.Folders.Count + 1):
                folder = parent.Folders.Item(i)
                if folder.Name.lower() == target_name.lower():
                    return folder
                # Buscar en subcarpetas
                result = self._search_folder_recursive(folder, target_name)
                if result:
                    return result
        except Exception:
            pass
        return None

    def _get_default_inbox(self, store_index: int):
        """Obtiene la bandeja de entrada por defecto de una cuenta."""
        try:
            store = self._namespace.Stores.Item(store_index)
            return store.GetDefaultFolder(OL_FOLDER_INBOX)
        except Exception:
            try:
                return self._namespace.GetDefaultFolder(OL_FOLDER_INBOX)
            except Exception:
                return None

    def _read_folder(
        self,
        folder,
        account:      OutlookAccount,
        cutoff_date:  datetime,
        limit:        int,
        include_read: bool,
    ) -> List[RawEmail]:
        """
        Lee los emails de una carpeta específica de Outlook.
        Ordena por fecha descendente para leer los más recientes primero.
        """
        emails = []
        try:
            items = folder.Items
            items.Sort("[ReceivedTime]", True)   # True = descendente (más nuevos primero)

            for item in items:
                if len(emails) >= limit:
                    break

                try:
                    # Solo procesar MailItems (clase 43), ignorar reuniones, tareas, etc.
                    if getattr(item, 'Class', 0) != OL_MAIL_ITEM:
                        continue

                    # Obtener fecha de recepción
                    received_raw = getattr(item, 'ReceivedTime', None)
                    if received_raw is None:
                        continue

                    # Normalizar fecha (win32com devuelve datetime con info de zona)
                    received_naive = received_raw.replace(tzinfo=None)
                    if received_naive < cutoff_date:
                        break  # Los items están ordenados, podemos parar aquí

                    # Filtrar leídos si se requiere
                    is_read = bool(getattr(item, 'UnRead', True) == False)
                    if not include_read and is_read:
                        continue

                    parsed = self._parse_mail_item(item, account, folder.Name)
                    if parsed:
                        emails.append(parsed)

                except Exception as e:
                    # Error en un item individual, continuar con los demás
                    continue

        except Exception as e:
            print(f"   ⚠️  Error leyendo carpeta: {e}")

        return emails

    # ──────────────────────────────────────────────────────────
    # 3. PARSEAR CADA EMAIL
    # ──────────────────────────────────────────────────────────

    def _parse_mail_item(
        self,
        item,
        account: OutlookAccount,
        folder_name: str,
    ) -> Optional[RawEmail]:
        """
        Extrae todos los campos relevantes de un MailItem de Outlook.
        Maneja errores en campos individuales sin perder el email completo.
        """
        try:
            # ── Identificadores ──────────────────────────────
            entry_id  = str(getattr(item, 'EntryID',        '') or '')
            convo_id  = str(getattr(item, 'ConversationID', entry_id) or entry_id)
            message_id = f"outlook-{hashlib.md5(entry_id.encode()).hexdigest()}"
            thread_key = f"thread-{hashlib.md5(convo_id.encode()).hexdigest()}"

            # ── Remitente ────────────────────────────────────
            sender_name  = str(getattr(item, 'SenderName',         '') or '')
            sender_email = str(getattr(item, 'SenderEmailAddress', '') or '').lower().strip()

            # Limpiar nombres de distribución LDAP de Exchange
            # (ej: "/O=EXCHANGELABS/OU=..." → usar el display name)
            if sender_email.startswith('/o=') or sender_email.startswith('/O='):
                sender_email = sender_name.lower().replace(' ', '.') + '@' + account.email.split('@')[-1]

            # ── Destinatarios ────────────────────────────────
            to_addr = str(getattr(item, 'To',  '') or '')
            cc_addr = str(getattr(item, 'CC',  '') or '')

            # ── Asunto ───────────────────────────────────────
            subject = str(getattr(item, 'Subject', '') or '').strip() or '(Sin asunto)'

            # ── Cuerpo ───────────────────────────────────────
            # Preferir texto plano para el análisis de IA
            body      = str(getattr(item, 'Body',     '') or '')
            html_body = str(getattr(item, 'HTMLBody', '') or '')

            # Limpiar el cuerpo de texto (quitar quoted reply, espacios excesivos)
            body_clean = self._clean_body(body)

            # ── Fecha ────────────────────────────────────────
            received_raw = getattr(item, 'ReceivedTime', None)
            if received_raw:
                date_str = received_raw.replace(tzinfo=None).isoformat()
            else:
                date_str = datetime.now().isoformat()

            # ── Adjuntos ─────────────────────────────────────
            attachments_obj  = getattr(item, 'Attachments', None)
            has_attachments  = False
            attachment_names = []

            if attachments_obj and attachments_obj.Count > 0:
                has_attachments = True
                for i in range(1, min(attachments_obj.Count + 1, 21)):
                    try:
                        att = attachments_obj.Item(i)
                        att_name = getattr(att, 'FileName', '') or getattr(att, 'DisplayName', '')
                        if att_name:
                            attachment_names.append(str(att_name))
                    except Exception:
                        pass

            # ── Importancia nativa de Outlook ────────────────
            # 0 = Baja, 1 = Normal, 2 = Alta
            importance = int(getattr(item, 'Importance', 1) or 1)

            # ── Estado de lectura ────────────────────────────
            is_read = bool(getattr(item, 'UnRead', True) == False)

            # ── Categorías de Outlook ────────────────────────
            categories = str(getattr(item, 'Categories', '') or '')

            return RawEmail(
                message_id       = message_id,
                thread_key       = thread_key,
                account_name     = account.name,
                account_email    = account.email,
                sender_name      = sender_name,
                sender_email     = sender_email,
                to_recipients    = to_addr,
                cc_recipients    = cc_addr,
                subject          = subject,
                body             = body_clean[:6000],
                html_body        = html_body[:12000],
                date             = date_str,
                has_attachments  = has_attachments,
                attachment_names = attachment_names,
                outlook_folder   = folder_name,
                importance       = importance,
                is_read          = is_read,
                categories       = categories,
            )

        except Exception as e:
            print(f"   ⚠️  Error parseando email: {e}")
            return None

    # ──────────────────────────────────────────────────────────
    # 4. UTILIDADES
    # ──────────────────────────────────────────────────────────

    def _clean_body(self, text: str) -> str:
        """
        Limpia el cuerpo del email:
        - Elimina líneas de texto citado (>) de respuestas previas
        - Elimina espacios y saltos de línea excesivos
        - Elimina firmas comunes
        """
        if not text:
            return ""

        # Normalizar saltos de línea
        text = re.sub(r'\r\n', '\n', text)

        # Quitar contenido citado de respuestas anteriores
        lines = text.split('\n')
        clean_lines = []
        in_quoted   = False

        for line in lines:
            stripped = line.strip()
            # Detectar inicio de bloque citado
            if stripped.startswith('>') or stripped.startswith('On ') and 'wrote:' in stripped:
                in_quoted = True
            elif stripped == '':
                in_quoted = False
            if not in_quoted:
                clean_lines.append(line)

        text = '\n'.join(clean_lines)
        # Eliminar más de 2 líneas vacías consecutivas
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()

    def test_connection(self) -> Dict:
        """
        Verifica que Outlook esté disponible y devuelve info de las cuentas.
        Útil para el endpoint /health de la API.
        """
        try:
            accounts = self.get_accounts()
            return {
                "outlook_available": True,
                "accounts_count":    len(accounts),
                "accounts":          [{"name": a.name, "email": a.email} for a in accounts],
            }
        except Exception as e:
            return {
                "outlook_available": False,
                "error":             str(e),
                "accounts_count":    0,
                "accounts":          [],
            }

    def mark_as_read(self, entry_id: str) -> bool:
        """Marca un email como leído en Outlook (opcional)."""
        try:
            item = self._namespace.GetItemFromID(entry_id)
            item.UnRead = False
            item.Save()
            return True
        except Exception:
            return False
