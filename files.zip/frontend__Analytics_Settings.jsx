// src/pages/Analytics.jsx
import { useEffect } from 'react'
import { useStore } from '../store'
import {
  ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis,
  Tooltip, LineChart, Line, CartesianGrid, Legend, RadarChart, Radar, PolarGrid,
  PolarAngleAxis, AreaChart, Area
} from 'recharts'

const CAT_COLORS = {
  trabajo:'#6366f1', ventas_marketing:'#f59e0b', finanzas:'#10b981',
  soporte_tecnico:'#3b82f6', personal:'#ec4899', legal:'#ef4444',
  educacion:'#06b6d4', redes_sociales:'#8b5cf6', spam:'#6b7280', otro:'#94a3b8'
}
const PRI_COLORS = { urgente:'#ef4444', alta:'#f97316', media:'#eab308', baja:'#22c55e' }
const SENT_COLORS = { positivo:'#10b981', negativo:'#ef4444', neutral:'#94a3b8', mixto:'#f59e0b' }

function StatCard({ label, value, sub, trend, icon, color }) {
  return (
    <div className="analytics-stat" style={{ '--ac': color }}>
      <div className="as-icon">{icon}</div>
      <div className="as-body">
        <div className="as-value">{value}</div>
        <div className="as-label">{label}</div>
        {sub && <div className="as-sub">{sub}</div>}
      </div>
    </div>
  )
}

function ChartCard({ title, children, action }) {
  return (
    <div className="chart-card">
      <div className="cc-header">
        <h3 className="cc-title">{title}</h3>
        {action && <button className="cc-action" onClick={action.fn}>{action.label}</button>}
      </div>
      {children}
    </div>
  )
}

const CUSTOM_TOOLTIP = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="custom-tooltip">
      {label && <div className="ct-label">{label}</div>}
      {payload.map((p, i) => (
        <div key={i} className="ct-row">
          <span style={{ color: p.color }}>●</span>
          <span>{p.name || p.dataKey}: <strong>{p.value}</strong></span>
        </div>
      ))}
    </div>
  )
}

export default function Analytics() {
  const { stats, statsLoading, fetchStats, setEmailFilters, setActivePage } = useStore()

  useEffect(() => { fetchStats() }, [])

  if (statsLoading || !stats) {
    return <div className="loading-full"><div className="spinner" /><p>Cargando analytics...</p></div>
  }

  const goFilter = (filters) => {
    setEmailFilters(filters)
    setActivePage('inbox')
  }

  // Enrich data
  const categoryData = (stats.by_category || []).map(d => ({
    ...d,
    fill: CAT_COLORS[d.category] || '#94a3b8'
  }))

  const priorityData = (stats.by_priority || []).map(d => ({
    ...d,
    fill: PRI_COLORS[d.priority_label] || '#94a3b8',
    name: { urgente:'Urgente', alta:'Alta', media:'Media', baja:'Baja' }[d.priority_label]
  }))

  const sentimentData = (stats.by_sentiment || []).map(d => ({
    ...d,
    fill: SENT_COLORS[d.sentiment_label] || '#94a3b8',
    name: d.sentiment_label
  }))

  const toneData = (stats.by_tone || []).map(d => ({ tone: d.tone, count: d.count }))

  return (
    <div className="analytics-page">
      {/* KPI Row */}
      <div className="analytics-kpis">
        <StatCard icon="📧" label="Total emails" value={stats.total.toLocaleString()}
          color="#6366f1" />
        <StatCard icon="⚡" label="Requieren acción" value={stats.requires_action}
          sub="pendientes de resolución" color="#ef4444"
          action={() => goFilter({ requires_action: true })} />
        <StatCard icon="📊" label="Prioridad promedio" value={`${stats.avg_priority}/100`}
          sub="score de prioridad" color="#f97316" />
        <StatCard icon="🤖" label="Confianza IA" value={`${stats.avg_confidence}%`}
          sub="precisión de clasificación" color="#10b981" />
        <StatCard icon="🚫" label="Spam detectado" value={stats.spam_count}
          sub="emails filtrados" color="#6b7280" />
      </div>

      {/* Charts row 1 */}
      <div className="analytics-grid-3">
        <ChartCard title="Distribución por Categoría"
          action={{ label: 'Ver todos', fn: () => goFilter({}) }}>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={categoryData} dataKey="count" nameKey="category"
                cx="50%" cy="50%" innerRadius={55} outerRadius={90}>
                {categoryData.map((d, i) => (
                  <Cell key={i} fill={d.fill} cursor="pointer"
                    onClick={() => goFilter({ category: d.category })} />
                ))}
              </Pie>
              <Tooltip content={<CUSTOM_TOOLTIP />} formatter={(v, n, p) => [v, p.payload.category]} />
            </PieChart>
          </ResponsiveContainer>
          <div className="pie-legend">
            {categoryData.slice(0, 5).map(d => (
              <button key={d.category} className="pie-legend-item"
                onClick={() => goFilter({ category: d.category })}>
                <span className="legend-dot" style={{ background: d.fill }} />
                <span>{d.category.replace('_', ' ')}</span>
                <span className="legend-num">{d.count}</span>
              </button>
            ))}
          </div>
        </ChartCard>

        <ChartCard title="Por Prioridad">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={priorityData} layout="vertical" margin={{ left: 10 }}>
              <XAxis type="number" hide />
              <YAxis type="category" dataKey="name" width={65} tick={{ fontSize: 12 }} />
              <Tooltip content={<CUSTOM_TOOLTIP />} />
              <Bar dataKey="count" radius={[0, 6, 6, 0]}>
                {priorityData.map((d, i) => (
                  <Cell key={i} fill={d.fill} cursor="pointer"
                    onClick={() => goFilter({ priority_label: d.priority_label })} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Sentimiento">
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={sentimentData} dataKey="count" nameKey="name"
                cx="50%" cy="50%" outerRadius={100}
                label={({ name, percent }) => `${name} ${Math.round(percent * 100)}%`}>
                {sentimentData.map((d, i) => <Cell key={i} fill={d.fill} />)}
              </Pie>
              <Tooltip content={<CUSTOM_TOOLTIP />} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Charts row 2 */}
      <div className="analytics-grid-2">
        <ChartCard title="Volumen por Día (30 días)">
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={stats.by_day || []} margin={{ top: 10, right: 10, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id="colorEmails" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="day" tick={{ fontSize: 10 }} tickFormatter={v => v?.slice(5)} />
              <YAxis allowDecimals={false} tick={{ fontSize: 10 }} />
              <Tooltip content={<CUSTOM_TOOLTIP />} />
              <Area type="monotone" dataKey="count" name="Emails"
                stroke="#6366f1" strokeWidth={2} fill="url(#colorEmails)" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Top Remitentes">
          <div className="top-senders-list">
            {(stats.top_senders || []).slice(0, 8).map((s, i) => (
              <div key={s.sender_email} className="top-sender-row">
                <span className="ts-rank">#{i + 1}</span>
                <div className="ts-info">
                  <div className="ts-name">{s.sender_name || s.sender_email}</div>
                  <div className="ts-email">{s.sender_email}</div>
                </div>
                <div className="ts-bar-wrap">
                  <div className="ts-bar"
                    style={{ width: `${(s.count / (stats.top_senders[0]?.count || 1)) * 100}%` }} />
                </div>
                <span className="ts-count">{s.count}</span>
              </div>
            ))}
          </div>
        </ChartCard>
      </div>

      {/* Bottom row */}
      <div className="analytics-grid-2">
        <ChartCard title="Tono de Emails">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={toneData}>
              <XAxis dataKey="tone" tick={{ fontSize: 11 }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip content={<CUSTOM_TOOLTIP />} />
              <Bar dataKey="count" fill="#6366f1" radius={[4, 4, 0, 0]} name="Emails" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Tipo de Hilo">
          {(stats.by_thread_type || []).length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={stats.by_thread_type}>
                <XAxis dataKey="thread_type" tick={{ fontSize: 10 }}
                  tickFormatter={v => ({ nuevo:'Nuevo', necesita_respuesta:'Responder',
                    esperando_respuesta:'Esperando', informativo:'Info',
                    seguimiento:'Seguim.', resuelto:'Resuelto' }[v] || v)} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip content={<CUSTOM_TOOLTIP />} />
                <Bar dataKey="count" fill="#10b981" radius={[4, 4, 0, 0]} name="Emails" />
              </BarChart>
            </ResponsiveContainer>
          ) : <div className="empty-chart">Sin datos suficientes</div>}
        </ChartCard>
      </div>
    </div>
  )
}


// ═══════════════════════════════════════════════════════════════
// src/pages/Settings.jsx
// ═══════════════════════════════════════════════════════════════
import { useState } from 'react'
import { api } from '../services/api'

const OPERATORS = [
  { value: 'equals', label: 'es igual a' },
  { value: 'contains', label: 'contiene' },
  { value: 'starts_with', label: 'empieza con' },
  { value: 'ends_with', label: 'termina con' },
  { value: 'gte', label: '≥ mayor o igual' },
  { value: 'lte', label: '≤ menor o igual' },
  { value: 'is_true', label: 'es verdadero' },
]

const FIELDS = [
  { value: 'sender_email', label: 'Email remitente' },
  { value: 'sender_name', label: 'Nombre remitente' },
  { value: 'sender_domain', label: 'Dominio remitente' },
  { value: 'subject', label: 'Asunto' },
  { value: 'body', label: 'Cuerpo' },
  { value: 'category', label: 'Categoría IA' },
  { value: 'priority_label', label: 'Prioridad IA' },
  { value: 'priority_score', label: 'Score de prioridad' },
  { value: 'sentiment', label: 'Sentimiento' },
  { value: 'tone', label: 'Tono' },
  { value: 'language', label: 'Idioma' },
  { value: 'spam_score', label: 'Score de spam' },
  { value: 'requires_action', label: 'Requiere acción' },
  { value: 'thread_type', label: 'Tipo de hilo' },
]

const ACTIONS_TYPES = [
  { value: 'set_category', label: 'Asignar categoría', hasValue: true },
  { value: 'set_priority', label: 'Asignar prioridad', hasValue: true },
  { value: 'set_starred', label: 'Destacar email', hasValue: false },
  { value: 'set_archived', label: 'Archivar email', hasValue: false },
  { value: 'mark_read', label: 'Marcar como leído', hasValue: false },
  { value: 'mark_deleted', label: 'Eliminar email', hasValue: false },
]

export function Settings() {
  const { rules, fetchRules, deleteRule, createRule, theme, setTheme,
          accounts, addToast } = useStore()

  const [ruleForm, setRuleForm] = useState({
    name: '', description: '', priority: 0,
    conditions: [{ field: 'sender_email', operator: 'contains', value: '' }],
    actions: [{ type: 'set_starred' }]
  })
  const [showNewRule, setShowNewRule] = useState(false)
  const [testResults, setTestResults] = useState(null)

  const addCondition = () => setRuleForm(prev => ({
    ...prev,
    conditions: [...prev.conditions, { field: 'sender_email', operator: 'contains', value: '' }]
  }))

  const updateCondition = (i, key, value) => setRuleForm(prev => ({
    ...prev,
    conditions: prev.conditions.map((c, idx) => idx === i ? { ...c, [key]: value } : c)
  }))

  const removeCondition = (i) => setRuleForm(prev => ({
    ...prev,
    conditions: prev.conditions.filter((_, idx) => idx !== i)
  }))

  const addAction = () => setRuleForm(prev => ({
    ...prev,
    actions: [...prev.actions, { type: 'mark_read' }]
  }))

  const updateAction = (i, key, value) => setRuleForm(prev => ({
    ...prev,
    actions: prev.actions.map((a, idx) => idx === i ? { ...a, [key]: value } : a)
  }))

  const removeAction = (i) => setRuleForm(prev => ({
    ...prev,
    actions: prev.actions.filter((_, idx) => idx !== i)
  }))

  const handleSaveRule = async () => {
    await createRule(ruleForm)
    setShowNewRule(false)
    setRuleForm({ name:'', description:'', priority:0,
      conditions: [{ field:'sender_email', operator:'contains', value:'' }],
      actions: [{ type:'set_starred' }]
    })
    addToast('Regla creada', 'success')
  }

  const handleTestRule = async (ruleId) => {
    try {
      const result = await api.post(`/rules/${ruleId}/test`, {})
      setTestResults({ ruleId, ...result })
    } catch (e) {
      addToast('Error testeando regla', 'error')
    }
  }

  return (
    <div className="settings-page">
      <div className="settings-section">
        <h2 className="settings-title">🎨 Apariencia</h2>
        <div className="settings-card">
          <div className="setting-row">
            <div>
              <div className="setting-label">Tema</div>
              <div className="setting-desc">Elige entre modo oscuro y claro</div>
            </div>
            <div className="theme-switcher">
              {['dark', 'light'].map(t => (
                <button key={t} className={`theme-btn ${theme === t ? 'active' : ''}`}
                  onClick={() => setTheme(t)}>
                  {t === 'dark' ? '🌙 Oscuro' : '☀️ Claro'}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="settings-section">
        <div className="settings-section-header">
          <h2 className="settings-title">⚡ Reglas Automáticas</h2>
          <button className="btn-primary" onClick={() => setShowNewRule(!showNewRule)}>
            + Nueva regla
          </button>
        </div>
        <p className="settings-desc">
          Las reglas se aplican automáticamente cuando se clasifican nuevos emails.
          Se procesan en orden de prioridad (mayor primero).
        </p>

        {showNewRule && (
          <div className="settings-card rule-form">
            <h3>Nueva Regla</h3>
            <div className="field-row">
              <div className="field-group">
                <label>Nombre</label>
                <input value={ruleForm.name} onChange={e => setRuleForm({...ruleForm, name: e.target.value})}
                  placeholder="Ej: VIP Clientes" />
              </div>
              <div className="field-group" style={{ maxWidth: 120 }}>
                <label>Prioridad</label>
                <input type="number" value={ruleForm.priority}
                  onChange={e => setRuleForm({...ruleForm, priority: +e.target.value})} />
              </div>
            </div>

            <div className="rule-section-label">SI (todas se deben cumplir):</div>
            {ruleForm.conditions.map((cond, i) => (
              <div key={i} className="condition-row">
                <select value={cond.field} onChange={e => updateCondition(i, 'field', e.target.value)}>
                  {FIELDS.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
                </select>
                <select value={cond.operator} onChange={e => updateCondition(i, 'operator', e.target.value)}>
                  {OPERATORS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
                {!['is_true','is_false'].includes(cond.operator) && (
                  <input placeholder="valor" value={cond.value}
                    onChange={e => updateCondition(i, 'value', e.target.value)} />
                )}
                <button className="remove-btn" onClick={() => removeCondition(i)}>✕</button>
              </div>
            ))}
            <button className="add-condition-btn" onClick={addCondition}>+ Condición</button>

            <div className="rule-section-label">ENTONCES:</div>
            {ruleForm.actions.map((act, i) => (
              <div key={i} className="condition-row">
                <select value={act.type} onChange={e => updateAction(i, 'type', e.target.value)}>
                  {ACTIONS_TYPES.map(a => <option key={a.value} value={a.value}>{a.label}</option>)}
                </select>
                {ACTIONS_TYPES.find(a => a.value === act.type)?.hasValue && (
                  <input placeholder="valor" value={act.value || ''}
                    onChange={e => updateAction(i, 'value', e.target.value)} />
                )}
                <button className="remove-btn" onClick={() => removeAction(i)}>✕</button>
              </div>
            ))}
            <button className="add-condition-btn" onClick={addAction}>+ Acción</button>

            <div className="rule-form-actions">
              <button className="btn-secondary" onClick={() => setShowNewRule(false)}>Cancelar</button>
              <button className="btn-primary" onClick={handleSaveRule}
                disabled={!ruleForm.name || !ruleForm.conditions.length || !ruleForm.actions.length}>
                Guardar Regla
              </button>
            </div>
          </div>
        )}

        <div className="rules-list">
          {rules.map(rule => (
            <div key={rule.id} className="rule-card">
              <div className="rule-card-header">
                <div>
                  <div className="rule-name">{rule.name}</div>
                  {rule.description && <div className="rule-desc">{rule.description}</div>}
                </div>
                <div className="rule-card-actions">
                  <span className="rule-priority">P{rule.priority}</span>
                  <button className="btn-test" onClick={() => handleTestRule(rule.id)}>Testear</button>
                  <button className="btn-danger-sm" onClick={() => deleteRule(rule.id)}>✕</button>
                </div>
              </div>
              <div className="rule-conditions">
                <span className="rule-if">SI</span>
                {rule.conditions.map((c, i) => (
                  <span key={i} className="rule-cond">
                    {FIELDS.find(f => f.value === c.field)?.label} {c.operator} "{c.value}"
                  </span>
                ))}
              </div>
              <div className="rule-actions-list">
                <span className="rule-then">ENTONCES</span>
                {rule.actions.map((a, i) => (
                  <span key={i} className="rule-action">
                    {ACTIONS_TYPES.find(at => at.value === a.type)?.label}
                    {a.value ? ` → ${a.value}` : ''}
                  </span>
                ))}
              </div>
              {testResults?.ruleId === rule.id && (
                <div className="test-results">
                  Coincide con {testResults.count} emails en los últimos 50 analizados
                  {testResults.matches.slice(0, 3).map(m => (
                    <div key={m.id} className="test-match">• {m.subject}</div>
                  ))}
                </div>
              )}
            </div>
          ))}
          {rules.length === 0 && (
            <div className="empty-rules">No hay reglas configuradas. Crea una para automatizar tu bandeja.</div>
          )}
        </div>
      </div>

      <div className="settings-section">
        <h2 className="settings-title">📊 Exportar Datos</h2>
        <div className="settings-card">
          <div className="export-row">
            <div>
              <div className="setting-label">Exportar emails clasificados</div>
              <div className="setting-desc">Descarga todos tus emails en formato CSV</div>
            </div>
            <a href="/api/export/csv" download className="btn-secondary">
              ⬇ Descargar CSV
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}

export { Settings as default }
