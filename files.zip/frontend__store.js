// src/store/index.js — Estado global con Zustand
import { create } from 'zustand'
import { devtools } from 'zustand/middleware'
import { api } from '../services/api'

export const useStore = create(devtools((set, get) => ({
  // ─── ACCOUNTS ───────────────────────────────────────────────
  accounts: [],
  activeAccountId: null,

  fetchAccounts: async () => {
    try {
      const accounts = await api.get('/accounts')
      set({ accounts })
      if (accounts.length > 0 && !get().activeAccountId) {
        set({ activeAccountId: accounts[0].id })
      }
    } catch (e) { console.error(e) }
  },

  setActiveAccount: (id) => {
    set({ activeAccountId: id, selectedEmail: null })
    get().fetchEmails()
    get().fetchStats()
  },

  // ─── EMAILS ─────────────────────────────────────────────────
  emails: [],
  emailsTotal: 0,
  emailsLoading: false,
  selectedEmail: null,
  emailFilters: { sort: 'date_desc' },
  emailOffset: 0,

  fetchEmails: async (reset = true) => {
    set({ emailsLoading: true })
    if (reset) set({ emailOffset: 0 })
    const { activeAccountId, emailFilters, emailOffset } = get()
    try {
      const params = {
        ...emailFilters,
        ...(activeAccountId ? { account_id: activeAccountId } : {}),
        limit: 50,
        offset: reset ? 0 : emailOffset,
      }
      const emails = await api.get('/emails', params)
      set(state => ({
        emails: reset ? emails : [...state.emails, ...emails],
        emailsLoading: false,
        emailOffset: (reset ? 0 : state.emailOffset) + emails.length
      }))
    } catch (e) {
      set({ emailsLoading: false })
    }
  },

  setEmailFilters: (filters) => {
    set({ emailFilters: filters, selectedEmail: null })
    get().fetchEmails()
  },

  selectEmail: async (email) => {
    set({ selectedEmail: email })
    if (email && !email.is_read) {
      try {
        await api.patch(`/emails/${email.id}`, { is_read: true })
        set(state => ({
          emails: state.emails.map(e => e.id === email.id ? { ...e, is_read: true } : e),
          selectedEmail: { ...email, is_read: true }
        }))
      } catch (e) { console.error(e) }
    }
  },

  updateEmail: async (emailId, updates) => {
    try {
      await api.patch(`/emails/${emailId}`, updates)
      set(state => ({
        emails: state.emails.map(e => e.id === emailId ? { ...e, ...updates } : e),
        selectedEmail: state.selectedEmail?.id === emailId
          ? { ...state.selectedEmail, ...updates }
          : state.selectedEmail
      }))
    } catch (e) { console.error(e) }
  },

  reclassifyEmail: async (emailId) => {
    try {
      const result = await api.post(`/emails/${emailId}/reclassify`, {})
      const clf = result.classification
      const updates = {
        category: clf.category,
        priority_label: clf.priority_label,
        priority_score: clf.priority_score,
        summary: clf.summary,
        requires_action: clf.requires_action,
      }
      set(state => ({
        emails: state.emails.map(e => e.id === emailId ? { ...e, ...updates } : e),
        selectedEmail: state.selectedEmail?.id === emailId
          ? { ...state.selectedEmail, ...updates }
          : state.selectedEmail
      }))
      return clf
    } catch (e) { console.error(e); return null }
  },

  bulkAction: async (emailIds, action, value) => {
    try {
      await api.post('/emails/bulk', { email_ids: emailIds, action, value })
      get().fetchEmails()
    } catch (e) { console.error(e) }
  },

  addRealtimeEmail: (emailData) => {
    set(state => ({ emails: [emailData, ...state.emails] }))
  },

  // ─── STATS ──────────────────────────────────────────────────
  stats: null,
  statsLoading: false,

  fetchStats: async () => {
    set({ statsLoading: true })
    const { activeAccountId } = get()
    try {
      const params = activeAccountId ? { account_id: activeAccountId } : {}
      const stats = await api.get('/stats', params)
      set({ stats, statsLoading: false })
    } catch (e) {
      set({ statsLoading: false })
    }
  },

  // ─── CONTACTS ───────────────────────────────────────────────
  contacts: [],
  selectedContact: null,
  contactsLoading: false,

  fetchContacts: async (search = null) => {
    set({ contactsLoading: true })
    try {
      const params = search ? { search } : {}
      const contacts = await api.get('/contacts', params)
      set({ contacts, contactsLoading: false })
    } catch (e) { set({ contactsLoading: false }) }
  },

  selectContact: async (contactId) => {
    try {
      const contact = await api.get(`/contacts/${contactId}`)
      set({ selectedContact: contact })
    } catch (e) { console.error(e) }
  },

  // ─── RULES ──────────────────────────────────────────────────
  rules: [],

  fetchRules: async () => {
    try {
      const rules = await api.get('/rules')
      set({ rules })
    } catch (e) { console.error(e) }
  },

  createRule: async (rule) => {
    try {
      await api.post('/rules', rule)
      get().fetchRules()
    } catch (e) { console.error(e) }
  },

  deleteRule: async (ruleId) => {
    try {
      await api.delete(`/rules/${ruleId}`)
      set(state => ({ rules: state.rules.filter(r => r.id !== ruleId) }))
    } catch (e) { console.error(e) }
  },

  // ─── UI ─────────────────────────────────────────────────────
  activePage: 'dashboard',
  setActivePage: (page) => set({ activePage: page, selectedEmail: null }),

  syncing: false,
  syncProgress: null,
  syncMessage: null,

  setSyncing: (val) => set({ syncing: val }),
  setSyncProgress: (progress, message) => set({ syncProgress: progress, syncMessage: message }),

  toasts: [],
  addToast: (message, type = 'info') => {
    const id = Date.now()
    set(state => ({ toasts: [...state.toasts, { id, message, type }] }))
    setTimeout(() => {
      set(state => ({ toasts: state.toasts.filter(t => t.id !== id) }))
    }, 4000)
  },

  commandOpen: false,
  setCommandOpen: (val) => set({ commandOpen: val }),

  theme: localStorage.getItem('theme') || 'dark',
  setTheme: (theme) => {
    localStorage.setItem('theme', theme)
    document.documentElement.setAttribute('data-theme', theme)
    set({ theme })
  },

  selectedEmailIds: new Set(),
  toggleEmailSelection: (id) => {
    set(state => {
      const next = new Set(state.selectedEmailIds)
      next.has(id) ? next.delete(id) : next.add(id)
      return { selectedEmailIds: next }
    })
  },
  clearSelection: () => set({ selectedEmailIds: new Set() }),
  selectAll: () => {
    const { emails } = get()
    set({ selectedEmailIds: new Set(emails.map(e => e.id)) })
  },
}), { name: 'EmailClassifier' }))
