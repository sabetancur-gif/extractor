// ═══════════════════════════════════════════════════════════════
// GUÍA DE SEPARACIÓN DE COMPONENTES
// Archivo: SEPARAR_COMPONENTES.md (en formato JSX para referencia)
//
// Los siguientes archivos combinan múltiples componentes.
// Esta guía muestra exactamente dónde cortar cada uno.
// ═══════════════════════════════════════════════════════════════

// ───────────────────────────────────────────────────────────────
// ARCHIVO: frontend__components_core.jsx
// Contiene 4 componentes. Sepáralos así:
// ───────────────────────────────────────────────────────────────

// ── 1. frontend/src/components/Sidebar.jsx ──────────────────
//    Desde: import { useStore } from '../store'
//    Hasta: el primer } (cierre del export default)
//    Bloque marcado con: // ════ src/components/Sidebar.jsx ════

// ── 2. frontend/src/components/Topbar.jsx ───────────────────
//    Desde: import { useState } from 'react'   (segunda sección)
//    Hasta: el } de export function Topbar
//    Bloque marcado con: // ════ src/components/Topbar.jsx ════
//    IMPORTANTE: al inicio del archivo agrega:
//       import { useStore } from '../store'

// ── 3. frontend/src/components/Toast.jsx ────────────────────
//    Desde: export function Toast
//    Hasta: el export default function ToastContainer
//    Bloque marcado con: // ════ src/components/Toast.jsx ════
//    IMPORTANTE: al inicio agrega:
//       import { useStore } from '../store'

// ── 4. frontend/src/components/CommandPalette.jsx ───────────
//    Desde: import { useState, useEffect, useRef } from 'react'
//    Hasta: el final del archivo
//    Bloque marcado con: // ════ src/components/CommandPalette.jsx ════
//    IMPORTANTE: al inicio agrega:
//       import { useStore } from '../store'

// ───────────────────────────────────────────────────────────────
// ARCHIVO: frontend__Analytics_Settings.jsx
// Contiene 2 páginas. Sepáralos así:
// ───────────────────────────────────────────────────────────────

// ── 1. frontend/src/pages/Analytics.jsx ─────────────────────
//    Desde: // src/pages/Analytics.jsx  (inicio del archivo)
//    Hasta: el export default function Analytics (con su cierre)
//    El archivo termina antes del comentario:
//       // ═══ src/pages/Settings.jsx ═══

// ── 2. frontend/src/pages/Settings.jsx ──────────────────────
//    Desde: // src/pages/Settings.jsx
//    Hasta: el final del archivo
//    IMPORTANTE: al inicio agrega:
//       import { useState } from 'react'
//       import { useStore } from '../store'
//       import { api } from '../services/api'

// ───────────────────────────────────────────────────────────────
// ARCHIVO: frontend__package_vite_main.txt
// Contiene 4 archivos de configuración. Sepáralos así:
// ───────────────────────────────────────────────────────────────

// ── 1. frontend/package.json ────────────────────────────────
//    El bloque JSON que empieza con { "name": "mailai-pro" ...}

// ── 2. frontend/vite.config.js ──────────────────────────────
//    El bloque que empieza con: import { defineConfig } from 'vite'

// ── 3. frontend/src/main.jsx ────────────────────────────────
//    El bloque que empieza con: import React from 'react'

// ── 4. frontend/index.html ──────────────────────────────────
//    El bloque que empieza con: <!DOCTYPE html>

// ───────────────────────────────────────────────────────────────
// VERSIÓN RÁPIDA: Copiar y pegar contenidos listos
// ───────────────────────────────────────────────────────────────

// frontend/src/components/Sidebar.jsx — COMPLETO
// =================================================
import { useStore } from '../store'

const NAV = [
  { id: 'dashboard', icon: '▦', label: 'Dashboard' },
  { id: 'inbox',     icon: '✉', label: 'Bandeja', badgeKey: 'action' },
  { id: 'analytics', icon: '↗', label: 'Analytics' },
  { id: 'contacts',  icon: '◉', label: 'Contactos' },
  { id: 'settings',  icon: '⚙', label: 'Ajustes' },
]

export default function Sidebar() {
  const { activePage, setActivePage, stats, accounts,
          activeAccountId, setActiveAccount, syncing } = useStore()

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="logo">
          <div className="logo-mark">M</div>
          <div>
            <div className="logo-name">MailAI</div>
            <div className="logo-version">Pro v2.0</div>
          </div>
        </div>
      </div>

      {accounts.length > 1 && (
        <div className="account-switcher">
          {accounts.map(acc => (
            <button
              key={acc.id}
              className={`account-pill ${acc.id === activeAccountId ? 'active' : ''}`}
              onClick={() => setActiveAccount(acc.id)}
              title={acc.email}
            >
              <span className="account-avatar">
                {(acc.display_name || acc.email)[0].toUpperCase()}
              </span>
            </button>
          ))}
        </div>
      )}

      <nav className="nav">
        {NAV.map(item => {
          const badge = item.badgeKey === 'action' ? stats?.requires_action : null
          return (
            <button
              key={item.id}
              className={`nav-btn ${activePage === item.id ? 'active' : ''}`}
              onClick={() => setActivePage(item.id)}
            >
              <span className="nav-icon">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
              {badge > 0 && (
                <span className="nav-badge">{badge > 99 ? '99+' : badge}</span>
              )}
            </button>
          )
        })}
      </nav>

      <div className="sidebar-footer">
        <div className="sync-status">
          <div className={`status-dot ${syncing ? 'syncing' : 'idle'}`} />
          <span className="status-text">
            {syncing ? 'Sincronizando...' : 'En tiempo real'}
          </span>
        </div>
        <div className="kbd-hint">
          <kbd>⌘K</kbd> Command palette
        </div>
      </div>
    </aside>
  )
}

// frontend/src/components/Toast.jsx — COMPLETO
// =================================================
import { useStore } from '../store'

export function Toast({ message, type }) {
  const icons = { success: '✓', error: '✕', info: 'ℹ', warning: '⚠' }
  return (
    <div className={`toast toast-${type}`}>
      <span className="toast-icon">{icons[type] || 'ℹ'}</span>
      <span className="toast-msg">{message}</span>
    </div>
  )
}

export default function ToastContainer() {
  const { toasts } = useStore()
  return (
    <div className="toast-container">
      {toasts.map(t => <Toast key={t.id} {...t} />)}
    </div>
  )
}
