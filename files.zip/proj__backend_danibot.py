"""
=============================================================
backend/danibot.py
DaniBot — IA Conversacional sobre tu Bandeja de Entrada
=============================================================
DaniBot permite hacer preguntas en lenguaje natural sobre
los emails clasificados. Usa Ollama para:
  1. Interpretar la pregunta del usuario
  2. Traducirla a una consulta sobre la DB
  3. Responder con datos reales en lenguaje natural

Ejemplos de preguntas:
  "¿Cuáles son mis emails más urgentes hoy?"
  "¿Cómo está la relación con Carlos Gómez?"
  "¿Cuántos emails negativos recibí esta semana?"
  "Resúmeme los emails de finanzas"
  "¿Quién me escribe más y con qué tono?"
=============================================================
"""

import json
import re
import sqlite3
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
import httpx


# ─────────────────────────────────────────────────────────────
# Prompt de sistema de DaniBot
# ─────────────────────────────────────────────────────────────

DANIBOT_SYSTEM = """Eres DaniBot, el asistente inteligente de MailAI Panel.
Analizas emails corporativos clasificados y respondes preguntas sobre el inbox del usuario.

PERSONALIDAD:
- Profesional pero cercano. Directo y conciso.
- Usas datos reales de la base de datos para responder.
- Si no tienes datos suficientes, lo dices claramente.
- Respondes en el mismo idioma en que te preguntan (español por defecto).

FORMATO DE RESPUESTA:
- Responde siempre con JSON válido con esta estructura exacta:
  {"answer": "tu respuesta en texto", "data_type": "none|emails|stats|sender", "insights": ["insight1", "insight2"]}
- "answer": texto claro y conciso, máximo 3 párrafos
- "data_type": qué tipo de datos adjuntas (none = solo texto)
- "insights": lista de 0-3 observaciones adicionales relevantes

NUNCA inventes datos. Solo usa los que te proporciono en el contexto."""


class DaniBot:
    """
    Motor conversacional de DaniBot.
    Recibe una pregunta, consulta la DB, llama a Ollama y devuelve la respuesta.
    """

    def __init__(self, db_path: str, ollama_url: str, model: str, timeout: float = 120.0):
        self.db_path    = db_path
        self.ollama_url = ollama_url.rstrip("/")
        self.model      = model
        self.timeout    = timeout
        # Historial de la conversación (máximo 10 turnos para no saturar el contexto)
        self.history: List[Dict] = []
        self.max_history = 10

    # ──────────────────────────────────────────────────────────
    # MÉTODO PRINCIPAL
    # ──────────────────────────────────────────────────────────

    def chat(self, user_message: str, account_id: Optional[int] = None) -> Dict:
        """
        Procesa un mensaje del usuario y devuelve la respuesta de DaniBot.

        Args:
            user_message: Pregunta o comentario del usuario
            account_id:   Filtrar por cuenta específica (None = todas)

        Returns:
            Dict con: answer, data_type, insights, context_used
        """
        # 1. Obtener contexto de datos relevante para la pregunta
        context = self._build_context(user_message, account_id)

        # 2. Construir los mensajes para Ollama (con historial)
        messages = self._build_messages(user_message, context)

        # 3. Llamar a Ollama
        try:
            raw_response = self._call_ollama(messages)
            result       = self._parse_response(raw_response)
        except Exception as e:
            result = {
                "answer":    f"Lo siento, tuve un problema procesando tu pregunta: {str(e)}",
                "data_type": "none",
                "insights":  [],
            }

        # 4. Actualizar historial de conversación
        self._update_history(user_message, result["answer"])

        result["context_used"] = context.get("summary", "")
        return result

    def reset_history(self):
        """Reinicia el historial de conversación."""
        self.history = []

    # ──────────────────────────────────────────────────────────
    # CONSTRUCCIÓN DEL CONTEXTO (consultas a la DB)
    # ──────────────────────────────────────────────────────────

    def _build_context(self, question: str, account_id: Optional[int]) -> Dict:
        """
        Detecta qué tipo de información necesita la pregunta
        y consulta la DB para obtenerla.
        """
        q_lower = question.lower()

        # Detectar intención de la pregunta
        intents = {
            "urgency":    any(w in q_lower for w in ["urgent", "urgente", "crítico", "critico", "inmediato", "hoy"]),
            "sentiment":  any(w in q_lower for w in ["sentimiento", "tono", "negativo", "positivo", "neutral"]),
            "sender":     any(w in q_lower for w in ["quién", "quien", "remitente", "contacto", "escribe", "envía"]),
            "vip":        any(w in q_lower for w in ["vip", "importante", "prioritario"]),
            "stats":      any(w in q_lower for w in ["cuántos", "cuantos", "total", "resumen", "semana", "mes"]),
            "actions":    any(w in q_lower for w in ["acción", "accion", "pendiente", "hacer", "responder"]),
            "category":   any(w in q_lower for w in ["trabajo", "finanzas", "legal", "spam", "marketing"]),
            "trend":      any(w in q_lower for w in ["tendencia", "evolución", "evolucion", "cambiado", "peor", "mejor"]),
        }

        context = {}
        acc_filter = f"AND account_id={account_id}" if account_id else ""

        with sqlite3.connect(self.db_path) as db:
            db.row_factory = sqlite3.Row

            # Estadísticas generales siempre útiles
            stats_row = db.execute(f"""
                SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN importance_label='critica' THEN 1 ELSE 0 END) as critical,
                    SUM(CASE WHEN urgency_level IN ('critica','alta') THEN 1 ELSE 0 END) as urgent,
                    SUM(CASE WHEN sender_is_vip=1 THEN 1 ELSE 0 END) as vip_count,
                    AVG(importance_score) as avg_importance,
                    SUM(CASE WHEN sentiment_label='negativo' THEN 1 ELSE 0 END) as negative,
                    SUM(CASE WHEN sentiment_label='positivo' THEN 1 ELSE 0 END) as positive
                FROM emails WHERE 1=1 {acc_filter}
            """).fetchone()
            context["global_stats"] = dict(stats_row) if stats_row else {}

            # Emails urgentes / críticos
            if intents["urgency"] or intents["actions"]:
                urgent = db.execute(f"""
                    SELECT sender_name, subject, urgency_level, urgency_deadline,
                           urgency_actions, importance_score, date
                    FROM emails
                    WHERE urgency_level IN ('critica','alta') {acc_filter}
                    ORDER BY importance_score DESC LIMIT 8
                """).fetchall()
                context["urgent_emails"] = [dict(r) for r in urgent]

            # Top senders
            if intents["sender"] or intents["vip"] or intents["stats"]:
                senders = db.execute(f"""
                    SELECT sender_name, sender_email, sender_profile, sender_trust,
                           sender_is_vip, COUNT(*) as total,
                           AVG(importance_score) as avg_imp,
                           SUM(CASE WHEN sentiment_label='negativo' THEN 1 ELSE 0 END) as neg_count
                    FROM emails WHERE 1=1 {acc_filter}
                    GROUP BY sender_email ORDER BY total DESC LIMIT 8
                """).fetchall()
                context["top_senders"] = [dict(r) for r in senders]

            # Distribución por sentimiento
            if intents["sentiment"] or intents["trend"]:
                sent_dist = db.execute(f"""
                    SELECT sentiment_label, sentiment_tone, COUNT(*) as c
                    FROM emails WHERE 1=1 {acc_filter}
                    GROUP BY sentiment_label, sentiment_tone
                    ORDER BY c DESC
                """).fetchall()
                context["sentiment_distribution"] = [dict(r) for r in sent_dist]

            # Emails pendientes de acción
            if intents["actions"]:
                actions_raw = db.execute(f"""
                    SELECT sender_name, subject, urgency_actions, urgency_deadline
                    FROM emails
                    WHERE urgency_level != 'ninguna'
                    AND urgency_actions != '[]' {acc_filter}
                    ORDER BY importance_score DESC LIMIT 10
                """).fetchall()
                context["pending_actions"] = [dict(r) for r in actions_raw]

            # Tendencia de los últimos 7 días
            if intents["trend"] or intents["stats"]:
                trend = db.execute(f"""
                    SELECT DATE(date) as day,
                           COUNT(*) as c,
                           AVG(importance_score) as avg_imp,
                           SUM(CASE WHEN sentiment_label='negativo' THEN 1 ELSE 0 END) as neg
                    FROM emails
                    WHERE date >= DATE('now', '-7 days') {acc_filter}
                    GROUP BY DATE(date) ORDER BY day
                """).fetchall()
                context["weekly_trend"] = [dict(r) for r in trend]

            # Buscar remitente específico si se menciona
            words = question.split()
            for word in words:
                if len(word) > 4 and word[0].isupper():
                    sender_info = db.execute(f"""
                        SELECT sender_name, sender_email, sender_profile, sender_trust,
                               sender_is_vip, COUNT(*) as total,
                               AVG(importance_score) as avg_imp,
                               GROUP_CONCAT(DISTINCT sentiment_label) as sentiments
                        FROM emails
                        WHERE (sender_name LIKE ? OR sender_email LIKE ?) {acc_filter}
                        GROUP BY sender_email LIMIT 1
                    """, (f"%{word}%", f"%{word}%")).fetchone()
                    if sender_info:
                        context["mentioned_sender"] = dict(sender_info)
                        break

        context["summary"] = f"Total: {context['global_stats'].get('total',0)} emails, " \
                              f"{context['global_stats'].get('critical',0)} críticos, " \
                              f"{context['global_stats'].get('vip_count',0)} VIPs"
        return context

    # ──────────────────────────────────────────────────────────
    # CONSTRUCCIÓN DE MENSAJES PARA OLLAMA
    # ──────────────────────────────────────────────────────────

    def _build_messages(self, user_message: str, context: Dict) -> List[Dict]:
        """Construye la lista de mensajes con historial y contexto."""
        messages = [{"role": "system", "content": DANIBOT_SYSTEM}]

        # Agregar contexto de datos como mensaje del sistema
        context_msg = f"""DATOS ACTUALES DEL INBOX:

Estadísticas generales: {json.dumps(context.get('global_stats', {}), ensure_ascii=False)}

{f"Emails urgentes/críticos: {json.dumps(context.get('urgent_emails', []), ensure_ascii=False)}" if 'urgent_emails' in context else ""}
{f"Top remitentes: {json.dumps(context.get('top_senders', []), ensure_ascii=False)}" if 'top_senders' in context else ""}
{f"Distribución de sentimiento: {json.dumps(context.get('sentiment_distribution', []), ensure_ascii=False)}" if 'sentiment_distribution' in context else ""}
{f"Acciones pendientes: {json.dumps(context.get('pending_actions', []), ensure_ascii=False)}" if 'pending_actions' in context else ""}
{f"Tendencia 7 días: {json.dumps(context.get('weekly_trend', []), ensure_ascii=False)}" if 'weekly_trend' in context else ""}
{f"Remitente mencionado: {json.dumps(context.get('mentioned_sender', {}), ensure_ascii=False)}" if 'mentioned_sender' in context else ""}

Fecha y hora actual: {datetime.now().strftime('%Y-%m-%d %H:%M')}"""

        messages.append({"role": "system", "content": context_msg})

        # Agregar historial de conversación (últimos N turnos)
        for turn in self.history[-self.max_history:]:
            messages.append({"role": "user",      "content": turn["user"]})
            messages.append({"role": "assistant",  "content": turn["assistant"]})

        # Mensaje actual del usuario
        messages.append({"role": "user", "content": user_message})
        return messages

    # ──────────────────────────────────────────────────────────
    # LLAMADA A OLLAMA
    # ──────────────────────────────────────────────────────────

    def _call_ollama(self, messages: List[Dict]) -> str:
        """Llama a Ollama con los mensajes y devuelve el texto de respuesta."""
        payload = {
            "model":   self.model,
            "stream":  False,
            "format":  "json",
            "options": {
                "temperature":   0.4,   # Un poco más alto que el clasificador para ser más conversacional
                "num_predict":   800,
                "top_p":         0.9,
            },
            "messages": messages,
        }
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(f"{self.ollama_url}/api/chat", json=payload)
            resp.raise_for_status()
            return resp.json().get("message", {}).get("content", "")

    # ──────────────────────────────────────────────────────────
    # PARSEO DE RESPUESTA
    # ──────────────────────────────────────────────────────────

    def _parse_response(self, raw: str) -> Dict:
        """Parsea el JSON de respuesta de Ollama."""
        try:
            text  = raw.strip()
            text  = re.sub(r'^```(?:json)?\s*', '', text)
            text  = re.sub(r'\s*```$', '', text)
            match = re.search(r'\{.*\}', text, re.DOTALL)
            if match:
                data = json.loads(match.group())
                return {
                    "answer":    str(data.get("answer", "No pude generar una respuesta."))[:1000],
                    "data_type": str(data.get("data_type", "none")),
                    "insights":  [str(i) for i in data.get("insights", [])][:3],
                }
        except Exception:
            pass
        # Si falla el parseo, devolver el texto crudo como respuesta
        return {"answer": raw[:800] if raw else "Sin respuesta", "data_type": "none", "insights": []}

    # ──────────────────────────────────────────────────────────
    # HISTORIAL
    # ──────────────────────────────────────────────────────────

    def _update_history(self, user_msg: str, assistant_msg: str):
        """Agrega el turno al historial, manteniendo el límite."""
        self.history.append({"user": user_msg, "assistant": assistant_msg})
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history:]

    # ──────────────────────────────────────────────────────────
    # SUGERENCIAS DE PREGUNTAS
    # ──────────────────────────────────────────────────────────

    @staticmethod
    def get_suggestions() -> List[str]:
        """Devuelve sugerencias de preguntas para mostrar en el chat."""
        return [
            "¿Cuáles son mis emails más urgentes hoy?",
            "¿Cómo está la relación con mis principales clientes?",
            "¿Cuántos emails negativos recibí esta semana?",
            "¿Quién me escribe más y con qué tono?",
            "¿Qué acciones tengo pendientes?",
            "Resúmeme los emails de finanzas",
            "¿Hay algún patrón inusual en mi bandeja?",
            "¿Cuáles son mis contactos VIP más activos?",
        ]
