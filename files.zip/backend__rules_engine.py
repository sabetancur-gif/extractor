"""
rules_engine.py — Motor de reglas automáticas
Aplica reglas definidas por el usuario sobre emails clasificados
"""
from typing import Dict, List
import re


class RulesEngine:
    """
    Evalúa reglas del tipo IF [condiciones] THEN [acciones]
    
    Condiciones soportadas:
      - sender_is / sender_contains / sender_domain_is
      - subject_contains / subject_starts_with
      - category_is / priority_is / priority_score_gte / priority_score_lte
      - sentiment_is / tone_is / language_is
      - spam_score_gte
      - has_attachments
      - body_contains
      - requires_action_is
      - entity_person_is / entity_company_is
    
    Acciones soportadas:
      - set_category / set_priority / set_starred / set_archived
      - add_tag / send_webhook / mark_read / mark_deleted
    """

    def evaluate(self, email: Dict, classification: Dict, rules: List[Dict]) -> List[Dict]:
        """
        Evalúa todas las reglas activas contra un email.
        Retorna lista de acciones a aplicar.
        """
        actions_to_apply = []
        
        for rule in sorted(rules, key=lambda r: r.get('priority', 0), reverse=True):
            if self._matches(email, classification, rule.get('conditions', [])):
                actions_to_apply.extend(rule.get('actions', []))
                
        return actions_to_apply

    def _matches(self, email: Dict, clf: Dict, conditions: List[Dict]) -> bool:
        """Todas las condiciones deben cumplirse (AND logic)"""
        if not conditions:
            return False
        return all(self._check(email, clf, c) for c in conditions)

    def _check(self, e: Dict, clf: Dict, condition: Dict) -> bool:
        field = condition.get('field', '')
        op = condition.get('operator', 'equals')
        value = condition.get('value', '')

        # Helpers
        def contains(text, val): return val.lower() in (text or '').lower()
        def equals(text, val): return (text or '').lower() == val.lower()
        def regex(text, val):
            try: return bool(re.search(val, text or '', re.IGNORECASE))
            except: return False

        sender = e.get('sender_email', '')
        sender_name = e.get('sender_name', '')
        subject = e.get('subject', '')
        body = e.get('body', '')
        entities = clf.get('entities', {})

        ops = {
            'equals': equals,
            'contains': contains,
            'starts_with': lambda t, v: (t or '').lower().startswith(v.lower()),
            'ends_with': lambda t, v: (t or '').lower().endswith(v.lower()),
            'regex': regex,
            'gte': lambda t, v: float(t or 0) >= float(v),
            'lte': lambda t, v: float(t or 0) <= float(v),
            'gt': lambda t, v: float(t or 0) > float(v),
            'is_true': lambda t, v: bool(t),
            'is_false': lambda t, v: not bool(t),
        }
        fn = ops.get(op, equals)

        field_map = {
            'sender_email': lambda: fn(sender, value),
            'sender_name': lambda: fn(sender_name, value),
            'sender_domain': lambda: fn(sender.split('@')[-1] if '@' in sender else '', value),
            'subject': lambda: fn(subject, value),
            'body': lambda: fn(body, value),
            'category': lambda: fn(clf.get('category', ''), value),
            'subcategory': lambda: fn(clf.get('subcategory', ''), value),
            'priority_label': lambda: fn(clf.get('priority_label', ''), value),
            'priority_score': lambda: fn(clf.get('priority_score', 50), value),
            'sentiment': lambda: fn(clf.get('sentiment', {}).get('label', ''), value),
            'tone': lambda: fn(clf.get('sentiment', {}).get('tone', ''), value),
            'urgency_level': lambda: fn(clf.get('urgency', {}).get('level', ''), value),
            'language': lambda: fn(clf.get('language', ''), value),
            'spam_score': lambda: fn(clf.get('spam_score', 0), value),
            'has_attachments': lambda: fn(e.get('has_attachments', False), value),
            'requires_action': lambda: fn(clf.get('requires_action', False), value),
            'entity_person': lambda: any(fn(p, value) for p in entities.get('people', [])),
            'entity_company': lambda: any(fn(c, value) for c in entities.get('companies', [])),
            'thread_type': lambda: fn(clf.get('thread_type', ''), value),
        }

        handler = field_map.get(field)
        if not handler:
            return False
        try:
            return handler()
        except (ValueError, TypeError):
            return False

    def apply_action(self, action: Dict) -> Dict:
        """
        Convierte una acción de regla en una actualización de DB.
        Retorna dict con los campos a actualizar.
        """
        act_type = action.get('type', '')
        act_value = action.get('value')

        mapping = {
            'set_category': {'user_category': act_value},
            'set_priority': {'priority_label': act_value},
            'set_starred': {'is_starred': True},
            'set_archived': {'is_archived': True},
            'mark_read': {'is_read': True},
            'mark_deleted': {'is_deleted': True},
        }

        return mapping.get(act_type, {})


# Reglas de ejemplo que se pueden cargar en la DB
DEFAULT_RULES = [
    {
        "name": "Spam a papelera",
        "description": "Mover emails con spam_score > 0.85 a eliminados",
        "priority": 100,
        "conditions": [{"field": "spam_score", "operator": "gte", "value": "0.85"}],
        "actions": [{"type": "mark_deleted"}, {"type": "mark_read"}]
    },
    {
        "name": "VIP - Destacar emails urgentes",
        "description": "Destacar emails con prioridad urgente",
        "priority": 90,
        "conditions": [{"field": "priority_label", "operator": "equals", "value": "urgente"}],
        "actions": [{"type": "set_starred"}]
    },
    {
        "name": "Newsletters a archivo",
        "description": "Archivar newsletters automáticamente",
        "priority": 50,
        "conditions": [{"field": "category", "operator": "equals", "value": "ventas_marketing"}],
        "actions": [{"type": "set_archived"}, {"type": "mark_read"}]
    },
    {
        "name": "Correos DIAN urgentes",
        "description": "Destacar emails gubernamentales/DIAN",
        "priority": 95,
        "conditions": [
            {"field": "sender_domain", "operator": "contains", "value": "dian.gov.co"},
        ],
        "actions": [{"type": "set_starred"}, {"type": "set_category", "value": "legal"}]
    },
    {
        "name": "Redes sociales auto-read",
        "description": "Marcar como leídas notificaciones de redes",
        "priority": 40,
        "conditions": [{"field": "category", "operator": "equals", "value": "redes_sociales"}],
        "actions": [{"type": "mark_read"}]
    },
]
