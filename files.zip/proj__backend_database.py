"""
=============================================================
backend/database.py — Base de datos SQLite completa
=============================================================
Schema de 4 dimensiones + métodos para Kanban, acciones,
contactos y queries del panel.
=============================================================
"""
import sqlite3, json
from datetime import datetime
from typing import List, Dict, Optional


class PanelDatabase:
    def __init__(self, db_path: str = "panel.db"):
        self.db_path = db_path

    def conn(self) -> sqlite3.Connection:
        c = sqlite3.connect(self.db_path, timeout=30)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        return c

    def initialize(self):
        with self.conn() as db:
            db.executescript("""
CREATE TABLE IF NOT EXISTS accounts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    email        TEXT NOT NULL UNIQUE,
    total_emails INTEGER DEFAULT 0,
    last_sync    TEXT,
    created_at   TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS emails (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id      TEXT UNIQUE NOT NULL,
    thread_key      TEXT,
    account_id      INTEGER REFERENCES accounts(id),
    account_name    TEXT,
    sender_name     TEXT, sender_email TEXT,
    to_recipients   TEXT, subject TEXT, body TEXT,
    date            TEXT, has_attachments BOOLEAN DEFAULT 0,
    outlook_folder  TEXT DEFAULT 'INBOX', is_read BOOLEAN DEFAULT 0,
    importance_score  INTEGER DEFAULT 50,
    importance_label  TEXT DEFAULT 'media',
    importance_reason TEXT, importance_color TEXT DEFAULT '#eab308',
    sentiment_label TEXT DEFAULT 'neutral',
    sentiment_score REAL DEFAULT 0.0,
    sentiment_tone  TEXT DEFAULT 'neutro',
    sentiment_emoji TEXT DEFAULT '😐',
    sender_profile  TEXT DEFAULT 'desconocido',
    sender_trust    INTEGER DEFAULT 50,
    sender_is_vip   BOOLEAN DEFAULT 0,
    sender_company  TEXT, sender_relation TEXT,
    urgency_level    TEXT DEFAULT 'ninguna',
    urgency_deadline TEXT,
    urgency_actions  TEXT DEFAULT '[]',
    urgency_reply    TEXT, urgency_color TEXT DEFAULT '#6b7280',
    summary TEXT, category TEXT DEFAULT 'otro',
    language TEXT DEFAULT 'es', key_topics TEXT DEFAULT '[]',
    spam_score REAL DEFAULT 0.0, confidence REAL DEFAULT 0.0,
    actions_done TEXT DEFAULT '[]',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_emails_account    ON emails(account_id);
CREATE INDEX IF NOT EXISTS idx_emails_importance ON emails(importance_score DESC);
CREATE INDEX IF NOT EXISTS idx_emails_urgency    ON emails(urgency_level);
CREATE INDEX IF NOT EXISTS idx_emails_sender     ON emails(sender_email);
CREATE INDEX IF NOT EXISTS idx_emails_date       ON emails(date DESC);
CREATE INDEX IF NOT EXISTS idx_emails_vip        ON emails(sender_is_vip);
CREATE INDEX IF NOT EXISTS idx_emails_sentiment  ON emails(sentiment_label);
""")
        print("✅ Base de datos inicializada")

    def save_account(self, name: str, email: str) -> int:
        with self.conn() as db:
            db.execute("INSERT OR IGNORE INTO accounts (name, email) VALUES (?,?)", (name, email))
            row = db.execute("SELECT id FROM accounts WHERE email=?", (email,)).fetchone()
            return row['id'] if row else 1

    def get_accounts(self) -> List[Dict]:
        with self.conn() as db:
            rows = db.execute("""
                SELECT a.*, COUNT(e.id) as email_count
                FROM accounts a LEFT JOIN emails e ON e.account_id=a.id
                GROUP BY a.id ORDER BY email_count DESC
            """).fetchall()
        return [dict(r) for r in rows]

    def email_exists(self, message_id: str) -> bool:
        with self.conn() as db:
            return db.execute("SELECT 1 FROM emails WHERE message_id=?", (message_id,)).fetchone() is not None

    def save_email(self, email_data: Dict, clf, account_id: int) -> int:
        with self.conn() as db:
            cur = db.execute("""
                INSERT OR REPLACE INTO emails (
                    message_id, thread_key, account_id, account_name,
                    sender_name, sender_email, to_recipients, subject, body,
                    date, has_attachments, outlook_folder, is_read,
                    importance_score, importance_label, importance_reason, importance_color,
                    sentiment_label, sentiment_score, sentiment_tone, sentiment_emoji,
                    sender_profile, sender_trust, sender_is_vip, sender_company, sender_relation,
                    urgency_level, urgency_deadline, urgency_actions, urgency_reply, urgency_color,
                    summary, category, language, key_topics, spam_score, confidence
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                email_data['message_id'], email_data.get('thread_key',''),
                account_id, email_data.get('account_name',''),
                email_data.get('sender_name',''), email_data.get('sender_email',''),
                email_data.get('to_recipients',''), email_data.get('subject',''),
                email_data.get('body',''), email_data.get('date',''),
                email_data.get('has_attachments',False), email_data.get('outlook_folder','INBOX'),
                email_data.get('is_read',False),
                clf.importance.score, clf.importance.label, clf.importance.reason, clf.importance.color,
                clf.sentiment.label, clf.sentiment.score, clf.sentiment.tone, clf.sentiment.emoji,
                clf.sender.profile, clf.sender.trust, clf.sender.is_vip, clf.sender.company, clf.sender.relation,
                clf.urgency.level, clf.urgency.deadline,
                json.dumps(clf.urgency.actions), clf.urgency.reply, clf.urgency.color,
                clf.summary, clf.category, clf.language,
                json.dumps(clf.key_topics), clf.spam_score, clf.confidence,
            ))
            return cur.lastrowid

    def get_email_by_id(self, email_id: int) -> Optional[Dict]:
        with self.conn() as db:
            row = db.execute("SELECT * FROM emails WHERE id=?", (email_id,)).fetchone()
        if row:
            d = dict(row)
            for f in ('urgency_actions','key_topics','actions_done'):
                try: d[f] = json.loads(d.get(f) or '[]')
                except: d[f] = []
            return d
        return None

    def get_emails(self, filters: Dict = None, limit: int = 100, offset: int = 0) -> List[Dict]:
        filters = filters or {}
        where, params = ["1=1"], []
        if filters.get('account_id'):
            where.append("account_id=?"); params.append(filters['account_id'])
        if filters.get('importance_label'):
            where.append("importance_label=?"); params.append(filters['importance_label'])
        if filters.get('sentiment_label'):
            where.append("sentiment_label=?"); params.append(filters['sentiment_label'])
        if filters.get('urgency_level'):
            where.append("urgency_level=?"); params.append(filters['urgency_level'])
        if filters.get('sender_profile'):
            where.append("sender_profile=?"); params.append(filters['sender_profile'])
        if filters.get('is_vip'):
            where.append("sender_is_vip=1")
        if filters.get('search'):
            s = f"%{filters['search']}%"
            where.append("(subject LIKE ? OR sender_name LIKE ? OR body LIKE ?)")
            params += [s, s, s]
        sort_map = {"importance":"importance_score DESC","date":"date DESC",
                    "urgency":"urgency_level DESC","trust":"sender_trust DESC"}
        sort = sort_map.get(filters.get('sort','date'), "date DESC")
        params += [limit, offset]
        with self.conn() as db:
            rows = db.execute(
                f"SELECT * FROM emails WHERE {' AND '.join(where)} ORDER BY {sort} LIMIT ? OFFSET ?",
                params).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            for f in ('urgency_actions','key_topics','actions_done'):
                try: d[f] = json.loads(d.get(f) or '[]')
                except: d[f] = []
            result.append(d)
        return result

    def update_email_urgency(self, email_id: int, new_urgency: str) -> bool:
        urgency_colors = {"critica":"#ef4444","alta":"#f97316","media":"#eab308","baja":"#22c55e","ninguna":"#6b7280"}
        with self.conn() as db:
            res = db.execute(
                "UPDATE emails SET urgency_level=?, urgency_color=? WHERE id=?",
                (new_urgency, urgency_colors.get(new_urgency,"#6b7280"), email_id))
            return res.rowcount > 0

    def mark_action_done(self, email_id: int, action_index: int) -> bool:
        email = self.get_email_by_id(email_id)
        if not email: return False
        done = email.get('actions_done', [])
        if action_index not in done:
            done.append(action_index)
        with self.conn() as db:
            db.execute("UPDATE emails SET actions_done=? WHERE id=?",
                       (json.dumps(done), email_id))
        return True

    def update_account_sync(self, account_id: int, total: int):
        with self.conn() as db:
            db.execute("UPDATE accounts SET last_sync=?, total_emails=total_emails+? WHERE id=?",
                       (datetime.now().isoformat(), total, account_id))

    def get_panel_stats(self, account_id: int = None) -> Dict:
        f = f"AND account_id={account_id}" if account_id else ""
        p = [account_id] if account_id else []
        with self.conn() as db:
            total      = db.execute(f"SELECT COUNT(*) FROM emails WHERE 1=1 {f}", p).fetchone()[0]
            vip_count  = db.execute(f"SELECT COUNT(*) FROM emails WHERE sender_is_vip=1 {f}", p).fetchone()[0]
            avg_imp    = db.execute(f"SELECT AVG(importance_score) FROM emails WHERE 1=1 {f}", p).fetchone()[0] or 0
            by_imp     = db.execute(f"SELECT importance_label, COUNT(*) c FROM emails WHERE 1=1 {f} GROUP BY importance_label", p).fetchall()
            by_sent    = db.execute(f"SELECT sentiment_label, COUNT(*) c FROM emails WHERE 1=1 {f} GROUP BY sentiment_label", p).fetchall()
            by_urg     = db.execute(f"SELECT urgency_level, COUNT(*) c FROM emails WHERE 1=1 {f} GROUP BY urgency_level", p).fetchall()
            by_prof    = db.execute(f"SELECT sender_profile, COUNT(*) c FROM emails WHERE 1=1 {f} GROUP BY sender_profile ORDER BY c DESC", p).fetchall()
            by_tone    = db.execute(f"SELECT sentiment_tone, COUNT(*) c FROM emails WHERE 1=1 {f} GROUP BY sentiment_tone ORDER BY c DESC LIMIT 6", p).fetchall()
            critical   = db.execute(f"SELECT id,sender_name,subject,importance_score,urgency_level,urgency_deadline,urgency_actions,sentiment_emoji FROM emails WHERE importance_label='critica' {f} ORDER BY importance_score DESC LIMIT 10", p).fetchall()
            top_s      = db.execute(f"SELECT sender_email,sender_name,sender_profile,sender_trust,sender_is_vip,COUNT(*) c,AVG(importance_score) avg_imp FROM emails WHERE 1=1 {f} GROUP BY sender_email ORDER BY c DESC LIMIT 10", p).fetchall()
            by_day     = db.execute(f"SELECT DATE(date) day,COUNT(*) c,AVG(importance_score) avg_imp FROM emails WHERE date>=DATE('now','-30 days') {f} GROUP BY DATE(date) ORDER BY day", p).fetchall()
            accs       = db.execute("SELECT a.name,a.email,COUNT(e.id) c FROM accounts a LEFT JOIN emails e ON e.account_id=a.id GROUP BY a.id").fetchall()
        return {
            "total": total, "vip_count": vip_count, "avg_importance": round(avg_imp, 1),
            "by_importance": [dict(r) for r in by_imp],
            "by_sentiment":  [dict(r) for r in by_sent],
            "by_urgency":    [dict(r) for r in by_urg],
            "by_profile":    [dict(r) for r in by_prof],
            "by_tone":       [dict(r) for r in by_tone],
            "critical_emails":[dict(r) for r in critical],
            "top_senders":   [dict(r) for r in top_s],
            "by_day":        [dict(r) for r in by_day],
            "accounts":      [dict(r) for r in accs],
        }
