// ============================================================
// src/services/api.ts — Cliente HTTP para el backend
// ============================================================
import type { Email, EmailFilters, PanelStats, HealthStatus,
              DaniBotResponse, WeeklyDigest, OutlookAccount } from '@/types';

const BASE = '/api';

async function request<T>(method: string, path: string, body?: unknown, params?: Record<string, unknown>): Promise<T> {
  let url = `${BASE}${path}`;
  if (params) {
    const q = new URLSearchParams(
      Object.entries(params)
        .filter(([, v]) => v !== null && v !== undefined)
        .map(([k, v]) => [k, String(v)])
    );
    if (q.toString()) url += `?${q}`;
  }
  const opts: RequestInit = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || `HTTP ${res.status}`);
  }
  if (res.status === 204) return null as T;
  return res.json();
}

export const api = {
  health:    ()                         => request<HealthStatus>('GET', '/health'),
  accounts:  ()                         => request<{outlook_accounts: OutlookAccount[], db_accounts: OutlookAccount[]}>('GET', '/accounts'),
  sync:      (body: object)             => request<{status:string}>('POST', '/sync', body),
  stats:     (accountId?: number)       => request<PanelStats>('GET', '/stats', null, accountId ? {account_id: accountId} : {}),
  patterns:  (accountId?: number)       => request<{patterns: unknown[]}>('GET', '/patterns', null, accountId ? {account_id: accountId} : {}),
  digest:    (accountId?: number)       => request<WeeklyDigest>('GET', '/digest', null, accountId ? {account_id: accountId} : {}),

  emails: {
    list:       (filters: EmailFilters, limit = 100, offset = 0) =>
                  request<Email[]>('GET', '/emails', null, {...filters, limit, offset} as Record<string,unknown>),
    moveKanban: (emailId: number, newUrgency: string) =>
                  request('PATCH', `/emails/${emailId}/urgency`, {email_id: emailId, new_urgency: newUrgency}),
    actionDone: (emailId: number, actionIndex: number) =>
                  request('PATCH', `/emails/${emailId}/action-done`, null, {action_index: actionIndex}),
    quickReply: (emailId: number) =>
                  request('POST', `/quick-reply/${emailId}`),
  },

  danibot: {
    chat:        (message: string, accountId?: number) =>
                   request<DaniBotResponse>('POST', '/danibot/chat', {message, account_id: accountId}),
    reset:       ()  => request('POST', '/danibot/reset'),
    suggestions: ()  => request<{suggestions: string[]}>('GET', '/danibot/suggestions'),
  },
};


// ============================================================
// src/services/websocket.ts — Cliente WebSocket con reconexión
// ============================================================
import type { WSEvent } from '@/types';

export class PanelWebSocket {
  private ws: WebSocket | null = null;
  private reconnectDelay = 1000;
  private maxDelay = 30000;
  private shouldReconnect = true;
  private onMessage: (event: WSEvent) => void;
  private onStatusChange: (status: 'connected' | 'disconnected' | 'error') => void;

  constructor(
    onMessage: (event: WSEvent) => void,
    onStatusChange: (status: 'connected' | 'disconnected' | 'error') => void
  ) {
    this.onMessage = onMessage;
    this.onStatusChange = onStatusChange;
  }

  connect() {
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    this.ws = new WebSocket(`${proto}//${window.location.host}/ws`);

    this.ws.onopen = () => {
      this.reconnectDelay = 1000;
      this.onStatusChange('connected');
    };
    this.ws.onmessage = (e) => {
      try { this.onMessage(JSON.parse(e.data)); }
      catch { /* ignorar JSON inválido */ }
    };
    this.ws.onclose = () => {
      this.onStatusChange('disconnected');
      if (this.shouldReconnect) {
        setTimeout(() => this.connect(), this.reconnectDelay);
        this.reconnectDelay = Math.min(this.reconnectDelay * 2, this.maxDelay);
      }
    };
    this.ws.onerror = () => this.onStatusChange('error');
  }

  disconnect() {
    this.shouldReconnect = false;
    this.ws?.close();
  }
}


// ============================================================
// src/store/useStore.ts — Estado global con Zustand
// ============================================================
import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { api } from '@/services/api';
import { PanelWebSocket } from '@/services/websocket';
import type { Email, EmailFilters, PanelStats, HealthStatus,
              Page, Toast, WSEvent } from '@/types';

interface StoreState {
  // ── Página activa ──
  page: Page;
  setPage: (p: Page) => void;

  // ── Cuentas ──
  accounts: unknown[];
  fetchAccounts: () => Promise<void>;
  activeAccountId: number | null;
  setActiveAccount: (id: number | null) => void;

  // ── Emails ──
  emails: Email[];
  emailsLoading: boolean;
  filters: EmailFilters;
  setFilters: (f: Partial<EmailFilters>) => void;
  clearFilters: () => void;
  fetchEmails: (reset?: boolean) => Promise<void>;
  selectedEmail: Email | null;
  setSelectedEmail: (e: Email | null) => void;
  addRealtimeEmail: (e: Partial<Email>) => void;
  updateEmailUrgency: (id: number, urgency: string) => Promise<void>;

  // ── Stats ──
  stats: PanelStats | null;
  statsLoading: boolean;
  fetchStats: () => Promise<void>;

  // ── Sync ──
  syncing: boolean;
  syncProgress: number;
  syncMessage: string;

  // ── Patrones ──
  patterns: unknown[];
  fetchPatterns: () => Promise<void>;

  // ── Focus mode ──
  focusMode: boolean;
  toggleFocusMode: () => void;

  // ── DaniBot panel ──
  danibotOpen: boolean;
  setDanibotOpen: (v: boolean) => void;

  // ── Toasts ──
  toasts: Toast[];
  addToast: (message: string, type?: Toast['type']) => void;

  // ── WebSocket ──
  wsStatus: 'connected' | 'disconnected' | 'error';
  initWebSocket: () => void;

  // ── Health ──
  health: HealthStatus | null;
  fetchHealth: () => Promise<void>;
}

export const useStore = create<StoreState>()(
  devtools((set, get) => ({
    // ── Página ──
    page: 'dashboard',
    setPage: (page) => set({ page, selectedEmail: null }),

    // ── Cuentas ──
    accounts: [],
    activeAccountId: null,
    fetchAccounts: async () => {
      try {
        const data = await api.accounts();
        set({ accounts: data.db_accounts || [] });
      } catch { /* silencioso */ }
    },
    setActiveAccount: (id) => {
      set({ activeAccountId: id });
      get().fetchEmails(true);
      get().fetchStats();
    },

    // ── Emails ──
    emails: [],
    emailsLoading: false,
    filters: {},
    setFilters: (f) => {
      set(s => ({ filters: { ...s.filters, ...f } }));
      get().fetchEmails(true);
    },
    clearFilters: () => { set({ filters: {} }); get().fetchEmails(true); },
    fetchEmails: async (reset = true) => {
      set({ emailsLoading: true });
      const { filters, activeAccountId, focusMode } = get();
      const f: EmailFilters = { ...filters };
      if (activeAccountId) f.account_id = activeAccountId;
      if (focusMode) f.importance_label = 'critica';
      try {
        const emails = await api.emails.list(f, 150, 0);
        set({ emails: reset ? emails : [...get().emails, ...emails], emailsLoading: false });
      } catch { set({ emailsLoading: false }); }
    },
    selectedEmail: null,
    setSelectedEmail: (e) => set({ selectedEmail: e }),
    addRealtimeEmail: (e) => set(s => ({ emails: [e as Email, ...s.emails].slice(0, 300) })),
    updateEmailUrgency: async (id, urgency) => {
      await api.emails.moveKanban(id, urgency);
      set(s => ({
        emails: s.emails.map(e => e.id === id ? { ...e, urgency_level: urgency as Email['urgency_level'] } : e),
        selectedEmail: s.selectedEmail?.id === id ? { ...s.selectedEmail, urgency_level: urgency as Email['urgency_level'] } : s.selectedEmail,
      }));
    },

    // ── Stats ──
    stats: null,
    statsLoading: false,
    fetchStats: async () => {
      set({ statsLoading: true });
      try {
        const stats = await api.stats(get().activeAccountId ?? undefined);
        set({ stats, statsLoading: false });
      } catch { set({ statsLoading: false }); }
    },

    // ── Sync ──
    syncing: false,
    syncProgress: 0,
    syncMessage: '',

    // ── Patrones ──
    patterns: [],
    fetchPatterns: async () => {
      try {
        const { patterns } = await api.patterns(get().activeAccountId ?? undefined);
        set({ patterns });
      } catch { /* silencioso */ }
    },

    // ── Focus mode ──
    focusMode: false,
    toggleFocusMode: () => {
      set(s => ({ focusMode: !s.focusMode }));
      get().fetchEmails(true);
    },

    // ── DaniBot ──
    danibotOpen: false,
    setDanibotOpen: (v) => set({ danibotOpen: v }),

    // ── Toasts ──
    toasts: [],
    addToast: (message, type = 'info') => {
      const id = crypto.randomUUID();
      set(s => ({ toasts: [...s.toasts, { id, message, type }] }));
      setTimeout(() => set(s => ({ toasts: s.toasts.filter(t => t.id !== id) })), 4000);
    },

    // ── WebSocket ──
    wsStatus: 'disconnected',
    initWebSocket: () => {
      const ws = new PanelWebSocket(
        (event: WSEvent) => {
          const { addToast, fetchStats, fetchEmails, fetchPatterns, addRealtimeEmail } = get();
          switch (event.type) {
            case 'sync_start':
              set({ syncing: true, syncProgress: 0, syncMessage: event.message || '' });
              break;
            case 'sync_reading_done':
              set({ syncMessage: event.message || '' });
              break;
            case 'email_classified':
              set({ syncProgress: event.progress || 0, syncMessage: `Clasificando... ${event.classified} emails` });
              if (event.data) addRealtimeEmail(event.data);
              break;
            case 'sync_complete':
              set({ syncing: false, syncProgress: 100 });
              addToast(event.message || '✅ Completado', 'success');
              fetchStats(); fetchEmails(true); fetchPatterns();
              break;
            case 'sync_error':
              set({ syncing: false });
              addToast(event.message || '❌ Error en sync', 'error');
              break;
            case 'pattern_detected':
              if (event.pattern) set(s => ({ patterns: [event.pattern!, ...s.patterns].slice(0, 6) }));
              break;
          }
        },
        (status) => set({ wsStatus: status })
      );
      ws.connect();
    },

    // ── Health ──
    health: null,
    fetchHealth: async () => {
      try {
        const health = await api.health();
        set({ health });
      } catch { /* silencioso */ }
    },
  }), { name: 'MailAIPanel' })
);


// ============================================================
// src/main.tsx
// ============================================================
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/variables.css';
import './styles/global.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode><App /></React.StrictMode>
);


// ============================================================
// src/App.tsx
// ============================================================
import { useEffect } from 'react';
import { useStore } from '@/store/useStore';
import Sidebar from '@/components/Sidebar';
import Topbar  from '@/components/Topbar';
import DaniBot from '@/components/DaniBot';
import Dashboard from '@/pages/Dashboard';
import Inbox     from '@/pages/Inbox';
import KanbanBoard from '@/components/KanbanBoard';
import Analytics from '@/pages/Analytics';
import Contacts  from '@/pages/Contacts';
import Settings  from '@/pages/Settings';
import ToastContainer from '@/components/ToastContainer';

const PAGES: Record<string, React.FC> = {
  dashboard: Dashboard,
  kanban:    KanbanBoard,
  inbox:     Inbox,
  analytics: Analytics,
  contacts:  Contacts,
  settings:  Settings,
};

export default function App() {
  const { page, initWebSocket, fetchStats, fetchEmails, fetchAccounts, fetchHealth, danibotOpen } = useStore();

  useEffect(() => {
    initWebSocket();
    fetchHealth();
    fetchAccounts();
    fetchStats();
    fetchEmails(true);
  }, []);

  const PageComponent = PAGES[page] || Dashboard;

  return (
    <div className="app-shell">
      <Sidebar />
      <div className="main-area">
        <Topbar />
        <main className="page-content">
          <PageComponent />
        </main>
      </div>
      {danibotOpen && <DaniBot />}
      <ToastContainer />
    </div>
  );
}
