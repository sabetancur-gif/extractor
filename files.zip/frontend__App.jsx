// src/App.jsx
import { useEffect } from 'react'
import { useStore } from './store'
import { EmailWebSocket } from './services/api'
import Sidebar from './components/Sidebar'
import Topbar from './components/Topbar'
import Dashboard from './pages/Dashboard'
import Inbox from './pages/Inbox'
import Analytics from './pages/Analytics'
import Contacts from './pages/Contacts'
import Settings from './pages/Settings'
import ToastContainer from './components/Toast'
import CommandPalette from './components/CommandPalette'

export default function App() {
  const {
    activePage, fetchAccounts, fetchStats, fetchEmails, fetchRules,
    addToast, setSyncing, setSyncProgress, addRealtimeEmail,
    commandOpen, setCommandOpen, theme, setTheme
  } = useStore()

  // Init theme
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme)
  }, [theme])

  // Load initial data
  useEffect(() => {
    fetchAccounts()
    fetchStats()
    fetchEmails()
    fetchRules()
  }, [])

  // WebSocket
  useEffect(() => {
    const ws = new EmailWebSocket((msg) => {
      switch (msg.type) {
        case 'sync_start':
          setSyncing(true)
          setSyncProgress(0, `Conectando a ${msg.email}...`)
          break
        case 'sync_progress':
          setSyncProgress(msg.progress || 0, msg.message)
          break
        case 'new_email':
          setSyncProgress(msg.progress, `Clasificando... ${msg.classified} emails`)
          if (msg.data) addRealtimeEmail(msg.data)
          break
        case 'sync_complete':
          setSyncing(false)
          setSyncProgress(null, null)
          addToast(msg.message, 'success')
          fetchStats()
          fetchEmails()
          fetchAccounts()
          break
        case 'sync_error':
          setSyncing(false)
          setSyncProgress(null, null)
          addToast(msg.message, 'error')
          break
      }
    })
    ws.connect()
    return () => ws.disconnect()
  }, [])

  // Command Palette keyboard shortcut
  useEffect(() => {
    const handleKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        setCommandOpen(!commandOpen)
      }
    }
    document.addEventListener('keydown', handleKey)
    return () => document.removeEventListener('keydown', handleKey)
  }, [commandOpen])

  const pages = {
    dashboard: Dashboard,
    inbox: Inbox,
    analytics: Analytics,
    contacts: Contacts,
    settings: Settings,
  }

  const PageComponent = pages[activePage] || Dashboard

  return (
    <div className="app-shell">
      <Sidebar />
      <div className="main-area">
        <Topbar />
        <main className="page-content">
          <PageComponent />
        </main>
      </div>
      <ToastContainer />
      {commandOpen && <CommandPalette />}
    </div>
  )
}
