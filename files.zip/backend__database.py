"""
database.py — Base de datos con schema completo multi-cuenta y análisis avanzado
"""
import sqlite3
import json
from datetime import datetime
from typing import List, Dict, Optional, Any
from config import Settings

settings = Settings()


class Database:
    def __init__(self):
        self.db_path = settings.database_url

    def conn(self) -> sqlite3.Connection:
        c = sqlite3.connect(self.db_path, timeout=30)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA foreign_keys=ON")
        return c

    def initialize(self):
        with self.conn() as db:
            db.executescript("""
-- Cuentas de email conectadas
CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    display_name TEXT,
    provider TEXT DEFAULT 'imap',
    imap_server TEXT,
    imap_port INTEGER DEFAULT 993,
    is_active BOOLEAN DEFAULT 1,
    last_sync TEXT,
    sync_interval_minutes INTEGER DEFAULT 30,
    total_synced INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Hilos de conversación
CREATE TABLE IF NOT EXISTS threads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    thread_key TEXT UNIQUE NOT NULL,
    account_id INTEGER REFERENCES accounts(id),
    subject TEXT,
    participants TEXT DEFAULT '[]',
    email_count INTEGER DEFAULT 1,
    last_activity TEXT,
    category TEXT,
    priority_label TEXT,
    is_resolved BOOLEAN DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Emails
CREATE TABLE IF NOT EXISTS emails (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT UNIQUE NOT NULL,
    account_id INTEGER REFERENCES accounts(id),
    thread_id INTEGER REFERENCES threads(id),
    sender_name TEXT,
    sender_email TEXT NOT NULL,
    to_address TEXT,
    cc_address TEXT,
    reply_to TEXT,
    subject TEXT,
    body TEXT,
    html_body TEXT,
    date TEXT,
    has_attachments BOOLEAN DEFAULT 0,
    attachment_names TEXT DEFAULT '[]',
    folder TEXT DEFAULT 'INBOX',

    -- Análisis IA (10+ dimensiones)
    category TEXT DEFAULT 'otro',
    subcategory TEXT DEFAULT 'general',
    priority_score INTEGER DEFAULT 50,
    priority_label TEXT DEFAULT 'media',
    sentiment_label TEXT DEFAULT 'neutral',
    sentiment_score REAL DEFAULT 0.0,
    tone TEXT DEFAULT 'neutral',
    urgency_level TEXT DEFAULT 'ninguna',
    urgency_reason TEXT,
    urgency_deadline TEXT,
    entities TEXT DEFAULT '{}',
    action_items TEXT DEFAULT '[]',
    suggested_reply TEXT,
    key_topics TEXT DEFAULT '[]',
    language TEXT DEFAULT 'es',
    spam_score REAL DEFAULT 0.0,
    thread_type TEXT DEFAULT 'nuevo',
    summary TEXT,
    requires_action BOOLEAN DEFAULT 0,
    ai_confidence REAL DEFAULT 0.0,

    -- Estado usuario
    is_read BOOLEAN DEFAULT 0,
    is_starred BOOLEAN DEFAULT 0,
    is_archived BOOLEAN DEFAULT 0,
    is_deleted BOOLEAN DEFAULT 0,
    user_category TEXT,
    notes TEXT,

    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Reglas automáticas
CREATE TABLE IF NOT EXISTS rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT 1,
    priority INTEGER DEFAULT 0,
    conditions TEXT NOT NULL DEFAULT '[]',
    actions TEXT NOT NULL DEFAULT '[]',
    match_count INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Contactos enriquecidos
CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    name TEXT,
    company TEXT,
    role TEXT,
    tags TEXT DEFAULT '[]',
    email_count INTEGER DEFAULT 0,
    last_email TEXT,
    avg_response_hours REAL,
    notes TEXT,
    is_vip BOOLEAN DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Historial de sincronización
CREATE TABLE IF NOT EXISTS sync_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER REFERENCES accounts(id),
    started_at TEXT NOT NULL,
    finished_at TEXT,
    emails_found INTEGER DEFAULT 0,
    emails_classified INTEGER DEFAULT 0,
    errors INTEGER DEFAULT 0,
    status TEXT DEFAULT 'running'
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_emails_account ON emails(account_id);
CREATE INDEX IF NOT EXISTS idx_emails_thread ON emails(thread_id);
CREATE INDEX IF NOT EXISTS idx_emails_category ON emails(category);
CREATE INDEX IF NOT EXISTS idx_emails_priority ON emails(priority_score DESC);
CREATE INDEX IF NOT EXISTS idx_emails_date ON emails(date DESC);
CREATE INDEX IF NOT EXISTS idx_emails_sender ON emails(sender_email);
CREATE INDEX IF NOT EXISTS idx_emails_requires_action ON emails(requires_action);
CREATE INDEX IF NOT EXISTS idx_emails_spam ON emails(spam_score);
CREATE INDEX IF NOT EXISTS idx_threads_account ON threads(account_id);
CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);
""")
        print("✅ DB inicializada")

    # ─── ACCOUNTS ────────────────────────────────────────────────
    def save_account(self, email: str, server: str, port: int, display_name: str = None) -> int:
        with self.conn() as db:
            cur = db.execute("""
                INSERT INTO accounts (email, display_name, imap_server, imap_port)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(email) DO UPDATE SET
                  imap_server=excluded.imap_server, imap_port=excluded.imap_port,
                  display_name=COALESCE(excluded.display_name, display_name)
            """, (email, display_name or email, server, port))
            return cur.lastrowid

    def get_accounts(self) -> List[Dict]:
        with self.conn() as db:
            return [dict(r) for r in db.execute("SELECT * FROM accounts WHERE is_active=1 ORDER BY created_at")]

    def update_account_sync(self, account_id: int, total: int):
        with self.conn() as db:
            db.execute("""
                UPDATE accounts SET last_sync=?, total_synced=total_synced+? WHERE id=?
            """, (datetime.now().isoformat(), total, account_id))

    # ─── THREADS ─────────────────────────────────────────────────
    def get_or_create_thread(self, thread_key: str, account_id: int, subject: str) -> int:
        with self.conn() as db:
            row = db.execute("SELECT id FROM threads WHERE thread_key=?", (thread_key,)).fetchone()
            if row:
                db.execute("""
                    UPDATE threads SET email_count=email_count+1, last_activity=?
                    WHERE thread_key=?
                """, (datetime.now().isoformat(), thread_key))
                return row['id']
            cur = db.execute("""
                INSERT INTO threads (thread_key, account_id, subject, last_activity)
                VALUES (?, ?, ?, ?)
            """, (thread_key, account_id, subject, datetime.now().isoformat()))
            return cur.lastrowid

    # ─── EMAILS ──────────────────────────────────────────────────
    def save_email(self, email_data: Dict, account_id: int, thread_id: int) -> int:
        ai = email_data.get('classification', {})
        entities = ai.get('entities', {})
        with self.conn() as db:
            cur = db.execute("""
                INSERT OR REPLACE INTO emails (
                    message_id, account_id, thread_id,
                    sender_name, sender_email, to_address, cc_address, reply_to,
                    subject, body, html_body, date, has_attachments, attachment_names, folder,
                    category, subcategory, priority_score, priority_label,
                    sentiment_label, sentiment_score, tone,
                    urgency_level, urgency_reason, urgency_deadline,
                    entities, action_items, suggested_reply, key_topics,
                    language, spam_score, thread_type, summary,
                    requires_action, ai_confidence, updated_at
                ) VALUES (
                    ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,
                    ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
                )
            """, (
                email_data['message_id'], account_id, thread_id,
                email_data.get('sender_name',''), email_data.get('sender_email',''),
                email_data.get('to',''), email_data.get('cc',''), email_data.get('reply_to',''),
                email_data.get('subject',''), email_data.get('body',''),
                email_data.get('html_body',''), email_data.get('date',''),
                email_data.get('has_attachments', False),
                json.dumps(email_data.get('attachment_names',[])),
                email_data.get('folder','INBOX'),
                ai.get('category','otro'), ai.get('subcategory','general'),
                ai.get('priority_score', 50), ai.get('priority_label','media'),
                ai.get('sentiment',{}).get('label','neutral'),
                ai.get('sentiment',{}).get('score', 0.0),
                ai.get('sentiment',{}).get('tone','neutral'),
                ai.get('urgency',{}).get('level','ninguna'),
                ai.get('urgency',{}).get('reason',''),
                ai.get('urgency',{}).get('deadline'),
                json.dumps(entities),
                json.dumps(ai.get('action_items',[])),
                ai.get('suggested_reply'),
                json.dumps(ai.get('key_topics',[])),
                ai.get('language','es'), ai.get('spam_score',0.0),
                ai.get('thread_type','nuevo'), ai.get('summary',''),
                ai.get('requires_action', False), ai.get('confidence', 0.0),
                datetime.now().isoformat()
            ))
            return cur.lastrowid

    def email_exists(self, message_id: str) -> bool:
        with self.conn() as db:
            return db.execute("SELECT 1 FROM emails WHERE message_id=?", (message_id,)).fetchone() is not None

    def get_emails(self, filters: Dict = None, limit: int = 50, offset: int = 0) -> List[Dict]:
        filters = filters or {}
        where, params = ["is_deleted=0"], []
        if filters.get('account_id'):
            where.append("account_id=?"); params.append(filters['account_id'])
        if filters.get('category'):
            where.append("category=?"); params.append(filters['category'])
        if filters.get('priority_label'):
            where.append("priority_label=?"); params.append(filters['priority_label'])
        if filters.get('sender'):
            where.append("(sender_email LIKE ? OR sender_name LIKE ?)")
            params += [f"%{filters['sender']}%", f"%{filters['sender']}%"]
        if filters.get('requires_action') is not None:
            where.append("requires_action=?"); params.append(filters['requires_action'])
        if filters.get('is_starred') is not None:
            where.append("is_starred=?"); params.append(filters['is_starred'])
        if filters.get('thread_id'):
            where.append("thread_id=?"); params.append(filters['thread_id'])
        if filters.get('search'):
            where.append("(subject LIKE ? OR body LIKE ? OR sender_name LIKE ?)")
            s = f"%{filters['search']}%"; params += [s, s, s]
        if filters.get('language'):
            where.append("language=?"); params.append(filters['language'])
        if filters.get('spam') is not None:
            if filters['spam']:
                where.append("spam_score > 0.7")
            else:
                where.append("spam_score <= 0.7")

        sort = filters.get('sort', 'date_desc')
        order = {
            'date_desc': 'date DESC',
            'date_asc': 'date ASC',
            'priority_desc': 'priority_score DESC',
            'priority_asc': 'priority_score ASC',
        }.get(sort, 'date DESC')

        query = f"SELECT * FROM emails WHERE {' AND '.join(where)} ORDER BY {order} LIMIT ? OFFSET ?"
        params += [limit, offset]
        with self.conn() as db:
            rows = db.execute(query, params).fetchall()
        return [self._parse_email(dict(r)) for r in rows]

    def get_email(self, email_id: int) -> Optional[Dict]:
        with self.conn() as db:
            row = db.execute("SELECT * FROM emails WHERE id=?", (email_id,)).fetchone()
        return self._parse_email(dict(row)) if row else None

    def _parse_email(self, row: Dict) -> Dict:
        for f in ('entities','action_items','key_topics','attachment_names'):
            try: row[f] = json.loads(row.get(f) or '{}' if f=='entities' else '[]')
            except: row[f] = {} if f == 'entities' else []
        return row

    def update_email(self, email_id: int, updates: Dict) -> bool:
        allowed = {'category','priority_label','is_read','is_starred','is_archived',
                   'is_deleted','user_category','notes','requires_action'}
        sets = {k: v for k, v in updates.items() if k in allowed}
        if not sets:
            return False
        sets['updated_at'] = datetime.now().isoformat()
        placeholders = ', '.join(f"{k}=?" for k in sets)
        with self.conn() as db:
            res = db.execute(f"UPDATE emails SET {placeholders} WHERE id=?",
                             list(sets.values()) + [email_id])
            return res.rowcount > 0

    def bulk_update(self, email_ids: List[int], updates: Dict) -> int:
        total = 0
        for eid in email_ids:
            if self.update_email(eid, updates):
                total += 1
        return total

    def get_email_by_message_id(self, message_id: str) -> Optional[Dict]:
        with self.conn() as db:
            row = db.execute("SELECT * FROM emails WHERE message_id=?", (message_id,)).fetchone()
        return self._parse_email(dict(row)) if row else None

    # ─── STATS ───────────────────────────────────────────────────
    def get_stats(self, account_id: int = None) -> Dict:
        acc_filter = "AND account_id=?" if account_id else ""
        acc_params = [account_id] if account_id else []

        with self.conn() as db:
            total = db.execute(f"SELECT COUNT(*) FROM emails WHERE is_deleted=0 {acc_filter}",
                               acc_params).fetchone()[0]
            requires_action = db.execute(
                f"SELECT COUNT(*) FROM emails WHERE is_deleted=0 AND requires_action=1 {acc_filter}",
                acc_params).fetchone()[0]
            avg_priority = db.execute(
                f"SELECT AVG(priority_score) FROM emails WHERE is_deleted=0 {acc_filter}",
                acc_params).fetchone()[0] or 0
            avg_confidence = db.execute(
                f"SELECT AVG(ai_confidence) FROM emails WHERE is_deleted=0 {acc_filter}",
                acc_params).fetchone()[0] or 0
            by_cat = db.execute(
                f"SELECT category, COUNT(*) as count FROM emails WHERE is_deleted=0 {acc_filter} GROUP BY category ORDER BY count DESC",
                acc_params).fetchall()
            by_priority = db.execute(
                f"SELECT priority_label, COUNT(*) as count FROM emails WHERE is_deleted=0 {acc_filter} GROUP BY priority_label",
                acc_params).fetchall()
            by_sentiment = db.execute(
                f"SELECT sentiment_label, COUNT(*) as count FROM emails WHERE is_deleted=0 {acc_filter} GROUP BY sentiment_label",
                acc_params).fetchall()
            by_language = db.execute(
                f"SELECT language, COUNT(*) as count FROM emails WHERE is_deleted=0 {acc_filter} GROUP BY language ORDER BY count DESC LIMIT 5",
                acc_params).fetchall()
            by_tone = db.execute(
                f"SELECT tone, COUNT(*) as count FROM emails WHERE is_deleted=0 {acc_filter} GROUP BY tone ORDER BY count DESC LIMIT 6",
                acc_params).fetchall()
            by_day = db.execute(
                f"""SELECT DATE(date) as day, COUNT(*) as count,
                    AVG(priority_score) as avg_priority
                    FROM emails WHERE is_deleted=0 AND date >= DATE('now','-30 days') {acc_filter}
                    GROUP BY DATE(date) ORDER BY day""",
                acc_params).fetchall()
            top_senders = db.execute(
                f"""SELECT sender_email, sender_name, COUNT(*) as count,
                    AVG(priority_score) as avg_priority, MAX(date) as last_email
                    FROM emails WHERE is_deleted=0 {acc_filter}
                    GROUP BY sender_email ORDER BY count DESC LIMIT 10""",
                acc_params).fetchall()
            by_thread_type = db.execute(
                f"SELECT thread_type, COUNT(*) as count FROM emails WHERE is_deleted=0 {acc_filter} GROUP BY thread_type",
                acc_params).fetchall()
            urgent_action = db.execute(
                f"""SELECT id, sender_name, sender_email, subject, summary,
                    urgency_level, urgency_deadline, priority_score
                    FROM emails WHERE is_deleted=0 AND requires_action=1 {acc_filter}
                    ORDER BY priority_score DESC LIMIT 8""",
                acc_params).fetchall()
            spam_count = db.execute(
                f"SELECT COUNT(*) FROM emails WHERE is_deleted=0 AND spam_score > 0.7 {acc_filter}",
                acc_params).fetchone()[0]

        return {
            "total": total,
            "requires_action": requires_action,
            "avg_priority": round(avg_priority, 1),
            "avg_confidence": round(avg_confidence * 100, 1),
            "spam_count": spam_count,
            "by_category": [dict(r) for r in by_cat],
            "by_priority": [dict(r) for r in by_priority],
            "by_sentiment": [dict(r) for r in by_sentiment],
            "by_language": [dict(r) for r in by_language],
            "by_tone": [dict(r) for r in by_tone],
            "by_day": [dict(r) for r in by_day],
            "top_senders": [dict(r) for r in top_senders],
            "by_thread_type": [dict(r) for r in by_thread_type],
            "urgent_action": [dict(r) for r in urgent_action],
        }

    # ─── CONTACTS ────────────────────────────────────────────────
    def upsert_contact(self, email: str, name: str = None, company: str = None):
        with self.conn() as db:
            db.execute("""
                INSERT INTO contacts (email, name, company, email_count, last_email)
                VALUES (?, ?, ?, 1, ?)
                ON CONFLICT(email) DO UPDATE SET
                  name=COALESCE(excluded.name, name),
                  company=COALESCE(excluded.company, company),
                  email_count=email_count+1,
                  last_email=excluded.last_email,
                  updated_at=?
            """, (email, name, company, datetime.now().isoformat(), datetime.now().isoformat()))

    def get_contacts(self, search: str = None, limit: int = 50) -> List[Dict]:
        query = "SELECT c.*, (SELECT COUNT(*) FROM emails WHERE sender_email=c.email) as total_emails FROM contacts c"
        params = []
        if search:
            query += " WHERE c.email LIKE ? OR c.name LIKE ? OR c.company LIKE ?"
            params = [f"%{search}%", f"%{search}%", f"%{search}%"]
        query += " ORDER BY total_emails DESC LIMIT ?"
        params.append(limit)
        with self.conn() as db:
            rows = db.execute(query, params).fetchall()
        return [dict(r) for r in rows]

    def get_contact(self, contact_id: int) -> Optional[Dict]:
        with self.conn() as db:
            row = db.execute("SELECT * FROM contacts WHERE id=?", (contact_id,)).fetchone()
        return dict(row) if row else None

    def update_contact(self, contact_id: int, updates: Dict) -> bool:
        allowed = {'name','company','role','tags','notes','is_vip'}
        sets = {k:v for k,v in updates.items() if k in allowed}
        if not sets: return False
        sets['updated_at'] = datetime.now().isoformat()
        if 'tags' in sets and isinstance(sets['tags'], list):
            sets['tags'] = json.dumps(sets['tags'])
        placeholders = ', '.join(f"{k}=?" for k in sets)
        with self.conn() as db:
            res = db.execute(f"UPDATE contacts SET {placeholders} WHERE id=?",
                             list(sets.values()) + [contact_id])
            return res.rowcount > 0

    # ─── RULES ───────────────────────────────────────────────────
    def get_rules(self) -> List[Dict]:
        with self.conn() as db:
            rows = db.execute("SELECT * FROM rules WHERE is_active=1 ORDER BY priority DESC").fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try: d['conditions'] = json.loads(d['conditions'])
            except: d['conditions'] = []
            try: d['actions'] = json.loads(d['actions'])
            except: d['actions'] = []
            out.append(d)
        return out

    def save_rule(self, name: str, conditions: list, actions: list,
                  description: str = None, priority: int = 0) -> int:
        with self.conn() as db:
            cur = db.execute("""
                INSERT INTO rules (name, description, conditions, actions, priority)
                VALUES (?, ?, ?, ?, ?)
            """, (name, description, json.dumps(conditions), json.dumps(actions), priority))
            return cur.lastrowid

    def delete_rule(self, rule_id: int):
        with self.conn() as db:
            db.execute("DELETE FROM rules WHERE id=?", (rule_id,))

    # ─── SYNC LOG ────────────────────────────────────────────────
    def start_sync(self, account_id: int) -> int:
        with self.conn() as db:
            cur = db.execute("INSERT INTO sync_log (account_id, started_at) VALUES (?, ?)",
                             (account_id, datetime.now().isoformat()))
            return cur.lastrowid

    def finish_sync(self, sync_id: int, found: int, classified: int, errors: int = 0):
        with self.conn() as db:
            db.execute("""
                UPDATE sync_log SET finished_at=?, emails_found=?, emails_classified=?,
                errors=?, status='completed' WHERE id=?
            """, (datetime.now().isoformat(), found, classified, errors, sync_id))

    def get_sync_history(self, account_id: int, limit: int = 10) -> List[Dict]:
        with self.conn() as db:
            rows = db.execute("""
                SELECT * FROM sync_log WHERE account_id=?
                ORDER BY started_at DESC LIMIT ?
            """, (account_id, limit)).fetchall()
        return [dict(r) for r in rows]
