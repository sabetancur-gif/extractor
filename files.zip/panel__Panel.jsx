// =============================================================
// Panel.jsx — Panel Clasificador MailAI (4 dimensiones)
// Importancia | Sentimiento | Remitente | Urgencia
// =============================================================
import { useState, useEffect, useCallback, useRef } from 'react'
import { ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar,
         XAxis, YAxis, Tooltip, AreaChart, Area } from 'recharts'

// ── Colores por dimensión ─────────────────────────────────────
const IMP_COLORS  = { critica:'#ef4444', alta:'#f97316', media:'#eab308', baja:'#22c55e', info:'#94a3b8' }
const URG_COLORS  = { critica:'#ef4444', alta:'#f97316', media:'#eab308', baja:'#22c55e', ninguna:'#6b7280' }
const SENT_COLORS = { positivo:'#10b981', negativo:'#ef4444', neutral:'#94a3b8', mixto:'#f59e0b' }
const SENT_EMOJI  = { positivo:'😊', negativo:'😟', neutral:'😐', mixto:'🤔' }
const PROF_COLORS = { cliente:'#6366f1', proveedor:'#f59e0b', colega:'#10b981', jefe:'#ef4444',
                      externo:'#94a3b8', interno:'#3b82f6', desconocido:'#6b7280' }

// ── API helpers ───────────────────────────────────────────────
const api = {
  get: (path, params) => {
    const url = new URL(`http://localhost:8000${path}`)
    if (params) Object.entries(params).filter(([,v])=>v!=null).forEach(([k,v])=>url.searchParams.set(k,v))
    return fetch(url).then(r => r.json())
  },
  post: (path, body) => fetch(`http://localhost:8000${path}`, {
    method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)
  }).then(r => r.json())
}

// ── Componentes de UI ─────────────────────────────────────────

function ScoreBar({ value, max=100, color }) {
  const pct = Math.round((value/max)*100)
  return (
    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
      <div style={{ flex:1, height:6, background:'#1e293b', borderRadius:3, overflow:'hidden' }}>
        <div style={{ width:`${pct}%`, height:'100%', background:color, borderRadius:3,
                      transition:'width .4s' }} />
      </div>
      <span style={{ fontSize:11, color:'#94a3b8', minWidth:28, fontFamily:'monospace' }}>{value}</span>
    </div>
  )
}

function DimensionBadge({ label, color, size='sm' }) {
  const pad = size==='sm' ? '2px 8px' : '4px 12px'
  const fs  = size==='sm' ? 10 : 12
  return (
    <span style={{
      display:'inline-block', padding:pad, borderRadius:20, fontSize:fs, fontWeight:600,
      background:`${color}22`, color, border:`1px solid ${color}44`
    }}>{label}</span>
  )
}

function StatCard({ icon, value, label, sub, color }) {
  return (
    <div style={{
      background:'#0f172a', borderRadius:12, padding:'16px 18px',
      borderLeft:`3px solid ${color}`, display:'flex', gap:14, alignItems:'center'
    }}>
      <span style={{ fontSize:26 }}>{icon}</span>
      <div>
        <div style={{ fontSize:26, fontWeight:700, color, lineHeight:1 }}>{value}</div>
        <div style={{ fontSize:12, color:'#64748b', marginTop:3 }}>{label}</div>
        {sub && <div style={{ fontSize:10, color:'#475569', marginTop:1 }}>{sub}</div>}
      </div>
    </div>
  )
}

function EmailRow({ email, onClick, selected }) {
  return (
    <div onClick={onClick} style={{
      padding:'10px 14px', cursor:'pointer', borderBottom:'1px solid #1e293b',
      background: selected ? '#1e293b' : 'transparent',
      borderLeft: selected ? `3px solid #6366f1` : '3px solid transparent',
      transition:'background .1s'
    }}>
      {/* Fila superior */}
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
        <span style={{ fontSize:12, fontWeight:600, color:'#f1f5f9',
                       overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', flex:1 }}>
          {email.sender_name || email.sender_email}
        </span>
        <span style={{ fontSize:10, color:'#475569', whiteSpace:'nowrap', marginLeft:8 }}>
          {email.account_name?.split('@')[0]}
        </span>
      </div>
      {/* Asunto */}
      <div style={{ fontSize:12, color:'#94a3b8', marginBottom:6,
                    overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
        {email.subject}
      </div>
      {/* Las 4 dimensiones en una fila */}
      <div style={{ display:'flex', gap:5, flexWrap:'wrap', alignItems:'center' }}>
        {/* Importancia */}
        <div style={{ display:'flex', alignItems:'center', gap:4 }}>
          <div style={{ width:6, height:6, borderRadius:'50%',
                        background: email.importance_color || IMP_COLORS[email.importance_label] }} />
          <span style={{ fontSize:9, color:'#64748b' }}>{email.importance_score}</span>
        </div>
        {/* Sentimiento */}
        <span style={{ fontSize:12 }}>{email.sentiment_emoji || SENT_EMOJI[email.sentiment_label] || '😐'}</span>
        {/* Perfil remitente */}
        <DimensionBadge label={email.sender_profile} color={PROF_COLORS[email.sender_profile] || '#6b7280'} />
        {/* Urgencia */}
        {email.urgency_level !== 'ninguna' && (
          <DimensionBadge label={email.urgency_level} color={email.urgency_color || URG_COLORS[email.urgency_level]} />
        )}
        {/* VIP */}
        {email.sender_is_vip && <span style={{ fontSize:10 }}>⭐</span>}
      </div>
    </div>
  )
}

function DetailPanel({ email, onClose }) {
  if (!email) return null
  const actions = Array.isArray(email.urgency_actions) ? email.urgency_actions : []
  return (
    <div style={{ display:'flex', flexDirection:'column', height:'100%', overflow:'hidden' }}>
      {/* Header */}
      <div style={{ padding:'14px 16px', borderBottom:'1px solid #1e293b', flexShrink:0 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
          <h3 style={{ fontSize:14, fontWeight:600, color:'#f1f5f9', lineHeight:1.4, flex:1 }}>
            {email.subject}
          </h3>
          <button onClick={onClose} style={{
            background:'transparent', border:'none', color:'#475569',
            cursor:'pointer', fontSize:18, padding:'0 0 0 10px'
          }}>✕</button>
        </div>
        <div style={{ fontSize:11, color:'#64748b', marginTop:6 }}>
          {email.sender_name} · {email.sender_email} · {email.account_name}
        </div>
        <div style={{ fontSize:11, color:'#475569', marginTop:2 }}>
          {email.date ? new Date(email.date).toLocaleString('es-CO') : ''}
        </div>
      </div>

      {/* Las 4 dimensiones */}
      <div style={{ flex:1, overflowY:'auto', padding:'14px 16px', display:'flex', flexDirection:'column', gap:14 }}>

        {/* DIMENSIÓN 1: IMPORTANCIA */}
        <div style={{ background:'#0f172a', borderRadius:10, padding:12,
                      borderLeft:`3px solid ${email.importance_color || '#eab308'}` }}>
          <div style={{ fontSize:10, fontWeight:700, color:'#64748b', textTransform:'uppercase',
                        letterSpacing:.5, marginBottom:8 }}>📊 Importancia</div>
          <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8 }}>
            <DimensionBadge label={email.importance_label} color={email.importance_color || IMP_COLORS[email.importance_label]} size='md' />
          </div>
          <ScoreBar value={email.importance_score || 50} color={email.importance_color || '#eab308'} />
          {email.importance_reason && (
            <div style={{ fontSize:11, color:'#94a3b8', marginTop:8, lineHeight:1.5 }}>
              {email.importance_reason}
            </div>
          )}
        </div>

        {/* DIMENSIÓN 2: SENTIMIENTO */}
        <div style={{ background:'#0f172a', borderRadius:10, padding:12,
                      borderLeft:`3px solid ${SENT_COLORS[email.sentiment_label] || '#94a3b8'}` }}>
          <div style={{ fontSize:10, fontWeight:700, color:'#64748b', textTransform:'uppercase',
                        letterSpacing:.5, marginBottom:8 }}>💬 Sentimiento</div>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <span style={{ fontSize:28 }}>{email.sentiment_emoji || SENT_EMOJI[email.sentiment_label] || '😐'}</span>
            <div>
              <DimensionBadge label={email.sentiment_label} color={SENT_COLORS[email.sentiment_label] || '#94a3b8'} size='md' />
              <div style={{ fontSize:11, color:'#64748b', marginTop:4 }}>Tono: {email.sentiment_tone}</div>
            </div>
            <div style={{ marginLeft:'auto', textAlign:'right' }}>
              <div style={{ fontSize:18, fontWeight:700, color:'#f1f5f9', fontFamily:'monospace' }}>
                {((email.sentiment_score || 0) >= 0 ? '+' : '')}{Number(email.sentiment_score || 0).toFixed(2)}
              </div>
              <div style={{ fontSize:9, color:'#475569' }}>score</div>
            </div>
          </div>
        </div>

        {/* DIMENSIÓN 3: REMITENTE */}
        <div style={{ background:'#0f172a', borderRadius:10, padding:12,
                      borderLeft:`3px solid ${PROF_COLORS[email.sender_profile] || '#6b7280'}` }}>
          <div style={{ fontSize:10, fontWeight:700, color:'#64748b', textTransform:'uppercase',
                        letterSpacing:.5, marginBottom:8 }}>👤 Remitente</div>
          <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
            <div style={{
              width:32, height:32, borderRadius:'50%',
              background: `${PROF_COLORS[email.sender_profile] || '#6b7280'}33`,
              display:'flex', alignItems:'center', justifyContent:'center',
              fontSize:14, fontWeight:700, color: PROF_COLORS[email.sender_profile] || '#6b7280'
            }}>
              {(email.sender_name || email.sender_email || '?')[0].toUpperCase()}
            </div>
            <div>
              <div style={{ fontSize:13, fontWeight:600, color:'#f1f5f9' }}>
                {email.sender_name}
                {email.sender_is_vip && ' ⭐'}
              </div>
              <div style={{ fontSize:11, color:'#64748b' }}>{email.sender_email}</div>
            </div>
          </div>
          <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:8 }}>
            <DimensionBadge label={email.sender_profile} color={PROF_COLORS[email.sender_profile] || '#6b7280'} size='md' />
            {email.sender_company && (
              <span style={{ fontSize:11, color:'#94a3b8' }}>🏢 {email.sender_company}</span>
            )}
          </div>
          <div style={{ marginBottom:4 }}>
            <div style={{ fontSize:10, color:'#475569', marginBottom:4 }}>Confianza</div>
            <ScoreBar value={email.sender_trust || 50} color={PROF_COLORS[email.sender_profile] || '#6b7280'} />
          </div>
          {email.sender_relation && (
            <div style={{ fontSize:11, color:'#94a3b8', marginTop:8, fontStyle:'italic' }}>
              "{email.sender_relation}"
            </div>
          )}
        </div>

        {/* DIMENSIÓN 4: URGENCIA */}
        <div style={{ background:'#0f172a', borderRadius:10, padding:12,
                      borderLeft:`3px solid ${email.urgency_color || '#6b7280'}` }}>
          <div style={{ fontSize:10, fontWeight:700, color:'#64748b', textTransform:'uppercase',
                        letterSpacing:.5, marginBottom:8 }}>⚡ Urgencia</div>
          <DimensionBadge label={email.urgency_level} color={email.urgency_color || '#6b7280'} size='md' />
          {email.urgency_deadline && (
            <div style={{ fontSize:11, color:'#f59e0b', marginTop:8 }}>
              📅 Fecha límite: {email.urgency_deadline}
            </div>
          )}
          {actions.length > 0 && (
            <div style={{ marginTop:10 }}>
              <div style={{ fontSize:10, color:'#475569', marginBottom:6 }}>ACCIONES REQUERIDAS</div>
              {actions.map((a, i) => (
                <div key={i} style={{ display:'flex', gap:8, alignItems:'flex-start',
                                      padding:'6px 0', borderBottom:'1px solid #1e293b' }}>
                  <span style={{ color:email.urgency_color || '#6b7280', marginTop:1 }}>→</span>
                  <span style={{ fontSize:12, color:'#94a3b8' }}>{a}</span>
                </div>
              ))}
            </div>
          )}
          {email.urgency_reply && (
            <div style={{ marginTop:12 }}>
              <div style={{ fontSize:10, color:'#475569', marginBottom:6 }}>💬 RESPUESTA SUGERIDA</div>
              <div style={{ background:'#1e293b', borderRadius:8, padding:10,
                            fontSize:11, color:'#94a3b8', lineHeight:1.6, fontStyle:'italic' }}>
                {email.urgency_reply}
              </div>
              <button onClick={() => navigator.clipboard.writeText(email.urgency_reply)}
                style={{ marginTop:6, background:'#1e293b', border:'1px solid #334155',
                         borderRadius:6, padding:'4px 10px', fontSize:10, color:'#94a3b8',
                         cursor:'pointer' }}>
                📋 Copiar
              </button>
            </div>
          )}
        </div>

        {/* Resumen */}
        {email.summary && (
          <div style={{ background:'#1e293b', borderRadius:8, padding:12 }}>
            <div style={{ fontSize:10, color:'#475569', marginBottom:6, textTransform:'uppercase', letterSpacing:.5 }}>📝 Resumen IA</div>
            <div style={{ fontSize:12, color:'#94a3b8', lineHeight:1.6 }}>{email.summary}</div>
          </div>
        )}
      </div>
    </div>
  )
}

// ── Panel Principal ───────────────────────────────────────────
export default function Panel() {
  const [stats,     setStats]     = useState(null)
  const [emails,    setEmails]    = useState([])
  const [selected,  setSelected]  = useState(null)
  const [filters,   setFilters]   = useState({})
  const [loading,   setLoading]   = useState(false)
  const [syncing,   setSyncing]   = useState(false)
  const [progress,  setProgress]  = useState(0)
  const [syncMsg,   setSyncMsg]   = useState('')
  const [wsStatus,  setWsStatus]  = useState('disconnected')
  const [toasts,    setToasts]    = useState([])
  const wsRef = useRef(null)

  const addToast = useCallback((msg, type='info') => {
    const id = Date.now()
    setToasts(p => [...p, {id, msg, type}])
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 4000)
  }, [])

  const loadData = useCallback(async () => {
    setLoading(true)
    try {
      const [statsData, emailsData] = await Promise.all([
        api.get('/stats'),
        api.get('/emails', { ...filters, limit: 100 }),
      ])
      setStats(statsData)
      setEmails(emailsData)
    } catch { addToast('Error cargando datos', 'error') }
    finally { setLoading(false) }
  }, [filters])

  // WebSocket para actualizaciones en tiempo real
  useEffect(() => {
    const connect = () => {
      const ws = new WebSocket('ws://localhost:8000/ws')
      wsRef.current = ws
      ws.onopen  = () => setWsStatus('connected')
      ws.onclose = () => { setWsStatus('disconnected'); setTimeout(connect, 3000) }
      ws.onerror = () => setWsStatus('error')
      ws.onmessage = (e) => {
        const data = JSON.parse(e.data)
        if (data.type === 'sync_start')   { setSyncing(true); setSyncMsg(data.message); setProgress(0) }
        if (data.type === 'sync_reading_done') setSyncMsg(data.message)
        if (data.type === 'email_classified') {
          setProgress(data.progress)
          setSyncMsg(`Clasificando... ${data.classified} emails`)
          setEmails(prev => [data.data, ...prev].slice(0, 200))
        }
        if (data.type === 'sync_complete') {
          setSyncing(false); setProgress(100)
          addToast(data.message, 'success')
          loadData()
        }
        if (data.type === 'sync_error') {
          setSyncing(false); addToast(data.message, 'error')
        }
      }
    }
    connect()
    return () => wsRef.current?.close()
  }, [])

  useEffect(() => { loadData() }, [filters])

  const startSync = async () => {
    try {
      await api.post('/sync', { days_back: 14, limit_per_account: 100 })
      addToast('Leyendo Outlook...', 'info')
    } catch { addToast('Error iniciando sincronización', 'error') }
  }

  // ── Estilos base ─────────────────────────────────────────────
  const S = {
    shell:   { display:'flex', height:'100vh', background:'#020817', color:'#f1f5f9',
                fontFamily:"'Inter','Segoe UI',system-ui,sans-serif", fontSize:13 },
    sidebar: { width:220, background:'#0f172a', borderRight:'1px solid #1e293b',
                display:'flex', flexDirection:'column', padding:'16px 10px', flexShrink:0 },
    main:    { flex:1, display:'flex', flexDirection:'column', overflow:'hidden' },
    topbar:  { height:52, background:'#0f172a', borderBottom:'1px solid #1e293b',
                display:'flex', alignItems:'center', gap:14, padding:'0 18px', flexShrink:0 },
    content: { flex:1, overflow:'auto', padding:18 },
  }

  return (
    <div style={S.shell}>

      {/* SIDEBAR */}
      <aside style={S.sidebar}>
        <div style={{ marginBottom:20, paddingBottom:14, borderBottom:'1px solid #1e293b' }}>
          <div style={{ fontSize:18, fontWeight:700, letterSpacing:-.3 }}>📧 MailAI</div>
          <div style={{ fontSize:10, color:'#475569' }}>Panel Clasificador</div>
        </div>

        {/* Filtros rápidos */}
        <div style={{ fontSize:10, color:'#475569', textTransform:'uppercase', letterSpacing:.5, marginBottom:8 }}>
          Filtrar por importancia
        </div>
        {['critica','alta','media','baja'].map(l => (
          <button key={l} onClick={() => setFilters(f => f.importance_label===l ? {} : {...f,importance_label:l})}
            style={{ display:'flex', alignItems:'center', gap:8, padding:'7px 10px', borderRadius:7,
                     border:'none', background: filters.importance_label===l ? `${IMP_COLORS[l]}22` : 'transparent',
                     color: filters.importance_label===l ? IMP_COLORS[l] : '#64748b',
                     cursor:'pointer', width:'100%', textAlign:'left', fontSize:12, marginBottom:2 }}>
            <span style={{ width:8, height:8, borderRadius:'50%', background:IMP_COLORS[l], flexShrink:0 }} />
            {l.charAt(0).toUpperCase()+l.slice(1)}
          </button>
        ))}

        <div style={{ fontSize:10, color:'#475569', textTransform:'uppercase', letterSpacing:.5, margin:'14px 0 8px' }}>
          Filtrar por urgencia
        </div>
        {['critica','alta','media'].map(l => (
          <button key={l} onClick={() => setFilters(f => f.urgency_level===l ? {} : {...f,urgency_level:l})}
            style={{ display:'flex', alignItems:'center', gap:8, padding:'7px 10px', borderRadius:7,
                     border:'none', background: filters.urgency_level===l ? `${URG_COLORS[l]}22` : 'transparent',
                     color: filters.urgency_level===l ? URG_COLORS[l] : '#64748b',
                     cursor:'pointer', width:'100%', textAlign:'left', fontSize:12, marginBottom:2 }}>
            <span style={{ fontSize:12 }}>⚡</span> {l.charAt(0).toUpperCase()+l.slice(1)}
          </button>
        ))}

        <button onClick={() => setFilters(f => ({...f, is_vip: f.is_vip ? undefined : true}))}
          style={{ display:'flex', alignItems:'center', gap:8, padding:'7px 10px', borderRadius:7, border:'none',
                   background: filters.is_vip ? '#f59e0b22' : 'transparent',
                   color: filters.is_vip ? '#f59e0b' : '#64748b',
                   cursor:'pointer', width:'100%', textAlign:'left', fontSize:12, marginTop:4 }}>
          ⭐ Solo VIP
        </button>

        {Object.keys(filters).length > 0 && (
          <button onClick={() => setFilters({})}
            style={{ marginTop:10, background:'transparent', border:'1px solid #334155',
                     borderRadius:7, padding:'6px 10px', color:'#64748b', cursor:'pointer',
                     fontSize:11, width:'100%' }}>✕ Limpiar filtros</button>
        )}

        {/* Estado WS */}
        <div style={{ marginTop:'auto', paddingTop:12, borderTop:'1px solid #1e293b',
                      display:'flex', alignItems:'center', gap:6, fontSize:11 }}>
          <span style={{ width:7, height:7, borderRadius:'50%', flexShrink:0,
                         background: wsStatus==='connected' ? '#22c55e' : '#ef4444',
                         boxShadow: wsStatus==='connected' ? '0 0 6px #22c55e' : 'none' }} />
          <span style={{ color:'#475569' }}>{wsStatus==='connected' ? 'En vivo' : 'Desconectado'}</span>
        </div>
      </aside>

      {/* ÁREA PRINCIPAL */}
      <div style={S.main}>

        {/* TOPBAR */}
        <header style={S.topbar}>
          <span style={{ fontWeight:600, fontSize:15, flex:1 }}>Panel Clasificador</span>
          {syncing && (
            <div style={{ display:'flex', alignItems:'center', gap:10, flex:2 }}>
              <div style={{ flex:1, height:4, background:'#1e293b', borderRadius:2, overflow:'hidden' }}>
                <div style={{ width:`${progress}%`, height:'100%', background:'#6366f1',
                              borderRadius:2, transition:'width .4s' }} />
              </div>
              <span style={{ fontSize:11, color:'#94a3b8', whiteSpace:'nowrap' }}>{syncMsg}</span>
            </div>
          )}
          <span style={{ background:'#1e293b', borderRadius:20, padding:'3px 12px',
                         fontSize:11, color:'#64748b' }}>
            {stats?.total || 0} emails
          </span>
          <button onClick={startSync} disabled={syncing}
            style={{ background: syncing ? '#1e293b' : '#6366f1', color: syncing ? '#64748b' : '#fff',
                     border:'none', borderRadius:8, padding:'6px 16px', fontSize:12,
                     fontWeight:600, cursor: syncing ? 'not-allowed' : 'pointer' }}>
            {syncing ? '⟳ Clasificando...' : '⟳ Clasificar Outlook'}
          </button>
        </header>

        {/* CONTENIDO */}
        <div style={S.content}>
          {!stats || stats.total === 0 ? (
            // Estado vacío
            <div style={{ display:'flex', flexDirection:'column', alignItems:'center',
                          justifyContent:'center', height:'60vh', gap:16, color:'#475569' }}>
              <div style={{ fontSize:56 }}>📧</div>
              <h2 style={{ fontSize:20, fontWeight:600, color:'#94a3b8' }}>Bienvenido a MailAI Panel</h2>
              <p style={{ textAlign:'center', maxWidth:380, lineHeight:1.6 }}>
                Haz clic en "Clasificar Outlook" para leer todos los correos de las cuentas
                abiertas y clasificarlos en 4 dimensiones con IA local.
              </p>
              <button onClick={startSync}
                style={{ background:'#6366f1', color:'#fff', border:'none', borderRadius:10,
                         padding:'12px 28px', fontSize:15, fontWeight:600, cursor:'pointer' }}>
                ⟳ Clasificar Outlook ahora
              </button>
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:16 }}>

              {/* KPIs */}
              <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12 }}>
                <StatCard icon="📧" value={stats.total}        label="Total emails"    color="#6366f1" />
                <StatCard icon="🔴" value={stats.by_importance?.find(i=>i.importance_label==='critica')?.c||0}
                          label="Críticos"  sub="importancia máxima" color="#ef4444" />
                <StatCard icon="⭐" value={stats.vip_count||0} label="VIP detectados"  color="#f59e0b" />
                <StatCard icon="📊" value={`${Math.round(stats.avg_importance||0)}/100`}
                          label="Importancia media" color="#10b981" />
              </div>

              {/* Gráficas: las 4 dimensiones */}
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr', gap:12 }}>

                {/* Importancia */}
                <div style={{ background:'#0f172a', borderRadius:12, padding:14 }}>
                  <div style={{ fontSize:11, fontWeight:600, color:'#64748b', textTransform:'uppercase',
                                letterSpacing:.5, marginBottom:10 }}>📊 Importancia</div>
                  <ResponsiveContainer width="100%" height={120}>
                    <PieChart>
                      <Pie data={stats.by_importance?.map(d=>({...d,name:d.importance_label,value:d.c}))||[]}
                           dataKey="value" cx="50%" cy="50%" innerRadius={30} outerRadius={55}>
                        {(stats.by_importance||[]).map(d=>(
                          <Cell key={d.importance_label} fill={IMP_COLORS[d.importance_label]||'#94a3b8'} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(v,n,p)=>[v,p.payload.importance_label]} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div style={{ display:'flex', flexDirection:'column', gap:3, marginTop:6 }}>
                    {(stats.by_importance||[]).map(d=>(
                      <div key={d.importance_label} style={{ display:'flex', alignItems:'center', gap:5, fontSize:10, color:'#64748b',
                           cursor:'pointer' }} onClick={()=>setFilters({importance_label:d.importance_label})}>
                        <span style={{ width:7, height:7, borderRadius:'50%', background:IMP_COLORS[d.importance_label] }} />
                        <span style={{ flex:1 }}>{d.importance_label}</span>
                        <span style={{ fontWeight:600, color:'#f1f5f9' }}>{d.c}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Sentimiento */}
                <div style={{ background:'#0f172a', borderRadius:12, padding:14 }}>
                  <div style={{ fontSize:11, fontWeight:600, color:'#64748b', textTransform:'uppercase',
                                letterSpacing:.5, marginBottom:10 }}>💬 Sentimiento</div>
                  <ResponsiveContainer width="100%" height={120}>
                    <PieChart>
                      <Pie data={stats.by_sentiment?.map(d=>({...d,name:d.sentiment_label,value:d.c}))||[]}
                           dataKey="value" cx="50%" cy="50%" outerRadius={55}>
                        {(stats.by_sentiment||[]).map(d=>(
                          <Cell key={d.sentiment_label} fill={SENT_COLORS[d.sentiment_label]||'#94a3b8'} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(v,n,p)=>[v,p.payload.sentiment_label]} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div style={{ display:'flex', flexDirection:'column', gap:3, marginTop:6 }}>
                    {(stats.by_sentiment||[]).map(d=>(
                      <div key={d.sentiment_label} style={{ display:'flex', alignItems:'center', gap:5, fontSize:10, color:'#64748b',
                           cursor:'pointer' }} onClick={()=>setFilters({sentiment_label:d.sentiment_label})}>
                        <span>{SENT_EMOJI[d.sentiment_label]||'😐'}</span>
                        <span style={{ flex:1 }}>{d.sentiment_label}</span>
                        <span style={{ fontWeight:600, color:'#f1f5f9' }}>{d.c}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Perfil remitente */}
                <div style={{ background:'#0f172a', borderRadius:12, padding:14 }}>
                  <div style={{ fontSize:11, fontWeight:600, color:'#64748b', textTransform:'uppercase',
                                letterSpacing:.5, marginBottom:10 }}>👤 Remitentes</div>
                  <ResponsiveContainer width="100%" height={120}>
                    <BarChart data={stats.by_profile?.slice(0,5)||[]} layout="vertical" margin={{left:0}}>
                      <XAxis type="number" hide />
                      <YAxis type="category" dataKey="sender_profile" width={75}
                             tick={{fontSize:9, fill:'#64748b'}} />
                      <Tooltip formatter={(v,n,p)=>[v,p.payload.sender_profile]} />
                      <Bar dataKey="c" radius={[0,4,4,0]}>
                        {(stats.by_profile?.slice(0,5)||[]).map(d=>(
                          <Cell key={d.sender_profile} fill={PROF_COLORS[d.sender_profile]||'#6b7280'}
                                style={{cursor:'pointer'}} onClick={()=>setFilters({sender_profile:d.sender_profile})} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                {/* Urgencia */}
                <div style={{ background:'#0f172a', borderRadius:12, padding:14 }}>
                  <div style={{ fontSize:11, fontWeight:600, color:'#64748b', textTransform:'uppercase',
                                letterSpacing:.5, marginBottom:10 }}>⚡ Urgencia</div>
                  <ResponsiveContainer width="100%" height={120}>
                    <BarChart data={stats.by_urgency?.filter(d=>d.urgency_level!=='ninguna')||[]} layout="vertical" margin={{left:0}}>
                      <XAxis type="number" hide />
                      <YAxis type="category" dataKey="urgency_level" width={55}
                             tick={{fontSize:9,fill:'#64748b'}} />
                      <Tooltip formatter={(v,n,p)=>[v,p.payload.urgency_level]} />
                      <Bar dataKey="c" radius={[0,4,4,0]}>
                        {(stats.by_urgency?.filter(d=>d.urgency_level!=='ninguna')||[]).map(d=>(
                          <Cell key={d.urgency_level} fill={URG_COLORS[d.urgency_level]||'#6b7280'}
                                style={{cursor:'pointer'}} onClick={()=>setFilters({urgency_level:d.urgency_level})} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                  <div style={{ display:'flex', flexDirection:'column', gap:3, marginTop:4 }}>
                    {(stats.by_urgency||[]).filter(d=>d.urgency_level!=='ninguna').map(d=>(
                      <div key={d.urgency_level} style={{ display:'flex', gap:5, fontSize:10, color:'#64748b' }}>
                        <span style={{ flex:1 }}>{d.urgency_level}</span>
                        <span style={{ fontWeight:600, color:URG_COLORS[d.urgency_level] }}>{d.c}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Lista + Detalle */}
              <div style={{ display:'flex', gap:12, height:480 }}>

                {/* Lista de emails */}
                <div style={{ width: selected ? 320 : '100%', background:'#0f172a', borderRadius:12, overflow:'hidden', display:'flex', flexDirection:'column', flexShrink:0 }}>
                  <div style={{ padding:'10px 14px', borderBottom:'1px solid #1e293b', fontSize:12, fontWeight:600, color:'#94a3b8' }}>
                    {emails.length} emails {Object.keys(filters).length > 0 ? '(filtrados)' : ''}
                  </div>
                  <div style={{ flex:1, overflowY:'auto' }}>
                    {loading ? (
                      <div style={{ padding:24, textAlign:'center', color:'#475569' }}>Cargando...</div>
                    ) : emails.length === 0 ? (
                      <div style={{ padding:24, textAlign:'center', color:'#475569' }}>Sin emails con estos filtros</div>
                    ) : emails.map((email,i) => (
                      <EmailRow key={email.id||i} email={email}
                        selected={selected?.id===email.id}
                        onClick={()=>setSelected(s=>s?.id===email.id ? null : email)} />
                    ))}
                  </div>
                </div>

                {/* Panel de detalle */}
                {selected && (
                  <div style={{ flex:1, background:'#0f172a', borderRadius:12, overflow:'hidden' }}>
                    <DetailPanel email={selected} onClose={()=>setSelected(null)} />
                  </div>
                )}
              </div>

              {/* Top senders */}
              {stats.top_senders?.length > 0 && (
                <div style={{ background:'#0f172a', borderRadius:12, padding:14 }}>
                  <div style={{ fontSize:12, fontWeight:600, color:'#94a3b8', marginBottom:12 }}>
                    🏆 Top Remitentes por Volumen
                  </div>
                  <div style={{ display:'flex', flexDirection:'column', gap:0 }}>
                    {stats.top_senders.slice(0,6).map((s,i)=>(
                      <div key={s.sender_email} style={{ display:'flex', alignItems:'center', gap:10,
                           padding:'8px 0', borderBottom:'1px solid #1e293b' }}>
                        <span style={{ fontSize:11, color:'#475569', width:20, textAlign:'right' }}>#{i+1}</span>
                        <div style={{ width:28, height:28, borderRadius:'50%',
                             background:`${PROF_COLORS[s.sender_profile]||'#6b7280'}22`,
                             display:'flex', alignItems:'center', justifyContent:'center',
                             fontSize:12, fontWeight:700, color:PROF_COLORS[s.sender_profile]||'#6b7280' }}>
                          {(s.sender_name||s.sender_email||'?')[0].toUpperCase()}
                        </div>
                        <div style={{ flex:1, minWidth:0 }}>
                          <div style={{ fontSize:12, fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                            {s.sender_name || s.sender_email}
                            {s.sender_is_vip ? ' ⭐' : ''}
                          </div>
                          <div style={{ fontSize:10, color:'#475569' }}>{s.sender_email}</div>
                        </div>
                        <DimensionBadge label={s.sender_profile} color={PROF_COLORS[s.sender_profile]||'#6b7280'} />
                        <div style={{ textAlign:'right', minWidth:50 }}>
                          <div style={{ fontSize:14, fontWeight:700, fontFamily:'monospace', color:'#f1f5f9' }}>{s.c}</div>
                          <div style={{ fontSize:9, color:'#475569' }}>imp: {Math.round(s.avg_imp)}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          )}
        </div>
      </div>

      {/* Toasts */}
      <div style={{ position:'fixed', bottom:20, right:20, display:'flex', flexDirection:'column', gap:8, zIndex:999 }}>
        {toasts.map(t=>(
          <div key={t.id} style={{
            display:'flex', alignItems:'center', gap:10, padding:'10px 16px', borderRadius:10,
            background:'#0f172a', border:`1px solid ${t.type==='success'?'#22c55e':t.type==='error'?'#ef4444':'#334155'}`,
            fontSize:13, animation:'slideIn .25s ease',
          }}>
            <span>{t.type==='success'?'✅':t.type==='error'?'❌':'ℹ️'}</span>
            <span style={{ color:'#f1f5f9' }}>{t.msg}</span>
          </div>
        ))}
      </div>

      <style>{`
        @keyframes slideIn { from{transform:translateX(100%);opacity:0} to{transform:translateX(0);opacity:1} }
        ::-webkit-scrollbar{width:5px} ::-webkit-scrollbar-track{background:transparent}
        ::-webkit-scrollbar-thumb{background:#334155;border-radius:3px}
        *{box-sizing:border-box;margin:0;padding:0}
        button:hover{opacity:.85}
      `}</style>
    </div>
  )
}
