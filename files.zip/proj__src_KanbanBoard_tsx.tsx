// ============================================================
// src/components/KanbanBoard.tsx
// Vista Kanban — arrastra emails entre columnas de urgencia
// ============================================================
import { useState, useEffect } from 'react';
import { useStore } from '@/store/useStore';
import type { Email, UrgencyLevel } from '@/types';

const COLUMNS: { id: UrgencyLevel; label: string; color: string; icon: string }[] = [
  { id: 'critica', label: 'Crítica',  color: '#ef4444', icon: '🔴' },
  { id: 'alta',    label: 'Alta',     color: '#f97316', icon: '🟠' },
  { id: 'media',   label: 'Media',    color: '#eab308', icon: '🟡' },
  { id: 'baja',    label: 'Baja',     color: '#22c55e', icon: '🟢' },
];

const IMP_COLORS: Record<string, string> = {
  critica:'#ef4444', alta:'#f97316', media:'#eab308', baja:'#22c55e', info:'#6b7280'
};

export default function KanbanBoard() {
  const { emails, fetchEmails, updateEmailUrgency, setSelectedEmail, addToast } = useStore();
  const [dragging, setDragging] = useState<number | null>(null);
  const [dragOver,  setDragOver] = useState<UrgencyLevel | null>(null);

  useEffect(() => { fetchEmails(true); }, []);

  // Agrupar emails por urgencia
  const grouped = COLUMNS.reduce((acc, col) => {
    acc[col.id] = emails.filter(e => e.urgency_level === col.id);
    return acc;
  }, {} as Record<UrgencyLevel, Email[]>);

  const handleDrop = async (targetCol: UrgencyLevel) => {
    if (dragging === null || dragging === undefined) return;
    const email = emails.find(e => e.id === dragging);
    if (!email || email.urgency_level === targetCol) { setDragging(null); setDragOver(null); return; }
    try {
      await updateEmailUrgency(dragging, targetCol);
      addToast(`Email movido a urgencia: ${targetCol}`, 'success');
    } catch { addToast('Error al mover el email', 'error'); }
    setDragging(null); setDragOver(null);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, height: '100%' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h2 style={{ fontSize: 18, fontWeight: 600 }}>Kanban de Urgencia</h2>
        <span className="pill">Arrastra emails entre columnas para reclasificar</span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, flex: 1, minHeight: 0 }}>
        {COLUMNS.map(col => {
          const colEmails = grouped[col.id] || [];
          const isOver = dragOver === col.id;
          return (
            <div key={col.id}
              style={{
                background: isOver ? `${col.color}11` : 'var(--bg-surface)',
                border: `1px solid ${isOver ? col.color : 'var(--border-dim)'}`,
                borderRadius: 'var(--radius-lg)',
                display: 'flex', flexDirection: 'column', overflow: 'hidden',
                transition: 'all .15s',
              }}
              onDragOver={e => { e.preventDefault(); setDragOver(col.id); }}
              onDragLeave={() => setDragOver(null)}
              onDrop={() => handleDrop(col.id)}
            >
              {/* Header de columna */}
              <div style={{
                padding: '12px 14px', borderBottom: '1px solid var(--border-dim)',
                display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0,
                borderTop: `3px solid ${col.color}`,
              }}>
                <span>{col.icon}</span>
                <span style={{ fontWeight: 600, fontSize: 13 }}>{col.label}</span>
                <span style={{
                  marginLeft: 'auto', background: `${col.color}22`, color: col.color,
                  borderRadius: 'var(--radius-full)', padding: '1px 8px', fontSize: 11, fontWeight: 600,
                }}>{colEmails.length}</span>
              </div>

              {/* Cards */}
              <div style={{ flex: 1, overflowY: 'auto', padding: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
                {colEmails.length === 0 ? (
                  <div style={{
                    border: `2px dashed ${isOver ? col.color : 'var(--border-dim)'}`,
                    borderRadius: 'var(--radius-md)', padding: 20,
                    textAlign: 'center', fontSize: 12, color: 'var(--text-tertiary)',
                  }}>
                    {isOver ? 'Suelta aquí' : 'Sin emails'}
                  </div>
                ) : (
                  colEmails.map(email => (
                    <div key={email.id}
                      draggable
                      onDragStart={() => setDragging(email.id)}
                      onDragEnd={() => { setDragging(null); setDragOver(null); }}
                      onClick={() => setSelectedEmail(email)}
                      style={{
                        background: dragging === email.id ? 'var(--bg-overlay)' : 'var(--bg-elevated)',
                        border: '1px solid var(--border-dim)', borderRadius: 'var(--radius-md)',
                        padding: '10px 12px', cursor: 'grab', opacity: dragging === email.id ? .5 : 1,
                        transition: 'all .12s',
                        borderLeft: `3px solid ${IMP_COLORS[email.importance_label] || '#6b7280'}`,
                      }}
                    >
                      {/* Score badge */}
                      <div style={{ display:'flex', justifyContent:'space-between', marginBottom: 5 }}>
                        <span style={{
                          fontSize: 10, fontFamily:'var(--font-mono)', fontWeight:600,
                          color: IMP_COLORS[email.importance_label],
                        }}>{email.importance_score}</span>
                        <span style={{ fontSize: 13 }}>{email.sentiment_emoji}</span>
                      </div>
                      {/* Remitente */}
                      <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 3,
                        overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                        {email.sender_name || email.sender_email}
                        {email.sender_is_vip && ' ⭐'}
                      </div>
                      {/* Asunto */}
                      <div style={{ fontSize: 11, color:'var(--text-secondary)',
                        overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', marginBottom: 6 }}>
                        {email.subject}
                      </div>
                      {/* Deadline si existe */}
                      {email.urgency_deadline && (
                        <div style={{ fontSize:10, color:'var(--warning)', display:'flex', gap:4, alignItems:'center' }}>
                          <span>📅</span><span>{email.urgency_deadline}</span>
                        </div>
                      )}
                      {/* Acciones pendientes */}
                      {email.urgency_actions?.length > 0 && (
                        <div style={{ fontSize:10, color:'var(--text-tertiary)', marginTop:4 }}>
                          {email.urgency_actions.length} acción{email.urgency_actions.length > 1 ? 'es' : ''} pendiente{email.urgency_actions.length > 1 ? 's' : ''}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
