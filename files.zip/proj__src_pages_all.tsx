// ============================================================
// src/pages/Dashboard.tsx — KPIs + 4 gráficas + top senders
// ============================================================
import { useEffect, useState } from 'react';
import { ResponsiveContainer, PieChart, Pie, Cell, BarChart,
         Bar, XAxis, YAxis, Tooltip, AreaChart, Area } from 'recharts';
import { useStore } from '@/store/useStore';
import { api } from '@/services/api';

const IMP_C: Record<string,string> = {critica:'#ef4444',alta:'#f97316',media:'#eab308',baja:'#22c55e',info:'#6b7280'};
const SEN_C: Record<string,string> = {positivo:'#10b981',negativo:'#ef4444',neutral:'#6b7280',mixto:'#f59e0b'};
const PRF_C: Record<string,string> = {cliente:'#6366f1',proveedor:'#f59e0b',colega:'#10b981',jefe:'#ef4444',externo:'#6b7280',interno:'#3b82f6',desconocido:'#4b5563'};
const URG_C: Record<string,string> = {critica:'#ef4444',alta:'#f97316',media:'#eab308',baja:'#22c55e',ninguna:'#374151'};

export default function Dashboard() {
  const { stats, statsLoading, fetchStats, patterns, fetchPatterns, setPage, setFilters, addToast } = useStore();
  const [digest, setDigest] = useState<{narrative?:string;key_insights?:string[]}|null>(null);

  useEffect(() => { fetchStats(); fetchPatterns(); }, []);
  useEffect(() => {
    api.digest().then(setDigest).catch(()=>{});
  }, []);

  if (statsLoading) return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:400,gap:14}}>
      <div className="spinner" /> <span style={{color:'var(--text-secondary)'}}>Cargando estadísticas...</span>
    </div>
  );

  if (!stats || stats.total === 0) return (
    <div className="empty-state">
      <div className="empty-state-icon">📧</div>
      <div className="empty-state-title">Bienvenido a MailAI Panel</div>
      <p className="empty-state-sub">Haz clic en "Clasificar Outlook" para leer y clasificar todos tus correos con IA local.</p>
      <button className="btn btn-primary btn-lg">⟳ Clasificar ahora</button>
    </div>
  );

  return (
    <div style={{display:'flex',flexDirection:'column',gap:20}}>

      {/* Modo foco banner */}
      {patterns.length > 0 && (
        <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
          {(patterns as {id:string;icon:string;title:string;description:string;severity:string;action:string}[]).map(p=>(
            <div key={p.id} style={{
              display:'flex',gap:10,alignItems:'flex-start',padding:'10px 14px',
              background: p.severity==='critical'?'var(--danger-muted)':p.severity==='warning'?'var(--warning-muted)':'var(--info-muted)',
              border:`1px solid ${p.severity==='critical'?'rgba(239,68,68,.3)':p.severity==='warning'?'rgba(245,158,11,.3)':'rgba(59,130,246,.3)'}`,
              borderRadius:'var(--radius-md)',flex:1,minWidth:260,
            }}>
              <span style={{fontSize:18}}>{p.icon}</span>
              <div>
                <div style={{fontSize:12,fontWeight:600,marginBottom:3}}>{p.title}</div>
                <div style={{fontSize:11,color:'var(--text-secondary)'}}>{p.description}</div>
                {p.action&&<div style={{fontSize:11,color:'var(--accent)',marginTop:4}}>→ {p.action}</div>}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* KPIs */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:14}}>
        {[
          {icon:'📧',value:stats.total,label:'Total emails',color:'var(--accent)'},
          {icon:'🔴',value:stats.by_importance?.find((i:{importance_label:string;c:number})=>i.importance_label==='critica')?.c||0,label:'Críticos',color:'#ef4444'},
          {icon:'⭐',value:stats.vip_count||0,label:'VIP detectados',color:'#f59e0b'},
          {icon:'📊',value:`${Math.round(stats.avg_importance||0)}/100`,label:'Importancia media',color:'#10b981'},
        ].map((kpi,i)=>(
          <div key={i} className="kpi-card" onClick={()=>{
            if(i===1){setFilters({importance_label:'critica'});setPage('inbox');}
            if(i===2){setFilters({is_vip:true});setPage('inbox');}
          }} style={{cursor:i===1||i===2?'pointer':'default'}}>
            <div className="kpi-accent" style={{background:kpi.color}}/>
            <span className="kpi-icon">{kpi.icon}</span>
            <div>
              <div className="kpi-value" style={{color:kpi.color}}>{kpi.value}</div>
              <div className="kpi-label">{kpi.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* 4 Gráficas de dimensiones */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:14}}>
        {/* Importancia */}
        <div className="card">
          <div className="card-header"><span className="card-title">📊 Importancia</span></div>
          <div className="card-body">
            <ResponsiveContainer width="100%" height={130}>
              <PieChart>
                <Pie data={(stats.by_importance||[]).map((d:{importance_label:string;c:number})=>({name:d.importance_label,value:d.c}))}
                  dataKey="value" cx="50%" cy="50%" innerRadius={35} outerRadius={58}>
                  {(stats.by_importance||[]).map((d:{importance_label:string},i:number)=>(
                    <Cell key={i} fill={IMP_C[d.importance_label]||'#6b7280'} />
                  ))}
                </Pie>
                <Tooltip formatter={(v:number,_:string,p:{payload:{name:string}})=>[v,p.payload.name]}/>
              </PieChart>
            </ResponsiveContainer>
            {(stats.by_importance||[]).map((d:{importance_label:string;c:number})=>(
              <div key={d.importance_label} onClick={()=>{setFilters({importance_label:d.importance_label as any});setPage('inbox');}}
                style={{display:'flex',gap:6,alignItems:'center',fontSize:11,padding:'3px 0',cursor:'pointer',
                  borderBottom:'1px solid var(--border-dim)'}}>
                <span style={{width:7,height:7,borderRadius:'50%',background:IMP_C[d.importance_label],flexShrink:0}}/>
                <span style={{flex:1,color:'var(--text-secondary)'}}>{d.importance_label}</span>
                <span style={{fontWeight:600}}>{d.c}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Sentimiento */}
        <div className="card">
          <div className="card-header"><span className="card-title">💬 Sentimiento</span></div>
          <div className="card-body">
            <ResponsiveContainer width="100%" height={130}>
              <PieChart>
                <Pie data={(stats.by_sentiment||[]).map((d:{sentiment_label:string;c:number})=>({name:d.sentiment_label,value:d.c}))}
                  dataKey="value" cx="50%" cy="50%" outerRadius={58}>
                  {(stats.by_sentiment||[]).map((d:{sentiment_label:string},i:number)=>(
                    <Cell key={i} fill={SEN_C[d.sentiment_label]||'#6b7280'} />
                  ))}
                </Pie>
                <Tooltip formatter={(v:number,_:string,p:{payload:{name:string}})=>[v,p.payload.name]}/>
              </PieChart>
            </ResponsiveContainer>
            {(stats.by_sentiment||[]).map((d:{sentiment_label:string;c:number})=>(
              <div key={d.sentiment_label} onClick={()=>{setFilters({sentiment_label:d.sentiment_label as any});setPage('inbox');}}
                style={{display:'flex',gap:6,alignItems:'center',fontSize:11,padding:'3px 0',cursor:'pointer',
                  borderBottom:'1px solid var(--border-dim)'}}>
                <span style={{width:7,height:7,borderRadius:'50%',background:SEN_C[d.sentiment_label],flexShrink:0}}/>
                <span style={{flex:1,color:'var(--text-secondary)'}}>{d.sentiment_label}</span>
                <span style={{fontWeight:600}}>{d.c}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Remitentes */}
        <div className="card">
          <div className="card-header"><span className="card-title">👤 Remitentes</span></div>
          <div className="card-body">
            <ResponsiveContainer width="100%" height={130}>
              <BarChart data={(stats.by_profile||[]).slice(0,5).map((d:{sender_profile:string;c:number})=>({name:d.sender_profile,c:d.c}))}
                layout="vertical" margin={{left:0,right:10}}>
                <XAxis type="number" hide/>
                <YAxis type="category" dataKey="name" width={80} tick={{fontSize:10,fill:'var(--text-secondary)'}}/>
                <Tooltip/>
                <Bar dataKey="c" radius={[0,4,4,0]}>
                  {(stats.by_profile||[]).slice(0,5).map((d:{sender_profile:string},i:number)=>(
                    <Cell key={i} fill={PRF_C[d.sender_profile]||'#6b7280'}
                      style={{cursor:'pointer'}}
                      onClick={()=>{setFilters({sender_profile:d.sender_profile as any});setPage('inbox');}}/>
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Urgencia */}
        <div className="card">
          <div className="card-header"><span className="card-title">⚡ Urgencia</span></div>
          <div className="card-body">
            <ResponsiveContainer width="100%" height={130}>
              <BarChart data={(stats.by_urgency||[]).filter((d:{urgency_level:string})=>d.urgency_level!=='ninguna').map((d:{urgency_level:string;c:number})=>({name:d.urgency_level,c:d.c}))}
                layout="vertical" margin={{left:0,right:10}}>
                <XAxis type="number" hide/>
                <YAxis type="category" dataKey="name" width={60} tick={{fontSize:10,fill:'var(--text-secondary)'}}/>
                <Tooltip/>
                <Bar dataKey="c" radius={[0,4,4,0]}>
                  {(stats.by_urgency||[]).filter((d:{urgency_level:string})=>d.urgency_level!=='ninguna').map((d:{urgency_level:string},i:number)=>(
                    <Cell key={i} fill={URG_C[d.urgency_level]||'#6b7280'}
                      style={{cursor:'pointer'}}
                      onClick={()=>{setFilters({urgency_level:d.urgency_level as any});setPage('inbox');}}/>
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Tendencia 30 días + Top senders */}
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
        {/* Tendencia */}
        <div className="card">
          <div className="card-header"><span className="card-title">📈 Volumen últimos 30 días</span></div>
          <div className="card-body">
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={(stats.by_day||[]).map((d:{day:string;c:number;avg_imp:number})=>({
                day:d.day.slice(5),emails:d.c,importancia:Math.round(d.avg_imp)
              }))}>
                <XAxis dataKey="day" tick={{fontSize:10,fill:'var(--text-secondary)'}} tickLine={false}/>
                <YAxis tick={{fontSize:10,fill:'var(--text-secondary)'}} tickLine={false} axisLine={false}/>
                <Tooltip/>
                <Area type="monotone" dataKey="emails" stroke="var(--accent)" fill="var(--accent-muted)" strokeWidth={2}/>
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top senders */}
        <div className="card">
          <div className="card-header"><span className="card-title">🏆 Top Remitentes</span></div>
          <div className="card-body" style={{display:'flex',flexDirection:'column',gap:0}}>
            {(stats.top_senders||[]).slice(0,6).map((s:{sender_email:string;sender_name:string;sender_profile:string;sender_trust:number;sender_is_vip:boolean;c:number;avg_imp:number},i:number)=>(
              <div key={s.sender_email} style={{
                display:'flex',alignItems:'center',gap:10,
                padding:'8px 0',borderBottom:'1px solid var(--border-dim)',cursor:'pointer',
              }} onClick={()=>{setFilters({search:s.sender_email});setPage('inbox');}}>
                <span style={{fontSize:11,color:'var(--text-tertiary)',width:18,textAlign:'right'}}>#{i+1}</span>
                <div style={{
                  width:28,height:28,borderRadius:'50%',flexShrink:0,
                  background:`${PRF_C[s.sender_profile]||'#6b7280'}22`,
                  display:'flex',alignItems:'center',justifyContent:'center',
                  fontSize:12,fontWeight:700,color:PRF_C[s.sender_profile]||'#6b7280',
                }}>{(s.sender_name||s.sender_email||'?')[0].toUpperCase()}</div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:12,fontWeight:500,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                    {s.sender_name||s.sender_email}{s.sender_is_vip?' ⭐':''}
                  </div>
                  <div style={{fontSize:10,color:'var(--text-tertiary)'}}>{s.sender_email}</div>
                </div>
                <span style={{
                  background:`${PRF_C[s.sender_profile]||'#6b7280'}22`,color:PRF_C[s.sender_profile]||'#6b7280',
                  borderRadius:'var(--radius-full)',padding:'1px 7px',fontSize:10,fontWeight:600,
                }}>{s.sender_profile}</span>
                <div style={{textAlign:'right',minWidth:40}}>
                  <div style={{fontSize:14,fontWeight:700,fontFamily:'var(--font-mono)'}}>{s.c}</div>
                  <div style={{fontSize:9,color:'var(--text-tertiary)'}}>imp {Math.round(s.avg_imp)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Digest semanal */}
      {digest?.narrative && (
        <div className="card">
          <div className="card-header">
            <span className="card-title">📋 Digest Semanal — Generado por Ollama</span>
          </div>
          <div className="card-body">
            <p style={{fontSize:13,color:'var(--text-secondary)',lineHeight:1.7,marginBottom:12}}>
              {digest.narrative}
            </p>
            {digest.key_insights && (
              <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
                {digest.key_insights.map((ins:string,i:number)=>(
                  <span key={i} className="pill">💡 {ins}</span>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}


// ============================================================
// src/pages/Inbox.tsx — Lista de emails con filtros
// ============================================================
import { useEffect } from 'react';
import { useStore } from '@/store/useStore';
import { api } from '@/services/api';
import type { Email } from '@/types';

const IMP_COLORS: Record<string,string> = {critica:'#ef4444',alta:'#f97316',media:'#eab308',baja:'#22c55e',info:'#6b7280'};
const URG_COLORS: Record<string,string> = {critica:'#ef4444',alta:'#f97316',media:'#eab308',baja:'#22c55e',ninguna:'#374151'};
const PRF_COLORS: Record<string,string> = {cliente:'#6366f1',proveedor:'#f59e0b',colega:'#10b981',jefe:'#ef4444',externo:'#6b7280',interno:'#3b82f6',desconocido:'#4b5563'};

function EmailDetailPanel({ email, onClose }: { email: Email; onClose: () => void }) {
  const { addToast } = useStore();
  const actions = Array.isArray(email.urgency_actions) ? email.urgency_actions : [];
  const handleQuickReply = async () => {
    try { await api.emails.quickReply(email.id); addToast('Abriendo en Outlook...','info'); }
    catch { addToast('Error al abrir Outlook','error'); }
  };
  return (
    <div style={{ width: 380, background:'var(--bg-surface)', borderLeft:'1px solid var(--border-dim)',
      display:'flex', flexDirection:'column', height:'100%', flexShrink:0 }}>
      {/* Header */}
      <div style={{padding:'14px 16px',borderBottom:'1px solid var(--border-dim)',flexShrink:0}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',gap:10}}>
          <h3 style={{fontSize:13,fontWeight:600,lineHeight:1.4,flex:1}}>{email.subject}</h3>
          <button className="btn-icon" onClick={onClose}>✕</button>
        </div>
        <div style={{fontSize:11,color:'var(--text-secondary)',marginTop:6}}>
          {email.sender_name} · {email.sender_email}
        </div>
        <div style={{fontSize:11,color:'var(--text-tertiary)',marginTop:2}}>
          {new Date(email.date).toLocaleString('es-CO')}
        </div>
      </div>
      {/* 4 dimensiones */}
      <div style={{flex:1,overflowY:'auto',padding:14,display:'flex',flexDirection:'column',gap:12}}>
        {/* Importancia */}
        <div style={{background:'var(--bg-elevated)',borderRadius:'var(--radius-md)',padding:12,
          borderLeft:`3px solid ${email.importance_color||IMP_COLORS[email.importance_label]}`}}>
          <div style={{fontSize:10,fontWeight:600,color:'var(--text-tertiary)',textTransform:'uppercase',letterSpacing:.5,marginBottom:8}}>
            📊 Importancia
          </div>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
            <span style={{background:`${email.importance_color}22`,color:email.importance_color,
              borderRadius:'var(--radius-full)',padding:'2px 10px',fontSize:11,fontWeight:600}}>
              {email.importance_label}
            </span>
          </div>
          <div className="score-bar-wrap">
            <div className="score-bar-track">
              <div className="score-bar-fill" style={{width:`${email.importance_score}%`,background:email.importance_color||IMP_COLORS[email.importance_label]}}/>
            </div>
            <span className="score-bar-val">{email.importance_score}</span>
          </div>
          {email.importance_reason && (
            <div style={{fontSize:11,color:'var(--text-secondary)',marginTop:8,lineHeight:1.5}}>{email.importance_reason}</div>
          )}
        </div>
        {/* Sentimiento */}
        <div style={{background:'var(--bg-elevated)',borderRadius:'var(--radius-md)',padding:12,
          borderLeft:`3px solid var(--sent-${email.sentiment_label})`}}>
          <div style={{fontSize:10,fontWeight:600,color:'var(--text-tertiary)',textTransform:'uppercase',letterSpacing:.5,marginBottom:8}}>
            💬 Sentimiento
          </div>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <span style={{fontSize:28}}>{email.sentiment_emoji}</span>
            <div>
              <span style={{fontSize:11,fontWeight:600,color:`var(--sent-${email.sentiment_label})`}}>{email.sentiment_label}</span>
              <div style={{fontSize:11,color:'var(--text-tertiary)',marginTop:2}}>Tono: {email.sentiment_tone}</div>
            </div>
            <div style={{marginLeft:'auto',textAlign:'right'}}>
              <div style={{fontSize:18,fontWeight:700,fontFamily:'var(--font-mono)'}}>
                {(email.sentiment_score>=0?'+':'')+Number(email.sentiment_score).toFixed(2)}
              </div>
            </div>
          </div>
        </div>
        {/* Remitente */}
        <div style={{background:'var(--bg-elevated)',borderRadius:'var(--radius-md)',padding:12,
          borderLeft:`3px solid ${PRF_COLORS[email.sender_profile]||'#6b7280'}`}}>
          <div style={{fontSize:10,fontWeight:600,color:'var(--text-tertiary)',textTransform:'uppercase',letterSpacing:.5,marginBottom:8}}>
            👤 Remitente
          </div>
          <div style={{display:'flex',gap:8,alignItems:'center',marginBottom:8}}>
            <div style={{width:32,height:32,borderRadius:'50%',flexShrink:0,
              background:`${PRF_COLORS[email.sender_profile]||'#6b7280'}22`,
              display:'flex',alignItems:'center',justifyContent:'center',
              fontSize:14,fontWeight:700,color:PRF_COLORS[email.sender_profile]||'#6b7280'}}>
              {(email.sender_name||email.sender_email||'?')[0].toUpperCase()}
            </div>
            <div>
              <div style={{fontSize:13,fontWeight:600}}>{email.sender_name}{email.sender_is_vip?' ⭐':''}</div>
              <div style={{fontSize:11,color:'var(--text-secondary)'}}>{email.sender_email}</div>
            </div>
          </div>
          <span style={{background:`${PRF_COLORS[email.sender_profile]}22`,color:PRF_COLORS[email.sender_profile]||'#6b7280',
            borderRadius:'var(--radius-full)',padding:'2px 10px',fontSize:11,fontWeight:600}}>
            {email.sender_profile}
          </span>
          <div style={{marginTop:8}}>
            <div style={{fontSize:10,color:'var(--text-tertiary)',marginBottom:4}}>Confianza</div>
            <div className="score-bar-wrap">
              <div className="score-bar-track">
                <div className="score-bar-fill" style={{width:`${email.sender_trust}%`,background:PRF_COLORS[email.sender_profile]||'#6b7280'}}/>
              </div>
              <span className="score-bar-val">{email.sender_trust}</span>
            </div>
          </div>
          {email.sender_relation&&<div style={{fontSize:11,color:'var(--text-secondary)',marginTop:8,fontStyle:'italic'}}>"{email.sender_relation}"</div>}
        </div>
        {/* Urgencia */}
        <div style={{background:'var(--bg-elevated)',borderRadius:'var(--radius-md)',padding:12,
          borderLeft:`3px solid ${email.urgency_color||URG_COLORS[email.urgency_level]}`}}>
          <div style={{fontSize:10,fontWeight:600,color:'var(--text-tertiary)',textTransform:'uppercase',letterSpacing:.5,marginBottom:8}}>
            ⚡ Urgencia
          </div>
          <span style={{background:`${email.urgency_color||URG_COLORS[email.urgency_level]}22`,
            color:email.urgency_color||URG_COLORS[email.urgency_level],
            borderRadius:'var(--radius-full)',padding:'2px 10px',fontSize:11,fontWeight:600}}>
            {email.urgency_level}
          </span>
          {email.urgency_deadline&&<div style={{fontSize:11,color:'var(--warning)',marginTop:8}}>📅 Deadline: {email.urgency_deadline}</div>}
          {actions.length>0&&(
            <div style={{marginTop:10}}>
              <div style={{fontSize:10,color:'var(--text-tertiary)',marginBottom:6}}>ACCIONES REQUERIDAS</div>
              {actions.map((a:string,i:number)=>(
                <div key={i} style={{display:'flex',gap:8,padding:'5px 0',borderBottom:'1px solid var(--border-dim)',fontSize:12,color:'var(--text-secondary)'}}>
                  <span style={{color:email.urgency_color||'var(--warning)'}}>→</span><span>{a}</span>
                </div>
              ))}
            </div>
          )}
          {email.urgency_reply&&(
            <div style={{marginTop:10}}>
              <div style={{fontSize:10,color:'var(--text-tertiary)',marginBottom:6}}>RESPUESTA SUGERIDA</div>
              <div style={{background:'var(--bg-subtle)',borderRadius:'var(--radius-sm)',padding:10,
                fontSize:11,color:'var(--text-secondary)',lineHeight:1.6,fontStyle:'italic'}}>
                {email.urgency_reply}
              </div>
              <div style={{display:'flex',gap:8,marginTop:8}}>
                <button className="btn btn-secondary btn-sm" onClick={()=>{navigator.clipboard.writeText(email.urgency_reply);addToast('Respuesta copiada','success');}}>
                  📋 Copiar
                </button>
                <button className="btn btn-primary btn-sm" onClick={handleQuickReply}>
                  📤 Abrir en Outlook
                </button>
              </div>
            </div>
          )}
        </div>
        {/* Resumen */}
        {email.summary&&(
          <div style={{background:'var(--bg-elevated)',borderRadius:'var(--radius-md)',padding:12}}>
            <div style={{fontSize:10,color:'var(--text-tertiary)',marginBottom:6,textTransform:'uppercase',letterSpacing:.5}}>📝 Resumen IA</div>
            <div style={{fontSize:12,color:'var(--text-secondary)',lineHeight:1.6}}>{email.summary}</div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function Inbox() {
  const { emails, emailsLoading, fetchEmails, filters, setFilters,
          clearFilters, selectedEmail, setSelectedEmail, focusMode } = useStore();

  useEffect(() => { fetchEmails(true); }, []);

  const FILTER_PILLS = [
    {label:'Críticos',filter:{importance_label:'critica'},color:'#ef4444'},
    {label:'Urgentes',filter:{urgency_level:'critica'},color:'#f97316'},
    {label:'VIP',filter:{is_vip:true},color:'#f59e0b'},
    {label:'Negativos',filter:{sentiment_label:'negativo'},color:'#ef4444'},
    {label:'Clientes',filter:{sender_profile:'cliente'},color:'#6366f1'},
  ];

  return (
    <div style={{display:'flex',gap:0,height:'calc(100vh - var(--topbar-h) - 40px)',overflow:'hidden'}}>
      <div style={{flex:1,display:'flex',flexDirection:'column',overflow:'hidden'}}>
        {/* Filtros rápidos */}
        <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:14,flexShrink:0}}>
          {FILTER_PILLS.map((p,i)=>(
            <button key={i} className="pill" style={{cursor:'pointer',color:p.color,borderColor:`${p.color}44`,
              background:`${p.color}11`}}
              onClick={()=>setFilters(p.filter as any)}>
              {p.label}
            </button>
          ))}
          {Object.keys(filters).length>0&&(
            <button className="btn btn-ghost btn-sm" onClick={clearFilters}>✕ Limpiar</button>
          )}
        </div>
        {/* Lista */}
        <div style={{flex:1,overflowY:'auto',background:'var(--bg-surface)',
          border:'1px solid var(--border-dim)',borderRadius:'var(--radius-lg)',overflow:'hidden'}}>
          <div style={{padding:'10px 14px',borderBottom:'1px solid var(--border-dim)',
            fontSize:12,fontWeight:600,color:'var(--text-secondary)',flexShrink:0}}>
            {emails.length} emails {focusMode?'(modo foco)':''}
          </div>
          {emailsLoading?(
            <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:200,gap:12}}>
              <div className="spinner spinner-sm"/><span style={{color:'var(--text-secondary)'}}>Cargando...</span>
            </div>
          ):emails.length===0?(
            <div className="empty-state"><div className="empty-state-icon">🔍</div>
              <div className="empty-state-title">Sin emails</div>
              <p className="empty-state-sub">Prueba con otros filtros o sincroniza Outlook.</p></div>
          ):(
            <div>
              {emails.map(email=>(
                <div key={email.id} onClick={()=>setSelectedEmail(selectedEmail?.id===email.id?null:email)}
                  style={{
                    padding:'10px 14px',cursor:'pointer',borderBottom:'1px solid var(--border-dim)',
                    background:selectedEmail?.id===email.id?'var(--bg-overlay)':'transparent',
                    borderLeft:selectedEmail?.id===email.id?'3px solid var(--accent)':'3px solid transparent',
                    transition:'background .1s',
                  }}>
                  <div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}>
                    <span style={{fontSize:12,fontWeight:600,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',flex:1}}>
                      {email.sender_name||email.sender_email}
                      {email.sender_is_vip&&' ⭐'}
                    </span>
                    <span style={{fontSize:10,color:'var(--text-tertiary)',whiteSpace:'nowrap',marginLeft:8}}>
                      {new Date(email.date).toLocaleDateString('es-CO')}
                    </span>
                  </div>
                  <div style={{fontSize:12,color:'var(--text-secondary)',marginBottom:6,
                    overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                    {email.subject}
                  </div>
                  <div style={{display:'flex',gap:6,alignItems:'center',flexWrap:'wrap'}}>
                    <div style={{display:'flex',alignItems:'center',gap:4}}>
                      <div style={{width:6,height:6,borderRadius:'50%',background:email.importance_color||IMP_COLORS[email.importance_label]}}/>
                      <span style={{fontSize:10,color:'var(--text-tertiary)',fontFamily:'var(--font-mono)'}}>{email.importance_score}</span>
                    </div>
                    <span style={{fontSize:13}}>{email.sentiment_emoji}</span>
                    <span style={{background:`${PRF_COLORS[email.sender_profile]||'#6b7280'}22`,
                      color:PRF_COLORS[email.sender_profile]||'#6b7280',
                      borderRadius:'var(--radius-full)',padding:'1px 7px',fontSize:10,fontWeight:600}}>
                      {email.sender_profile}
                    </span>
                    {email.urgency_level!=='ninguna'&&(
                      <span style={{background:`${email.urgency_color||URG_COLORS[email.urgency_level]}22`,
                        color:email.urgency_color||URG_COLORS[email.urgency_level],
                        borderRadius:'var(--radius-full)',padding:'1px 7px',fontSize:10,fontWeight:600}}>
                        {email.urgency_level}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      {selectedEmail&&<EmailDetailPanel email={selectedEmail} onClose={()=>setSelectedEmail(null)}/>}
    </div>
  );
}


// ============================================================
// src/pages/Analytics.tsx
// ============================================================
import { useEffect } from 'react';
import { useStore } from '@/store/useStore';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip,
         LineChart, Line, CartesianGrid, Legend } from 'recharts';

export function Analytics() {
  const { stats, statsLoading, fetchStats } = useStore();
  useEffect(()=>{fetchStats();},[]);
  if(statsLoading||!stats) return <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:300}}><div className="spinner"/></div>;
  return (
    <div style={{display:'flex',flexDirection:'column',gap:18}}>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
        <div className="card">
          <div className="card-header"><span className="card-title">Importancia por día</span></div>
          <div className="card-body">
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={(stats.by_day||[]).map((d:{day:string;c:number;avg_imp:number})=>({day:d.day.slice(5),avg_imp:Math.round(d.avg_imp),emails:d.c}))}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border-dim)"/>
                <XAxis dataKey="day" tick={{fontSize:10,fill:'var(--text-secondary)'}}/>
                <YAxis tick={{fontSize:10,fill:'var(--text-secondary)'}}/>
                <Tooltip/>
                <Legend/>
                <Line type="monotone" dataKey="avg_imp" stroke="var(--accent)" strokeWidth={2} dot={false} name="Importancia"/>
                <Line type="monotone" dataKey="emails" stroke="var(--success)" strokeWidth={2} dot={false} name="Emails"/>
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="card">
          <div className="card-header"><span className="card-title">Tonos de comunicación</span></div>
          <div className="card-body">
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={(stats.by_tone||[]).map((d:{sentiment_tone:string;c:number})=>({name:d.sentiment_tone,c:d.c}))}>
                <XAxis dataKey="name" tick={{fontSize:10,fill:'var(--text-secondary)'}}/>
                <YAxis tick={{fontSize:10,fill:'var(--text-secondary)'}}/>
                <Tooltip/>
                <Bar dataKey="c" fill="var(--accent)" radius={[4,4,0,0]}/>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Analytics;


// ============================================================
// src/pages/Contacts.tsx
// ============================================================
import { useStore } from '@/store/useStore';

export function Contacts() {
  const { stats, setFilters, setPage } = useStore();
  const senders = stats?.top_senders || [];
  const PRF_COLORS: Record<string,string> = {cliente:'#6366f1',proveedor:'#f59e0b',colega:'#10b981',jefe:'#ef4444',externo:'#6b7280',interno:'#3b82f6',desconocido:'#4b5563'};
  return (
    <div style={{display:'flex',flexDirection:'column',gap:14}}>
      <h2 style={{fontSize:18,fontWeight:600}}>Directorio de Contactos</h2>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))',gap:12}}>
        {(senders as {sender_email:string;sender_name:string;sender_profile:string;sender_trust:number;sender_is_vip:boolean;c:number;avg_imp:number}[]).map(s=>(
          <div key={s.sender_email} className="card" style={{padding:16,cursor:'pointer',transition:'transform .15s'}}
            onClick={()=>{setFilters({search:s.sender_email});setPage('inbox');}}
            onMouseEnter={e=>(e.currentTarget.style.transform='translateY(-2px)')}
            onMouseLeave={e=>(e.currentTarget.style.transform='none')}>
            <div style={{display:'flex',gap:12,alignItems:'flex-start'}}>
              <div style={{width:42,height:42,borderRadius:'50%',flexShrink:0,
                background:`${PRF_COLORS[s.sender_profile]||'#6b7280'}22`,
                display:'flex',alignItems:'center',justifyContent:'center',
                fontSize:18,fontWeight:700,color:PRF_COLORS[s.sender_profile]||'#6b7280',
                borderTop:`2px solid ${PRF_COLORS[s.sender_profile]||'#6b7280'}`}}>
                {(s.sender_name||s.sender_email||'?')[0].toUpperCase()}
              </div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:13,fontWeight:600,marginBottom:2}}>
                  {s.sender_name||s.sender_email}{s.sender_is_vip?' ⭐':''}
                </div>
                <div style={{fontSize:11,color:'var(--text-secondary)',marginBottom:8,
                  overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{s.sender_email}</div>
                <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                  <span style={{background:`${PRF_COLORS[s.sender_profile]}22`,color:PRF_COLORS[s.sender_profile]||'#6b7280',
                    borderRadius:'var(--radius-full)',padding:'2px 8px',fontSize:10,fontWeight:600}}>
                    {s.sender_profile}
                  </span>
                  <span className="pill">{s.c} emails</span>
                  <span className="pill">imp {Math.round(s.avg_imp)}</span>
                </div>
                <div style={{marginTop:8}}>
                  <div style={{fontSize:10,color:'var(--text-tertiary)',marginBottom:3}}>Confianza</div>
                  <div className="score-bar-wrap">
                    <div className="score-bar-track">
                      <div className="score-bar-fill" style={{width:`${s.sender_trust}%`,background:PRF_COLORS[s.sender_profile]||'#6b7280'}}/>
                    </div>
                    <span className="score-bar-val">{s.sender_trust}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
export default Contacts;


// ============================================================
// src/pages/Settings.tsx
// ============================================================
import { useState } from 'react';
import { useStore } from '@/store/useStore';
import { api } from '@/services/api';

export function Settings() {
  const { health, fetchHealth, addToast } = useStore();
  const [model, setModel] = useState('llama3.2:3b');

  return (
    <div style={{display:'flex',flexDirection:'column',gap:18,maxWidth:700}}>
      <h2 style={{fontSize:18,fontWeight:600}}>Configuración</h2>

      <div className="card">
        <div className="card-header"><span className="card-title">Estado del sistema</span></div>
        <div className="card-body" style={{display:'flex',flexDirection:'column',gap:10}}>
          <button className="btn btn-secondary btn-sm" style={{alignSelf:'flex-start'}} onClick={fetchHealth}>
            ↻ Verificar estado
          </button>
          {health && (
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
              <div style={{background:'var(--bg-elevated)',borderRadius:'var(--radius-md)',padding:12}}>
                <div style={{fontSize:11,color:'var(--text-tertiary)',marginBottom:6}}>Ollama</div>
                <div style={{display:'flex',alignItems:'center',gap:8}}>
                  <span style={{width:8,height:8,borderRadius:'50%',
                    background:health.ollama.ollama_running?'var(--success)':'var(--danger)'}}/>
                  <span style={{fontSize:12}}>{health.ollama.ollama_running?'Corriendo':'Detenido'}</span>
                </div>
                <div style={{fontSize:11,color:'var(--text-secondary)',marginTop:4}}>Modelo: {health.ollama.model}</div>
              </div>
              <div style={{background:'var(--bg-elevated)',borderRadius:'var(--radius-md)',padding:12}}>
                <div style={{fontSize:11,color:'var(--text-tertiary)',marginBottom:6}}>Outlook</div>
                <div style={{display:'flex',alignItems:'center',gap:8}}>
                  <span style={{width:8,height:8,borderRadius:'50%',
                    background:health.outlook.outlook_available?'var(--success)':'var(--danger)'}}/>
                  <span style={{fontSize:12}}>{health.outlook.outlook_available?`${health.outlook.accounts_count} cuenta(s)`:'No disponible'}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="card">
        <div className="card-header"><span className="card-title">Modelos Ollama instalados</span></div>
        <div className="card-body">
          {health?.ollama.installed_models?.map((m:string)=>(
            <div key={m} style={{display:'flex',alignItems:'center',justifyContent:'space-between',
              padding:'8px 0',borderBottom:'1px solid var(--border-dim)'}}>
              <span style={{fontSize:12,fontFamily:'var(--font-mono)'}}>{m}</span>
              <button className="btn btn-secondary btn-sm" onClick={()=>{setModel(m);addToast(`Modelo cambiado a ${m}`,'info');}}>
                Usar
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <div className="card-header"><span className="card-title">Acerca de MailAI Panel</span></div>
        <div className="card-body">
          <p style={{fontSize:13,color:'var(--text-secondary)',lineHeight:1.7}}>
            MailAI Panel v2.0 — Clasificador de emails con IA local usando Ollama.<br/>
            Lee todas las cuentas abiertas en Microsoft Outlook simultáneamente.<br/>
            Sin envío de datos a servidores externos. Todo corre en tu máquina.
          </p>
        </div>
      </div>
    </div>
  );
}
export default Settings;
