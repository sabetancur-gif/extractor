// src/pages/Dashboard.jsx
import { useEffect } from 'react'
import { useStore } from '../store'
import { ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar,
         XAxis, YAxis, Tooltip, AreaChart, Area } from 'recharts'

const CAT_COLORS = {
  trabajo:'#6366f1', ventas_marketing:'#f59e0b', finanzas:'#10b981',
  soporte_tecnico:'#3b82f6', personal:'#ec4899', legal:'#ef4444',
  educacion:'#06b6d4', redes_sociales:'#8b5cf6', spam:'#6b7280', otro:'#94a3b8'
}
const PRI_COLORS = { urgente:'#ef4444', alta:'#f97316', media:'#eab308', baja:'#22c55e' }

export default function Dashboard() {
  const { stats, statsLoading, fetchStats, emails, setEmailFilters,
          setActivePage, syncing, syncProgress, syncMessage } = useStore()

  useEffect(() => { fetchStats() }, [])

  const goInbox = (filters) => {
    setEmailFilters(filters)
    setActivePage('inbox')
  }

  if (statsLoading && !stats) {
    return (
      <div className="loading-full">
        <div className="spinner" />
        <p>Cargando dashboard...</p>
      </div>
    )
  }

  if (!stats || stats.total === 0) {
    return (
      <div className="dashboard-empty">
        <div className="de-icon">✉</div>
        <h2>Bienvenido a MailAI Pro</h2>
        <p>Conecta tu cuenta de email para comenzar a clasificar y analizar tus correos con IA.</p>
        <button className="btn-primary btn-lg" onClick={() => setActivePage('settings')}>
          🔌 Conectar cuenta de email
        </button>
        <div className="de-features">
          {[
            { icon: '🤖', title: '10+ dimensiones IA', desc: 'Categoría, prioridad, sentimiento, entidades, acciones y más' },
            { icon: '⚡', title: 'Reglas automáticas', desc: 'Aplica reglas IF/THEN sobre cada email clasificado' },
            { icon: '📊', title: 'Analytics avanzado', desc: 'Tendencias, remitentes, tonos, idiomas y distribuciones' },
            { icon: '◉', title: 'CRM de contactos', desc: 'Perfil enriquecido de cada remitente con historial' },
          ].map(f => (
            <div key={f.title} className="de-feature">
              <span className="de-feature-icon">{f.icon}</span>
              <div>
                <div className="de-feature-title">{f.title}</div>
                <div className="de-feature-desc">{f.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  const urgentCount = stats.by_priority?.find(p => p.priority_label === 'urgente')?.count || 0
  const urgentActions = stats.urgent_action || []
  const catData = (stats.by_category || []).slice(0, 6)

  return (
    <div className="dashboard-page">
      {syncing && (
        <div className="sync-banner">
          <div className="sync-spinner" />
          <span>{syncMessage || 'Sincronizando...'}</span>
          <div className="sync-pbar">
            <div className="sync-pbar-fill" style={{ width: `${syncProgress || 0}%` }} />
          </div>
          <span className="sync-pct">{syncProgress || 0}%</span>
        </div>
      )}

      {/* KPI Row */}
      <div className="kpi-row">
        {[
          { icon:'📧', val: stats.total.toLocaleString(), label:'Total emails', color:'#6366f1', click: () => goInbox({}) },
          { icon:'⚡', val: stats.requires_action, label:'Requieren acción', color:'#ef4444', click: () => goInbox({ requires_action: true }) },
          { icon:'🔴', val: urgentCount, label:'Urgentes', color:'#f97316', click: () => goInbox({ priority_label: 'urgente' }) },
          { icon:'🚫', val: stats.spam_count, label:'Spam detectado', color:'#6b7280', click: () => goInbox({ spam: true }) },
          { icon:'🤖', val: `${stats.avg_confidence}%`, label:'Confianza IA', color:'#10b981' },
        ].map((k, i) => (
          <div key={i} className={`kpi-card ${k.click ? 'clickable' : ''}`}
            style={{ '--kc': k.color }} onClick={k.click}>
            <div className="kpi-icon">{k.icon}</div>
            <div className="kpi-val">{k.val}</div>
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-accent-bar" />
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="dashboard-charts">
        <div className="db-chart-card db-chart-wide">
          <h3>Actividad últimos 30 días</h3>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={stats.by_day || []}>
              <defs>
                <linearGradient id="grad1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="day" tick={{ fontSize: 10 }} tickFormatter={v => v?.slice(5)} />
              <YAxis allowDecimals={false} tick={{ fontSize: 10 }} width={28} />
              <Tooltip formatter={(v) => [v, 'Emails']} labelFormatter={v => `Fecha: ${v}`} />
              <Area type="monotone" dataKey="count" stroke="#6366f1" strokeWidth={2}
                fill="url(#grad1)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="db-chart-card">
          <h3>Por Categoría</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={catData} dataKey="count" nameKey="category"
                cx="50%" cy="50%" innerRadius={50} outerRadius={80}>
                {catData.map(d => (
                  <Cell key={d.category} fill={CAT_COLORS[d.category] || '#94a3b8'}
                    cursor="pointer" onClick={() => goInbox({ category: d.category })} />
                ))}
              </Pie>
              <Tooltip formatter={(v, n, p) => [v, p.payload.category]} />
            </PieChart>
          </ResponsiveContainer>
          <div className="mini-legend">
            {catData.slice(0, 4).map(d => (
              <button key={d.category} className="ml-item" onClick={() => goInbox({ category: d.category })}>
                <span className="ml-dot" style={{ background: CAT_COLORS[d.category] }} />
                <span>{d.category.replace('_',' ')}</span>
                <span className="ml-num">{d.count}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="db-chart-card">
          <h3>Por Prioridad</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={stats.by_priority || []} layout="vertical" margin={{ left: 8 }}>
              <XAxis type="number" hide />
              <YAxis type="category" dataKey="priority_label" width={60} tick={{ fontSize: 11 }}
                tickFormatter={v => ({ urgente:'Urgente', alta:'Alta', media:'Media', baja:'Baja' }[v] || v)} />
              <Tooltip formatter={(v, n, p) => [v, p.payload.priority_label]} />
              <Bar dataKey="count" radius={[0,6,6,0]}>
                {(stats.by_priority || []).map(d => (
                  <Cell key={d.priority_label} fill={PRI_COLORS[d.priority_label] || '#94a3b8'}
                    cursor="pointer" onClick={() => goInbox({ priority_label: d.priority_label })} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="dashboard-bottom">
        {/* Urgent actions */}
        <div className="db-panel">
          <div className="db-panel-header">
            <h3>⚡ Acciones pendientes</h3>
            <button className="db-see-all" onClick={() => goInbox({ requires_action: true })}>
              Ver todas →
            </button>
          </div>
          {urgentActions.length === 0 ? (
            <div className="db-panel-empty">🎉 Sin acciones pendientes</div>
          ) : (
            urgentActions.map(email => (
              <div key={email.id} className="urgent-email-row">
                <div className="uer-bar"
                  style={{ background: PRI_COLORS[email.priority_label] || '#ef4444' }} />
                <div className="uer-body">
                  <div className="uer-sender">{email.sender_name || email.sender_email}</div>
                  <div className="uer-subject">{email.subject}</div>
                  {email.summary && <div className="uer-summary">{email.summary}</div>}
                </div>
                <div className="uer-score"
                  style={{ color: email.priority_score > 75 ? '#ef4444' : '#f97316' }}>
                  {email.priority_score}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Top senders */}
        <div className="db-panel">
          <div className="db-panel-header">
            <h3>📨 Top Remitentes</h3>
            <button className="db-see-all" onClick={() => setActivePage('contacts')}>
              Ver contactos →
            </button>
          </div>
          {(stats.top_senders || []).slice(0, 6).map((s, i) => (
            <div key={s.sender_email} className="sender-row">
              <span className="sr-rank">{i + 1}</span>
              <div className="sr-avatar">
                {(s.sender_name || s.sender_email || '?')[0].toUpperCase()}
              </div>
              <div className="sr-info">
                <div className="sr-name">{s.sender_name || s.sender_email}</div>
                <div className="sr-email">{s.sender_email}</div>
              </div>
              <div className="sr-bar-wrap">
                <div className="sr-bar"
                  style={{ width: `${(s.count / ((stats.top_senders[0]?.count) || 1)) * 100}%` }} />
              </div>
              <span className="sr-count">{s.count}</span>
            </div>
          ))}
        </div>

        {/* Languages & Tones */}
        <div className="db-panel">
          <div className="db-panel-header">
            <h3>🌍 Idiomas & Tonos</h3>
          </div>
          <div className="lang-section">
            <div className="ls-title">Idiomas detectados</div>
            {(stats.by_language || []).map(l => (
              <div key={l.language} className="lang-row">
                <span>{l.language === 'es' ? '🇨🇴 Español' : l.language === 'en' ? '🇺🇸 Inglés'
                  : l.language === 'pt' ? '🇧🇷 Portugués' : l.language}</span>
                <div className="lang-bar-wrap">
                  <div className="lang-bar" style={{ width: `${(l.count / stats.total) * 100}%` }} />
                </div>
                <span className="lang-count">{l.count}</span>
              </div>
            ))}
          </div>
          <div className="lang-section" style={{ marginTop: 16 }}>
            <div className="ls-title">Tonos predominantes</div>
            {(stats.by_tone || []).slice(0, 4).map(t => (
              <div key={t.tone} className="lang-row">
                <span>{t.tone}</span>
                <div className="lang-bar-wrap">
                  <div className="lang-bar" style={{ width: `${(t.count / stats.total) * 100}%`, background: '#8b5cf6' }} />
                </div>
                <span className="lang-count">{t.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
