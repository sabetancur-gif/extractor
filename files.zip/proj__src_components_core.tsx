// ============================================================
// src/components/Sidebar.tsx + Topbar.tsx + ToastContainer.tsx
// ============================================================

// ════ src/components/Sidebar.tsx ════
import { useStore } from '@/store/useStore';
import type { Page } from '@/types';

const NAV: { id: Page; icon: string; label: string; badge?: string }[] = [
  { id: 'dashboard', icon: '▦', label: 'Dashboard' },
  { id: 'kanban',    icon: '⠿', label: 'Kanban' },
  { id: 'inbox',     icon: '✉', label: 'Bandeja', badge: 'urgent' },
  { id: 'analytics', icon: '↗', label: 'Analytics' },
  { id: 'contacts',  icon: '◉', label: 'Contactos', badge: 'vip' },
  { id: 'settings',  icon: '⚙', label: 'Ajustes' },
];

export function Sidebar() {
  const { page, setPage, stats, wsStatus, syncing,
          danibotOpen, setDanibotOpen, focusMode, toggleFocusMode,
          accounts, activeAccountId, setActiveAccount } = useStore();

  const urgentCount = stats?.by_urgency?.find((u: {urgency_level:string;c:number}) => u.urgency_level === 'critica')?.c ?? 0;
  const vipCount    = stats?.vip_count ?? 0;

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <div className="logo-mark">M</div>
        <div>
          <div className="logo-text">MailAI</div>
          <div className="logo-sub">Panel v2.0</div>
        </div>
      </div>

      {(accounts as {id:number;name:string}[]).length > 0 && (
        <div style={{ marginBottom: 10 }}>
          <div className="nav-section-label">Cuenta</div>
          <select className="input" style={{ fontSize: 11, padding: '5px 8px' }}
            value={activeAccountId ?? ''}
            onChange={e => setActiveAccount(e.target.value ? Number(e.target.value) : null)}>
            <option value="">Todas las cuentas</option>
            {(accounts as {id:number;name:string}[]).map(a => (
              <option key={a.id} value={a.id}>{a.name}</option>
            ))}
          </select>
        </div>
      )}

      <div className="nav-section-label">Vistas</div>
      <nav>
        {NAV.map(item => {
          const badge = item.badge === 'urgent' ? urgentCount : item.badge === 'vip' ? vipCount : 0;
          return (
            <button key={item.id}
              className={`nav-btn ${page === item.id ? 'active' : ''}`}
              onClick={() => setPage(item.id)}>
              <span className="nav-icon">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
              {badge > 0 && <span className="nav-badge">{badge > 99 ? '99+' : badge}</span>}
            </button>
          );
        })}
      </nav>

      <div className="nav-section-label" style={{ marginTop: 8 }}>Asistente IA</div>
      <button className={`nav-btn danibot-btn ${danibotOpen ? 'active' : ''}`}
        onClick={() => setDanibotOpen(!danibotOpen)}>
        <span className="nav-icon">🤖</span>
        <span className="nav-label">DaniBot</span>
        <span className="danibot-dot" />
      </button>

      <button className={`nav-btn ${focusMode ? 'active' : ''}`}
        onClick={toggleFocusMode}
        style={{ color: focusMode ? 'var(--danibot)' : undefined }}>
        <span className="nav-icon">⊙</span>
        <span className="nav-label">Modo Foco</span>
        {focusMode && <span className="nav-badge" style={{ background:'var(--danibot)' }}>ON</span>}
      </button>

      <div className="sidebar-footer">
        <div className="ws-status">
          <span className={`ws-dot ${syncing ? 'syncing' : wsStatus === 'connected' ? 'connected' : ''}`} />
          <span>{syncing ? 'Clasificando...' : wsStatus === 'connected' ? 'En vivo' : 'Desconectado'}</span>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;


// ════ src/components/Topbar.tsx ════
import { useState } from 'react';
import { useStore } from '@/store/useStore';
import { api } from '@/services/api';

const PAGE_LABELS: Record<string, string> = {
  dashboard: 'Dashboard', kanban: 'Kanban', inbox: 'Bandeja',
  analytics: 'Analytics', contacts: 'Contactos', settings: 'Ajustes',
};

export function Topbar() {
  const { page, syncing, syncProgress, syncMessage, stats, addToast, setFilters } = useStore();
  const [showSync, setShowSync] = useState(false);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ days_back: 14, limit_per_account: 100, include_read: true });

  const handleSync = async () => {
    setShowSync(false);
    try { await api.sync(form); addToast('Sincronización iniciada', 'info'); }
    catch (e: unknown) { addToast((e as Error).message || 'Error', 'error'); }
  };

  const handleSearch = (val: string) => {
    setSearch(val);
    if (val.length > 2 || val.length === 0) setFilters({ search: val || undefined });
  };

  return (
    <>
      <header className="topbar">
        <h1 className="topbar-title">{PAGE_LABELS[page] ?? 'MailAI Panel'}</h1>
        <div className="topbar-center">
          {syncing && (
            <div className="sync-bar">
              <div className="sync-bar-track">
                <div className="sync-bar-fill" style={{ width: `${syncProgress}%` }} />
              </div>
              <span className="sync-label">{syncMessage}</span>
            </div>
          )}
        </div>
        <div className="topbar-right">
          <input className="input" style={{ width: 200 }} placeholder="🔍 Buscar emails..."
            value={search} onChange={e => handleSearch(e.target.value)} />
          {stats && <span className="pill">{stats.total.toLocaleString()} emails</span>}
          <button className="btn btn-primary" onClick={() => setShowSync(true)} disabled={syncing}>
            <span style={{ display:'inline-block', animation: syncing ? 'spin .7s linear infinite' : 'none' }}>⟳</span>
            {syncing ? 'Clasificando...' : 'Clasificar Outlook'}
          </button>
        </div>
      </header>

      {showSync && (
        <div className="modal-backdrop" onClick={() => setShowSync(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <span className="modal-title">Clasificar Outlook con IA</span>
              <button className="btn-icon" onClick={() => setShowSync(false)}>✕</button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize:13, color:'var(--text-secondary)' }}>
                Lee todas las cuentas abiertas en Outlook y las clasifica con Ollama local.
              </p>
              <div className="sync-row">
                <div>
                  <label className="input-label">Días atrás</label>
                  <input className="input" type="number" min={1} max={90} value={form.days_back}
                    onChange={e => setForm(f => ({ ...f, days_back: +e.target.value }))} />
                </div>
                <div>
                  <label className="input-label">Máx. por cuenta</label>
                  <input className="input" type="number" min={1} max={500} value={form.limit_per_account}
                    onChange={e => setForm(f => ({ ...f, limit_per_account: +e.target.value }))} />
                </div>
                <div>
                  <label className="input-label">Incluir leídos</label>
                  <select className="input" value={form.include_read ? '1' : '0'}
                    onChange={e => setForm(f => ({ ...f, include_read: e.target.value === '1' }))}>
                    <option value="1">Sí</option>
                    <option value="0">No</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowSync(false)}>Cancelar</button>
              <button className="btn btn-primary" onClick={handleSync}>Iniciar</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}


// ════ src/components/ToastContainer.tsx ════
import { useStore } from '@/store/useStore';

const ICONS: Record<string, string> = {
  success:'✅', error:'❌', warning:'⚠️', info:'ℹ️'
};

export function ToastContainer() {
  const { toasts } = useStore();
  return (
    <div className="toast-container" role="status" aria-live="polite">
      {toasts.map(t => (
        <div key={t.id} className={`toast toast-${t.type}`}>
          <span>{ICONS[t.type]}</span>
          <span style={{ color:'var(--text-primary)' }}>{t.message}</span>
        </div>
      ))}
    </div>
  );
}

export default ToastContainer;
