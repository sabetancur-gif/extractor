"""
=============================================================
MÓDULO 2: classifier.py
Panel Clasificador MailAI — Motor de Clasificación 4 Dimensiones
=============================================================
Clasifica cada email en 4 dimensiones usando Ollama local:

  1. IMPORTANCIA  — Score 1-100, etiqueta, razón
  2. SENTIMIENTO  — Positivo/Negativo/Neutral/Mixto + tono
  3. REMITENTE    — Perfil, relación, confianza, VIP
  4. URGENCIA     — Nivel, fecha límite, acciones requeridas

Todo corre localmente con Ollama. Sin APIs externas.
=============================================================
"""

import json
import re
import httpx
from typing import Dict, Optional
from dataclasses import dataclass, field


# ─────────────────────────────────────────────────────────────
# Estructura de resultado de clasificación
# ─────────────────────────────────────────────────────────────

@dataclass
class ImportanceResult:
    """Dimensión 1: Qué tan importante es este email."""
    score:      int    = 50          # 1-100
    label:      str    = "media"     # critica | alta | media | baja | info
    reason:     str    = ""          # Por qué tiene esta importancia
    color:      str    = "#eab308"   # Color hex para la UI


@dataclass
class SentimentResult:
    """Dimensión 2: Qué sentimiento transmite el email."""
    label:      str    = "neutral"   # positivo | negativo | neutral | mixto
    score:      float  = 0.0         # -1.0 a 1.0
    tone:       str    = "neutral"   # formal | informal | agresivo | urgente | amigable | neutro
    emoji:      str    = "😐"        # Emoji representativo


@dataclass
class SenderResult:
    """Dimensión 3: Perfil del remitente."""
    profile:    str    = "desconocido"  # cliente | proveedor | colega | jefe | externo | interno | desconocido
    trust:      int    = 50             # 0-100 nivel de confianza
    is_vip:     bool   = False          # Requiere atención prioritaria
    company:    str    = ""             # Empresa detectada
    relation:   str    = ""             # Relación con el remitente


@dataclass
class UrgencyResult:
    """Dimensión 4: Qué tan urgente es actuar."""
    level:      str    = "ninguna"   # critica | alta | media | baja | ninguna
    deadline:   str    = ""          # Fecha límite detectada (ISO o descripción)
    actions:    list   = field(default_factory=list)  # Acciones concretas requeridas
    reply:      str    = ""          # Borrador de respuesta sugerido
    color:      str    = "#6b7280"   # Color hex para la UI


@dataclass
class ClassificationResult:
    """Resultado completo de las 4 dimensiones para un email."""
    importance:   ImportanceResult  = field(default_factory=ImportanceResult)
    sentiment:    SentimentResult   = field(default_factory=SentimentResult)
    sender:       SenderResult      = field(default_factory=SenderResult)
    urgency:      UrgencyResult     = field(default_factory=UrgencyResult)
    summary:      str               = ""       # Resumen de 1-2 oraciones
    category:     str               = "otro"   # Categoría general
    language:     str               = "es"     # Idioma detectado
    key_topics:   list              = field(default_factory=list)
    spam_score:   float             = 0.0      # 0-1 probabilidad de spam
    confidence:   float             = 0.8      # Confianza en la clasificación


# ─────────────────────────────────────────────────────────────
# Mapeos de colores para la UI
# ─────────────────────────────────────────────────────────────

IMPORTANCE_COLORS = {
    "critica": "#ef4444",
    "alta":    "#f97316",
    "media":   "#eab308",
    "baja":    "#22c55e",
    "info":    "#94a3b8",
}

URGENCY_COLORS = {
    "critica": "#ef4444",
    "alta":    "#f97316",
    "media":   "#eab308",
    "baja":    "#22c55e",
    "ninguna": "#6b7280",
}

SENTIMENT_EMOJIS = {
    "positivo": "😊",
    "negativo": "😟",
    "neutral":  "😐",
    "mixto":    "🤔",
}


# ─────────────────────────────────────────────────────────────
# Clasificador principal
# ─────────────────────────────────────────────────────────────

class EmailClassifier:
    """
    Clasifica emails usando Ollama local en 4 dimensiones.

    Ejemplo:
        clf = EmailClassifier(ollama_url="http://localhost:11434", model="llama3.2:3b")
        result = clf.classify(email_dict)
        print(result.importance.score)   # 87
        print(result.urgency.level)      # "alta"
        print(result.sentiment.emoji)    # "😟"
    """

    # Prompt del sistema: instruye al modelo como clasificador especializado
    SYSTEM_PROMPT = """Eres un clasificador experto de emails corporativos.
Tu única función es analizar emails y devolver un JSON estructurado con 4 dimensiones de análisis.
REGLAS OBLIGATORIAS:
1. Responde ÚNICAMENTE con JSON válido y puro. Sin texto antes ni después.
2. Completa TODOS los campos del esquema.
3. Los textos van en el mismo idioma del email analizado.
4. Sé preciso y objetivo en las puntuaciones."""

    def __init__(
        self,
        ollama_url: str = "http://localhost:11434",
        model:      str = "llama3.2:3b",
        timeout:    float = 120.0,
    ):
        self.ollama_url = ollama_url.rstrip("/")
        self.model      = model
        self.timeout    = timeout

    # ──────────────────────────────────────────────────────────
    # MÉTODO PRINCIPAL
    # ──────────────────────────────────────────────────────────

    def classify(self, email_data: Dict) -> ClassificationResult:
        """
        Clasifica un email en las 4 dimensiones.

        Args:
            email_data: Dict con campos sender_name, sender_email,
                        subject, body, date, account_name, importance (Outlook)

        Returns:
            ClassificationResult con las 4 dimensiones completas
        """
        prompt = self._build_prompt(email_data)

        try:
            raw_response = self._call_ollama(prompt)
            return self._parse_response(raw_response, email_data)
        except Exception as e:
            print(f"⚠️  Error clasificando email '{email_data.get('subject','')[:40]}': {e}")
            return self._default_result(email_data)

    # ──────────────────────────────────────────────────────────
    # CONSTRUCCIÓN DEL PROMPT
    # ──────────────────────────────────────────────────────────

    def _build_prompt(self, e: Dict) -> str:
        """
        Construye el prompt optimizado para obtener las 4 dimensiones.
        Incluye contexto de la cuenta para que el modelo sepa
        si el remitente es interno o externo.
        """
        body_preview = (e.get('body') or '')[:1200]
        account_domain = e.get('account_email', '').split('@')[-1]
        sender_domain  = e.get('sender_email', '').split('@')[-1]
        is_internal    = account_domain and sender_domain == account_domain

        return f"""Analiza este email y devuelve SOLO el JSON de clasificación en 4 dimensiones.

━━━ DATOS DEL EMAIL ━━━
Cuenta receptora : {e.get('account_name', '')}
De               : {e.get('sender_name', '')} <{e.get('sender_email', '')}>
Remitente interno: {'SÍ (misma empresa)' if is_internal else 'NO (externo)'}
Para             : {e.get('to_recipients', '')}
Asunto           : {e.get('subject', '')}
Fecha            : {e.get('date', '')}
Adjuntos         : {'SÍ' if e.get('has_attachments') else 'NO'}
Importancia Outlook: {['Baja','Normal','Alta'][int(e.get('importance',1) or 1)]}

Cuerpo:
{body_preview}

━━━ ESQUEMA JSON REQUERIDO ━━━
Devuelve exactamente este objeto JSON con todos los campos:

{{
  "importancia": {{
    "score": <1-100, donde 100 es máxima importancia>,
    "label": "<critica|alta|media|baja|info>",
    "reason": "<una oración explicando por qué tiene esta importancia>"
  }},
  "sentimiento": {{
    "label": "<positivo|negativo|neutral|mixto>",
    "score": <-1.0 a 1.0, negativo=malo, positivo=bueno>,
    "tone":  "<formal|informal|agresivo|urgente|amigable|neutro|corporativo>"
  }},
  "remitente": {{
    "profile":  "<cliente|proveedor|colega|jefe|externo|interno|desconocido>",
    "trust":    <0-100, confianza en el remitente>,
    "is_vip":   <true|false, ¿requiere atención prioritaria?>,
    "company":  "<empresa del remitente si se detecta, o vacío>",
    "relation": "<una frase describiendo la relación con el remitente>"
  }},
  "urgencia": {{
    "level":   "<critica|alta|media|baja|ninguna>",
    "deadline":"<fecha o plazo mencionado explícitamente, o vacío si no hay>",
    "actions": ["<acción concreta 1>", "<acción 2>"],
    "reply":   "<borrador de respuesta de 2-3 oraciones en el idioma del email, o vacío si no aplica>"
  }},
  "summary":    "<resumen objetivo de 1-2 oraciones del email>",
  "category":   "<trabajo|finanzas|legal|soporte|personal|marketing|educacion|redes|spam|otro>",
  "language":   "<es|en|pt|fr|otro>",
  "key_topics": ["<tema1>","<tema2>","<tema3>"],
  "spam_score": <0.0-1.0>,
  "confidence": <0.0-1.0>
}}"""

    # ──────────────────────────────────────────────────────────
    # LLAMADA A OLLAMA
    # ──────────────────────────────────────────────────────────

    def _call_ollama(self, prompt: str) -> str:
        """
        Llama a la API de Ollama con format=json para garantizar
        que la respuesta sea JSON válido.
        """
        payload = {
            "model":  self.model,
            "stream": False,
            "format": "json",   # Ollama fuerza salida JSON válida
            "options": {
                "temperature":    0.05,   # Baja temperatura = más determinismo
                "num_predict":    1200,
                "top_p":          0.9,
                "repeat_penalty": 1.1,
            },
            "messages": [
                {"role": "system", "content": self.SYSTEM_PROMPT},
                {"role": "user",   "content": prompt},
            ],
        }

        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                f"{self.ollama_url}/api/chat",
                json=payload,
            )
            response.raise_for_status()
            data = response.json()
            return data.get("message", {}).get("content", "")

    # ──────────────────────────────────────────────────────────
    # PARSEO DE LA RESPUESTA
    # ──────────────────────────────────────────────────────────

    def _parse_response(self, raw: str, email_data: Dict) -> ClassificationResult:
        """
        Parsea el JSON devuelto por Ollama y construye el ClassificationResult.
        Aplica validaciones y valores por defecto para cada campo.
        """
        try:
            # Limpiar posibles fences de markdown (por si acaso)
            text = raw.strip()
            text = re.sub(r'^```(?:json)?\s*', '', text)
            text = re.sub(r'\s*```$', '', text)

            # Extraer el objeto JSON
            match = re.search(r'\{.*\}', text, re.DOTALL)
            if not match:
                raise ValueError("No se encontró JSON en la respuesta")

            data = json.loads(match.group())

            # ── Parsear cada dimensión ────────────────────────
            imp_data  = data.get("importancia", {})
            sent_data = data.get("sentimiento", {})
            rem_data  = data.get("remitente",   {})
            urg_data  = data.get("urgencia",    {})

            # Validar y construir IMPORTANCIA
            imp_label = self._valid(imp_data.get("label"), ["critica","alta","media","baja","info"], "media")
            importance = ImportanceResult(
                score  = self._clamp_int(imp_data.get("score", 50), 1, 100),
                label  = imp_label,
                reason = str(imp_data.get("reason", ""))[:300],
                color  = IMPORTANCE_COLORS.get(imp_label, "#eab308"),
            )

            # Validar y construir SENTIMIENTO
            sent_label = self._valid(sent_data.get("label"), ["positivo","negativo","neutral","mixto"], "neutral")
            sentiment = SentimentResult(
                label = sent_label,
                score = self._clamp_float(sent_data.get("score", 0.0), -1.0, 1.0),
                tone  = self._valid(sent_data.get("tone"),
                                    ["formal","informal","agresivo","urgente","amigable","neutro","corporativo"],
                                    "neutro"),
                emoji = SENTIMENT_EMOJIS.get(sent_label, "😐"),
            )

            # Validar y construir REMITENTE
            sender = SenderResult(
                profile  = self._valid(rem_data.get("profile"),
                                       ["cliente","proveedor","colega","jefe","externo","interno","desconocido"],
                                       "desconocido"),
                trust    = self._clamp_int(rem_data.get("trust", 50), 0, 100),
                is_vip   = bool(rem_data.get("is_vip", False)),
                company  = str(rem_data.get("company", ""))[:100],
                relation = str(rem_data.get("relation", ""))[:200],
            )

            # Validar y construir URGENCIA
            urg_label = self._valid(urg_data.get("level"),
                                    ["critica","alta","media","baja","ninguna"], "ninguna")
            urgency = UrgencyResult(
                level    = urg_label,
                deadline = str(urg_data.get("deadline", ""))[:100],
                actions  = [str(a) for a in urg_data.get("actions", [])][:8],
                reply    = str(urg_data.get("reply",    ""))[:600] or "",
                color    = URGENCY_COLORS.get(urg_label, "#6b7280"),
            )

            return ClassificationResult(
                importance  = importance,
                sentiment   = sentiment,
                sender      = sender,
                urgency     = urgency,
                summary     = str(data.get("summary",   ""))[:500],
                category    = str(data.get("category",  "otro")),
                language    = str(data.get("language",  "es"))[:10],
                key_topics  = [str(t) for t in data.get("key_topics", [])][:8],
                spam_score  = self._clamp_float(data.get("spam_score", 0.0)),
                confidence  = self._clamp_float(data.get("confidence", 0.8)),
            )

        except Exception as e:
            print(f"   ⚠️  Error parseando respuesta Ollama: {e}\n   Raw: {raw[:200]}")
            return self._default_result(email_data)

    # ──────────────────────────────────────────────────────────
    # HELPERS
    # ──────────────────────────────────────────────────────────

    def _valid(self, value: str, options: list, default: str) -> str:
        """Valida que value esté en la lista de opciones."""
        v = (value or "").lower().strip()
        return v if v in options else default

    def _clamp_int(self, value, lo: int, hi: int) -> int:
        """Fuerza value al rango [lo, hi]."""
        try:
            return max(lo, min(hi, int(value)))
        except (TypeError, ValueError):
            return (lo + hi) // 2

    def _clamp_float(self, value, lo: float = 0.0, hi: float = 1.0) -> float:
        """Fuerza value al rango [lo, hi]."""
        try:
            return max(lo, min(hi, float(value)))
        except (TypeError, ValueError):
            return (lo + hi) / 2

    def _default_result(self, email_data: Dict = None) -> ClassificationResult:
        """Resultado por defecto cuando hay error de clasificación."""
        # Usar la importancia de Outlook como fallback para urgencia
        outlook_importance = int((email_data or {}).get("importance", 1) or 1)
        urg_map = {0: "baja", 1: "ninguna", 2: "alta"}
        urg_level = urg_map.get(outlook_importance, "ninguna")

        return ClassificationResult(
            importance  = ImportanceResult(score=50, label="media", reason="Sin clasificar", color="#eab308"),
            sentiment   = SentimentResult(label="neutral", score=0.0, tone="neutro", emoji="😐"),
            sender      = SenderResult(profile="desconocido", trust=50),
            urgency     = UrgencyResult(level=urg_level, color=URGENCY_COLORS.get(urg_level, "#6b7280")),
            summary     = "No se pudo clasificar automáticamente",
            confidence  = 0.0,
        )

    def health_check(self) -> Dict:
        """Verifica que Ollama esté disponible."""
        try:
            with httpx.Client(timeout=5.0) as client:
                resp = client.get(f"{self.ollama_url}/api/tags")
                models = [m["name"] for m in resp.json().get("models", [])]
                model_ok = any(self.model.split(":")[0] in m for m in models)
                return {
                    "ollama_running":   True,
                    "model":            self.model,
                    "model_available":  model_ok,
                    "installed_models": models,
                }
        except Exception as e:
            return {"ollama_running": False, "error": str(e)}
