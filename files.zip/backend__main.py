"""
main.py — Servidor FastAPI profesional
Incluye: multi-cuenta, WebSocket, reglas, contactos, search, export, scheduler
"""
from fastapi import FastAPI, BackgroundTasks, HTTPException, WebSocket, WebSocketDisconnect, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from contextlib import asynccontextmanager
import asyncio, json, csv, io
from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel

from database import Database
from email_fetcher import EmailFetcher
from classifier import EmailClassifier
from rules_engine import RulesEngine, DEFAULT_RULES
from scheduler import SyncScheduler
from config import Settings

settings = Settings()


# ─── WEBSOCKET MANAGER ─────────────────────────────────────────
class WSManager:
    def __init__(self):
        self.connections: List[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.connections.append(ws)

    def disconnect(self, ws: WebSocket):
        if ws in self.connections:
            self.connections.remove(ws)

    async def broadcast(self, data: dict):
        dead = []
        for ws in self.connections:
            try:
                await ws.send_json(data)
            except:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)

ws_manager = WSManager()
db = Database()
classifier = EmailClassifier()
rules_engine = RulesEngine()
scheduler = SyncScheduler()


# ─── LIFESPAN ──────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    db.initialize()
    # Cargar reglas por defecto si no existen
    if not db.get_rules():
        for rule in DEFAULT_RULES:
            db.save_rule(
                name=rule['name'],
                description=rule.get('description'),
                conditions=rule['conditions'],
                actions=rule['actions'],
                priority=rule.get('priority', 0)
            )
    print("✅ Email Classifier API iniciado")
    yield
    print("🛑 Apagando...")


# ─── APP ───────────────────────────────────────────────────────
app = FastAPI(
    title="Email Classifier Pro",
    version="2.0.0",
    description="Clasificador inteligente de emails con IA",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173", "http://localhost:4173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── MODELS ────────────────────────────────────────────────────
class SyncRequest(BaseModel):
    email: str
    password: str
    imap_server: Optional[str] = None
    imap_port: int = 993
    folder: str = "INBOX"
    limit: int = 100
    days_back: int = 14

class EmailUpdate(BaseModel):
    category: Optional[str] = None
    priority_label: Optional[str] = None
    is_read: Optional[bool] = None
    is_starred: Optional[bool] = None
    is_archived: Optional[bool] = None
    notes: Optional[str] = None
    requires_action: Optional[bool] = None

class BulkAction(BaseModel):
    email_ids: List[int]
    action: str
    value: Optional[str] = None

class RuleCreate(BaseModel):
    name: str
    description: Optional[str] = None
    priority: int = 0
    conditions: List[Dict[str, Any]]
    actions: List[Dict[str, Any]]

class ContactUpdate(BaseModel):
    name: Optional[str] = None
    company: Optional[str] = None
    role: Optional[str] = None
    tags: Optional[List[str]] = None
    notes: Optional[str] = None
    is_vip: Optional[bool] = None


# ─── HEALTH ────────────────────────────────────────────────────
@app.get("/health")
async def health():
    return {"status": "healthy", "version": "2.0.0", "timestamp": datetime.now().isoformat()}


# ─── ACCOUNTS ──────────────────────────────────────────────────
@app.get("/accounts")
async def get_accounts():
    return db.get_accounts()

@app.post("/accounts/connect")
async def connect_account(req: SyncRequest):
    """Probar conexión y guardar cuenta"""
    try:
        fetcher = EmailFetcher(
            email=req.email, password=req.password,
            imap_server=req.imap_server, imap_port=req.imap_port
        )
        fetcher.connect()
        fetcher.disconnect()
        account_id = db.save_account(req.email, req.imap_server or fetcher.imap_server,
                                     req.imap_port, req.email)
        return {"status": "connected", "account_id": account_id, "email": req.email}
    except Exception as e:
        raise HTTPException(400, f"Error de conexión: {str(e)}")

@app.delete("/accounts/{account_id}")
async def delete_account(account_id: int):
    db.conn().execute("UPDATE accounts SET is_active=0 WHERE id=?", (account_id,)).connection.commit()
    return {"status": "deleted"}


# ─── SYNC ──────────────────────────────────────────────────────
@app.post("/sync")
async def sync_emails(req: SyncRequest, background_tasks: BackgroundTasks):
    """Iniciar sincronización y clasificación en background"""
    background_tasks.add_task(_sync_and_classify, req)
    return {"status": "started", "message": "Sincronización iniciada"}

async def _sync_and_classify(req: SyncRequest):
    account_id = db.save_account(
        req.email, req.imap_server or '', req.imap_port
    )
    sync_id = db.start_sync(account_id)
    rules = db.get_rules()
    classified = 0
    errors = 0

    try:
        await ws_manager.broadcast({"type": "sync_start", "email": req.email, "account_id": account_id})

        fetcher = EmailFetcher(
            email=req.email, password=req.password,
            imap_server=req.imap_server, imap_port=req.imap_port
        )
        emails = fetcher.fetch_emails(folder=req.folder, limit=req.limit, days_back=req.days_back)

        await ws_manager.broadcast({
            "type": "sync_progress",
            "message": f"📬 {len(emails)} emails encontrados. Clasificando con IA...",
            "total": len(emails), "account_id": account_id
        })

        for i, email_data in enumerate(emails):
            if db.email_exists(email_data['message_id']):
                continue
            try:
                clf = classifier.classify_email(email_data)
                email_data['classification'] = clf

                # Obtener o crear hilo
                thread_key = email_data.get('thread_key') or email_data['message_id']
                thread_id = db.get_or_create_thread(thread_key, account_id, email_data.get('subject', ''))

                email_id = db.save_email(email_data, account_id, thread_id)

                # Aplicar reglas automáticas
                actions = rules_engine.evaluate(email_data, clf, rules)
                updates = {}
                for action in actions:
                    updates.update(rules_engine.apply_action(action))
                if updates:
                    db.update_email(email_id, updates)

                # Actualizar contacto
                db.upsert_contact(
                    email=email_data.get('sender_email', ''),
                    name=email_data.get('sender_name'),
                    company=next(iter(clf.get('entities', {}).get('companies', [])), None)
                )

                classified += 1
                await ws_manager.broadcast({
                    "type": "new_email",
                    "account_id": account_id,
                    "progress": round((i+1) / len(emails) * 100),
                    "classified": classified,
                    "data": {
                        "id": email_id,
                        "sender_name": email_data.get('sender_name'),
                        "sender_email": email_data.get('sender_email'),
                        "subject": email_data.get('subject'),
                        "date": email_data.get('date'),
                        "category": clf.get('category'),
                        "priority_label": clf.get('priority_label'),
                        "priority_score": clf.get('priority_score'),
                        "summary": clf.get('summary'),
                        "requires_action": clf.get('requires_action'),
                    }
                })
                await asyncio.sleep(0.3)

            except Exception as e:
                errors += 1
                print(f"⚠️ Error en email {email_data.get('message_id')}: {e}")

        db.finish_sync(sync_id, len(emails), classified, errors)
        db.update_account_sync(account_id, classified)

        await ws_manager.broadcast({
            "type": "sync_complete",
            "account_id": account_id,
            "classified": classified,
            "total": len(emails),
            "errors": errors,
            "message": f"✅ {classified} emails clasificados"
        })

    except Exception as e:
        db.finish_sync(sync_id, 0, 0, 1)
        await ws_manager.broadcast({
            "type": "sync_error",
            "account_id": account_id,
            "message": f"❌ {str(e)}"
        })


# ─── EMAILS ────────────────────────────────────────────────────
@app.get("/emails")
async def get_emails(
    account_id: Optional[int] = None,
    category: Optional[str] = None,
    priority_label: Optional[str] = None,
    sender: Optional[str] = None,
    search: Optional[str] = None,
    requires_action: Optional[bool] = None,
    is_starred: Optional[bool] = None,
    language: Optional[str] = None,
    spam: Optional[bool] = None,
    thread_id: Optional[int] = None,
    sort: str = "date_desc",
    limit: int = Query(50, ge=1, le=200),
    offset: int = 0
):
    filters = {k: v for k, v in {
        'account_id': account_id, 'category': category, 'priority_label': priority_label,
        'sender': sender, 'search': search, 'requires_action': requires_action,
        'is_starred': is_starred, 'language': language, 'spam': spam,
        'thread_id': thread_id, 'sort': sort
    }.items() if v is not None}
    return db.get_emails(filters, limit, offset)

@app.get("/emails/{email_id}")
async def get_email(email_id: int):
    email = db.get_email(email_id)
    if not email:
        raise HTTPException(404, "Email no encontrado")
    if not email.get('is_read'):
        db.update_email(email_id, {'is_read': True})
    return email

@app.patch("/emails/{email_id}")
async def update_email(email_id: int, update: EmailUpdate):
    updates = {k: v for k, v in update.model_dump().items() if v is not None}
    if not db.update_email(email_id, updates):
        raise HTTPException(404, "Email no encontrado")
    return {"status": "updated"}

@app.post("/emails/{email_id}/reclassify")
async def reclassify_email(email_id: int):
    email = db.get_email(email_id)
    if not email:
        raise HTTPException(404, "Email no encontrado")
    clf = classifier.classify_email(email)
    db.update_email(email_id, {
        'category': clf.get('category'),
        'priority_label': clf.get('priority_label')
    })
    return {"status": "reclassified", "classification": clf}

@app.post("/emails/bulk")
async def bulk_action(action: BulkAction):
    action_map = {
        'read': {'is_read': True},
        'unread': {'is_read': False},
        'star': {'is_starred': True},
        'unstar': {'is_starred': False},
        'archive': {'is_archived': True},
        'delete': {'is_deleted': True},
    }
    if action.action == 'categorize' and action.value:
        updates = {'category': action.value}
    elif action.action == 'prioritize' and action.value:
        updates = {'priority_label': action.value}
    else:
        updates = action_map.get(action.action, {})
    if not updates:
        raise HTTPException(400, "Acción no válida")
    count = db.bulk_update(action.email_ids, updates)
    return {"status": "updated", "count": count}

@app.delete("/emails/{email_id}")
async def delete_email(email_id: int):
    db.update_email(email_id, {'is_deleted': True})
    return {"status": "deleted"}


# ─── THREADS ───────────────────────────────────────────────────
@app.get("/threads/{thread_id}/emails")
async def get_thread_emails(thread_id: int):
    emails = db.get_emails({'thread_id': thread_id}, limit=100)
    return sorted(emails, key=lambda e: e.get('date', ''))


# ─── STATS ─────────────────────────────────────────────────────
@app.get("/stats")
async def get_stats(account_id: Optional[int] = None):
    return db.get_stats(account_id)


# ─── CONTACTS ──────────────────────────────────────────────────
@app.get("/contacts")
async def get_contacts(search: Optional[str] = None, limit: int = 50):
    return db.get_contacts(search, limit)

@app.get("/contacts/{contact_id}")
async def get_contact(contact_id: int):
    c = db.get_contact(contact_id)
    if not c:
        raise HTTPException(404, "Contacto no encontrado")
    emails = db.get_emails({'sender': c['email']}, limit=20)
    return {**c, "recent_emails": emails}

@app.patch("/contacts/{contact_id}")
async def update_contact(contact_id: int, update: ContactUpdate):
    updates = {k: v for k, v in update.model_dump().items() if v is not None}
    if not db.update_contact(contact_id, updates):
        raise HTTPException(404, "Contacto no encontrado")
    return {"status": "updated"}


# ─── RULES ─────────────────────────────────────────────────────
@app.get("/rules")
async def get_rules():
    return db.get_rules()

@app.post("/rules")
async def create_rule(rule: RuleCreate):
    rule_id = db.save_rule(
        name=rule.name, description=rule.description,
        conditions=rule.conditions, actions=rule.actions,
        priority=rule.priority
    )
    return {"status": "created", "id": rule_id}

@app.delete("/rules/{rule_id}")
async def delete_rule(rule_id: int):
    db.delete_rule(rule_id)
    return {"status": "deleted"}

@app.post("/rules/{rule_id}/test")
async def test_rule(rule_id: int):
    """Testear una regla contra los últimos 50 emails"""
    rules = [r for r in db.get_rules() if r['id'] == rule_id]
    if not rules:
        raise HTTPException(404, "Regla no encontrada")
    emails = db.get_emails({}, limit=50)
    matches = []
    for email in emails:
        clf = {
            'category': email.get('category'),
            'priority_label': email.get('priority_label'),
            'priority_score': email.get('priority_score'),
            'sentiment': {'label': email.get('sentiment_label'), 'tone': email.get('tone')},
            'urgency': {'level': email.get('urgency_level')},
            'language': email.get('language'),
            'spam_score': email.get('spam_score'),
            'requires_action': email.get('requires_action'),
            'thread_type': email.get('thread_type'),
            'entities': email.get('entities', {}),
        }
        if rules_engine._matches(email, clf, rules[0]['conditions']):
            matches.append({'id': email['id'], 'subject': email.get('subject'), 'sender': email.get('sender_email')})
    return {"matches": matches, "count": len(matches)}


# ─── SYNC HISTORY ──────────────────────────────────────────────
@app.get("/accounts/{account_id}/sync-history")
async def get_sync_history(account_id: int):
    return db.get_sync_history(account_id)


# ─── EXPORT ────────────────────────────────────────────────────
@app.get("/export/csv")
async def export_csv(
    account_id: Optional[int] = None,
    category: Optional[str] = None,
    priority_label: Optional[str] = None
):
    filters = {k: v for k, v in {
        'account_id': account_id, 'category': category, 'priority_label': priority_label
    }.items() if v is not None}
    emails = db.get_emails(filters, limit=5000)
    
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=[
        'id','date','sender_email','sender_name','subject','category',
        'priority_label','priority_score','sentiment_label','requires_action',
        'summary','language','spam_score'
    ])
    writer.writeheader()
    for e in emails:
        writer.writerow({k: e.get(k, '') for k in writer.fieldnames})
    
    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=emails_{datetime.now().strftime('%Y%m%d')}.csv"}
    )


# ─── WEBSOCKET ─────────────────────────────────────────────────
@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws_manager.connect(ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(ws)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
