// src/pages/Inbox.jsx
import { useState, useCallback } from 'react'
import { useStore } from '../store'
import AIInsights from '../components/AIInsights'

const CATS = ['trabajo','ventas_marketing','finanzas','soporte_tecnico',
              'personal','legal','educacion','redes_sociales','spam','otro']
const PRIS = ['urgente','alta','media','baja']

const CAT_COLORS = {
  trabajo:'#6366f1', ventas_marketing:'#f59e0b', finanzas:'#10b981',
  soporte_tecnico:'#3b82f6', personal:'#ec4899', legal:'#ef4444',
  educacion:'#06b6d4', redes_sociales:'#8b5cf6', spam:'#6b7280', otro:'#94a3b8'
}
const PRI_COLORS = { urgente:'#ef4444', alta:'#f97316', media:'#eab308', baja:'#22c55e' }
const PRI_LABELS = { urgente:'🔴 Urgente', alta:'🟠 Alta', media:'🟡 Media', baja:'🟢 Baja' }

function FilterBar({ filters, onChange }) {
  return (
    <div className="filter-bar">
      <div className="filter-group">
        <select value={filters.category || ''} onChange={e => onChange({ ...filters, category: e.target.value || undefined })}>
          <option value="">Todas las categorías</option>
          {CATS.map(c => <option key={c} value={c}>{c.replace('_', ' ')}</option>)}
        </select>
        <select value={filters.priority_label || ''} onChange={e => onChange({ ...filters, priority_label: e.target.value || undefined })}>
          <option value="">Todas prioridades</option>
          {PRIS.map(p => <option key={p} value={p}>{PRI_LABELS[p]}</option>)}
        </select>
        <select value={filters.sort || 'date_desc'} onChange={e => onChange({ ...filters, sort: e.target.value })}>
          <option value="date_desc">Más recientes</option>
          <option value="date_asc">Más antiguos</option>
          <option value="priority_desc">Mayor prioridad</option>
          <option value="priority_asc">Menor prioridad</option>
        </select>
      </div>
      <div className="filter-toggles">
        {[
          { key: 'requires_action', icon: '⚡', label: 'Acción' },
          { key: 'is_starred', icon: '★', label: 'Destacados' },
        ].map(({ key, icon, label }) => (
          <button
            key={key}
            className={`toggle-btn ${filters[key] ? 'active' : ''}`}
            onClick={() => onChange({ ...filters, [key]: filters[key] ? undefined : true })}
          >
            {icon} {label}
          </button>
        ))}
        {Object.keys(filters).filter(k => !['sort'].includes(k)).length > 0 && (
          <button className="clear-btn" onClick={() => onChange({ sort: 'date_desc' })}>
            ✕ Limpiar filtros
          </button>
        )}
      </div>
    </div>
  )
}

function EmailRow({ email, isSelected, isChecked, onSelect, onCheck }) {
  const priorityScore = email.priority_score || 50
  return (
    <div
      className={`email-row ${isSelected ? 'selected' : ''} ${!email.is_read ? 'unread' : ''}`}
      onClick={() => onSelect(email)}
    >
      <div className="email-row-check">
        <input type="checkbox" checked={isChecked} onClick={e => e.stopPropagation()}
          onChange={() => onCheck(email.id)} />
      </div>
      <div className="email-row-main">
        <div className="email-row-top">
          <span className="email-sender">{email.sender_name || email.sender_email}</span>
          <div className="email-row-meta">
            {email.has_attachments && <span className="attachment-icon" title="Tiene adjuntos">📎</span>}
            {email.requires_action && <span className="action-dot" title="Requiere acción" />}
            <span className="email-date">{formatDate(email.date)}</span>
          </div>
        </div>
        <div className="email-subject">{email.subject || '(Sin asunto)'}</div>
        <div className="email-preview">{email.summary || email.body?.slice(0, 100)}</div>
        <div className="email-row-tags">
          <span className="cat-chip" style={{ '--chip-color': CAT_COLORS[email.category] || '#94a3b8' }}>
            {email.category?.replace('_', ' ')}
          </span>
          <div className="priority-bar-wrap" title={`Prioridad: ${priorityScore}/100`}>
            <div className="priority-bar" style={{ width: `${priorityScore}%`,
              background: priorityScore > 75 ? '#ef4444' : priorityScore > 50 ? '#f97316' : '#eab308' }} />
          </div>
          {email.key_topics?.slice(0, 2).map(t => (
            <span key={t} className="topic-chip">{t}</span>
          ))}
        </div>
      </div>
    </div>
  )
}

function BulkToolbar({ count, onAction }) {
  return (
    <div className="bulk-toolbar">
      <span className="bulk-count">{count} seleccionados</span>
      <button onClick={() => onAction('read')}>Leer</button>
      <button onClick={() => onAction('star')}>Destacar</button>
      <button onClick={() => onAction('archive')}>Archivar</button>
      <button onClick={() => onAction('delete')} className="danger">Eliminar</button>
    </div>
  )
}

function formatDate(dateStr) {
  if (!dateStr) return ''
  const d = new Date(dateStr)
  const now = new Date()
  const diff = now - d
  if (diff < 86400000 * 1) return d.toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' })
  if (diff < 86400000 * 7) return d.toLocaleDateString('es', { weekday: 'short' })
  return d.toLocaleDateString('es', { day: '2-digit', month: 'short' })
}

export default function Inbox() {
  const {
    emails, emailsLoading, selectedEmail, selectEmail,
    emailFilters, setEmailFilters, fetchEmails,
    selectedEmailIds, toggleEmailSelection, clearSelection, bulkAction,
    updateEmail, reclassifyEmail, addToast
  } = useStore()

  const [showDetail, setShowDetail] = useState(false)

  const handleSelect = useCallback((email) => {
    selectEmail(email)
    setShowDetail(true)
  }, [])

  const handleBulk = async (action) => {
    const ids = [...selectedEmailIds]
    await bulkAction(ids, action)
    clearSelection()
    addToast(`${ids.length} emails actualizados`, 'success')
  }

  const handleStar = async (email, e) => {
    e.stopPropagation()
    await updateEmail(email.id, { is_starred: !email.is_starred })
  }

  return (
    <div className={`inbox-layout ${showDetail && selectedEmail ? 'with-panel' : ''}`}>
      <div className="inbox-list-col">
        <FilterBar filters={emailFilters} onChange={setEmailFilters} />

        {selectedEmailIds.size > 0 && (
          <BulkToolbar count={selectedEmailIds.size} onAction={handleBulk} />
        )}

        <div className="email-list">
          {emailsLoading && emails.length === 0 ? (
            <div className="loading-state">
              {[1,2,3,4,5].map(i => (
                <div key={i} className="skeleton-row">
                  <div className="sk-avatar" />
                  <div className="sk-body">
                    <div className="sk-line sk-line-sm" />
                    <div className="sk-line sk-line-lg" />
                    <div className="sk-line sk-line-md" />
                  </div>
                </div>
              ))}
            </div>
          ) : emails.length === 0 ? (
            <div className="empty-inbox">
              <div className="empty-icon">✉</div>
              <p>No hay emails con estos filtros</p>
              <button onClick={() => setEmailFilters({ sort: 'date_desc' })}>Limpiar filtros</button>
            </div>
          ) : (
            <>
              {emails.map(email => (
                <EmailRow
                  key={email.id}
                  email={email}
                  isSelected={selectedEmail?.id === email.id}
                  isChecked={selectedEmailIds.has(email.id)}
                  onSelect={handleSelect}
                  onCheck={toggleEmailSelection}
                />
              ))}
              {emails.length % 50 === 0 && emails.length > 0 && (
                <button className="load-more" onClick={() => fetchEmails(false)}>
                  Cargar más emails
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {showDetail && selectedEmail && (
        <div className="detail-panel">
          <AIInsights
            email={selectedEmail}
            onClose={() => setShowDetail(false)}
            onUpdate={updateEmail}
            onReclassify={reclassifyEmail}
            catColors={CAT_COLORS}
            priColors={PRI_COLORS}
          />
        </div>
      )}
    </div>
  )
}
