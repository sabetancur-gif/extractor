# config.py
from pydantic_settings import BaseSettings
import os


class Settings(BaseSettings):
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")
    database_url: str = os.getenv("DATABASE_URL", "emails.db")
    debug: bool = os.getenv("DEBUG", "false").lower() == "true"
    secret_key: str = os.getenv("SECRET_KEY", "change-this-in-production-32chars")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
