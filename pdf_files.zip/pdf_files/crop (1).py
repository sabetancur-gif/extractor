# src/utils/crop.py
"""
Utilidad de recorte de regiones PDF.

Dos mejoras sobre la version original:
1. Padding adaptativo: inversamente proporcional al tamano del bloque.
   Bloques pequenos reciben mas contexto visual que bloques grandes.
2. Sharpening adaptativo: detecta el nivel de desenfoque del crop y aplica
   el tratamiento justo. Documentos nativos no se tocan; escaneados
   borrosos reciben denoise + CLAHE + UnsharpMask calibrado por nivel.
"""
from __future__ import annotations

import base64
import io
import math
from typing import Any

import cv2
import numpy as np
from PIL import Image, ImageFilter


# ── Multiplicadores de padding por tipo semantico ─────────────────────────────
_SEMANTIC_MULTIPLIERS: dict[str, tuple[float, float]] = {
    "signature":   (1.6, 1.0),
    "table":       (0.8, 1.8),
    "address":     (1.2, 1.2),
    "amount":      (1.5, 0.8),
    "date":        (1.5, 0.8),
    "title":       (0.7, 0.6),
    "subtitle":    (0.9, 0.7),
    "header":      (0.6, 0.4),
    "footer":      (0.6, 0.4),
    "email":       (1.4, 0.7),
    "phone":       (1.4, 0.7),
    "identifier":  (1.5, 0.8),
    "paragraph":   (0.8, 0.6),
    "url":         (1.3, 0.6),
}

# ── Umbrales de nitidez (varianza Laplaciana) y parametros de tratamiento ─────
# Formato: (umbral_minimo, nivel, usar_clahe, usar_denoise, usm_radius, usm_percent, usm_threshold)
_SHARPNESS_THRESHOLDS = [
    (2000, "sharp",       False, False, 0, 0,   0),   # nativo / alta resolucion → sin toque
    (500,  "moderate",    False, False, 1, 120, 3),   # 300 DPI → USM ligero
    (100,  "blurry",      True,  False, 2, 170, 2),   # 200 DPI → CLAHE + USM moderado
    (30,   "very_blurry", True,  True,  2, 200, 1),   # 150 DPI → denoise + CLAHE + USM
    (0,    "extreme",     True,  True,  3, 220, 0),   # fotocopia → tratamiento maximo
]


# ── Padding adaptativo ────────────────────────────────────────────────────────

def compute_adaptive_padding(
    block_w: int,
    block_h: int,
    img_w: int,
    img_h: int,
    semantic_type: str = "other",
    min_pad: int = 8,
    max_pad: int = 80,
) -> tuple[int, int, int, int]:
    """
    Calcula padding asimetrico (top, right, bottom, left) adaptado al bloque.

    Principio: cuanto mas pequeno es el bloque relativo a la pagina, mas
    contexto visual necesita para que el crop sea interpretable.

    Retorna: (pad_top, pad_right, pad_bottom, pad_left) en pixeles.
    """
    img_area     = max(1, img_w * img_h)
    block_area   = max(1, block_w * block_h)
    area_ratio   = block_area / img_area
    pad_fraction = max(0.0, min(1.0, 1.0 - math.sqrt(min(1.0, area_ratio * 200))))
    pad_base     = min_pad + pad_fraction * (max_pad - min_pad)

    mv, mh  = _SEMANTIC_MULTIPLIERS.get(semantic_type, (1.0, 1.0))
    pad_v   = pad_base * mv
    pad_h   = pad_base * mh

    pad_top    = pad_v * 1.2   # 20% mas arriba: labels suelen estar encima
    pad_bottom = pad_v
    pad_left   = pad_h
    pad_right  = pad_h

    max_v = img_h // 4
    max_h = img_w // 4

    return (
        max(min_pad, min(max_pad, min(max_v, int(pad_top)))),
        max(min_pad, min(max_pad, min(max_h, int(pad_right)))),
        max(min_pad, min(max_pad, min(max_v, int(pad_bottom)))),
        max(min_pad, min(max_pad, min(max_h, int(pad_left)))),
    )


# ── Sharpening adaptativo ─────────────────────────────────────────────────────

def _laplacian_variance(img: Image.Image) -> float:
    """Mide la nitidez de una imagen. Mayor valor = mas nítida."""
    arr = np.array(img.convert("L"))
    return float(cv2.Laplacian(arr, cv2.CV_64F).var())


def _classify_sharpness(lv: float) -> tuple:
    """Retorna (nivel, usar_clahe, usar_denoise, usm_r, usm_p, usm_t)."""
    for lo, level, clahe, denoise, usm_r, usm_p, usm_t in _SHARPNESS_THRESHOLDS:
        if lv >= lo:
            return level, clahe, denoise, usm_r, usm_p, usm_t
    return "sharp", False, False, 0, 0, 0


def _apply_clahe(img: Image.Image, clip: float = 2.0) -> Image.Image:
    """
    Mejora el contraste local con CLAHE (Contrast Limited Adaptive Histogram
    Equalization). Opera en el canal Y del espacio YCrCb para no afectar el color.
    Util para texto de bajo contraste en documentos escaneados.
    """
    arr  = np.array(img.convert("RGB"))
    ycc  = cv2.cvtColor(arr, cv2.COLOR_RGB2YCrCb)
    cl   = cv2.createCLAHE(clipLimit=clip, tileGridSize=(8, 8))
    ycc[:, :, 0] = cl.apply(ycc[:, :, 0])
    return Image.fromarray(cv2.cvtColor(ycc, cv2.COLOR_YCrCb2RGB))


def _apply_denoise(img: Image.Image) -> Image.Image:
    """
    Elimina ruido de escaner con Non-Local Means (NLMeans).
    Se aplica ANTES del sharpening para no amplificar el ruido con USM.
    h=5 es conservador: reduce ruido sin borrar detalles de texto fino.
    """
    arr = np.array(img.convert("RGB"))
    den = cv2.fastNlMeansDenoisingColored(
        arr, h=5, hColor=5, templateWindowSize=7, searchWindowSize=21
    )
    return Image.fromarray(den)


def _apply_usm(
    img: Image.Image,
    radius: int,
    percent: int,
    threshold: int,
) -> Image.Image:
    """Unsharp Mask via PIL. No hace nada si radius == 0."""
    if radius == 0:
        return img
    return img.filter(
        ImageFilter.UnsharpMask(radius=radius, percent=percent, threshold=threshold)
    )


def sharpen_scanned_crop(
    img: Image.Image,
    force_level: str | None = None,
) -> tuple[Image.Image, str]:
    """
    Aplica el pipeline de nitidez adaptativo a un crop de documento.

    Detecta automaticamente el nivel de desenfoque con varianza del Laplaciano
    y aplica el tratamiento calibrado para ese nivel:

      sharp       (lv >= 2000): sin toque — documentos nativos no necesitan procesado
      moderate    (lv >= 500):  UnsharpMask ligero — 300 DPI con ligero desenfoque
      blurry      (lv >= 100):  CLAHE + UnsharpMask — 200 DPI
      very_blurry (lv >= 30):   NLMeans + CLAHE + UnsharpMask — 150 DPI
      extreme     (lv < 30):    NLMeans + CLAHE + USM maximo — fotocopias

    Args:
        img:         Imagen PIL del crop a mejorar.
        force_level: Si se especifica ("moderate", "blurry", etc.), omite
                     la deteccion automatica y aplica ese nivel directamente.
                     Util para tests o cuando el caller ya conoce el tipo de PDF.

    Returns:
        Tupla (imagen_mejorada, nivel_detectado).
        Si el nivel es "sharp", retorna la imagen original sin cambios.
    """
    lv = _laplacian_variance(img)

    if force_level:
        # Buscar parametros del nivel forzado
        params = None
        for _, level, clahe, denoise, usm_r, usm_p, usm_t in _SHARPNESS_THRESHOLDS:
            if level == force_level:
                params = (level, clahe, denoise, usm_r, usm_p, usm_t)
                break
        if params is None:
            return img, "sharp"
        level, clahe, denoise, usm_r, usm_p, usm_t = params
    else:
        level, clahe, denoise, usm_r, usm_p, usm_t = _classify_sharpness(lv)

    if level == "sharp":
        return img, level

    result = img
    if denoise:
        result = _apply_denoise(result)
    if clahe:
        result = _apply_clahe(result)
    result = _apply_usm(result, usm_r, usm_p, usm_t)

    return result, level


# ── Helpers de bbox ───────────────────────────────────────────────────────────

def _as_box(bbox: Any) -> tuple[float, float, float, float] | None:
    if bbox is None:
        return None
    if isinstance(bbox, dict):
        x0 = bbox.get("x0", bbox.get("left",  bbox.get("xmin")))
        y0 = bbox.get("y0", bbox.get("top",   bbox.get("ymin")))
        x1 = bbox.get("x1", bbox.get("right", bbox.get("xmax")))
        y1 = bbox.get("y1", bbox.get("bottom",bbox.get("ymax")))
        if None in (x0, y0, x1, y1):
            return None
        return float(x0), float(y0), float(x1), float(y1)
    if isinstance(bbox, (list, tuple)) and len(bbox) == 4:
        return float(bbox[0]), float(bbox[1]), float(bbox[2]), float(bbox[3])
    return None


def _scale_bbox(
    box: tuple[float, float, float, float],
    img_w: int,
    img_h: int,
    pdf_width:  float | None = None,
    pdf_height: float | None = None,
) -> tuple[int, int, int, int]:
    x0, y0, x1, y1 = box
    if pdf_width and pdf_height and pdf_width > 0 and pdf_height > 0:
        sx = img_w / pdf_width
        sy = img_h / pdf_height
        x0, x1 = x0 * sx, x1 * sx
        y0, y1 = y0 * sy, y1 * sy
    elif max(abs(x0), abs(y0), abs(x1), abs(y1)) <= 1.5:
        x0, x1 = x0 * img_w, x1 * img_w
        y0, y1 = y0 * img_h, y1 * img_h
    left   = max(0, min(img_w, int(min(x0, x1))))
    top    = max(0, min(img_h, int(min(y0, y1))))
    right  = max(0, min(img_w, int(max(x0, x1))))
    bottom = max(0, min(img_h, int(max(y0, y1))))
    return left, top, right, bottom


# ── API publica ───────────────────────────────────────────────────────────────

def crop_page_region(
    image_path:     str,
    bbox:           Any,
    padding:        int | None = None,
    pdf_width:      float | None = None,
    pdf_height:     float | None = None,
    semantic_type:  str = "other",
    min_pad:        int = 8,
    max_pad:        int = 80,
    sharpen:        bool = True,
    force_sharpen_level: str | None = None,
) -> str:
    """
    Recorta la region definida por bbox con padding adaptativo y sharpening
    automatico calibrado por nivel de desenfoque.

    Args:
        image_path:          Ruta a la imagen de la pagina (PNG/JPEG).
        bbox:                Bounding box. Lista, dict, coords PDF, [0..1] o px.
        padding:             Si se especifica (int), padding fijo simetrico legado.
                             Si es None, usa el sistema adaptativo.
        pdf_width:           Ancho PDF en puntos para escalar bbox.
        pdf_height:          Alto PDF en puntos para escalar bbox.
        semantic_type:       Tipo semantico (ajusta padding y sharpening).
        min_pad:             Padding minimo en pixeles.
        max_pad:             Padding maximo en pixeles.
        sharpen:             True para aplicar sharpening adaptativo (default).
                             False para desactivarlo (documentos nativos o cuando
                             el caller ya hizo su propio procesado).
        force_sharpen_level: Forzar nivel de sharpening ("moderate", "blurry", etc.)
                             ignorando la deteccion automatica.

    Returns:
        Data-URI "data:image/png;base64,..." o "" si hay error.
    """
    box = _as_box(bbox)
    if not image_path or box is None:
        return ""

    try:
        with Image.open(image_path) as img:
            img = img.convert("RGB")
            img_w, img_h = img.size
            left, top, right, bottom = _scale_bbox(
                box, img_w, img_h, pdf_width, pdf_height
            )

            block_w = max(1, right  - left)
            block_h = max(1, bottom - top)

            # ── Padding ───────────────────────────────────────────────────────
            if padding is not None:
                pt = pb = pl = pr = int(padding)
            else:
                pt, pr, pb, pl = compute_adaptive_padding(
                    block_w, block_h, img_w, img_h,
                    semantic_type=semantic_type,
                    min_pad=min_pad,
                    max_pad=max_pad,
                )

            left   = max(0,     left   - pl)
            top    = max(0,     top    - pt)
            right  = min(img_w, right  + pr)
            bottom = min(img_h, bottom + pb)

            if right <= left or bottom <= top:
                return ""

            crop = img.crop((left, top, right, bottom))

            # ── Sharpening adaptativo ─────────────────────────────────────────
            if sharpen:
                crop, _ = sharpen_scanned_crop(crop, force_level=force_sharpen_level)

            buf     = io.BytesIO()
            crop.save(buf, format="PNG", optimize=True)
            encoded = base64.b64encode(buf.getvalue()).decode("ascii")
            return f"data:image/png;base64,{encoded}"

    except Exception:
        return ""
