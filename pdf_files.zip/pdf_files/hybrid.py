# src/extraction/hybrid.py
from __future__ import annotations
from typing import Any
from .base import BaseExtractor
from .native import NativePDFExtractor
from .ocr import OCRExtractor
from src.utils.geometry import iou_bbox
from src.extraction.block_classifier import classify_block


def _fix_bbox(block, page_w, page_h):
    bbox = block.get("bbox", [0,0,0,0])
    if len(bbox) < 4: return [0,0,0,0]
    x0,y0,x1,y1 = bbox
    x0,x1 = sorted([float(x0),float(x1)])
    y0,y1 = sorted([float(y0),float(y1)])
    if page_w: x0,x1 = max(0.0,x0), min(float(page_w),x1)
    if page_h: y0,y1 = max(0.0,y0), min(float(page_h),y1)
    return [round(x0),round(y0),round(x1),round(y1)]


def _enrich_block(block, order, page_w, page_h):
    from .field_detection import extract_fields_from_block
    block["order"] = order
    text = block.get("text","")
    if text:
        fi = extract_fields_from_block(text, context=text)
        if fi:
            block["field_type"]  = fi["field"]
            block["field_value"] = fi["value"]
            block["all_fields"]  = fi.get("all_fields",[])
    font_size  = block.get("font_size")
    text_lower = text.lower()
    text_len   = len(text)
    if font_size and font_size > 16 and text_len < 80:
        block["block_type"] = "title"
    elif "table" in text_lower or "tabla" in text_lower:
        block["block_type"] = "table"
    elif any(k in text_lower for k in ["total","monto","$","importe"]):
        block["block_type"] = "amount"
    elif any(k in text_lower for k in ["fecha","date"]):
        block["block_type"] = "date"
    elif text_len > 200:
        block["block_type"] = "paragraph"
    elif text_len < 30 and font_size and font_size > 10:
        block["block_type"] = "header"
    else:
        block["block_type"] = "other"
    semantic = classify_block(block, page_width=page_w, page_height=page_h)
    block.update({
        "semantic_type":       semantic["semantic_type"],
        "semantic_confidence": semantic["confidence"],
        "semantic_labels":     semantic["labels"],
        "is_table_like":       semantic["is_table_like"],
        "is_signature":        semantic["is_signature"],
        "is_logo":             semantic["is_logo"],
        "is_image":            semantic["is_image"],
        "is_address":          semantic["is_address"],
        "is_date":             semantic["is_date"],
        "is_amount":           semantic["is_amount"],
        "is_phone":            semantic["is_phone"],
        "is_email":            semantic["is_email"],
        "is_url":              semantic["is_url"],
        "is_identifier":       semantic["is_identifier"],
        "is_name":             semantic.get("is_name", False),
        "is_math":             semantic.get("is_math", False),
    })
    return block


def _partition_pages(detection, total_pages):
    """
    Separa páginas en 3 grupos según DetectionResult:
      native_only  → solo fitz      (rápido)
      ocr_only     → solo Tesseract (lento — solo las que lo necesitan)
      mixed_both   → ambos + fusión
    """
    native_only, ocr_only, mixed_both = [], [], []
    for pno in range(1, total_pages + 1):
        pt = detection.page_type_for(pno)
        if pt == "scanned":
            ocr_only.append(pno)
        elif pt == "mixed":
            mixed_both.append(pno)
        else:
            native_only.append(pno)
    return native_only, ocr_only, mixed_both


class HybridExtractor(BaseExtractor):
    """
    Extractor híbrido inteligente página a página.

    CON DetectionResult:
      - native  → solo NativePDFExtractor.extract_pages([...])
      - scanned → solo OCRExtractor.extract_pages([...])
      - mixed   → ambos + fusión de duplicados

    SIN DetectionResult (fallback):
      - Comportamiento anterior: ambos extractores en todo el doc.

    AHORRO TÍPICO (PDF 40p, 5 escaneadas):
      Antes:      40p native + 40p OCR = ~122s
      Optimizado: 35p native +  5p OCR =  ~17s  (86% menos)
    """

    def __init__(self, native=None, ocr=None, iou_thresh=0.45):
        self.native     = native or NativePDFExtractor()
        self.ocr        = ocr    or OCRExtractor()
        self.iou_thresh = iou_thresh

    def _is_duplicate(self, ocr_block, native_blocks):
        ocr_text = ocr_block.get("text","").strip().lower()
        for nb in native_blocks:
            if iou_bbox(ocr_block["bbox"], nb["bbox"]) > self.iou_thresh:
                return True
            if ocr_text and ocr_text == nb.get("text","").strip().lower():
                return True
        return False

    def extract(self, file_path: str, detection=None):
        if detection is not None:
            return self._extract_per_page(file_path, detection)
        return self._extract_fallback(file_path)

    # ── MODO PRINCIPAL: por página ────────────────────────────────────────────

    def _extract_per_page(self, file_path: str, detection) -> list[dict]:
        """
        Llama extract_pages([lista]) en cada extractor solo con las páginas
        que realmente necesitan ese tipo de procesamiento.
        """
        import fitz

        # Obtener total de páginas del documento
        total = getattr(detection, "total_pages", 0)
        if not total:
            doc   = fitz.open(file_path)
            total = len(doc)
            doc.close()

        native_only, ocr_only, mixed_both = _partition_pages(detection, total)

        native_needed = set(native_only) | set(mixed_both)
        ocr_needed    = set(ocr_only)    | set(mixed_both)

        # ── Extraer solo lo necesario ─────────────────────────────────────────
        native_map: dict[int, dict] = {}
        if native_needed:
            for p in self.native.extract_pages(file_path, sorted(native_needed)):
                native_map[p["page_number"]] = p

        ocr_map: dict[int, dict] = {}
        if ocr_needed:
            for p in self.ocr.extract_pages(file_path, sorted(ocr_needed)):
                ocr_map[p["page_number"]] = p

        # Dimensiones de páginas vacías (no pasaron por ningún extractor)
        dim_map: dict[int, tuple] = {}
        empty_pages = set(range(1, total + 1)) - native_needed - ocr_needed
        if empty_pages:
            doc = fitz.open(file_path)
            for pno in empty_pages:
                if 1 <= pno <= len(doc):
                    r = doc[pno - 1].rect
                    dim_map[pno] = (r.width, r.height)
            doc.close()

        # ── Ensamblar resultado página a página ───────────────────────────────
        pages_out: list[dict] = []

        for pno in range(1, total + 1):
            page_type = detection.page_type_for(pno)

            # Dimensiones
            if pno in native_map:
                pw, ph = native_map[pno].get("width"), native_map[pno].get("height")
            elif pno in ocr_map:
                pw, ph = ocr_map[pno].get("width"), ocr_map[pno].get("height")
            elif pno in dim_map:
                pw, ph = dim_map[pno]
            else:
                pw = ph = None

            # ── Página nativa / vacía ─────────────────────────────────────────
            if page_type in ("native", "empty"):
                out_blocks = []
                for b in native_map.get(pno, {}).get("blocks", []):
                    b["bbox"] = _fix_bbox(b, pw, ph)
                    out_blocks.append(b)

            # ── Página escaneada ──────────────────────────────────────────────
            elif page_type == "scanned":
                out_blocks = []
                for b in ocr_map.get(pno, {}).get("blocks", []):
                    b["bbox"]   = _fix_bbox(b, pw, ph)
                    b["source"] = b.get("source", "ocr")
                    out_blocks.append(b)

            # ── Página mixta: fusionar ────────────────────────────────────────
            else:
                native_blocks = native_map.get(pno, {}).get("blocks", [])
                ocr_blocks    = ocr_map.get(pno, {}).get("blocks", [])
                native_texts  = {b.get("text","").strip().lower() for b in native_blocks}
                out_blocks = []
                for b in native_blocks:
                    b["bbox"] = _fix_bbox(b, pw, ph)
                    out_blocks.append(b)
                for ob in ocr_blocks:
                    ob["bbox"] = _fix_bbox(ob, pw, ph)
                    if (not self._is_duplicate(ob, native_blocks)
                            and ob.get("text","").strip().lower() not in native_texts):
                        ob["source"] = ob.get("source", "ocr")
                        out_blocks.append(ob)

            # ── Ordenar y enriquecer ──────────────────────────────────────────
            out_blocks.sort(key=lambda b: (b["bbox"][1], b["bbox"][0]))
            for idx, b in enumerate(out_blocks):
                _enrich_block(b, idx, pw, ph)

            pages_out.append({
                "page_number": pno,
                "width":       pw,
                "height":      ph,
                "page_type":   page_type,
                "blocks":      out_blocks,
            })

        return pages_out

    # ── FALLBACK: sin DetectionResult ─────────────────────────────────────────

    def _extract_fallback(self, file_path: str) -> list[dict]:
        """
        Sin DetectionResult: extrae con ambos y fusiona (comportamiento anterior).
        Se usa cuando el pipeline no pasó detection, o el tipo es desconocido.
        """
        native_pages = self.native.extract(file_path)

        def _chars(pages):
            return sum(len(b.get("text","").strip())
                       for p in pages for b in p.get("blocks",[]))

        if not native_pages or _chars(native_pages) < 30:
            return self.ocr.extract(file_path)

        ocr_pages  = self.ocr.extract(file_path)
        ocr_by_num = {p.get("page_number", i+1): p
                      for i, p in enumerate(ocr_pages)}

        pages_out = []
        for i, n_page in enumerate(native_pages):
            pno    = n_page.get("page_number", i+1)
            pw, ph = n_page.get("width"), n_page.get("height")
            o_page = ocr_by_num.get(pno, {"blocks": []})

            native_texts = set()
            out_blocks   = []
            for b in n_page["blocks"]:
                b["bbox"] = _fix_bbox(b, pw, ph)
                native_texts.add(b.get("text","").strip().lower())
                out_blocks.append(b)
            for ob in o_page.get("blocks",[]):
                ob["bbox"] = _fix_bbox(ob, pw, ph)
                if (not self._is_duplicate(ob, n_page["blocks"])
                        and ob.get("text","").strip().lower() not in native_texts):
                    ob["source"] = ob.get("source","ocr")
                    out_blocks.append(ob)

            out_blocks.sort(key=lambda b: (b["bbox"][1], b["bbox"][0]))
            for idx, b in enumerate(out_blocks):
                _enrich_block(b, idx, pw, ph)

            pages_out.append({
                "page_number": pno,
                "width":       pw,
                "height":      ph,
                "page_type":   "unknown",
                "blocks":      out_blocks,
            })

        return pages_out
