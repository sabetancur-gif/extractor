# src/utils/minimap.py
"""
Generacion de minimaps de pagina PDF con bloque resaltado.

Un minimap es una miniatura de la pagina completa con el bbox del bloque
seleccionado destacado mediante un rectangulo semitransparente + borde.
Permite al usuario ver en que parte de la pagina esta el elemento
sin necesidad de hacer scroll en el overlay completo.
"""
from __future__ import annotations

import base64
import io
from typing import Any

from PIL import Image, ImageDraw


def generate_minimap(
    page_img_path: str,
    bbox: list[float] | tuple[float, ...],
    pdf_width:  float | None = None,
    pdf_height: float | None = None,
    minimap_w:  int   = 200,
    highlight_color: tuple[int, int, int] = (227, 83, 15),
    highlight_alpha: float = 0.25,
    border_px:  int   = 2,
) -> str:
    """
    Genera una miniatura de la pagina completa con el bloque resaltado.

    Escala la imagen de la pagina a minimap_w pixeles de ancho (manteniendo
    el aspect ratio), luego dibuja un rectangulo naranja semitransparente
    sobre la region del bbox para indicar donde esta el bloque.

    Args:
        page_img_path:   Ruta a la imagen de la pagina completa (PNG/JPEG).
        bbox:            Bounding box del bloque [x0, y0, x1, y1].
                         Acepta coordenadas PDF (si se pasan pdf_width/pdf_height),
                         normalizadas [0..1], o en pixeles directamente.
        pdf_width:       Ancho de la pagina en puntos PDF.
                         Necesario para convertir bbox de coords PDF a pixeles.
        pdf_height:      Alto de la pagina en puntos PDF.
        minimap_w:       Ancho del minimap en pixeles (default 200).
                         El alto se calcula para mantener el aspect ratio de la pagina.
        highlight_color: Color RGB del rectangulo de resaltado (default naranja del tema).
        highlight_alpha: Opacidad del relleno del rectangulo, 0.0-1.0 (default 0.25).
        border_px:       Grosor del borde del rectangulo en pixeles (default 2).

    Returns:
        Data-URI "data:image/png;base64,..." listo para usar como src de <img>.
        Retorna "" si la imagen no existe, el bbox es invalido, o hay cualquier error.
    """
    if not page_img_path or not bbox or len(bbox) < 4:
        return ""

    try:
        with Image.open(page_img_path) as img:
            img = img.convert("RGBA")
            img_w, img_h = img.size
            if img_w == 0 or img_h == 0:
                return ""

            # ── Escalar pagina a minimap ──────────────────────────────────────
            scale     = minimap_w / img_w
            minimap_h = int(img_h * scale)
            thumb     = img.resize((minimap_w, minimap_h), Image.LANCZOS)

            # ── Convertir bbox a pixeles de la imagen ─────────────────────────
            x0, y0, x1, y1 = float(bbox[0]), float(bbox[1]), float(bbox[2]), float(bbox[3])

            if pdf_width and pdf_height and pdf_width > 0 and pdf_height > 0:
                # Coordenadas PDF -> pixeles de imagen
                sx = img_w / pdf_width
                sy = img_h / pdf_height
                x0, x1 = x0 * sx, x1 * sx
                y0, y1 = y0 * sy, y1 * sy
            elif max(abs(x0), abs(y0), abs(x1), abs(y1)) <= 1.5:
                # Coordenadas normalizadas [0..1]
                x0, x1 = x0 * img_w, x1 * img_w
                y0, y1 = y0 * img_h, y1 * img_h
            # else: ya en pixeles, usar directamente

            # ── Escalar bbox al espacio del minimap ───────────────────────────
            mx0 = max(0,         int(min(x0, x1) * scale))
            my0 = max(0,         int(min(y0, y1) * scale))
            mx1 = min(minimap_w, int(max(x0, x1) * scale))
            my1 = min(minimap_h, int(max(y0, y1) * scale))

            # Garantizar que el rectangulo tenga al menos 2px de tamano visible
            if mx1 - mx0 < 2:
                mx1 = min(minimap_w, mx0 + 2)
            if my1 - my0 < 2:
                my1 = min(minimap_h, my0 + 2)

            if mx1 <= mx0 or my1 <= my0:
                return ""

            # ── Dibujar highlight sobre la miniatura ──────────────────────────
            overlay = Image.new("RGBA", (minimap_w, minimap_h), (0, 0, 0, 0))
            draw    = ImageDraw.Draw(overlay)

            r, g, b  = highlight_color
            alpha_fill = max(0, min(255, int(highlight_alpha * 255)))

            # Relleno semitransparente
            draw.rectangle(
                [mx0, my0, mx1, my1],
                fill=(r, g, b, alpha_fill),
            )
            # Borde solido (varios pasadas para grosor)
            for i in range(border_px):
                x0b = mx0 + i
                y0b = my0 + i
                x1b = mx1 - i
                y1b = my1 - i
                if x1b > x0b and y1b > y0b:
                    draw.rectangle([x0b, y0b, x1b, y1b], outline=(r, g, b, 255))

            # ── Componer y serializar ─────────────────────────────────────────
            result = Image.alpha_composite(thumb, overlay).convert("RGB")

            buf = io.BytesIO()
            result.save(buf, format="PNG", optimize=True)
            encoded = base64.b64encode(buf.getvalue()).decode("ascii")
            return f"data:image/png;base64,{encoded}"

    except Exception:
        return ""
