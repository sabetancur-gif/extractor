"""
src/llm/prompts.py
──────────────────────────────────────────────────────────────────────────────
Prompts para el LLM Enricher con detección de tipo de documento y campos
adaptados por tipo.

ARQUITECTURA DE 2 CAPAS
────────────────────────
Capa 1 — Pre-clasificador heurístico (sin LLM, <1ms):
  classify_document_heuristic(text) → (doc_type, confidence, scores)
  Usa regex sobre los primeros 3000 chars del documento para detectar el tipo
  antes de construir el prompt. Si hay señales claras (CUFE, "Cláusula Primera",
  "Cordialmente") → devuelve el tipo con confianza alta.
  Si no hay señales suficientes → devuelve "unknown" y el LLM confirma.

Capa 2 — Prompt adaptado al tipo (build_enrichment_prompt):
  Si el tipo es conocido (heurístico o pasado explícitamente), el prompt incluye:
    - La sección DOCUMENT TYPE con el tipo ya determinado
    - Lista de campos REQUIRED para ese tipo (el LLM los busca primero)
    - Lista de campos OPTIONAL comunes
    - SEARCH HINT específico del tipo (guía de dónde buscar cada campo)
  Si el tipo es "unknown" → el LLM primero lo detecta, luego extrae campos.

TIPOS SOPORTADOS
────────────────
  invoice  → Factura, cuenta de cobro, invoice, bill
  contract → Contrato, convenio, acuerdo
  letter   → Carta, comunicado, circular, oficio, memo
  report   → Informe, acta, diagnóstico, reporte
  form     → Formulario, solicitud, declaración
  receipt  → Recibo, comprobante, voucher
  id_card  → Cédula, pasaporte, licencia, ID
  other    → Cualquier otro documento
"""
from __future__ import annotations

import re
import unicodedata
from typing import Any


# ── System prompt base ────────────────────────────────────────────────────────
#
# Instructivo general que el LLM recibe en todos los llamados.
# No varía por tipo de documento — la variación está en el USER prompt.

SYSTEM_PROMPT = """\
You are a document-enrichment assistant for a PDF extraction pipeline.
You work with documents in Spanish and English (mainly Colombian business documents).

Your task:
1. Read the document text carefully.
2. Identify the document type if not already provided.
3. Extract ALL fields listed under REQUIRED FIELDS and OPTIONAL FIELDS.
4. Fill or correct missing/low-confidence fields using text evidence only.
5. Return STRICT JSON ONLY — no markdown, no code fences, no preamble.

Output JSON structure (EXACT, no deviations):
{
  "document_type": "<invoice|contract|letter|report|form|receipt|id_card|other>",
  "document_summary": "<1-3 sentence summary in the document language>",
  "fill_suggestions": [
    {
      "field": "<field_id from the REQUIRED/OPTIONAL list>",
      "suggested_value": "<extracted value, or null if not found>",
      "confidence": <0.0 to 1.0>,
      "status": "<filled|corrected|new|rejected>",
      "reason": "<brief explanation, 1 sentence>",
      "evidence": ["<exact text excerpt supporting this value>"],
      "page_number": <int or null>
    }
  ]
}

Status meanings:
  filled    → field was missing/empty, you found a value
  corrected → field had a value but low confidence, you improved it
  new       → field not in the original extraction, you found it
  rejected  → you could NOT find a reliable value in the document

Rules:
  - NEVER invent data not present in the document text.
  - Confidence 1.0 = certain (exact match in text). 0.5 = inferred. 0.0 = guessed.
  - Always respond in the SAME language as the document.
  - Include ALL required fields in fill_suggestions, even if status=rejected.
"""


# ── Schema de campos por tipo de documento ────────────────────────────────────
#
# Cada tipo tiene: required (campos que siempre se buscan), optional (si están
# presentes), y search_hint (guía de búsqueda específica para el tipo).
#
# Los field_id son snake_case y bilingüe-friendly: el LLM entiende el contexto
# por la descripción en inglés, independientemente del idioma del documento.

FIELD_SCHEMA: dict[str, dict[str, Any]] = {
    "invoice": {
        "label":    "Factura / Cuenta de cobro / Invoice / Bill",
        "required": [
            ("numero_factura",    "Invoice or bill number"),
            ("fecha_emision",     "Issue date"),
            ("fecha_vencimiento", "Due date / payment deadline"),
            ("emisor_nombre",     "Issuer / seller company name"),
            ("emisor_nit",        "Issuer NIT, RUC, RFC or Tax ID"),
            ("receptor_nombre",   "Recipient / buyer / client name"),
            ("receptor_nit",      "Recipient NIT or Tax ID"),
            ("subtotal",          "Subtotal amount before taxes"),
            ("iva",               "VAT / IVA / tax amount"),
            ("total",             "Total amount due"),
            ("forma_pago",        "Payment method (cash, transfer, etc.)"),
        ],
        "optional": [
            ("cufe",             "CUFE — Colombian electronic invoice verification code"),
            ("descripcion",      "Service or product description"),
            ("banco",            "Bank name for payment"),
            ("cuenta_bancaria",  "Bank account number"),
            ("moneda",           "Currency (COP, USD, EUR, etc.)"),
            ("orden_compra",     "Purchase order number"),
            ("periodo",          "Service period covered"),
        ],
        "search_hint": (
            "Search for: invoice number (No., #, Factura), NIT of both parties, "
            "amounts labeled subtotal/IVA/total, payment date, CUFE code (40+ char hex), "
            "bank transfer details, service period."
        ),
    },

    "contract": {
        "label":    "Contrato / Convenio / Acuerdo / Contract / Agreement",
        "required": [
            ("numero_contrato",   "Contract or agreement reference number"),
            ("fecha_suscripcion", "Contract signing / execution date"),
            ("fecha_inicio",      "Contract start date / vigencia desde"),
            ("fecha_fin",         "Contract end date / vigencia hasta"),
            ("parte_contratante", "Contracting party — name and NIT/ID"),
            ("parte_contratista", "Contractor / service provider — name and NIT/ID"),
            ("objeto",            "Contract purpose / object (Cláusula Primera)"),
            ("valor_contrato",    "Total contract value / amount"),
            ("forma_pago",        "Payment schedule or terms"),
            ("lugar_suscripcion", "City where the contract was signed"),
        ],
        "optional": [
            ("supervisor",          "Assigned contract supervisor"),
            ("representante_legal", "Legal representative name(s)"),
            ("garantias",           "Required guarantees or warranties"),
            ("plazo",               "Duration in days/months/years"),
            ("acta_inicio",         "Start act (acta de inicio) number"),
            ("adicion_valor",       "Value amendment or addition"),
            ("numero_poliza",       "Insurance policy number"),
        ],
        "search_hint": (
            "Search for: 'CONTRATO No.' or reference, signing date, start/end dates, "
            "full names and NIT of both parties, Cláusula Primera (object), "
            "total value, legal representatives, guarantees, city."
        ),
    },

    "letter": {
        "label":    "Carta / Comunicado / Circular / Oficio / Letter / Memo",
        "required": [
            ("fecha",              "Letter date"),
            ("destinatario",       "Recipient name and/or company"),
            ("remitente",          "Sender name and/or company"),
            ("asunto",             "Subject line (ASUNTO / RE / Subject)"),
            ("ciudad",             "Origin city"),
        ],
        "optional": [
            ("radicado",           "Filing or reference number (Radicado)"),
            ("cargo_remitente",    "Sender job title / position"),
            ("cargo_destinatario", "Recipient job title / position"),
            ("adjuntos",           "Attachments mentioned"),
            ("copia",              "CC recipients"),
        ],
        "search_hint": (
            "Search for: date at top, salutation (Señores/Estimado/Dear), "
            "ASUNTO or Subject line, closing phrase (Cordialmente/Atentamente/Sincerely), "
            "sender name and position, reference/radicado number."
        ),
    },

    "report": {
        "label":    "Informe / Acta / Diagnóstico / Reporte / Report / Minutes",
        "required": [
            ("titulo",        "Report title"),
            ("numero",        "Report or act number"),
            ("fecha",         "Report date"),
            ("elaborado_por", "Prepared by — name and position"),
            ("periodo",       "Reporting period or date range"),
            ("entidad",       "Entity, company or department"),
        ],
        "optional": [
            ("aprobado_por",      "Approved by"),
            ("revisado_por",      "Reviewed by"),
            ("conclusion",        "Main conclusion or result"),
            ("hallazgos",         "Key findings"),
            ("recomendaciones",   "Recommendations"),
        ],
        "search_hint": (
            "Search for: report title and number, report date, "
            "author(s) with positions, entity name, period covered, "
            "conclusions section, recommendation section."
        ),
    },

    "form": {
        "label":    "Formulario / Solicitud / Declaración / Form / Application",
        "required": [
            ("nombre_solicitante", "Applicant full name"),
            ("identificacion",     "ID number (cédula, NIT, passport)"),
            ("fecha_solicitud",    "Application or submission date"),
            ("tipo_solicitud",     "Type or purpose of the request"),
        ],
        "optional": [
            ("cargo",           "Applicant job title / position"),
            ("dependencia",     "Department or organizational unit"),
            ("firma",           "Signature present (yes/no)"),
            ("datos_contacto",  "Contact information (phone, email)"),
        ],
        "search_hint": (
            "Search for: applicant name and ID number, date, "
            "purpose or type of request, department, contact details, "
            "signature fields."
        ),
    },

    "receipt": {
        "label":    "Recibo / Comprobante / Voucher / Receipt",
        "required": [
            ("numero_recibo",    "Receipt or voucher number"),
            ("fecha",            "Receipt date"),
            ("pagador_nombre",   "Payer name"),
            ("concepto",         "Payment concept or description"),
            ("valor",            "Amount paid"),
            ("forma_pago",       "Payment method"),
        ],
        "optional": [
            ("recibido_por",       "Received by (name)"),
            ("numero_transaccion", "Transaction / authorization number"),
            ("banco",              "Bank or payment platform"),
        ],
        "search_hint": (
            "Search for: receipt number, payer name, payment date, "
            "concept/description, total amount, payment method, "
            "bank or transaction reference."
        ),
    },

    "id_card": {
        "label":    "Documento de identidad / Cédula / Pasaporte / ID Card / Passport",
        "required": [
            ("nombres",            "First name(s)"),
            ("apellidos",          "Last name(s)"),
            ("numero_documento",   "Document number"),
            ("fecha_nacimiento",   "Date of birth"),
            ("lugar_nacimiento",   "Place of birth"),
            ("fecha_expedicion",   "Issue date"),
            ("lugar_expedicion",   "Issue place / municipality"),
        ],
        "optional": [
            ("genero",           "Gender"),
            ("sangre",           "Blood type / RH factor"),
            ("fecha_vencimiento","Expiry date"),
        ],
        "search_hint": (
            "Search for: full name (names + surnames), document number, "
            "birth date and place, issue date and municipality, "
            "blood type, expiry date."
        ),
    },

    "other": {
        "label":    "Documento genérico / Generic document",
        "required": [
            ("titulo",    "Document title or heading"),
            ("fecha",     "Main date"),
            ("entidad",   "Entity, company or author"),
        ],
        "optional": [
            ("referencia", "Reference number"),
            ("firmante",   "Signatory name"),
            ("lugar",      "Location or city"),
        ],
        "search_hint": (
            "Search for: title, all dates, entity/company names, "
            "any amounts or identifiers, reference numbers, signatories."
        ),
    },
}


# ── Pre-clasificador heurístico ───────────────────────────────────────────────

def _norm(text: str) -> str:
    """Minúsculas sin acentos para matching robusto."""
    return "".join(
        c for c in unicodedata.normalize("NFD", text.lower())
        if unicodedata.category(c) != "Mn"
    )


# Señales por tipo: (peso, patrón)
# Peso 1.0 = señal definitiva | 0.6-0.8 = señal fuerte | 0.3-0.4 = señal débil
_TYPE_SIGNALS: dict[str, list[tuple[float, re.Pattern]]] = {
    "invoice": [
        (1.0, re.compile(r"factura\s+(electronica|de\s+venta|no\.?)", re.I)),
        (1.0, re.compile(r"\bcufe\b",   re.I)),
        (1.0, re.compile(r"invoice\s+(no\.?|number|#)", re.I)),
        (0.8, re.compile(r"\binvoice\b", re.I)),
        (0.6, re.compile(r"\bfactura\b", re.I)),
        (0.6, re.compile(r"subtotal\b.*\biva\b|\biva\b.*\bsubtotal\b", re.I)),
        (0.6, re.compile(r"cuenta\s+de\s+cobro", re.I)),
        (0.6, re.compile(r"orden\s+de\s+(compra|servicio)", re.I)),
        (0.6, re.compile(r"bill\s+to\b", re.I)),
        (0.6, re.compile(r"payment\s+(due|terms)", re.I)),
        (0.3, re.compile(r"forma\s+de\s+pago", re.I)),
        (0.3, re.compile(r"\btax\s+id\b|\bvat\b", re.I)),
    ],
    "contract": [
        (1.0, re.compile(r"contrato\s+de\b", re.I)),
        (1.0, re.compile(r"las\s+partes\s+contratantes", re.I)),
        (1.0, re.compile(r"cl[aá]usula\s+(primera|segunda|\d+)", re.I)),
        (0.8, re.compile(r"\bcontrato\b", re.I)),
        (0.8, re.compile(r"el\s+contratante\b|la\s+contratista\b", re.I)),
        (0.6, re.compile(r"\bconvenio\b|\bacuerdo\b", re.I)),
        (0.6, re.compile(r"objeto\s+del\s+(contrato|convenio|acuerdo)", re.I)),
        (0.3, re.compile(r"obligaciones\s+de\s+las\s+partes", re.I)),
    ],
    "letter": [
        (1.0, re.compile(r"se[nñ]ores?\b|\bapreciado[s]?\b", re.I)),
        (1.0, re.compile(r"\bcordialmente\b|\batentamente\b", re.I)),
        (0.8, re.compile(r"\bcircular\b|\boficio\b", re.I)),
        (0.6, re.compile(r"\bcomunicado\b|\bcarta\b", re.I)),
        (0.6, re.compile(r"dear\s+(mr|ms|mrs|sir|madam)", re.I)),
        (0.3, re.compile(r"\bsincerely\b|\bregards\b", re.I)),
    ],
    "report": [
        (1.0, re.compile(r"informe\s+(de|final|t[eé]cnico)", re.I)),
        (0.8, re.compile(r"acta\s+(de|no\.?)\b", re.I)),
        (0.8, re.compile(r"\bdiagn[oó]stico\b", re.I)),
        (0.6, re.compile(r"\breporte\b|\breport\b", re.I)),
        (0.3, re.compile(r"\bconclusiones?\b|\brecomendaciones?\b", re.I)),
    ],
    "form": [
        (1.0, re.compile(r"\bformulario\b", re.I)),
        (0.8, re.compile(r"solicitud\s+de\b", re.I)),
        (0.6, re.compile(r"declaraci[oó]n\s+(de|jurada)", re.I)),
        (0.3, re.compile(r"llenar\s+(con\s+letra|en\s+imprenta)", re.I)),
    ],
    "receipt": [
        (1.0, re.compile(r"recibo\s+de\s+(pago|caja|ingreso)", re.I)),
        (0.8, re.compile(r"comprobante\s+de\s+(pago|transacci[oó]n)", re.I)),
        (0.6, re.compile(r"\bvoucher\b|\breceipt\b", re.I)),
    ],
    "id_card": [
        (1.0, re.compile(r"tarjeta\s+de\s+identidad", re.I)),
        (0.8, re.compile(r"cedula\s+de\s+ciudadan[ií]a", re.I)),
        (0.6, re.compile(r"n[uú]mero\s+de\s+identificaci[oó]n", re.I)),
        (0.6, re.compile(r"\bpasaporte\b", re.I)),
    ],
}

_HEURISTIC_CONFIDENCE_MIN = 0.15  # debajo de esto → "unknown"


def classify_document_heuristic(text: str) -> tuple[str, float, dict[str, float]]:
    """
    Pre-clasifica el tipo de documento por señales heurísticas sin LLM.

    Analiza los primeros 3000 caracteres del texto (donde suelen estar las
    señales más claras: encabezado, título, número de documento).

    Args:
        text: Texto completo o parcial del documento.

    Returns:
        Tupla (doc_type, confidence, all_scores):
          - doc_type:   Tipo detectado, o "unknown" si no hay señales claras.
          - confidence: Score normalizado [0..1] sobre el máximo posible del tipo.
          - all_scores: Dict con los scores de todos los tipos (para debug/log).

    Ejemplos:
        classify_document_heuristic("FACTURA No. 001 CUFE: abc123...")
        → ("invoice", 0.72, {"invoice": 5.2, ...})

        classify_document_heuristic("Estimados señores, Cordialmente...")
        → ("letter", 0.63, {"letter": 2.0, ...})

        classify_document_heuristic("Este documento certifica...")
        → ("unknown", 0.0, {})
    """
    sample = _norm(text[:3000])

    scores: dict[str, float] = {}
    for dtype, signals in _TYPE_SIGNALS.items():
        score = sum(weight for weight, pat in signals if pat.search(sample))
        if score > 0.0:
            scores[dtype] = round(score, 3)

    if not scores:
        return "unknown", 0.0, {}

    best_type  = max(scores, key=scores.__getitem__)
    best_score = scores[best_type]
    max_possible = sum(w for w, _ in _TYPE_SIGNALS[best_type])
    confidence   = round(min(1.0, best_score / max_possible), 3)

    if confidence < _HEURISTIC_CONFIDENCE_MIN:
        return "unknown", confidence, scores

    return best_type, confidence, scores


# ── Construcción del prompt ───────────────────────────────────────────────────

def _is_missing(value: Any) -> bool:
    return value in (None, "", [], {})


def _is_low_confidence(field: dict[str, Any], threshold: float = 0.45) -> bool:
    try:
        return float(field.get("confidence", 1.0) or 1.0) < threshold
    except Exception:
        return True


def _toon_field(f: dict[str, Any]) -> str:
    """Serializa un campo en TOON compacto: 'name|value|conf|page'."""
    name  = f.get("field") or f.get("label") or f.get("name") or ""
    value = f.get("value") or ""
    conf  = f.get("confidence") or ""
    page  = f.get("page_number") or f.get("page") or ""
    return f"{name}|{value}|{conf}|{page}"


def _toon_block(b: dict[str, Any]) -> str:
    """Serializa un bloque en TOON compacto: 'type|page|text[:80]'."""
    btype = b.get("semantic_type") or b.get("block_type") or "other"
    page  = b.get("page_number")  or b.get("page") or ""
    text  = (b.get("text") or "")[:80].replace("\n", " ")
    return f"{btype}|{page}|{text}"


def _build_type_section(doc_type: str, heuristic_confidence: float) -> str:
    """
    Genera la sección TYPE-AWARE del prompt con campos prioritarios.
    """
    schema = FIELD_SCHEMA.get(doc_type, FIELD_SCHEMA["other"])
    lines: list[str] = []

    if doc_type != "unknown":
        conf_note = f" (heuristic confidence: {heuristic_confidence:.0%})"
        lines += [
            f"# DOCUMENT TYPE DETECTED: {doc_type.upper()}{conf_note}",
            f"# Label: {schema['label']}",
            "",
            "# REQUIRED FIELDS — extract ALL of these (include even if status=rejected):",
        ]
        for field_id, desc in schema["required"]:
            lines.append(f"  - {field_id}: {desc}")
        lines += [
            "",
            "# OPTIONAL FIELDS — extract if present in the document:",
        ]
        for field_id, desc in schema["optional"]:
            lines.append(f"  - {field_id}: {desc}")
        lines += [
            "",
            f"# SEARCH HINT: {schema['search_hint']}",
        ]
    else:
        lines += [
            "# DOCUMENT TYPE: UNKNOWN — detect it from the text.",
            "# Possible types: invoice, contract, letter, report, form, receipt, id_card, other",
            "# Once you identify the type, extract the fields most relevant for that type.",
            "# At minimum extract: title/heading, date, entity/author, any amounts, any IDs.",
        ]

    return "\n".join(lines)


def build_enrichment_prompt(
    doc_ctx: dict[str, Any],
    mode: str = "auto_fill_missing",
    doc_type: str | None = None,
) -> str:
    """
    Construye el prompt de enriquecimiento con detección de tipo y campos adaptados.

    Flujo:
      1. Si doc_type no se pasa → clasificar heurísticamente con el texto.
      2. Construir sección TYPE-AWARE con campos required/optional del tipo.
      3. Construir sección TOON con texto, campos existentes y bloques.

    Args:
        doc_ctx:  Contexto del documento (pages, fields, classified_blocks, etc.)
        mode:     Modo de enriquecimiento ("auto_fill_missing", etc.)
        doc_type: Tipo ya conocido (p.ej. desde detección previa o metadata).
                  Si None → se clasifica automáticamente.

    Returns:
        Prompt completo listo para enviar al LLM.
    """
    # ── Extraer texto del documento ───────────────────────────────────────────
    full_text = doc_ctx.get("full_text", "")
    if not full_text:
        pages = doc_ctx.get("pages", []) or []
        parts = []
        for p in pages:
            for b in p.get("blocks", []) or []:
                t = (b.get("text") or "").strip()
                if t:
                    parts.append(f"[p{p.get('page_number', '')}] {t}")
        full_text = "\n".join(parts)

    # ── Pre-clasificación heurística ──────────────────────────────────────────
    heuristic_conf = 0.0
    if doc_type is None:
        # Usar tipo previo del LLM si ya se enriqueció antes
        doc_type = doc_ctx.get("llm_document_type") or "unknown"
        if doc_type == "unknown" or not doc_type:
            doc_type, heuristic_conf, _ = classify_document_heuristic(full_text)
    else:
        heuristic_conf = 1.0  # tipo provisto externamente → confianza máxima

    # ── Campos existentes ─────────────────────────────────────────────────────
    all_fields     = []
    missing_fields = []

    for f in (doc_ctx.get("fields", []) or [])[:100]:
        if not isinstance(f, dict):
            continue
        toon = _toon_field(f)
        all_fields.append(toon)
        if _is_missing(f.get("value")) or _is_low_confidence(f):
            missing_fields.append(toon)

    # ── Bloques relevantes ────────────────────────────────────────────────────
    relevant_types = {
        "title", "date", "amount", "email", "phone",
        "signature", "table", "address", "name", "identifier",
        "subtitle", "header",
    }
    top_blocks = [
        _toon_block(b)
        for b in (doc_ctx.get("classified_blocks", []) or [])
        if b.get("semantic_type") in relevant_types
    ][:60]

    # ── Sección de tipo con campos adaptados ──────────────────────────────────
    type_section = _build_type_section(doc_type, heuristic_conf)

    # ── Construir prompt final ────────────────────────────────────────────────
    lines: list[str] = [
        f"MODE: {mode}",
        f"FILE: {doc_ctx.get('file_name', 'unknown')}",
        f"PAGES: {doc_ctx.get('pages_total', '?')}",
        "",
        type_section,
        "",
        "# DOCUMENT TEXT (first 6000 chars):",
        full_text[:6000],
        "",
        "# ALL EXTRACTED FIELDS (name|value|confidence|page):",
        *all_fields[:80],
        "",
        "# MISSING OR LOW-CONFIDENCE FIELDS (also cover these):",
        *missing_fields[:40],
        "",
        "# RELEVANT CLASSIFIED BLOCKS (semantic_type|page|text):",
        *top_blocks,
        "",
        "# TASK:",
        "1. Confirm or correct the document type.",
        "2. Extract ALL REQUIRED FIELDS listed above.",
        "3. Extract any OPTIONAL FIELDS present in the text.",
        "4. Fill or correct MISSING/LOW-CONFIDENCE fields.",
        "5. Add NEW fields you find that are not in the lists.",
        "6. Return STRICT JSON ONLY as specified in the system prompt.",
        "   Include ALL required fields in fill_suggestions — even rejected ones.",
    ]

    return "\n".join(lines)


# ── Prompt y builder para extracción de tablas ────────────────────────────────

TABLE_SYSTEM_PROMPT = """\
You are a table-extraction assistant for a PDF processing pipeline.
Documents may be in Spanish or English (mainly Colombian business documents).

Your task: identify and extract ALL tables present in the document text.

A "table" is any structured data with:
  - Multiple rows of related information
  - Consistent columns across rows (even if column headers are implicit)
  - Examples: invoice line items, payment schedules, financial summaries,
    employee lists, product catalogs, contract clauses with amounts.

Output STRICT JSON ONLY — no markdown, no code fences, no preamble.

Output structure:
{
  "tables_found": <int>,
  "tables": [
    {
      "table_id": <int starting at 1>,
      "title": "<descriptive table title, inferred if not explicit>",
      "page_number": <int or null>,
      "table_type": "<line_items|schedule|summary|list|comparison|other>",
      "confidence": <0.0 to 1.0>,
      "headers": ["col1", "col2", ...],
      "rows": [
        ["val1", "val2", ...],
        ["val1", "val2", ...]
      ],
      "notes": "<relevant observation about the table, or null>"
    }
  ]
}

Rules:
  - Extract tables even if they use spaces/tabs for alignment (no borders).
  - Infer column headers from context if not explicitly stated.
  - Normalize numeric values: keep original format (1.500.000 not 1500000).
  - If a table spans multiple pages, merge it into one table entry.
  - confidence: 1.0 = explicit borders/headers. 0.7 = aligned columns. 0.4 = inferred.
  - Always respond in STRICT JSON. Never include explanatory text outside JSON.
"""


def build_table_extraction_prompt(doc_ctx: dict[str, Any]) -> str:
    """
    Construye el prompt de usuario para extraer tablas del documento.

    Incluye el texto completo con marcadores de tipo de bloque
    para que el LLM pueda identificar qué regiones ya fueron
    clasificadas como tablas por el pipeline.

    Args:
        doc_ctx: Contexto del documento con pages, blocks y full_text.

    Returns:
        Prompt de usuario listo para enviar al LLM junto con TABLE_SYSTEM_PROMPT.
    """
    file_name   = doc_ctx.get("file_name", "unknown")
    pages_total = doc_ctx.get("pages_total", "?")

    # Texto enriquecido con marcadores de bloque
    parts: list[str] = []
    for pg in (doc_ctx.get("pages") or []):
        pno = pg.get("page_number", "?")
        for b in (pg.get("blocks") or []):
            text  = (b.get("text") or "").strip()
            if not text or len(text) < 3:
                continue
            btype = b.get("semantic_type") or b.get("block_type") or ""
            # Marcar bloques de tabla con etiqueta especial para guiar al LLM
            if btype == "table":
                prefix = f"[TABLE_BLOCK p{pno}]"
            elif btype in ("title", "subtitle", "header"):
                prefix = f"[{btype.upper()} p{pno}]"
            else:
                prefix = f"[p{pno}]"
            parts.append(f"{prefix} {text}")

    full_text = doc_ctx.get("full_text") or "\n".join(parts)
    if not full_text and parts:
        full_text = "\n".join(parts)

    lines = [
        f"FILE: {file_name}",
        f"PAGES: {pages_total}",
        "",
        "# DOCUMENT TEXT (table-relevant blocks marked with [TABLE_BLOCK]):",
        full_text[:8000],
        "",
        "# TASK:",
        "Extract ALL tables from the document text above.",
        "Include implicit tables (space-aligned columns) and data lists.",
        "Return STRICT JSON only — no markdown, no explanations.",
    ]
    return "\n".join(lines)
