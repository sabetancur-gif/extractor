"""
src/llm/enricher.py
-------------------
Enriquecedor de documentos con LLM (Ollama).
Recibe el contexto del documento, construye el prompt TOON,
llama al modelo y parsea la respuesta JSON de forma robusta.

Correcciones clave vs. versión anterior:
- El cliente SIEMPRE retorna str → se parsea aquí.
- _extract_json() maneja: JSON puro, markdown fenced, JSON embebido.
- Se normaliza la respuesta del modelo para evitar "cambios: 0" falso-positivos.
- Se permite flexibilidad en los nombres de campo de la respuesta.
"""
from __future__ import annotations

import json
import re
import unicodedata
from copy import deepcopy
from typing import Any

from src.llm.client import BaseLLMClient, build_llm_client
from src.llm.prompts import (
    SYSTEM_PROMPT,
    build_enrichment_prompt,
    classify_document_heuristic,
    TABLE_SYSTEM_PROMPT,
    build_table_extraction_prompt,
)


# ── Parseo de JSON robusto ────────────────────────────────────────────────────

def _extract_json(raw: Any) -> dict[str, Any]:
    """
    Intenta extraer un objeto JSON de la respuesta del LLM.
    Maneja: JSON puro, markdown ```json...```, JSON embebido en texto, texto libre.
    """
    if isinstance(raw, dict):
        return raw

    text = (raw or "").strip()
    if not text:
        return {}

    # 1. JSON puro
    try:
        return json.loads(text)
    except Exception:
        pass

    # 2. Bloque markdown ```json ... ```
    for m in re.finditer(r"```(?:json)?\s*([\s\S]*?)```", text, re.IGNORECASE):
        try:
            return json.loads(m.group(1).strip())
        except Exception:
            continue

    # 3. Primer objeto JSON completo en el texto
    start = text.find("{")
    end   = text.rfind("}")
    if 0 <= start < end:
        try:
            return json.loads(text[start:end + 1])
        except Exception:
            pass

    # 4. Fallback: intentar extraer sugerencias de texto markdown
    suggestions = _parse_markdown_suggestions(text)
    if suggestions:
        return {
            "document_summary": "Respuesta en formato texto (no JSON).",
            "fill_suggestions": suggestions,
        }

    return {}


def _parse_markdown_suggestions(text: str) -> list[dict[str, Any]]:
    """
    Extrae sugerencias de una respuesta en markdown cuando el modelo no siguió el formato JSON.
    Busca patrones como: `field`: "value" o **Field:** value.
    """
    suggestions = []
    seen: set[str] = set()

    patterns = [
        re.compile(r"`([^`]+)`\s*:\s*[\"']([^\"'\n]+)[\"']"),
        re.compile(r"\*\*([^*]+)\*\*\s*:\s*[\"']([^\"'\n]+)[\"']"),
        re.compile(r"[-*]\s+`?([a-z_][a-z0-9_]*)`?\s*:\s*[\"']([^\"'\n]+)[\"']", re.I),
    ]

    for pat in patterns:
        for m in pat.finditer(text):
            f_name = m.group(1).strip()
            f_val  = m.group(2).strip()
            key    = f"{f_name}|{f_val}"
            if key not in seen and f_name and f_val:
                seen.add(key)
                suggestions.append({
                    "field":           f_name,
                    "suggested_value": f_val,
                    "confidence":      0.5,
                    "status":          "filled",
                    "reason":          "Extracted from markdown response",
                    "evidence":        [],
                    "page_number":     None,
                })

    return suggestions


# ── Normalización de sugerencias ─────────────────────────────────────────────

def _normalize_suggestion(s: Any) -> dict[str, Any] | None:
    """
    Normaliza una sugerencia del LLM a formato estándar.
    Acepta múltiples nombres de keys para mayor flexibilidad.
    """
    if not isinstance(s, dict):
        return None

    field = (
        s.get("field") or s.get("target_field") or
        s.get("name")  or s.get("field_name")
    )
    value = s.get("suggested_value")
    if value is None:
        value = s.get("value") or s.get("filled_value")

    if not field:
        return None

    try:
        confidence = float(s.get("confidence") or 0.0)
    except (TypeError, ValueError):
        confidence = 0.0

    status = s.get("status") or ("filled" if value not in (None, "", []) else "rejected")

    return {
        "field":           str(field),
        "value":           value,
        "confidence":      round(min(max(confidence, 0.0), 1.0), 3),
        "status":          status,
        "reason":          str(s.get("reason") or ""),
        "evidence":        s.get("evidence") or [],
        "page_number":     s.get("page_number"),
        "block_id":        s.get("block_id"),
    }


def _safe_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


# ── LLMEnricher ──────────────────────────────────────────────────────────────

import re as _re
import json as _json
from copy import deepcopy as _deepcopy


def _extract_json_safe(raw: Any) -> dict[str, Any]:
    """Extrae JSON de respuesta del LLM, tolerante a markdown fences."""
    if isinstance(raw, dict):
        return raw
    text = (raw or "").strip()
    if not text:
        return {}
    try:
        return _json.loads(text)
    except Exception:
        pass
    for m in _re.finditer(r"```(?:json)?\s*([\s\S]*?)```", text, _re.IGNORECASE):
        try:
            return _json.loads(m.group(1).strip())
        except Exception:
            continue
    start = text.find("{")
    end   = text.rfind("}")
    if 0 <= start < end:
        try:
            return _json.loads(text[start:end + 1])
        except Exception:
            pass
    return {}


def _normalize_table(t: Any, auto_id: int = 0) -> dict[str, Any] | None:
    """Normaliza una tabla cruda al formato estándar."""
    if not isinstance(t, dict):
        return None
    rows = t.get("rows") or []
    if not rows:
        return None

    headers = t.get("headers") or []
    if not isinstance(headers, list):
        headers = []
    headers = [str(h).strip() for h in headers if h is not None]

    clean_rows: list[list[str]] = []
    for row in rows:
        if isinstance(row, (list, tuple)):
            clean_rows.append([str(c).strip() if c is not None else "" for c in row])
        elif isinstance(row, dict):
            clean_rows.append([str(v).strip() if v is not None else "" for v in row.values()])

    if not clean_rows:
        return None

    try:
        conf = round(min(1.0, max(0.0, float(t.get("confidence") or 0.7))), 3)
    except (TypeError, ValueError):
        conf = 0.7

    table_id = int(t.get("table_id") or auto_id or 0)

    return {
        "table_id":    table_id,
        "title":       str(t.get("title") or "Tabla sin título").strip(),
        "page_number": t.get("page_number"),
        "table_type":  str(t.get("table_type") or "other"),
        "confidence":  conf,
        "headers":     headers,
        "rows":        clean_rows,
        "row_count":   len(clean_rows),
        "col_count":   len(headers) or (len(clean_rows[0]) if clean_rows else 0),
        "notes":       t.get("notes"),
    }


def parse_table_response(raw: Any) -> list[dict[str, Any]]:
    """
    Parsea la respuesta del LLM para extracción de tablas.

    Acepta JSON directo, JSON en markdown fence o JSON parcial.
    Normaliza headers y rows a tipos consistentes.
    Filtra tablas vacías. Asigna table_id si falta.

    Args:
        raw: Respuesta cruda del LLM (string o dict).

    Returns:
        Lista de tablas normalizadas. Lista vacía si no hay tablas o hay error.
    """
    parsed = _extract_json_safe(raw)
    if not parsed:
        return []

    raw_tables = (
        parsed.get("tables")
        or parsed.get("table_list")
        or parsed.get("extracted_tables")
        or []
    )
    if isinstance(raw_tables, dict):
        raw_tables = [raw_tables]

    result: list[dict[str, Any]] = []
    for i, t in enumerate(raw_tables, start=1):
        normalized = _normalize_table(t, auto_id=i)
        if normalized:
            if not normalized["table_id"]:
                normalized["table_id"] = i
            result.append(normalized)

    return result


class LLMEnricher:
    """Enriquece el contexto de un documento usando un LLM."""

    def __init__(self, client: BaseLLMClient | None = None):
        self.client = client or build_llm_client()


    def _call_llm(self, system_prompt: str, user_prompt: str) -> str:
        """Wrapper interno sobre client.generate para facilitar el mockeo en tests."""
        return self.client.generate(
            system=system_prompt,
            user=user_prompt,
            temperature=0.0,
        )

    def enrich_document(
        self,
        doc_ctx: dict[str, Any],
        mode: str = "auto_fill_missing",
        confidence_threshold: float = 0.3,
        doc_type: str | None = None,
    ) -> dict[str, Any]:
        """
        Enriquece el documento llamando al LLM con un prompt adaptado al tipo.

        Flujo:
          1. Pre-clasifica el tipo de documento heurísticamente (sin LLM).
          2. Construye el prompt con campos prioritarios para ese tipo.
          3. Llama al LLM y parsea la respuesta.
          4. Aplica sugerencias con confianza >= confidence_threshold.

        Args:
            doc_ctx:              Contexto del documento (pages, fields, etc.)
            mode:                 Modo de enriquecimiento.
            confidence_threshold: Confianza mínima para aplicar una sugerencia.
            doc_type:             Tipo de documento ya conocido. Si None, se
                                  detecta automáticamente por heurística antes
                                  de construir el prompt.

        Returns:
            Copia enriquecida del doc_ctx con llm_applied_changes, llm_raw_response,
            llm_document_type, llm_heuristic_type, llm_heuristic_confidence.
        """
        enriched = deepcopy(doc_ctx or {})

        # ── Pre-clasificación heurística (sin costo de LLM) ───────────────────
        full_text = enriched.get("full_text") or ""
        if not full_text:
            pages = enriched.get("pages") or []
            parts = []
            for pg in pages:
                for b in pg.get("blocks") or []:
                    t = (b.get("text") or "").strip()
                    if t:
                        parts.append(t)
            full_text = " ".join(parts)

        if doc_type is None:
            heuristic_type, heuristic_conf, heuristic_scores =                 classify_document_heuristic(full_text)
        else:
            heuristic_type  = doc_type
            heuristic_conf  = 1.0
            heuristic_scores = {doc_type: 1.0}

        effective_type = heuristic_type if heuristic_type != "unknown" else None

        print(
            f"[LLMEnricher] heuristic_type={heuristic_type!r} "
            f"conf={heuristic_conf:.2f} → prompt type={effective_type!r}"
        )

        # ── Prompt adaptado al tipo ───────────────────────────────────────────
        prompt = build_enrichment_prompt(
            enriched,
            mode=mode,
            doc_type=effective_type,
        )

        # Llamar al LLM (siempre retorna str)
        raw_str: str = self._call_llm(SYSTEM_PROMPT, prompt)

        # Log para debug
        print("\n===== LLM RAW RESPONSE =====")
        print(raw_str[:2000])
        print("============================\n")

        # Parsear JSON
        parsed = _extract_json(raw_str)
        warnings: list[str] = parsed.get("warnings", [])

        # Extraer sugerencias normalizando keys
        raw_suggestions = (
            parsed.get("fill_suggestions")
            or parsed.get("suggestions")
            or parsed.get("fields")
            or []
        )

        applied_changes: list[dict[str, Any]] = []
        fields_map: dict[str, dict] = {
            _safe_text(f.get("field") or "").lower(): f
            for f in (enriched.get("fields") or [])
            if isinstance(f, dict)
        }

        for raw_s in raw_suggestions:
            norm = _normalize_suggestion(raw_s)
            if not norm:
                continue

            # Solo aplicar si la confianza supera el umbral o el campo estaba vacío
            field_key    = norm["field"].lower()
            existing     = fields_map.get(field_key)
            existing_val = existing.get("value") if existing else None
            is_missing   = existing_val in (None, "", [], {})

            if norm["confidence"] >= confidence_threshold or is_missing:
                change_entry = {
                    "field":      norm["field"],
                    "value":      norm["value"],
                    "confidence": norm["confidence"],
                    "status":     norm["status"],
                    "reason":     norm["reason"],
                    "page_number":norm["page_number"],
                }
                applied_changes.append(change_entry)

                # Actualizar el campo en el contexto enriquecido
                if existing:
                    existing["llm_filled_value"]  = norm["value"]
                    existing["llm_confidence"]     = norm["confidence"]
                    existing["llm_status"]         = norm["status"]
                else:
                    # Campo nuevo detectado por el LLM
                    enriched.setdefault("fields", []).append({
                        "field":      norm["field"],
                        "value":      norm["value"],
                        "confidence": norm["confidence"],
                        "source":     "llm",
                        "status":     "new",
                    })

        # El LLM puede confirmar o corregir el tipo heurístico
        llm_type = parsed.get("document_type") or ""

        enriched.update({
            "llm_applied_changes":     applied_changes,
            "llm_raw_response":        raw_str[:8000],
            "llm_document_summary":    parsed.get("document_summary", ""),
            "llm_document_type":       llm_type or heuristic_type,
            "llm_heuristic_type":      heuristic_type,
            "llm_heuristic_confidence":heuristic_conf,
            "llm_warnings":            warnings,
            "llm_mode":                mode,
        })

        return enriched

    def extract_tables(
        self,
        doc_ctx: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Extrae todas las tablas del documento usando el LLM.

        A diferencia de enrich_document (que completa campos faltantes),
        extract_tables se enfoca exclusivamente en detectar y estructurar
        datos tabulares: ítems de factura, cronogramas de pago, listas
        de personal, resúmenes financieros, etc.

        El LLM detecta incluso tablas implícitas (columnas alineadas con
        espacios, sin bordes visibles) que el pipeline de bloques no
        captura como semantic_type="table".

        Args:
            doc_ctx: Contexto del documento con pages, blocks y/o full_text.

        Returns:
            Dict con:
              tables         → lista de tablas normalizadas
              tables_found   → número de tablas detectadas
              llm_raw_response → respuesta cruda del LLM (para debug)
              error          → mensaje de error si falló, o None
        """
        prompt = build_table_extraction_prompt(doc_ctx)

        try:
            raw = self._call_llm(TABLE_SYSTEM_PROMPT, prompt)
        except Exception as exc:
            return {
                "tables":            [],
                "tables_found":      0,
                "llm_raw_response":  "",
                "error":             f"LLM call failed: {exc}",
            }

        raw_str = raw if isinstance(raw, str) else str(raw)
        tables  = parse_table_response(raw_str)

        return {
            "tables":           tables,
            "tables_found":     len(tables),
            "llm_raw_response": raw_str[:4000],
            "error":            None,
        }

    def enrich_with_tables(
        self,
        doc_ctx: dict[str, Any],
        mode: str = "auto_fill_missing",
        confidence_threshold: float = 0.3,
        doc_type: str | None = None,
    ) -> dict[str, Any]:
        """
        Combina enriquecimiento de campos Y extracción de tablas en un solo resultado.

        Útil para documentos que necesitan ambos: facturas con líneas de detalle,
        contratos con cronogramas de pago, informes con tablas de datos.

        Hace DOS llamadas al LLM:
          1. enrich_document → completa campos faltantes
          2. extract_tables  → detecta y estructura tablas

        Args:
            doc_ctx:              Contexto del documento.
            mode:                 Modo de enriquecimiento para enrich_document.
            confidence_threshold: Confianza mínima para aplicar sugerencias.
            doc_type:             Tipo de documento ya conocido (o None para detección).

        Returns:
            Resultado de enrich_document fusionado con extract_tables:
            el dict enriquecido incluye "tables" y "tables_found".
        """
        # Llamada 1: enriquecimiento de campos
        enriched = self.enrich_document(
            doc_ctx,
            mode=mode,
            confidence_threshold=confidence_threshold,
            doc_type=doc_type,
        )

        # Llamada 2: extracción de tablas (usa el contexto original)
        table_result = self.extract_tables(doc_ctx)

        # Fusionar: agregar tablas al resultado enriquecido
        enriched["tables"]             = table_result["tables"]
        enriched["tables_found"]       = table_result["tables_found"]
        enriched["tables_raw_response"]= table_result["llm_raw_response"]
        enriched["tables_error"]       = table_result["error"]

        return enriched

