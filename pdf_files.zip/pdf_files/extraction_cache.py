"""
src/extraction/extraction_cache.py
───────────────────────────────────────────────────────────────────────────────
Caché de extracción PDF por hash de contenido.

PROBLEMA QUE RESUELVE
─────────────────────
Cada vez que el usuario sube el mismo PDF (o lo reprocesa), el pipeline corre
NativePDFExtractor u OCRExtractor desde cero: abre el archivo, lee cada página,
clasifica cada bloque, detecta campos. Para un PDF de 20 páginas con OCR eso
puede tomar 30-90 segundos.

SOLUCIÓN
────────
Antes de extraer, calcular un hash del PDF. Si existe una entrada en caché con
ese hash → retornar las páginas guardadas en disco (JSON). Si no → extraer
normalmente y guardar el resultado.

ESTRUCTURA EN DISCO
────────────────────
    data/cache/extraction/
        <hash_32chars>/
            meta.json    ← metadatos: nombre, tamaño, fecha, tipo, páginas
            pages.json   ← resultado de extract() serializado

La caché de extracción es INDEPENDIENTE de data/output/<doc_id>/:
  - El mismo PDF subido dos veces (distinto doc_id) reutiliza la extracción.
  - Borrar un documento del output no invalida la caché de extracción.
  - La caché sobrevive reinicios de la aplicación.

HASH
────
SHA-256 de los primeros 512 KB del PDF + tamaño total + nombre de archivo.

Por qué no el PDF completo:
  - Un PDF de 100 MB tardaría ~300 ms solo en hash → latencia perceptible.
  - Los primeros 512 KB incluyen cabecera PDF, metadatos XMP y la primera
    página completa. Cualquier cambio de contenido modifica alguno de ellos.
  - El tamaño como segundo factor evita colisiones entre PDFs que compartan
    el mismo comienzo pero difieran en páginas posteriores.

USO
────
    # En pipeline.py o en el extractor directamente:
    cache = ExtractionCache()

    pages, file_hash = cache.get(file_path)
    if pages is None:                          # miss → extraer
        pages = extractor.extract(file_path)
        cache.set(file_path, file_hash, pages, pdf_type=str(context.pdf_type))

INVALIDACIÓN
────────────
La caché se invalida automáticamente cuando el hash cambia (contenido del PDF
distinto). No hay TTL por defecto porque un PDF no cambia una vez procesado.
Para forzar re-procesamiento:
    cache.invalidate(file_path)   # un archivo específico
    cache.clear_all()             # toda la caché
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
from typing import Any

# Cuántos bytes del inicio del PDF usar para el hash (512 KB)
_HASH_CHUNK = 524_288


def hash_pdf(file_path: str) -> str:
    """
    Calcula un hash estable de 32 caracteres hexadecimales para el PDF.

    Combina:
      - SHA-256 de los primeros 512 KB del contenido
      - Tamaño total del archivo (detecta cambios en páginas posteriores)
      - Nombre del archivo (diferencia PDFs con mismo contenido pero diferente nombre)

    El hash resultante es estable: el mismo archivo produce siempre el mismo hash.
    Archivos con cualquier diferencia de contenido o tamaño producen hashes distintos.

    Args:
        file_path: Ruta absoluta o relativa al archivo PDF.

    Returns:
        String hexadecimal de 32 caracteres (128 bits de SHA-256).

    Raises:
        FileNotFoundError: Si el archivo no existe.
        OSError: Si no se puede leer el archivo.
    """
    h = hashlib.sha256()
    file_size = os.path.getsize(file_path)

    with open(file_path, "rb") as f:
        chunk = f.read(_HASH_CHUNK)
        h.update(chunk)

    h.update(str(file_size).encode("ascii"))
    h.update(os.path.basename(file_path).encode("utf-8"))

    return h.hexdigest()[:32]


class ExtractionCache:
    """
    Caché de extracción de PDFs por hash de contenido.

    Thread-safety: las escrituras son atómicas (write-to-temp + rename)
    en sistemas de archivos POSIX. En Windows las escrituras directas son
    suficientemente seguras para el caso de uso single-process de esta app.

    Parámetros:
        cache_dir: Directorio raíz de la caché. Default: "data/cache/extraction".
    """

    def __init__(self, cache_dir: str = "data/cache/extraction") -> None:
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)

    # ── Paths internos ────────────────────────────────────────────────────────

    def _entry_dir(self, file_hash: str) -> str:
        return os.path.join(self.cache_dir, file_hash)

    def _meta_path(self, file_hash: str) -> str:
        return os.path.join(self._entry_dir(file_hash), "meta.json")

    def _pages_path(self, file_hash: str) -> str:
        return os.path.join(self._entry_dir(file_hash), "pages.json")

    # ── API pública ───────────────────────────────────────────────────────────

    def get(self, file_path: str) -> tuple[list[dict] | None, str]:
        """
        Busca el resultado de extracción cacheado para el PDF dado.

        Calcula el hash del archivo, comprueba si existe una entrada válida
        y retorna las páginas cacheadas si las hay.

        Args:
            file_path: Ruta al PDF.

        Returns:
            Tupla (pages, file_hash):
              - pages: Lista de páginas cacheadas, o None si hay miss.
              - file_hash: Hash calculado (reutilizar en set() para no recalcular).

        Ejemplo::

            pages, file_hash = cache.get(file_path)
            if pages is None:
                pages = extractor.extract(file_path)
                cache.set(file_path, file_hash, pages, pdf_type="native")
        """
        file_hash  = hash_pdf(file_path)
        meta_path  = self._meta_path(file_hash)
        pages_path = self._pages_path(file_hash)

        if not os.path.exists(meta_path) or not os.path.exists(pages_path):
            return None, file_hash  # miss — entrada no existe

        try:
            with open(pages_path, "r", encoding="utf-8") as f:
                pages = json.load(f)
            return pages, file_hash  # hit
        except (json.JSONDecodeError, OSError, ValueError):
            # Entrada corrupta → eliminar y reportar miss
            self._remove_entry(file_hash)
            return None, file_hash

    def set(
        self,
        file_path: str,
        file_hash: str,
        pages: list[dict[str, Any]],
        pdf_type: str = "unknown",
    ) -> None:
        """
        Guarda el resultado de extracción en caché.

        Args:
            file_path: Ruta al PDF (usado solo para metadatos).
            file_hash: Hash calculado por get() — se reutiliza para no recalcular.
            pages:     Lista de páginas retornada por el extractor.
            pdf_type:  Tipo de PDF detectado: "native", "scanned" o "mixed".
        """
        entry_dir = self._entry_dir(file_hash)
        os.makedirs(entry_dir, exist_ok=True)

        meta: dict[str, Any] = {
            "hash":       file_hash,
            "file_name":  os.path.basename(file_path),
            "file_size":  os.path.getsize(file_path),
            "cached_at":  time.strftime("%Y-%m-%dT%H:%M:%S"),
            "pdf_type":   pdf_type,
            "page_count": len(pages),
        }

        with open(self._meta_path(file_hash), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)

        with open(self._pages_path(file_hash), "w", encoding="utf-8") as f:
            json.dump(pages, f, ensure_ascii=False)

    def invalidate(self, file_path: str) -> bool:
        """
        Elimina la entrada de caché para el PDF dado.

        Útil para forzar re-procesamiento sin borrar toda la caché.

        Args:
            file_path: Ruta al PDF cuya caché se quiere invalidar.

        Returns:
            True si había una entrada y fue eliminada. False si no había nada.
        """
        file_hash = hash_pdf(file_path)
        existed   = os.path.exists(self._entry_dir(file_hash))
        self._remove_entry(file_hash)
        return existed

    def clear_all(self) -> int:
        """
        Elimina TODAS las entradas de caché.

        Returns:
            Número de entradas eliminadas.
        """
        if not os.path.exists(self.cache_dir):
            return 0

        count = 0
        for entry in os.listdir(self.cache_dir):
            entry_path = os.path.join(self.cache_dir, entry)
            if os.path.isdir(entry_path):
                shutil.rmtree(entry_path)
                count += 1

        return count

    def stats(self) -> dict[str, Any]:
        """
        Retorna estadísticas de la caché en disco.

        Returns:
            Dict con:
              - entries:       Número de entradas cacheadas.
              - total_size_mb: Tamaño total en MB.
              - cached_files:  Lista de nombres de archivo cacheados.
              - oldest:        Fecha de la entrada más antigua (ISO).
              - newest:        Fecha de la entrada más reciente (ISO).
        """
        if not os.path.exists(self.cache_dir):
            return {"entries": 0, "total_size_mb": 0.0, "cached_files": []}

        metas:      list[dict] = []
        total_bytes: int       = 0

        for entry in os.listdir(self.cache_dir):
            entry_dir = os.path.join(self.cache_dir, entry)
            if not os.path.isdir(entry_dir):
                continue

            meta_path = os.path.join(entry_dir, "meta.json")
            if os.path.exists(meta_path):
                try:
                    with open(meta_path, encoding="utf-8") as f:
                        metas.append(json.load(f))
                except (json.JSONDecodeError, OSError):
                    pass

            for fname in os.listdir(entry_dir):
                fpath = os.path.join(entry_dir, fname)
                if os.path.isfile(fpath):
                    total_bytes += os.path.getsize(fpath)

        dates     = [m.get("cached_at", "") for m in metas if m.get("cached_at")]
        file_names = [m.get("file_name", "") for m in metas]

        return {
            "entries":       len(metas),
            "total_size_mb": round(total_bytes / 1_048_576, 2),
            "cached_files":  file_names,
            "oldest":        min(dates) if dates else None,
            "newest":        max(dates) if dates else None,
        }

    # ── Helpers internos ──────────────────────────────────────────────────────

    def _remove_entry(self, file_hash: str) -> None:
        entry_dir = self._entry_dir(file_hash)
        if os.path.exists(entry_dir):
            shutil.rmtree(entry_dir)
