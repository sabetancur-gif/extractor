/* Módulo 2 · utilidades
   Funciones puras reutilizables para formato, sanitización y pequeños helpers.
*/

function esc(v){
  return String(v ?? '')
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;')
    .replaceAll("'",'&#39;');
}

function fn(code){
  return MNAMES[code] || code;
}

function toDate(ds){
  return ds ? new Date(ds) : null;
}

function isVD(d){
  return d instanceof Date && !Number.isNaN(d.getTime());
}

function daysTo(ds){
  const d = toDate(ds);
  if(!isVD(d)) return 0;
  const now = new Date();
  now.setHours(0,0,0,0);
  d.setHours(0,0,0,0);
  return Math.ceil((d - now) / 864e5);
}

function fmtDate(ds){
  const d = toDate(ds);
  if(!isVD(d)) return { s: 'sin fecha', c: '' };
  const days = daysTo(ds);
  const s = d.toLocaleDateString('es-CO', { day:'numeric', month:'short' });
  if(days < 0) return { s: `${s} · vencido`, c: 'past' };
  if(days <= 7) return { s: `${s} · ${days}d`, c: 'soon' };
  return { s, c: '' };
}

function pct(p){
  if(!p.deliverables?.length) return 0;
  return Math.round(p.deliverables.filter(d => d.done).length / p.deliverables.length * 100);
}

function pbCls(p){
  if(p.status === 'delivered') return 'pb-info';
  if(p.status === 'risk') return 'pb-warn';
  const progress = pct(p);
  return progress >= 70 ? 'pb-ok' : progress >= 40 ? 'pb-warn' : 'pb-bad';
}

function sbadge(s){
  const map = { active:'b-active', risk:'b-risk', delivered:'b-delivered', paused:'b-paused' };
  const label = { active:'activo', risk:'en riesgo', delivered:'entregado', paused:'pausado' };
  return `<span class="badge ${map[s] || 'b-paused'}">${label[s] || s}</span>`;
}

function av(i, idx){
  const [bg, fg] = AVC[idx % AVC.length];
  return `<div class="av" style="background:${bg};color:${fg}" title="${esc(fn(i))}" aria-label="${esc(fn(i))}">${esc(i)}</div>`;
}

function isDark(){
  return document.documentElement.getAttribute('data-theme') === 'dark';
}

function setThemeLabel(){
  const lbl = document.getElementById('tog-lbl');
  if(lbl) lbl.textContent = isDark() ? 'Dark' : 'Light';
}
