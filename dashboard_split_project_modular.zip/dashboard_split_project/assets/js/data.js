/* Módulo 1 · datos base y estado
   Aquí viven las constantes, el estado global y la capa de almacenamiento.
*/

// Colores de avatar y capacidades por miembro.
const AVC = [
  ['#1D9E75','#E1F5EE'],
  ['#378ADD','#E6F1FB'],
  ['#D85A30','#FAECE7'],
  ['#D4537E','#FBEAF0'],
  ['#BA7517','#FAEEDA'],
  ['#7F77DD','#EEEDFE']
];

const MNAMES = {
  SB: 'Santiago Betancur',
  FQ: 'Fernanda Quintero',
  YS: 'Yoryam Sanchez'
};

const MCAP = {
  SB: 3,
  FQ: 3,
  YS: 7
};

// Datos de ejemplo del dashboard. Cada proyecto tiene blockers, entregables, timeline y comentarios.
const DEFAULTS = [
  {
    id: 'p1',
    name: 'Sistema OCR, Clasificación y Análisis Documental con LLM',
    description: 'Plataforma integral de inteligencia documental. Carga documentos nativos o escaneados para extraer, clasificar y analizar automáticamente su contenido mediante OCR, NLP e IA basada en LLM.',
    status: 'active',
    businessPriority: 5,
    technicalSeverity: 4,
    urgency: 5,
    dependencyCriticality: 5,
    deadline: '2026-07-15',
    committedAt: '2026-06-10',
    actualAt: '',
    assignees: ['YS', 'SB'],
    tech: ['Python', 'HTML', 'CSS', 'YAML', 'TOON'],
    blockers: [
      { text: 'Capacidad de la memoria RAM para el uso del LLM', severity: 'crit' },
      { text: 'Ajuste final de los umbrales en el procesamiento OCR', severity: 'crit' },
      { text: 'Interfaz de usuario desordenada y excesivamente codificada', severity: 'med' },
      { text: 'Uso prioritario de JSON para estructurar las peticiones al LLM', severity: 'med' }
    ],
    dependencies: ['Poppler', 'Tesseract', 'Ollama'],
    timeline: [
      { date: '2025-12-15', title: 'Primer acercamiento', desc: 'Primer acercamiento a la petición e idea de Yoryam.' },
      { date: '2026-02-09', title: 'Extracción OCR', desc: 'Integración inicial del OCR; extracción mediante dos motores externos.' },
      { date: '2026-02-18', title: 'Entrega v1.0', desc: 'Interfaz y operatividad de los tabs de upload, extracción y PDF Analysis.' },
      { date: '2026-04-22', title: 'Entrega v2.0', desc: 'Cambios en la UI e incorporación de los tabs asociados al LLM.' }
    ],
    history: [
      { date: '2026-04-22 16:11', author: 'SB', action: 'En progreso — Se actualiza el repositorio privado.', detail: 'https://github.com/MontoyaSantiago/pdf' }
    ],
    recentActivity: [
      { author: 'SB', date: '2026-04-22 19:47', text: 'Se ajustó la estructura completa del proyecto para acoplar vacíos en la lógica.' },
      { author: 'SB', date: '2026-04-22 21:33', text: 'Se integró el chatbot sobre el documento cargado con Ollama.' }
    ],
    deliverables: [
      { id: 'd1', text: 'Mejorar estructura y lógica del backend', done: false, owner: 'SB', sla: '2026-05-05', committed: '2026-05-04', actual: '', goal: 'Remover vacíos en la lógica actual', criteria: 'Pruebas de cohesión y acoplamiento', notes: 'Pendiente revisar nuevos huecos' },
      { id: 'd2', text: 'Organizar la UI para facilitar comprensión del usuario', done: false, owner: 'SB', sla: '2026-05-05', committed: '2026-05-04', actual: '', goal: 'Mejorar interfaz reduciendo codificación excesiva', criteria: 'Acercamiento al público objetivo', notes: 'Priorizar PDF Analysis, LLM Enrichment y Chatbot' },
      { id: 'd3', text: 'Mejorar la integración del LLM', done: false, owner: 'SB', sla: '2026-05-05', committed: '2026-05-04', actual: '', goal: 'Sugerencias LLM coherentes e integradas', criteria: 'Medida diferente de 0 en LLM Enrichment', notes: 'Chatbot con contexto de todos los documentos' }
    ],
    comments: [
      { author: 'SB', date: 'Apr 22', text: 'Mejorar clasificación reconociendo firmas, tablas, imágenes y expresiones matemáticas.' },
      { author: 'YS', date: 'Apr 22', text: 'Integrar TOON para las peticiones al LLM.' }
    ]
  },
  {
    id: 'p2',
    name: 'Automation: PEO License Manager',
    description: 'Automatización para gestionar altas y bajas de licencias PEO en EE.UU. Centraliza un proceso manual, reduciendo errores y mejorando la trazabilidad del ciclo completo.',
    status: 'active',
    businessPriority: 5,
    technicalSeverity: 3,
    urgency: 5,
    dependencyCriticality: 4,
    deadline: '2026-05-21',
    committedAt: '2026-05-20',
    actualAt: '',
    assignees: ['YS', 'SB'],
    tech: ['JS', 'HTML', 'Python', 'xlsm', 'CSS', 'JSON'],
    blockers: [
      { text: 'Ausencia de base de datos persistente para almacenamiento centralizado.', severity: 'crit' },
      { text: 'Restricciones de IT sobre instalación de aplicativos locales por usuario.', severity: 'crit' }
    ],
    dependencies: ['xlsm'],
    timeline: [
      { date: '2026-03-02', title: 'Acercamiento ADD/TERM', desc: 'Primer encuentro con el proceso manual del equipo.' },
      { date: '2026-04-10', title: 'v1.0 — Propuesta', desc: 'No escaló por falta de permisos para API.' },
      { date: '2026-04-17', title: 'v2.1 — Localhost', desc: 'Vuelta a la idea inicial minimizando herramientas externas.' },
      { date: '2026-04-22', title: 'Entrega v2.1', desc: 'Estructura de la página y flujo TERM para Arkansas.' },
      { date: '2026-04-27', title: 'v2.2 — Mejoras UI', desc: 'Renovación visual y ajustes lógicos.' }
    ],
    history: [
      { date: '2026-04-22 10:30', author: 'SB', action: 'Primera entrega reproducible del proceso.', detail: 'Solo proceso TERM en Arkansas.' },
      { date: '2026-04-27 12:17', author: 'YS', action: 'Renovación total de la UI.', detail: 'Mejoras en Front-End manteniendo Back-End.' }
    ],
    recentActivity: [
      { author: 'SB', date: '2026-04-22 11:00', text: 'Se priorizó la vinculación de la totalidad de los templates del archivo .xlsm.' },
      { author: 'YS', date: '2026-04-27 09:55', text: 'Cambio significativo en la propuesta del mapa.' }
    ],
    deliverables: [
      { id: 'd1', text: 'Articular la mejor opción para el proyecto', done: true, owner: 'SB', sla: '2026-03-17', committed: '2026-03-16', actual: '2026-03-16', goal: 'Mejor herramienta disponible', criteria: 'Aprobación formal de Yoryam', notes: 'Vista con un único proceso' },
      { id: 'd2', text: 'Elaboración del archivo fuente xlsm', done: true, owner: 'SB', sla: '2026-04-01', committed: '2026-03-31', actual: '2026-03-31', goal: 'Archivo xlsm fuente', criteria: 'Módulos reutilizables', notes: 'Normalizar al agregar estados' },
      { id: 'd3', text: 'Acoplamiento Back-End / Front-End', done: true, owner: 'SB', sla: '2026-04-22', committed: '2026-04-21', actual: '2026-04-16', goal: 'Primera versión funcional de la UI', criteria: 'Logs para trazabilidad', notes: 'Un proceso/estado prioritario' },
      { id: 'd4', text: 'Mejoras en la UI', done: false, owner: 'SB', sla: '2026-05-01', committed: '2026-05-01', actual: '', goal: 'Aspectos lógicos y de interacción', criteria: 'Validar todas las aristas', notes: 'Ventana emergente para editar formularios' },
      { id: 'd5', text: 'Integración de estados al proceso', done: false, owner: 'SB', sla: '2026-05-15', committed: '2026-05-14', actual: '', goal: 'Integración de +7 estados', criteria: 'Validar con el departamento', notes: 'Normalización de campos' }
    ],
    comments: [
      { author: 'SB', date: 'Apr 27', text: 'Falta scroll vertical en la ventana emergente para editar campos del PDF.' },
      { author: 'RG', date: 'Apr 28', text: 'Comprobar la estructura interna de cada módulo.' }
    ]
  }
];

// Almacenamiento compatible con localStorage o con un storage inyectado por el entorno.
const storage = (window.storage && typeof window.storage.get === 'function')
  ? window.storage
  : {
      async get(key){ const v = localStorage.getItem(key); return v ? { value: v } : null; },
      async set(key, value){ localStorage.setItem(key, value); }
    };

// Estado global de la interfaz.
const S = {
  projects: [],
  filter: 'all',
  sel: null,
  tab: 'executive',
  showForm: false,
  editId: null,
  form: {}
};

if(!window._charts) window._charts = [];
