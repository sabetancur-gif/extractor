/* Módulo 5 · acciones y persistencia
   Mutaciones del estado, edición, creación, eliminación y sincronización.
*/

function setF(f){
  S.filter = f;
  S.sel = null;
  render();
}

function pick(id){
  S.sel = (S.sel === id) ? null : id;
  S.tab = 'executive';
  render();
  if(S.sel){
    setTimeout(() => document.querySelector('.detail')?.scrollIntoView({ behavior:'smooth', block:'nearest' }), 80);
  }
}

function setTab(t){
  S.tab = t;
  render();
}

function tgForm(){
  S.showForm = !S.showForm;
  S.editId = null;
  S.form = {};
  render();
}

function cancelF(){
  S.showForm = false;
  S.editId = null;
  S.form = {};
  render();
}

// Persistencia local del dashboard.
async function save(){
  await storage.set('devdash-split-v1', JSON.stringify(S.projects));
}

function parseCSV(v){
  return String(v || '').split(',').map(s => s.trim()).filter(Boolean);
}

function parseLines(v){
  return String(v || '').split('\n').map(s => s.trim()).filter(Boolean);
}

function slugId(){
  return 'd' + Date.now() + Math.random().toString(36).slice(2, 6);
}

function normalizeBlockers(blockers){
  return (blockers || []).map(b => {
    if(typeof b === 'string') return { text: b, severity: 'med' };
    return { text: b.text || '', severity: b.severity === 'crit' ? 'crit' : 'med' };
  }).filter(b => b.text);
}

function editP(id){
  const p = S.projects.find(x => x.id === id);
  if(!p) return;
  S.form = {
    name: p.name,
    description: p.description,
    status: p.status,
    businessPriority: p.businessPriority,
    technicalSeverity: p.technicalSeverity,
    urgency: p.urgency,
    dependencyCriticality: p.dependencyCriticality,
    deadline: p.deadline,
    committedAt: p.committedAt,
    actualAt: p.actualAt,
    assignees: (p.assignees || []).join(', '),
    tech: (p.tech || []).join(', '),
    blockers: normalizeBlockers(p.blockers).map(b => `${b.severity === 'crit' ? '[crit] ' : ''}${b.text}`).join('\n'),
    dependencies: (p.dependencies || []).join('\n'),
    deliverables: (p.deliverables || []).map(d => d.text).join('\n')
  };
  S.editId = id;
  S.showForm = true;
  S.sel = null;
  render();
  setTimeout(() => document.querySelector('.fs')?.scrollIntoView({ behavior:'smooth', block:'start' }), 80);
}

async function delP(id){
  if(!confirm('¿Eliminar este proyecto?')) return;
  S.projects = S.projects.filter(p => p.id !== id);
  S.sel = null;
  await save();
  render();
}

function parseBlockerLines(lines){
  return parseLines(lines).map(line => {
    const crit = line.startsWith('[crit]') || line.startsWith('crit:');
    const clean = line.replace(/^\[crit\]\s*/i, '').replace(/^crit:\s*/i, '').trim();
    return clean ? { text: clean, severity: crit ? 'crit' : 'med' } : null;
  }).filter(Boolean);
}

async function saveP(){
  const name = document.getElementById('fn').value.trim();
  if(!name){ alert('El nombre es requerido'); return; }

  const base = {
    name,
    description: document.getElementById('fd').value.trim(),
    status: document.getElementById('fst').value,
    businessPriority: Number(document.getElementById('fbp').value),
    technicalSeverity: Number(document.getElementById('fts').value),
    urgency: Number(document.getElementById('fur').value),
    dependencyCriticality: Number(document.getElementById('fdc').value),
    deadline: document.getElementById('fdl').value,
    committedAt: document.getElementById('fca').value,
    actualAt: document.getElementById('fra').value,
    assignees: parseCSV(document.getElementById('fass').value),
    tech: parseCSV(document.getElementById('ftc').value),
    blockers: parseBlockerLines(document.getElementById('fblk').value),
    dependencies: parseLines(document.getElementById('fdep').value)
  };

  const deliveredMap = new Map();
  if(S.editId){
    const ex = S.projects.find(p => p.id === S.editId);
    if(ex){
      for(const d of ex.deliverables || []) deliveredMap.set(d.text, d);
    }
  }

  const newDels = parseLines(document.getElementById('fdels').value).map((t, i) => {
    const existing = deliveredMap.get(t);
    return existing ? { ...existing, text: t } : {
      id: slugId() + i,
      text: t,
      done: false,
      owner: base.assignees[i % Math.max(base.assignees.length, 1)] || 'CR',
      sla: '', committed: '', actual: '', goal: '', criteria: '', notes: ''
    };
  });

  if(S.editId){
    const idx = S.projects.findIndex(p => p.id === S.editId);
    if(idx >= 0){
      const ex = S.projects[idx];
      S.projects[idx] = {
        ...ex,
        ...base,
        deliverables: newDels,
        comments: ex.comments || [],
        timeline: ex.timeline || [],
        history: ex.history || [],
        recentActivity: ex.recentActivity || []
      };
    }
  }else{
    const today = new Date().toISOString().slice(0,10);
    S.projects.unshift({
      id: 'p' + Date.now(),
      ...base,
      timeline: [{ date: today, title: 'Proyecto creado', desc: 'Registro inicial creado desde el dashboard.' }],
      history: [{ date: `${today} 00:00`, author: 'SYS', action: 'Creó el proyecto', detail: 'Alta inicial desde panel ejecutivo.' }],
      recentActivity: [],
      comments: [],
      deliverables: newDels
    });
  }

  S.showForm = false;
  S.editId = null;
  S.form = {};
  await save();
  render();
}

async function toggleD(pid, did){
  const p = S.projects.find(x => x.id === pid);
  if(!p) return;
  const d = p.deliverables.find(x => x.id === did);
  if(!d) return;
  d.done = !d.done;
  if(d.done && !d.actual){
    d.actual = new Date().toISOString().slice(0,10);
  }
  await save();
  render();
}

async function addDel(pid){
  const inp = document.getElementById('nd');
  if(!inp) return;
  const txt = inp.value.trim();
  if(!txt) return;
  const p = S.projects.find(x => x.id === pid);
  if(!p) return;
  p.deliverables.push({ id: slugId(), text: txt, done: false, owner: p.assignees?.[0] || 'CR', sla: '', committed: '', actual: '', goal: '', criteria: '', notes: '' });
  inp.value = '';
  await save();
  render();
}

async function addCmt(pid){
  const inp = document.getElementById('nc');
  if(!inp) return;
  const txt = inp.value.trim();
  if(!txt) return;
  const p = S.projects.find(x => x.id === pid);
  if(!p) return;
  const now = new Date().toLocaleDateString('es-CO', { day:'numeric', month:'short' });
  p.comments.push({ author: 'TÚ', date: now, text: txt });
  p.recentActivity = [{ author: 'TÚ', date: 'Ahora', text: txt }, ...(p.recentActivity || [])].slice(0,5);
  inp.value = '';
  await save();
  render();
}

function parseBlockersForLoad(raw){
  if(!raw) return [];
  return raw.map(b => typeof b === 'string' ? { text:b, severity:'med' } : { text:b.text, severity:b.severity === 'crit' ? 'crit' : 'med' });
}

async function load(){
  try{
    const r = await storage.get('devdash-split-v1');
    S.projects = r ? JSON.parse(r.value) : DEFAULTS;
    if(!Array.isArray(S.projects)) S.projects = DEFAULTS;
  }catch{
    S.projects = DEFAULTS;
  }
  // Normalizamos blockers por si vienen como strings desde localStorage o versiones viejas.
  S.projects = S.projects.map(p => ({
    ...p,
    blockers: parseBlockersForLoad(p.blockers),
    assignees: Array.isArray(p.assignees) ? p.assignees : parseCSV(p.assignees),
    tech: Array.isArray(p.tech) ? p.tech : parseCSV(p.tech),
    dependencies: Array.isArray(p.dependencies) ? p.dependencies : parseLines(p.dependencies),
    deliverables: (p.deliverables || []).map(d => ({
      ...d,
      done: Boolean(d.done)
    }))
  }));
  render();
}

function toggleTheme(){
  const h = document.documentElement;
  const dark = h.getAttribute('data-theme') === 'dark';
  h.setAttribute('data-theme', dark ? 'light' : 'dark');
  setThemeLabel();
  clearCharts();
  render();
}
