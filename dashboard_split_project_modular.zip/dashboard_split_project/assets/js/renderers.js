/* Módulo 4 · renderizado de vistas
   Generadores de HTML del panel, tarjetas, pestañas y panel de detalle.
*/

const CHART_COLORS = {
  blue: '#5bbdff',
  green: '#2ee89a',
  amber: '#ffb547',
  red: '#ff5c5c',
  purple: '#b47cff',
  cyan: '#2de8d0'
};

function clearCharts(){
  if(window._charts){
    for(const ch of window._charts){
      try{ ch.destroy(); }catch(e){}
    }
    window._charts = [];
  }
}

function regCh(ch){
  if(!window._charts) window._charts = [];
  window._charts.push(ch);
}

function ttStyle(){
  const dk = isDark();
  return {
    backgroundColor: dk ? '#101c2a' : '#fff',
    titleColor: dk ? '#ddeeff' : '#0a1f35',
    bodyColor: dk ? '#7a9db8' : '#3a6080',
    borderColor: dk ? '#1a2e42' : '#ccdaec',
    borderWidth: 1,
    padding: 10,
    cornerRadius: 8
  };
}

function gridStyle(){
  return { color: isDark() ? 'rgba(26,46,66,.7)' : 'rgba(204,218,236,.5)' };
}

function tickStyle(){
  return { color: isDark() ? '#3d5f7a' : '#8aa8c4', font: { family: "'JetBrains Mono',monospace", size: 10 } };
}

function legendStyle(){
  return {
    display: true,
    position: 'bottom',
    labels: { color: isDark() ? '#7a9db8' : '#3a6080', font: { family: "'JetBrains Mono',monospace", size: 10 }, boxWidth: 10, padding: 12 }
  };
}

function donutSVG(data){
  const items = [
    { k:'active', color: CHART_COLORS.green },
    { k:'risk', color: CHART_COLORS.amber },
    { k:'delivered', color: CHART_COLORS.blue },
    { k:'paused', color: '#7a9db8' }
  ];
  const total = items.reduce((acc, x) => acc + (data[x.k] || 0), 0) || 1;
  let start = -90;
  const cx = 56, cy = 56, r = 38, sw = 13, circ = 2 * Math.PI * r;
  const parts = items.filter(x => (data[x.k] || 0) > 0).map(x => {
    const val = data[x.k] || 0;
    const len = circ * val / total;
    const off = circ * (start + 90) / 360;
    const angle = (val / total) * 360;
    const seg = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${x.color}" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${len} ${circ - len}" stroke-dashoffset="${-off}"></circle>`;
    start += angle;
    return seg;
  }).join('');
  const dk = isDark();
  return `
    <svg viewBox="0 0 112 112" width="106" height="106" aria-label="Distribución ejecutiva">
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${dk ? '#1a2e42' : '#ccdaec'}" stroke-width="${sw}"></circle>
      ${parts}
      <circle cx="${cx}" cy="${cy}" r="24" fill="${dk ? '#0c1520' : '#fff'}"></circle>
      <text x="56" y="53" text-anchor="middle" fill="${dk ? '#ddeeff' : '#0a1f35'}" font-size="17" font-family="'JetBrains Mono',monospace" font-weight="700">${total}</text>
      <text x="56" y="67" text-anchor="middle" fill="#3d5f7a" font-size="8" font-family="'JetBrains Mono',monospace" letter-spacing=".1em">TOTAL</text>
    </svg>`;
}

function renderHeader(){
  const today = new Date().toLocaleDateString('es-CO', { weekday:'short', day:'numeric', month:'short', year:'numeric' });
  const avgR = S.projects.length ? Math.round(S.projects.reduce((a,p) => a + riskScore(p), 0) / S.projects.length) : 0;
  const rCol = avgR >= 60 ? 'var(--danger)' : avgR >= 35 ? 'var(--warn)' : 'var(--ok)';
  return `
    <div class="hdr">
      <div>
        <p class="team-tag"><span class="pulse-dot"></span>ENGINEERING · SENIOR TEAM</p>
        <p class="hdr-title">Project Dashboard</p>
        <p class="hdr-desc">Vista ejecutiva de portfolio · riesgo · capacidad · blockers · entregas críticas.</p>
      </div>
      <div class="hdr-meta">
        <div>${esc(today)}</div>
        <div style="color:var(--accent);margin-top:3px">Sprint activo</div>
        <div style="margin-top:5px">Riesgo medio: <span style="color:${rCol};font-weight:700">${avgR}/100</span></div>
        <div style="margin-top:5px">${S.projects.length} proyectos activos</div>
      </div>
    </div>
    <div class="kpis">
      ${execKpis().map(k => `
        <div class="kpi ${k.cls}">
          <div class="kpi-ico">${k.ico}</div>
          <p class="kpi-lbl">${esc(k.l)}</p>
          <p class="kpi-val">${esc(k.v)}<span style="font-size:13px;font-family:var(--mono);color:var(--soft)">${k.u}</span></p>
          <p class="kpi-sub">${esc(k.s)}</p>
        </div>
      `).join('')}
    </div>`;
}

function renderAnalytics(){
  const counts = statusCounts();
  const mem = memberCounts();
  const deadlines = [...S.projects].sort((a,b) => daysTo(a.deadline) - daysTo(b.deadline)).slice(0,4);
  const cap = loadVsCapacity();
  return `
    <div class="an-row">
      <div class="card">
        <p class="card-title"><span>🎯</span>Distribución ejecutiva</p>
        <div class="donut-wrap">
          ${donutSVG(counts)}
          <div class="donut-legend">
            <div class="leg"><span class="leg-left"><span class="dot" style="background:${CHART_COLORS.green}"></span>Activos</span><span>${counts.active || 0}</span></div>
            <div class="leg"><span class="leg-left"><span class="dot" style="background:${CHART_COLORS.amber}"></span>Riesgo</span><span>${counts.risk || 0}</span></div>
            <div class="leg"><span class="leg-left"><span class="dot" style="background:${CHART_COLORS.blue}"></span>Entregados</span><span>${counts.delivered || 0}</span></div>
            <div class="leg"><span class="leg-left"><span class="dot" style="background:#7a9db8"></span>Pausados</span><span>${counts.paused || 0}</span></div>
          </div>
        </div>
      </div>
      <div class="card">
        <p class="card-title"><span>👥</span>Carga por miembro<span style="margin-left:auto;font-size:11px;color:var(--soft)">${cap.assigned}/${cap.cap}</span></p>
        <div class="mbars">
          ${mem.length ? mem.map(([m,c]) => `
            <div class="mbrow">
              <div class="mblbl">${esc(fn(m).split(' ')[0])}</div>
              <div class="mbtrack"><div class="mbfill" style="width:${Math.max(8, Math.round(c / Math.max(...mem.map(x => x[1]), 1) * 100))}%"></div></div>
              <div class="mbnum">${c}</div>
            </div>
          `).join('') : '<div style="font-size:12px;color:var(--soft)">Sin asignaciones</div>'}
        </div>
      </div>
      <div class="card">
        <p class="card-title"><span>📅</span>Próximos vencimientos</p>
        <div class="deadlist">
          ${deadlines.map(p => {
            const d = fmtDate(p.deadline);
            const pr = pct(p);
            return `
              <div class="deaditem">
                <div class="deadtop">
                  <p class="deadname">${esc(p.name.slice(0,44))}${p.name.length > 44 ? '…' : ''}</p>
                  <span class="deadmeta ${d.c}">${esc(d.s)}</span>
                </div>
                <div class="deadprog"><div class="${pbCls(p)} pb" style="width:${pr}%"></div></div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    </div>`;
}

function renderChartsRow1(){
  return `
    <div class="sec3">
      <div class="card">
        <p class="card-title"><span>🔥</span>Radar de riesgo por proyecto</p>
        <div class="chart-wrap" style="height:260px"><canvas id="ch-radar" role="img" aria-label="Radar de riesgo por proyecto"></canvas></div>
      </div>
      <div class="card">
        <p class="card-title"><span>📈</span>Burndown de entregables</p>
        <div class="chart-wrap" style="height:260px"><canvas id="ch-burn" role="img" aria-label="Burndown de entregables"></canvas></div>
      </div>
      <div class="card">
        <p class="card-title"><span>📊</span>Entregables por estado</p>
        <div class="chart-wrap" style="height:260px"><canvas id="ch-dough" role="img" aria-label="Entregables por estado"></canvas></div>
      </div>
    </div>`;
}

function mountChartsRow1(){
  const tt = ttStyle();
  const grid = gridStyle();
  const ticks = tickStyle();
  const legend = legendStyle();

  const rCtx = document.getElementById('ch-radar');
  if(rCtx && !rCtx._mounted){
    rCtx._mounted = true;
    const ch = new Chart(rCtx, {
      type: 'radar',
      data: {
        labels: ['Prioridad', 'Severidad', 'Urgencia', 'Dependencia', 'Blockers', 'Progreso'],
        datasets: S.projects.slice(0,3).map((p, i) => ({
          label: `${p.name.slice(0,16)}…`,
          data: [p.businessPriority || 0, p.technicalSeverity || 0, p.urgency || 0, p.dependencyCriticality || 0, Math.min((p.blockers || []).length, 5), Math.round(pct(p) / 20)],
          borderColor: [CHART_COLORS.blue, CHART_COLORS.green, CHART_COLORS.amber][i],
          backgroundColor: [CHART_COLORS.blue + '22', CHART_COLORS.green + '22', CHART_COLORS.amber + '22'][i],
          borderWidth: 2,
          pointBackgroundColor: [CHART_COLORS.blue, CHART_COLORS.green, CHART_COLORS.amber][i],
          pointRadius: 4
        }))
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend, tooltip: { ...tt } },
        scales: {
          r: {
            grid: { color: isDark() ? 'rgba(26,46,66,.9)' : 'rgba(204,218,236,.5)' },
            angleLines: { color: isDark() ? 'rgba(26,46,66,.9)' : 'rgba(204,218,236,.5)' },
            ticks: { color: isDark() ? '#3d5f7a' : '#8aa8c4', font: { size: 9 }, backdropColor: 'transparent' },
            pointLabels: { color: isDark() ? '#7a9db8' : '#3a6080', font: { family: "'JetBrains Mono',monospace", size: 10 } },
            min: 0,
            max: 5
          }
        }
      }
    });
    regCh(ch);
  }

  const bCtx = document.getElementById('ch-burn');
  if(bCtx && !bCtx._mounted){
    bCtx._mounted = true;
    const totalD = S.projects.flatMap(p => p.deliverables || []).length || 1;
    const doneD = S.projects.flatMap(p => p.deliverables || []).filter(d => d.done).length;
    const labels = ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4', 'Sem 5', 'Sem 6', 'Actual'];
    const ideal = labels.map((_, i) => Math.round(totalD - (totalD / 6) * i));
    const actual = [
      totalD,
      ...Array(5).fill(null).map((_, i) => Math.max(0, totalD - Math.round(doneD / 2 * (i / 4)))),
      totalD - doneD
    ];
    const ch = new Chart(bCtx, {
      type: 'line',
      data: {
        labels,
        datasets: [
          { label: 'Ideal', data: ideal, borderColor: CHART_COLORS.blue + '88', borderDash: [6,3], borderWidth: 1.5, pointRadius: 0, fill: false },
          { label: 'Real', data: actual, borderColor: CHART_COLORS.green, backgroundColor: CHART_COLORS.green + '18', borderWidth: 2.5, pointBackgroundColor: CHART_COLORS.green, pointRadius: 4, fill: true, tension: .3 }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend, tooltip: { ...tt } },
        scales: {
          x: { grid, ticks },
          y: { grid, ticks, title: { display: true, text: 'Pendientes', color: isDark() ? '#3d5f7a' : '#8aa8c4', font: { size: 10 } } }
        }
      }
    });
    regCh(ch);
  }

  const dCtx = document.getElementById('ch-dough');
  if(dCtx && !dCtx._mounted){
    dCtx._mounted = true;
    const { completed, pending, overdue } = deliverableStatusCounts();
    const dk = isDark();
    const ch = new Chart(dCtx, {
      type: 'doughnut',
      data: {
        labels: ['Completados', 'Pendientes', 'Vencidos'],
        datasets: [{ data: [completed, pending, overdue], backgroundColor: [CHART_COLORS.green + 'cc', CHART_COLORS.blue + 'cc', CHART_COLORS.red + 'cc'], borderColor: dk ? '#0c1520' : '#fff', borderWidth: 3, hoverOffset: 6 }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        plugins: { legend: legendStyle(), tooltip: { ...ttStyle() } }
      }
    });
    regCh(ch);
  }
}

function renderBlockers(){
  const all = S.projects
    .filter(p => p.status !== 'delivered')
    .flatMap(p => (p.blockers || []).map(b => ({ ...b, proj: p.name, projId: p.id })));

  if(!all.length) return '';

  const crits = all.filter(b => b.severity === 'crit');
  const meds = all.filter(b => b.severity !== 'crit');

  return `
    <div class="sec-full">
      <details class="card collapsible" open>
        <summary>
          <div class="collapsible-head">
            <div class="collapsible-title">
              <span style="font-size:16px">🚧</span>
              <span>Blockers activos del portfolio</span>
              <span style="font-size:10px;padding:3px 9px;border-radius:999px;background:rgba(255,92,92,.12);color:var(--danger);border:1px solid rgba(255,92,92,.2)">${crits.length} críticos</span>
              <span style="font-size:10px;padding:3px 9px;border-radius:999px;background:rgba(255,181,71,.1);color:var(--warn);border:1px solid rgba(255,181,71,.2)">${meds.length} medios</span>
            </div>
            <span class="collapse-arrow" style="font-family:var(--mono);color:var(--soft)">▾</span>
          </div>
        </summary>
        <div class="collapsible-body">
          <div class="blocker-grid">
            ${all.map(b => `
              <div class="blocker-item ${b.severity !== 'crit' ? 'warn-blk' : ''}" onclick="pick('${esc(b.projId)}')">
                <div class="bl-top">
                  <p class="bl-name">${esc(b.text)}</p>
                  <span class="bl-badge ${b.severity === 'crit' ? 'crit' : 'med'}">${b.severity === 'crit' ? 'Crítico' : 'Medio'}</span>
                </div>
                <p class="bl-proj">↗ ${esc(b.proj.slice(0,58))}${b.proj.length > 58 ? '…' : ''}</p>
              </div>
            `).join('')}
          </div>
        </div>
      </details>
    </div>`;
}

function renderCard(p){
  const dl = fmtDate(p.deadline);
  const pc = pct(p);
  const sel = S.sel === p.id;
  const rs = riskScore(p);
  const blkHtml = (p.blockers || []).length ? `
    <div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:11px">
      ${(p.blockers || []).slice(0,2).map(b => `
        <span style="font-size:10px;font-family:var(--mono);padding:3px 8px;border-radius:999px;background:rgba(255,${b.severity === 'crit' ? '92,92' : '181,71'},.1);color:var(--${b.severity === 'crit' ? 'danger' : 'warn'});border:1px solid rgba(255,${b.severity === 'crit' ? '92,92' : '181,71'},.2)">⚠ ${esc(b.text.slice(0,28))}${b.text.length > 28 ? '…' : ''}</span>
      `).join('')}
      ${(p.blockers || []).length > 2 ? `<span style="font-size:10px;font-family:var(--mono);padding:3px 8px;border-radius:999px;color:var(--soft)">+${(p.blockers || []).length - 2} más</span>` : ''}
    </div>` : '';

  return `
    <div class="pcard${sel ? ' sel' : ''}" onclick="pick('${p.id}')">
      <div class="pc-top"><p class="pc-name">${esc(p.name)}</p>${sbadge(p.status)}</div>
      <p class="pc-desc">${esc(p.description.slice(0,100))}${p.description.length > 100 ? '…' : ''}</p>
      <div class="tech-row">${(p.tech || []).map(t => `<span class="tt">${esc(t)}</span>`).join('')}</div>
      <div class="prog-bar"><div class="${pbCls(p)} pb" style="width:${pc}%"></div></div>
      <div class="pc-meta"><span class="dl ${dl.c}">${esc(dl.s)}</span><span style="font-size:11px;color:var(--soft);font-family:var(--mono)">${pc}%</span></div>
      ${blkHtml}
      <div class="pc-foot">
        <div class="avs">${(p.assignees || []).map((a,i) => av(a, i)).join('')}</div>
        <div class="pill-row"><span class="rpill ${riskCls(rs)}">RS ${rs}</span><span class="rpill">${(p.comments || []).length} notas</span><span class="rpill">${(p.blockers || []).length} blocker${(p.blockers || []).length !== 1 ? 's' : ''}</span></div>
      </div>
    </div>`;
}

function tabExec(p){
  const rs = riskScore(p);
  return `
    <div class="exec-grid">
      <div class="mcard">
        <p class="mcard-title">Resumen general</p>
        <p class="mcard-val">${pct(p)}<span>% avance</span></p>
        <p class="mcard-desc">${riskLabel(rs)} · combinación de prioridad, severidad, urgencia, dependencias, blockers y vencimiento.</p>
        <div class="badge-stack">
          <span class="rpill ${riskCls(rs)}">RS ${rs}</span>
          <span class="rpill">${Math.max(0, daysTo(p.deadline))}d para deadline</span>
          <span class="rpill">${p.deliverables.filter(d => d.done).length}/${p.deliverables.length} entregables</span>
        </div>
        <div class="mrows">
          <div class="mrow"><span>Estado</span>${sbadge(p.status)}</div>
          <div class="mrow"><span>Deadline</span><strong>${esc(fmtDate(p.deadline).s)}</strong></div>
          <div class="mrow"><span>SLA comprometido</span><strong>${esc(p.committedAt || 'N/D')}</strong></div>
          <div class="mrow"><span>Entrega real</span><strong>${esc(p.actualAt || 'Pendiente')}</strong></div>
        </div>
      </div>
      <div class="mcard">
        <p class="mcard-title">Factor de riesgo</p>
        <div class="score-bars">
          ${[
            ['Prioridad negocio', p.businessPriority || 0, 5],
            ['Severidad técnica', p.technicalSeverity || 0, 5],
            ['Urgencia', p.urgency || 0, 5],
            ['Dependencia crítica', p.dependencyCriticality || 0, 5]
          ].map(([lbl, val, max]) => `
            <div class="sbar-row">
              <div class="sbar-lbl">${lbl}</div>
              <div class="sbar-track"><div class="sbar-fill" style="width:${Math.round((val / max) * 100)}%;background:linear-gradient(90deg,var(--accent),var(--purple))"></div></div>
              <div class="sbar-num">${val}</div>
            </div>
          `).join('')}
        </div>
      </div>
      <div class="mcard">
        <p class="mcard-title">Capacidad y bloqueo</p>
        <p class="mcard-val">${(p.blockers || []).length}<span> blockers</span></p>
        <p class="mcard-desc">Blockers activos, dependencias y señales de riesgo operativo para priorizar decisiones.</p>
        <div class="mrows">
          <div class="mrow"><span>Miembros</span><strong>${(p.assignees || []).map(a => fn(a)).join(', ')}</strong></div>
          <div class="mrow"><span>Tech</span><strong>${(p.tech || []).join(', ')}</strong></div>
          <div class="mrow"><span>Dependencias</span><strong>${(p.dependencies || []).join(', ') || 'Ninguna'}</strong></div>
        </div>
      </div>
    </div>`;
}

function tabDelivs(p){
  const done = p.deliverables.filter(d => d.done).length;
  const total = p.deliverables.length;
  return `
    <div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap">
      <div style="background:rgba(46,232,154,.08);border:1px solid rgba(46,232,154,.2);padding:8px 11px;border-radius:999px;font-family:var(--mono);font-size:11px;color:var(--ok)">${done} completados</div>
      <div style="background:rgba(91,189,255,.08);border:1px solid rgba(91,189,255,.2);padding:8px 11px;border-radius:999px;font-family:var(--mono);font-size:11px;color:var(--info)">${total - done} pendientes</div>
      <div style="background:rgba(255,181,71,.08);border:1px solid rgba(255,181,71,.2);padding:8px 11px;border-radius:999px;font-family:var(--mono);font-size:11px;color:var(--warn)">${p.deliverables.filter(d => !d.done && d.sla && daysTo(d.sla) < 0).length} vencidos</div>
    </div>
    <div style="display:grid;gap:9px">
      ${p.deliverables.map(d => {
        const sl = d.sla ? fmtDate(d.sla) : { s:'sin SLA', c:'' };
        const ddlClass = d.done ? 'soon' : (daysTo(d.sla) < 0 ? 'past' : '');
        return `
          <details class="deliv-item">
            <summary class="deliv-sum">
              <input type="checkbox" ${d.done ? 'checked' : ''} onclick="event.stopPropagation()" onchange="toggleD('${p.id}','${d.id}')">
              <div class="deliv-main">
                <span class="dt ${d.done ? 'done' : ''}">${esc(d.text)}</span>
                <div class="dhint">${d.done ? 'Completado' : 'Pendiente'} · responsable ${esc(fn(d.owner || ''))}</div>
              </div>
              <span class="darrow">▾</span>
            </summary>
            <div class="dextra">
              <div class="kv"><span class="kv-k">Responsable</span><span>${esc(d.owner ? fn(d.owner) : 'Sin definir')}</span></div>
              <div class="kv"><span class="kv-k">Objetivo</span><span>${esc(d.goal || 'No definido')}</span></div>
              <div class="kv"><span class="kv-k">Criterio</span><span>${esc(d.criteria || 'No definido')}</span></div>
              <div class="kv"><span class="kv-k">Notas</span><span>${esc(d.notes || 'Sin notas')}</span></div>
              <div class="kv"><span class="kv-k">SLA</span><span class="${ddlClass}">${esc(sl.s || 'N/D')}</span></div>
              <div class="kv"><span class="kv-k">Compromiso</span><span>${esc(d.committed || 'N/D')}</span></div>
              <div class="kv"><span class="kv-k">Real</span><span>${esc(d.actual || 'N/D')}</span></div>
            </div>
          </details>
        `;
      }).join('')}
      <div style="margin-top:12px">
        <input id="nd" placeholder="+ Añadir entregable..." onkeydown="if(event.key==='Enter')addDel('${p.id}')">
      </div>
    </div>`;
}

function tabComments(p){
  return `
    ${p.comments.length ? p.comments.map(c => `
      <div class="cmt">
        <div class="cmt-hd"><span class="cmt-a">${esc(c.author)}</span><span class="cmt-d">${esc(c.date)}</span></div>
        <p class="cmt-t">${esc(c.text)}</p>
      </div>
    `).join('') : '<p style="font-size:12px;color:var(--soft);font-family:var(--mono)">Sin comentarios aún.</p>'}
    <div class="add-cmt">
      <input id="nc" placeholder="Añadir comentario..." onkeydown="if(event.key==='Enter')addCmt('${p.id}')">
      <button class="btn-p" onclick="addCmt('${p.id}')">Enviar</button>
    </div>`;
}

function tabTimeline(p){
  const tl = p.timeline || [];
  if(!tl.length) return `<div class="empty">Sin hitos registrados.</div>`;
  const dates = tl.map(t => new Date(t.date)).filter(d => isVD(d));
  const minD = dates.length ? Math.min(...dates) : Date.now();
  const maxD = dates.length ? Math.max(...dates, Date.now()) : Date.now();
  const rng = (maxD - minD) || 1;
  const nodeColors = [CHART_COLORS.blue, CHART_COLORS.green, CHART_COLORS.amber, CHART_COLORS.purple, CHART_COLORS.cyan, CHART_COLORS.red];
  const ganttRows = tl.map((t, i) => {
    const d = new Date(t.date);
    const pos = isVD(d) ? Math.round((d - minD) / rng * 85) : 0;
    const w = Math.max(10, i < tl.length - 1 ? Math.round(((new Date(tl[i + 1].date)) - d) / rng * 75) : 12);
    const c = nodeColors[i % nodeColors.length];
    return `<div class="gantt-row"><div class="gantt-lbl">${esc(t.title.slice(0,11))}…</div><div class="gantt-track"><div class="gantt-bar" style="left:${pos}%;width:${Math.min(w,100-pos)}%;background:${c}22;border-left:3px solid ${c}"><span class="gantt-bar-txt">${esc(t.date.slice(5))}</span></div></div></div>`;
  }).join('');
  const items = tl.map((t, i) => {
    const c = nodeColors[i % nodeColors.length];
    return `<div class="tl-item" style="animation-delay:${i * .08}s"><div class="tl-node" style="background:${c}20;border-color:${c}"><div class="tl-dot-inner" style="background:${c}"></div></div><div class="tl-box"><div class="tl-bhead"><p class="tl-bname">${esc(t.title)}</p><span class="tl-date">${esc(t.date)}</span></div><p class="tl-bdesc">${esc(t.desc)}</p></div></div>`;
  }).join('');
  return `
    <div class="gantt-wrap"><p class="gantt-title">Distribución temporal de hitos</p>${ganttRows}</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="tl-wrap"><div class="tl-axis"></div>${items}</div>
      <div>
        <p style="font-size:10px;font-family:var(--mono);color:var(--soft);text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px">Historial</p>
        <div style="display:grid;gap:9px">${(p.history || []).map(h => `
          <div style="border:1px solid var(--line);border-radius:var(--rsm);background:var(--s2);padding:11px 13px">
            <div style="display:flex;justify-content:space-between;gap:8px;margin-bottom:5px"><p style="font-size:12px;font-weight:600;color:var(--text)">${esc(h.action)}</p><span style="font-size:10px;font-family:var(--mono);color:var(--soft);white-space:nowrap">${esc(h.date)}</span></div>
            <p style="font-size:11px;color:var(--muted);line-height:1.4"><strong>${esc(h.author)}</strong> · ${esc(h.detail)}</p>
          </div>
        `).join('') || '<p style="font-size:12px;color:var(--soft)">Sin historial.</p>'}</div>
        <p style="font-size:10px;font-family:var(--mono);color:var(--soft);text-transform:uppercase;letter-spacing:.08em;margin:14px 0 10px">Actividad reciente</p>
        <div style="display:grid;gap:9px">${(p.recentActivity || []).map(r => `
          <div style="border:1px solid var(--line);border-radius:var(--rsm);background:var(--s2);padding:11px 13px">
            <div style="display:flex;justify-content:space-between;gap:8px;margin-bottom:5px"><p style="font-size:12px;font-weight:600;color:var(--text)">${esc(r.author)}</p><span style="font-size:10px;font-family:var(--mono);color:var(--soft)">${esc(r.date)}</span></div>
            <p style="font-size:11px;color:var(--muted)">${esc(r.text)}</p>
          </div>
        `).join('') || '<p style="font-size:12px;color:var(--soft)">Sin actividad.</p>'}</div>
      </div>
    </div>`;
}

function tabSla(p){
  return `
    <div class="sla-grid">
      ${(p.deliverables || []).map(d => {
        const diff = d.sla ? daysTo(d.sla) : null;
        const delta = diff === null ? 'N/D' : `${Math.abs(diff)}d`;
        const slaText = diff === null ? 'sin fecha' : diff < 0 ? 'vencido' : diff === 0 ? 'hoy' : 'en plazo';
        const col = d.done ? 'var(--ok)' : (diff !== null && diff < 0 ? 'var(--danger)' : 'var(--warn)');
        return `
          <div class="sla-card">
            <p class="sla-k">${d.done ? '✅ entregado' : '🔄 en curso'}</p>
            <p class="sla-v" style="color:${col}">${esc(delta)}</p>
            <p class="sla-s">${esc(d.text)}</p>
            <div class="badge-stack" style="margin-top:8px">
              <span class="rpill">👤 ${esc(fn(d.owner || ''))}</span>
              <span class="rpill">SLA ${esc(d.sla || 'N/D')}</span>
              <span class="rpill" style="color:${diff !== null && diff > 0 ? 'var(--danger)' : 'var(--ok)'}">${esc(slaText)}</span>
            </div>
          </div>
        `;
      }).join('')}
    </div>`;
}

function tabInfo(p){
  const ov = daysTo(p.deadline) < 0;
  const near = daysTo(p.deadline) >= 0 && daysTo(p.deadline) <= 7;
  return `
    <details class="acc" open>
      <summary>Resumen general</summary>
      <div class="acc-body">
        <div class="kv"><span class="kv-k">Estado</span>${sbadge(p.status)}</div>
        <div class="kv"><span class="kv-k">Progreso</span><span>${pct(p)}% (${p.deliverables.filter(d => d.done).length}/${p.deliverables.length})</span></div>
        <div class="kv"><span class="kv-k">Deadline</span><span style="font-family:var(--mono)">${esc(p.deadline)}</span></div>
        <div class="kv"><span class="kv-k">Alerta</span><span style="color:${ov ? 'var(--danger)' : near ? 'var(--warn)' : 'var(--ok)'}">${ov ? 'Vencido' : near ? 'Próximo a vencer' : 'OK'}</span></div>
        <div class="kv"><span class="kv-k">Risk score</span><span>${riskScore(p)} · ${riskLabel(riskScore(p))}</span></div>
      </div>
    </details>
    <details class="acc">
      <summary>Equipo y Stack</summary>
      <div class="acc-body">
        <div class="kv"><span class="kv-k">Miembros</span><span>${(p.assignees || []).map(a => fn(a)).join(', ')}</span></div>
        <div class="kv"><span class="kv-k">Tech</span><div style="display:flex;gap:5px;flex-wrap:wrap">${(p.tech || []).map(t => `<span class="tt">${esc(t)}</span>`).join('')}</div></div>
      </div>
    </details>
    <details class="acc">
      <summary>Gestión</summary>
      <div class="acc-body">
        <div class="kv"><span class="kv-k">Comentarios</span><span>${p.comments.length}</span></div>
        <div class="kv"><span class="kv-k">Blockers</span><span style="color:${(p.blockers || []).length ? 'var(--danger)' : 'var(--ok)'}">${(p.blockers || []).length}</span></div>
        <div class="kv"><span class="kv-k">Dependencias</span><span>${(p.dependencies || []).join(', ') || 'Ninguna'}</span></div>
        <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
          <button class="btn-p" onclick="editP('${p.id}')">Editar proyecto</button>
          <button class="btn-s btn-d" onclick="delP('${p.id}')">Eliminar</button>
        </div>
      </div>
    </details>`;
}

function renderDetail(){
  const p = S.projects.find(x => x.id === S.sel);
  if(!p) return '';
  const tabs = [
    ['executive', '🎯 Ejecutivo'],
    ['deliverables', '📦 Entregables'],
    ['timeline', '📅 Timeline'],
    ['blockers', '🚧 Blockers'],
    ['comments', '💬 Comentarios'],
    ['sla', '📋 SLA'],
    ['info', 'ℹ️ Info']
  ];
  let body = '';
  if(S.tab === 'executive') body = tabExec(p);
  else if(S.tab === 'deliverables') body = tabDelivs(p);
  else if(S.tab === 'timeline') body = tabTimeline(p);
  else if(S.tab === 'blockers') body = tabBlockers(p);
  else if(S.tab === 'comments') body = tabComments(p);
  else if(S.tab === 'sla') body = tabSla(p);
  else body = tabInfo(p);

  return `
    <div class="detail">
      <div class="dp-hdr">
        <div style="flex:1;min-width:0">
          <p class="dp-title">${esc(p.name)}</p>
          <p class="dp-sub">${esc(p.description.slice(0,130))}${p.description.length > 130 ? '…' : ''}</p>
        </div>
        <div style="display:flex;gap:8px;align-items:center;flex-shrink:0">${sbadge(p.status)}<button onclick="pick(null)" class="tiny-btn">✕</button></div>
      </div>
      <div class="dp-tabs">
        ${tabs.map(([k,l]) => `<div class="dpt ${S.tab === k ? 'on' : ''}" onclick="setTab('${k}')">${l}</div>`).join('')}
      </div>
      ${body}
    </div>`;
}

function tabBlockers(p){
  const crit = (p.blockers || []).filter(b => b.severity === 'crit');
  const med = (p.blockers || []).filter(b => b.severity !== 'crit');
  return `
    <p style="font-size:10px;font-family:var(--mono);color:var(--danger);text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px">— Blockers críticos</p>
    <div class="blocker-grid">
      ${crit.map(b => `<div class="blocker-item"><div class="bl-top"><p class="bl-name">${esc(b.text)}</p><span class="bl-badge crit">Crítico</span></div><p class="bl-proj">Impacto directo en producción y entrega</p></div>`).join('') || '<p style="font-size:12px;color:var(--soft)">Ninguno.</p>'}
    </div>
    <p style="font-size:10px;font-family:var(--mono);color:var(--warn);text-transform:uppercase;letter-spacing:.08em;margin:16px 0 10px">— Blockers medios</p>
    <div class="blocker-grid">
      ${med.map(b => `<div class="blocker-item warn-blk"><div class="bl-top"><p class="bl-name">${esc(b.text)}</p><span class="bl-badge med">Medio</span></div><p class="bl-proj">Impacto en velocidad y calidad</p></div>`).join('') || '<p style="font-size:12px;color:var(--soft)">Ninguno.</p>'}
    </div>
    <p style="font-size:10px;font-family:var(--mono);color:var(--soft);text-transform:uppercase;letter-spacing:.08em;margin:16px 0 10px">— Dependencias externas</p>
    <div style="display:flex;gap:7px;flex-wrap:wrap">${(p.dependencies || []).map(d => `<span style="font-size:11px;font-family:var(--mono);padding:5px 12px;border-radius:999px;background:rgba(180,124,255,.1);border:1px solid rgba(180,124,255,.2);color:var(--purple)">${esc(d)}</span>`).join('') || '<span style="font-size:12px;color:var(--soft)">Sin dependencias.</span>'}</div>`;
}

function renderForm(){
  if(!S.showForm) return '';
  const ed = S.editId ? S.projects.find(p => p.id === S.editId) : null;
  const f = S.form || {};
  return `
    <div class="fs">
      <p style="font-size:11px;font-family:var(--mono);text-transform:uppercase;letter-spacing:.08em;color:var(--accent);margin-bottom:18px">${ed ? '// editar proyecto' : '// nuevo proyecto'}</p>
      <div class="fg">
        <div class="full"><label class="flabel">Nombre</label><input id="fn" value="${esc(f.name || '')}" placeholder="Nombre del proyecto"></div>
        <div class="full"><label class="flabel">Descripción</label><textarea id="fd" placeholder="Objetivo y alcance...">${esc(f.description || '')}</textarea></div>
        <div><label class="flabel">Estado</label><select id="fst"><option value="active" ${(f.status || 'active') === 'active' ? 'selected' : ''}>Activo</option><option value="risk" ${f.status === 'risk' ? 'selected' : ''}>En riesgo</option><option value="delivered" ${f.status === 'delivered' ? 'selected' : ''}>Entregado</option><option value="paused" ${f.status === 'paused' ? 'selected' : ''}>Pausado</option></select></div>
        <div><label class="flabel">Prioridad negocio</label><select id="fbp">${[5,4,3,2,1].map(n => `<option value="${n}" ${String(f.businessPriority || 3) === String(n) ? 'selected' : ''}>${n}/5</option>`).join('')}</select></div>
        <div><label class="flabel">Severidad técnica</label><select id="fts">${[5,4,3,2,1].map(n => `<option value="${n}" ${String(f.technicalSeverity || 3) === String(n) ? 'selected' : ''}>${n}/5</option>`).join('')}</select></div>
        <div><label class="flabel">Urgencia</label><select id="fur">${[5,4,3,2,1].map(n => `<option value="${n}" ${String(f.urgency || 3) === String(n) ? 'selected' : ''}>${n}/5</option>`).join('')}</select></div>
        <div><label class="flabel">Dependencia crítica</label><select id="fdc">${[5,4,3,2,1].map(n => `<option value="${n}" ${String(f.dependencyCriticality || 3) === String(n) ? 'selected' : ''}>${n}/5</option>`).join('')}</select></div>
        <div><label class="flabel">Fecha de entrega</label><input type="date" id="fdl" value="${esc(f.deadline || '')}"></div>
        <div><label class="flabel">SLA comprometido</label><input type="date" id="fca" value="${esc(f.committedAt || '')}"></div>
        <div><label class="flabel">Fecha real</label><input type="date" id="fra" value="${esc(f.actualAt || '')}"></div>
        <div><label class="flabel">Miembros</label><input id="fass" value="${esc(f.assignees || '')}" placeholder="CR, ML, JP"></div>
        <div class="full"><label class="flabel">Tech stack</label><input id="ftc" value="${esc(f.tech || '')}" placeholder="Node.js, Redis, K8s"></div>
        <div class="full"><label class="flabel">Blockers (uno por línea)</label><textarea id="fblk" placeholder="Bloqueador 1
Bloqueador 2">${esc(f.blockers || '')}</textarea></div>
        <div class="full"><label class="flabel">Dependencias (una por línea)</label><textarea id="fdep" placeholder="Servicio A
Servicio B">${esc(f.dependencies || '')}</textarea></div>
        <div class="full"><label class="flabel">Entregables (uno por línea)</label><textarea id="fdels" placeholder="Diseño de arquitectura
Implementación de auth
Tests de carga">${esc(f.deliverables || '')}</textarea></div>
      </div>
      <div class="fa">
        <button class="btn-s" onclick="cancelF()">Cancelar</button>
        <button class="btn-p" onclick="saveP()">${ed ? 'Guardar cambios' : 'Crear proyecto'}</button>
      </div>
    </div>`;
}

function render(){
  clearCharts();
  const fil = S.projects.filter(p => S.filter === 'all' || p.status === S.filter);
  const root = document.getElementById('root');
  if(!root) return;
  root.innerHTML = `
    ${renderHeader()}
    ${renderAnalytics()}
    ${renderChartsRow1()}
    ${renderBlockers()}
    <div class="fbar">
      <div class="filters">
        ${[['all','Todos'],['active','Activos'],['risk','En riesgo'],['delivered','Entregados'],['paused','Pausados']].map(([k,l]) => `<button class="fb ${S.filter===k ? 'on' : ''}" onclick="setF('${k}')">${l}</button>`).join('')}
      </div>
      <button class="add-btn" onclick="tgForm()">${S.showForm && !S.editId ? '✕ Cancelar' : '+ Nuevo proyecto'}</button>
    </div>
    ${renderForm()}
    <div class="proj-grid">${fil.length ? fil.map(renderCard).join('') : `<div class="empty" style="grid-column:1/-1">// no hay proyectos en esta vista</div>`}</div>
    ${renderDetail()}
  `;

  requestAnimationFrame(() => {
    mountChartsRow1();
    setThemeLabel();
  });
}
