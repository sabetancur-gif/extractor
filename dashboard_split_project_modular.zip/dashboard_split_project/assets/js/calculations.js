/* Módulo 3 · cálculos ejecutivos
   Métricas de negocio, indicadores de riesgo y agregaciones del portafolio.
*/

function statusCounts(){
  const counts = { active:0, risk:0, delivered:0, paused:0 };
  for(const p of S.projects) counts[p.status] = (counts[p.status] || 0) + 1;
  return counts;
}

function memberCounts(){
  const map = new Map();
  for(const p of S.projects){
    for(const a of p.assignees || []) map.set(a, (map.get(a) || 0) + 1);
  }
  return [...map.entries()].sort((a,b) => b[1] - a[1]);
}

function completionRate(){
  const dels = S.projects.flatMap(p => p.deliverables || []);
  if(!dels.length) return 0;
  return Math.round(dels.filter(d => d.done).length / dels.length * 100);
}

function overdueDeliverablesCount(){
  const today = new Date();
  today.setHours(0,0,0,0);
  let c = 0;
  for(const p of S.projects){
    for(const d of p.deliverables || []){
      if(!d.done && d.sla){
        const dd = toDate(d.sla);
        if(isVD(dd)){
          dd.setHours(0,0,0,0);
          if(dd < today) c++;
        }
      }
    }
  }
  return c;
}

function blockedProjectsCount(){
  return S.projects.filter(p => (p.blockers || []).length > 0 && p.status !== 'delivered').length;
}

function deliveredRecently(){
  const now = new Date();
  now.setHours(0,0,0,0);
  let count = 0;
  for(const p of S.projects){
    for(const d of p.deliverables || []){
      if(d.done && d.actual){
        const dd = toDate(d.actual);
        if(isVD(dd)){
          dd.setHours(0,0,0,0);
          const delta = Math.round((now - dd) / 864e5);
          if(delta >= 0 && delta <= 14) count++;
        }
      }
    }
  }
  return count;
}

function loadVsCapacity(){
  const load = new Map();
  for(const p of S.projects){
    for(const a of p.assignees || []) load.set(a, (load.get(a) || 0) + 1);
  }
  let assigned = 0, cap = 0;
  for(const [member, tasks] of load.entries()){
    assigned += tasks;
    cap += (MCAP[member] || 2);
  }
  return { assigned, cap, pct: cap ? Math.round((assigned / cap) * 100) : 0 };
}

function velocity(){
  // Cantidad de entregables cerrados en la ventana de 14 días.
  return deliveredRecently();
}

function riskScore(p){
  const business = (p.businessPriority || 0) * 6;
  const technical = (p.technicalSeverity || 0) * 5;
  const urgency = (p.urgency || 0) * 5;
  const dependency = (p.dependencyCriticality || 0) * 4;
  const overdue = Math.max(0, -daysTo(p.deadline)) * 5;
  const near = daysTo(p.deadline);
  const nearPenalty = near >= 0 && near <= 7 ? (8 - near) * 3 : 0;
  const critBlockers = (p.blockers || []).filter(b => b.severity === 'crit').length;
  const medBlockers = (p.blockers || []).filter(b => b.severity !== 'crit').length;
  const blockers = Math.min((critBlockers * 10) + (medBlockers * 5), 25);
  const progressPenalty = Math.max(0, 60 - pct(p)) * 0.4;
  const statusPenalty = p.status === 'risk' ? 14 : p.status === 'paused' ? 18 : 0;
  return Math.max(0, Math.min(100, Math.round(business + technical + urgency + dependency + overdue + nearPenalty + blockers + progressPenalty + statusPenalty)));
}

function riskLabel(score){
  if(score >= 80) return 'Crítico';
  if(score >= 60) return 'Alto';
  if(score >= 35) return 'Medio';
  return 'Bajo';
}

function riskCls(score){
  if(score >= 80) return 'crit';
  if(score >= 60) return 'high';
  if(score >= 35) return 'med';
  return 'low';
}

function execKpis(){
  const cap = loadVsCapacity();
  const overdue = overdueDeliverablesCount();
  const blocked = blockedProjectsCount();
  const avgRisk = S.projects.length ? Math.round(S.projects.reduce((a,p) => a + riskScore(p), 0) / S.projects.length) : 0;
  const portfolioProgress = completionRate();
  const sprintVel = velocity();
  const riskProjects = S.projects.filter(p => riskScore(p) >= 60).length;
  const totalBlockers = S.projects.reduce((a,p) => a + (p.blockers || []).length, 0);

  return [
    { l:'Avance global', v:`${portfolioProgress}`, u:'%', s:`${S.projects.flatMap(p => p.deliverables || []).filter(d => d.done).length} entregables completados`, cls: portfolioProgress >= 75 ? 'ok' : portfolioProgress >= 45 ? 'warn' : 'bad', ico:'📊' },
    { l:'Riesgo acumulado', v:`${avgRisk}`, u:'', s:`${riskProjects} proyectos con riesgo alto`, cls: avgRisk >= 60 ? 'bad' : avgRisk >= 35 ? 'warn' : 'ok', ico:'⚠️' },
    { l:'SLA vencidos', v:`${overdue}`, u:'', s:'entregables fuera de plazo', cls: overdue ? 'bad' : 'ok', ico:'🕒' },
    { l:'Carga/Capacidad', v:`${cap.pct}`, u:'%', s:`${cap.assigned}/${cap.cap} asignaciones`, cls: cap.pct >= 100 ? 'bad' : cap.pct >= 75 ? 'warn' : 'ok', ico:'👥' },
    { l:'Velocidad sprint', v:`${sprintVel}`, u:'', s:'entregas cerradas · 14 días', cls: sprintVel >= 4 ? 'ok' : sprintVel >= 2 ? 'warn' : 'bad', ico:'⚡' },
    { l:'Blockers activos', v:`${totalBlockers}`, u:'', s:`${blocked} proyectos bloqueados`, cls: totalBlockers ? 'bad' : 'ok', ico:'🚧' }
  ];
}

function deliverableStatusCounts(){
  const all = S.projects.flatMap(p => p.deliverables || []);
  const completed = all.filter(d => d.done).length;
  const overdue = all.filter(d => !d.done && d.sla && daysTo(d.sla) < 0).length;
  const pending = all.length - completed - overdue;
  return { completed, pending, overdue, total: all.length };
}
