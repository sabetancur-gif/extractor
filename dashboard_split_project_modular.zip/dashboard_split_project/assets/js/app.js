/* Módulo 6 · arranque
   Inicializa el fondo animado y dispara la carga del dashboard.
*/

(function initMathBg(){
  const c = document.getElementById('mbg');
  if(!c) return;
  const ctx = c.getContext('2d');
  const SYM = ['∑','∫','∂','π','∞','√','Δ','θ','λ','σ','μ','∇','≈','≡','∈','∀','∃','∮','ℝ','ℕ','⊗','⊕','∥','⊥','∧','∨','∇²','f(x)','x²','eˣ','logn','∂²f','det(A)','∫₀¹','Σᵢ','P(B|A)','O(n)','∈ℝⁿ','lim→','∮C','α+β','λₙ','ψ(x)','E[X]','Ax=b','∇f=0','F=ma','E=mc²'];
  let W = 0, H = 0, items = [], F = 0;

  function resize(){
    W = c.width = window.innerWidth;
    H = c.height = window.innerHeight;
  }

  function spawn(){
    items = [];
    const n = Math.floor(W * H / 14000);
    for(let i = 0; i < n; i++){
      items.push({
        x: Math.random() * W,
        y: Math.random() * H,
        s: SYM[Math.floor(Math.random() * SYM.length)],
        sz: 12 + Math.random() * 18,
        sp: .1 + Math.random() * .24,
        op: .4 + Math.random() * .6,
        dr: (Math.random() - .5) * .35,
        ph: Math.random() * Math.PI * 2
      });
    }
  }

  function draw(){
    ctx.clearRect(0,0,W,H);
    const dark = document.documentElement.getAttribute('data-theme') !== 'light';
    const col = dark ? '91,189,255' : '20,90,180';
    const base = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--math-alpha')) || 0.11;
    F++;

    for(const it of items){
      it.y -= it.sp;
      it.x += it.dr * Math.sin(F * .012 + it.ph);
      if(it.y < -50){ it.y = H + 20; it.x = Math.random() * W; }
      if(it.x < -80) it.x = W + 30;
      if(it.x > W + 80) it.x = -30;
      const pulse = 0.65 + 0.35 * Math.sin(F * .018 + it.ph);
      ctx.save();
      ctx.globalAlpha = base * it.op * pulse;
      ctx.fillStyle = `rgb(${col})`;
      ctx.font = `${it.sz}px 'JetBrains Mono',monospace`;
      ctx.fillText(it.s, it.x, it.y);
      ctx.restore();
    }
    requestAnimationFrame(draw);
  }

  resize();
  spawn();
  draw();
  window.addEventListener('resize', () => { resize(); spawn(); });
})();

(function boot(){
  const start = () => {
    if(typeof load === 'function') load();
  };
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', start, { once: true });
  }else{
    start();
  }
})();
