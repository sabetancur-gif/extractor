# Engineering Dashboard · estructura modular

Este proyecto separa el dashboard original en archivos independientes para que sea más fácil de mantener y modificar.

## Estructura

- `index.html`: punto de entrada.
- `assets/css/styles.css`: estilos globales y componentes.
- `assets/js/data.js`: datos de ejemplo, estado global y almacenamiento.
- `assets/js/utils.js`: funciones auxiliares reutilizables.
- `assets/js/calculations.js`: métricas del portafolio.
- `assets/js/renderers.js`: renderizado de secciones, tarjetas y vistas.
- `assets/js/actions.js`: acciones de usuario, persistencia y mutaciones.
- `assets/js/app.js`: animación de fondo y arranque.

## Cambios incluidos

- Se eliminó la tarjeta de **Risk Score por proyecto**.
- Se reemplazó por **Entregables por estado**.
- Se eliminó **Actividad del equipo — heatmap**.
- La sección **Blockers activos del portfolio** ahora es plegable con `details/summary`.

## Ejecución

Abre `index.html` en un navegador moderno.
