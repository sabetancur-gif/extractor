/**  Módulo 5 · Vizualización tab SLA
  * Responsabilidad:
  *   - Visualización SLA: donut, heatmap compacto y carrusel de 4
  */

/**
 * Genera el SVG de una dona (donut) para visualizar el SLA de un entregable.
 */
function slaDonutSVG(d) {
  const diff   = d.sla ? daysTo(d.sla) : null;
  const total  = (d.committed && d.sla) ? Math.max(1, Math.round((new Date(d.sla) - new Date(d.committed)) / 86400000)) : 30;
  const elapsed = diff !== null ? Math.max(0, total - diff) : total;
  const pct    = Math.min(100, Math.round(elapsed / total * 100));
  const colHex = d.done ? '#2ee89a' : diff === null ? '#3d5f7a' : diff < 0 ? '#ff5c5c' : diff <= 3 ? '#ffb547' : '#2ee89a';
  const cx = 36, cy = 36, r = 28, sw = 8;
  const circ = 2 * Math.PI * r;
  const filled = circ * pct / 100;
  const dk = isDark();
  const label = d.done ? t('sla_entregado') : diff === null ? t('nd') : diff < 0 ? t('sla_vencido') : diff === 0 ? t('sla_hoy') : `${diff}d`;
  return `<svg viewBox="0 0 72 72" width="72" height="72" style="flex-shrink:0">
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${dk ? '#1a2e42' : '#ddeeff'}" stroke-width="${sw}"/>
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${colHex}" stroke-width="${sw}" stroke-linecap="round"
        stroke-dasharray="${filled} ${circ - filled}" stroke-dashoffset="${circ * 0.25}" style="transition:stroke-dasharray .6s ease"/>
      <circle cx="${cx}" cy="${cy}" r="17" fill="${dk ? '#0c1520' : '#fff'}"/>
      <text x="${cx}" y="${cy - 3}" text-anchor="middle" fill="${colHex}" font-size="9" font-family="'JetBrains Mono',monospace" font-weight="700">${pct}%</text>
      <text x="${cx}" y="${cy + 9}" text-anchor="middle" fill="${dk ? '#3d5f7a' : '#8aa8c4'}" font-size="7" font-family="'JetBrains Mono',monospace">${esc(label)}</text>
    </svg>`;
}

/** Genera un heatmap calendario de los SLA del proyecto. */

/**
 * Heatmap de calendario SLA — SVG nativo mejorado.
 * 13 semanas × 7 días, celdas de 16px con bordes redondeados.
 * Tooltip enriquecido, hoy resaltado, filtro por clic, leyenda integrada.
*/
function slaHeatmapHTML(p, filterDate) {
  const deliverables = p.deliverables || [];
  const dateMap = {};
  deliverables.forEach(d => { if (d.sla) dateMap[d.sla] = (dateMap[d.sla] || 0) + 1; });

  const today = new Date(); today.setHours(0, 0, 0, 0);
  const todayISO = today.toISOString().slice(0, 10);

  const WEEKS = 13;
  const start = new Date(today);
  start.setDate(today.getDate() - (WEEKS - 1) * 7);
  start.setDate(start.getDate() - ((start.getDay() + 6) % 7));

  const maxCount = Math.max(1, ...Object.values(dateMap), 0);
  const dk = isDark();

  const CELL = 16, GAP = 4, STEP = CELL + GAP;
  const LEFT = 20, TOP = 22;
  const W_SVG = LEFT + WEEKS * STEP + 4;
  const H_SVG = TOP + 7 * STEP + 24;

  function cellColor(count, pct) {
    if (count === 0) return dk ? '#0d1d2e' : '#e2edf7';
    if (pct < 0.25)  return dk ? '#7c3a0e88' : '#fed7aa';
    if (pct < 0.50)  return dk ? '#c2410cbb' : '#fb923c';
    if (pct < 0.75)  return dk ? '#dc2626cc' : '#ef4444';
    return dk ? '#991b1bee' : '#b91c1c';
  }

  const cellRects = [];
  const seenMonths = {};

  for (let w = 0; w < WEEKS; w++) {
    for (let d = 0; d < 7; d++) {
      const date = new Date(start);
      date.setDate(start.getDate() + w * 7 + d);
      const iso   = date.toISOString().slice(0, 10);
      const count = dateMap[iso] || 0;
      const pct   = count / maxCount;
      const fill  = cellColor(count, pct);

      const isToday    = iso === todayISO;
      const isFiltered = filterDate && iso === filterDate;
      const isFuture   = iso > todayISO;

      let stroke = 'none', sw = 0;
      if      (isFiltered)        { stroke = '#5bbdff'; sw = 2; }
      else if (isToday)           { stroke = '#2ee89a'; sw = 2; }
      else if (isFuture && count) { stroke = '#ff8a3d'; sw = 1; }

      const x = LEFT + w * STEP;
      const y = TOP  + d * STEP;

      if (d === 0) {
        const mkey = `${date.getFullYear()}-${date.getMonth()}`;
        if (!seenMonths[mkey]) {
          seenMonths[mkey] = { x, label: date.toLocaleString('default', { month: 'short' }) };
        }
      }

      const dlvs = deliverables.filter(dv => dv.sla === iso);
      const tipLines = dlvs.length
        ? [`${iso} — ${dlvs.length} SLA`, ...dlvs.slice(0,3).map(dv => '· ' + dv.text.slice(0,38))]
        : [iso];
      const tip = tipLines.join('\n');
      const opacity = (isFuture && !count) ? '0.35' : '1';

      cellRects.push(`<rect x="${x}" y="${y}" width="${CELL}" height="${CELL}" rx="3"
        fill="${fill}" stroke="${stroke}" stroke-width="${sw}" opacity="${opacity}"
        style="cursor:${count || isFiltered?'pointer':'default'};transition:opacity .12s"
        onclick="slaHeatmapFilter('${p.id}','${isFiltered ? '' : iso}')"
        onmouseenter="this.setAttribute('opacity','0.65')"
        onmouseleave="this.setAttribute('opacity','${opacity}')"
      ><title>${esc(tip)}</title></rect>`);
    }
  }

  const DAY_MAP = { 0:'L', 2:'X', 4:'V' };
  const dayLabels = Object.entries(DAY_MAP).map(([d, lbl]) =>
    `<text x="${LEFT - 4}" y="${TOP + parseInt(d) * STEP + CELL * 0.75}"
      text-anchor="end" font-size="9" font-family="'JetBrains Mono',monospace"
      fill="${dk ? '#2d4a62' : '#94aabf'}">${lbl}</text>`
  ).join('');

  const monthLabels = Object.values(seenMonths).map(({ x, label }) =>
    `<text x="${x + CELL/2}" y="${TOP - 7}" text-anchor="middle"
      font-size="9" font-family="'JetBrains Mono',monospace"
      fill="${dk ? '#3d5f7a' : '#7a9db8'}">${label}</text>`
  ).join('');

  const monthDividers = Object.values(seenMonths).slice(1).map(({ x }) =>
    `<line x1="${x - GAP/2}" y1="${TOP - 2}" x2="${x - GAP/2}" y2="${TOP + 7 * STEP - GAP}"
      stroke="${dk ? '#1a2e42' : '#cbd5e1'}" stroke-width="1" stroke-dasharray="3,3"/>`
  ).join('');

  const legY = TOP + 7 * STEP + 8;
  const legColors = [
    dk ? '#0d1d2e' : '#e2edf7',
    dk ? '#7c3a0e88' : '#fed7aa',
    dk ? '#c2410cbb' : '#fb923c',
    dk ? '#dc2626cc' : '#ef4444',
    dk ? '#991b1bee' : '#b91c1c',
  ];
  const legRects = legColors.map((c, i) =>
    `<rect x="${LEFT + i * (CELL + 2)}" y="${legY}" width="${CELL}" height="${CELL}" rx="3" fill="${c}"/>`
  ).join('');
  const legLess = `<text x="${LEFT - 4}" y="${legY + CELL * 0.75}" text-anchor="end"
    font-size="8" font-family="'JetBrains Mono',monospace"
    fill="${dk ? '#2d4a62' : '#94aabf'}">−</text>`;
  const legMore = `<text x="${LEFT + legColors.length * (CELL + 2) + 2}" y="${legY + CELL * 0.75}"
    font-size="8" font-family="'JetBrains Mono',monospace"
    fill="${dk ? '#ff5c3a' : '#dc2626'}">+</text>`;

  const filterBadge = filterDate
    ? `<div class="shm-filter-badge" style="display: flex; gap: 5px; align-items: center;">
        <img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/calendar.svg" style="width: .6rem; height: .6rem; filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">
        <span>${filterDate}</span>
        <button class="shm-clear" onclick="slaHeatmapFilter('${p.id}','')">✕ limpiar</button>
      </div>`
    : '';

  return `<div class="shm-wrap-v2">
    <svg width="${W_SVG}" height="${H_SVG}" xmlns="http://www.w3.org/2000/svg"
      style="display:block;overflow:visible">
      ${monthDividers}
      ${monthLabels}
      ${dayLabels}
      ${cellRects.join('')}
      ${legRects}
      ${legLess}${legMore}
    </svg>
    ${filterBadge}
  </div>`;
}

function slaHeatmapFilter(pid, date) {
  if (!S._slaFilter) S._slaFilter = {};
  S._slaFilter[pid] = date || null;
  render();
}


/**
 * Navega el carrusel de tarjetas SLA hacia adelante.
 * @param {string} pid - ID del proyecto
 * @param {number} total - Total de tarjetas
 */
function slaCflowNext(pid, total) {
  if (!S._slaCarousel) S._slaCarousel = {};
  const cur = S._slaCarousel[pid] || 0;
  S._slaCarousel[pid] = (cur + 4) >= total ? 0 : cur + 1;
  slaCflowLayout(pid, total);
}

/**
 * Navega el carrusel de tarjetas SLA hacia atrás.
 * @param {string} pid - ID del proyecto
 * @param {number} total - Total de tarjetas
 */
function slaCflowPrev(pid, total) {
  if (!S._slaCarousel) S._slaCarousel = {};
  const cur = S._slaCarousel[pid] || 0;
  S._slaCarousel[pid] = cur <= 0 ? Math.max(0, total - 4) : cur - 1;
  slaCflowLayout(pid, total);
}

/**
 * Actualiza la posición visual del carrusel SLA sin re-renderizar el DOM completo.
 * Mueve el track con CSS transform para simular movimiento circular.
 * @param {string} pid   - ID del proyecto
 * @param {number} total - Total de tarjetas (para calcular dots)
 */
function slaCflowLayout(pid, total) {
  if (!S._slaCarousel) S._slaCarousel = {};
  const idx   = S._slaCarousel[pid] || 0;
  const inner = document.getElementById('sla-cinner-' + pid);
  const dotsEl= document.getElementById('sla-cdots-' + pid);
  if (!inner) return;

  // Cada tarjeta ocupa 25% del track; el gap es 10px
  const cardW = inner.parentElement.offsetWidth / 4 - 8;
  inner.style.transform = `translateX(-${idx * (cardW + 10)}px)`;

  // Actualizar dots
  if (dotsEl) {
    const maxDots = Math.max(1, total - 3);
    dotsEl.querySelectorAll('.sla-cdot').forEach((d, i) => {
      d.classList.toggle('active', i === idx);
    });
  }
}

/**
 * Renderiza el tab de SLA con:
 *   1. Fila de 4 donuts resumen (completados / en plazo / vencidos / sin fecha)
 *   2. Heatmap compacto de 8 semanas con filtro por clic
 *   3. Carrusel de tarjetas de entregables (4 visibles, navegación circular)
 * @param {Object} p - Proyecto con deliverables, id, etc.
 * @returns {string} HTML del tab SLA
 */
function tabSla(p) {
  if (!S._slaCarousel) S._slaCarousel = {};
  const filterDate = S._slaFilter && S._slaFilter[p.id];
  const allDels    = p.deliverables || [];
  const deliverables = filterDate ? allDels.filter(d => d.sla === filterDate) : allDels;

  const total   = allDels.length || 1;
  const done    = allDels.filter(d => d.done).length;
  const overdue = allDels.filter(d => !d.done && d.sla && daysTo(d.sla) < 0).length;
  const onTrack = allDels.filter(d => !d.done && d.sla && daysTo(d.sla) >= 0).length;
  const noDate  = allDels.filter(d => !d.sla).length;
  const dk      = isDark();

  // Fila de donuts resumen
  const summaryDonuts = [
    { label: t('entregable_completado') || 'Completados', count: done,    color: '#2ee89a', pct: done/total },
    { label: t('sla_en_plazo')          || 'En plazo',    count: onTrack, color: '#ffb547', pct: onTrack/total },
    { label: t('sla_vencido')           || 'Vencidos',    count: overdue, color: '#ff5c5c', pct: overdue/total },
    { label: t('nd')                    || 'Sin fecha',   count: noDate,  color: '#3d5f7a', pct: noDate/total },
  ];
  const summaryRow = summaryDonuts.map(item => {
    const cx = 22, cy = 22, r = 16, sw = 5;
    const circ = 2 * Math.PI * r, filled = circ * item.pct;
    return `<div class="sla-sum-card">
      <svg viewBox="0 0 44 44" width="44" height="44">
        <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${dk?'#1a2e42':'#ddeeff'}" stroke-width="${sw}"/>
        <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${item.color}" stroke-width="${sw}"
          stroke-linecap="round" stroke-dasharray="${filled} ${circ-filled}" stroke-dashoffset="${circ*0.25}"/>
        <text x="${cx}" y="${cy+4}" text-anchor="middle" fill="${item.color}"
          font-size="9" font-family="'JetBrains Mono',monospace" font-weight="700">${item.count}</text>
      </svg>
      <p class="sla-sum-lbl">${item.label}</p>
    </div>`;
  }).join('');

  // Heatmap compacto
  const heatmap = slaHeatmapHTML(p, filterDate);

  // Carrusel de tarjetas
  const cardItems = deliverables.map(d => {
    const diff    = d.sla ? daysTo(d.sla) : null;
    const slaText = diff === null ? (t('sla_sin_fecha')||'Sin fecha')
                  : diff < 0     ? (t('sla_vencido')||'Vencido')
                  : diff === 0   ? (t('sla_hoy')||'Hoy')
                  :                (t('sla_en_plazo')||'En plazo');
    const col = d.done ? 'var(--ok)'
              : diff !== null && diff < 0  ? 'var(--danger)'
              : diff !== null && diff <= 3 ? 'var(--warn)'
              : 'var(--soft)';
    return `<div class="sla-card sla-card-v2">
      <div class="sla-card-top">
        ${slaDonutSVG(d)}
        <div class="sla-card-info">
          <p class="sla-k">${d.done?(t('sla_entregado')||'Entregado'):(t('sla_en_curso')||'En curso')}</p>
          <p class="sla-s">${esc(d.text.slice(0,52))}${d.text.length>52?'…':''}</p>
          <div class="badge-stack" style="margin-top:5px">
            <span class="rpill">👤 ${esc(fn(d.owner||''))}</span>
            <span class="rpill">SLA ${esc(d.sla||t('nd')||'—')}</span>
            <span class="rpill" style="color:${col}">${esc(slaText)}</span>
          </div>
        </div>
      </div>
    </div>`;
  }).join('');

  // Dots para el carrusel (uno por página de 4)
  const numDots = Math.max(1, deliverables.length - 3);
  const curIdx  = S._slaCarousel[p.id] || 0;
  const dots    = Array.from({ length: numDots }, (_, i) =>
    `<div class="sla-cdot${i===curIdx?' active':''}" onclick="S._slaCarousel['${p.id}']=${i};slaCflowLayout('${p.id}',${deliverables.length})"></div>`
  ).join('');

  const carouselHTML = deliverables.length === 0
    ? `<div class="cflow-empty">// No hay entregables en esta vista</div>`
    : `<div class="sla-carousel-wrap">
        <button class="sla-cbtn prev" onclick="slaCflowPrev('${p.id}',${deliverables.length})">&#8249;</button>
        <div class="sla-carousel-track">
          <div class="sla-carousel-inner" id="sla-cinner-${p.id}">${cardItems}</div>
        </div>
        <button class="sla-cbtn next" onclick="slaCflowNext('${p.id}',${deliverables.length})">&#8250;</button>
      </div>
      <div class="sla-cdots" id="sla-cdots-${p.id}">${dots}</div>`;

 // ── Recomendaciones: 4 entregables pendientes más urgentes ──────────
  const urgentes = allDels
    .filter(d => !d.done && d.sla)
    .map(d => ({ ...d, diff: daysTo(d.sla) }))
    .sort((a, b) => a.diff - b.diff)
    .slice(0, 4);

  const recoItems = urgentes.length === 0
    ? `<li class="sla-reco-empty">// Sin pendientes con fecha SLA</li>`
    : urgentes.map(d => {
        const icon  = d.diff < 0 ? '🔴' : d.diff === 0 ? '🟠' : d.diff <= 3 ? '🟡' : '🟢';
        const label = d.diff < 0 ? `${t('vencido hace') || 'Vencido hace'} ${Math.abs(d.diff)}d`
                    : d.diff === 0 ? `${t('vence hoy') || 'Vence hoy'}`
                    : `${t('vence hoy') || 'Vence en'} ${d.diff}d`;
        const col   = d.diff < 0 ? 'var(--danger)' : d.diff <= 3 ? 'var(--warn)' : 'var(--ok)';
        return `<li class="sla-reco-item">
          <span class="sla-reco-icon">${icon}</span>
          <div class="sla-reco-body">
            <span class="sla-reco-text">${esc(d.text.slice(0,44))}${d.text.length>44?'…':''}</span>
            <span class="sla-reco-date" style="color:${col}">${label} · ${esc(d.sla)}</span>
          </div>
        </li>`;
      }).join('');

  return `<div class="sla-tab-wrap">

    <!-- FILA SUPERIOR: 3 columnas -->
    <div class="sla-three-col">

      <!-- Columna 1: Calendario -->
      <div class="sla-col-cal">
        <p class="sla-section-title" style="display: flex; gap: 5px; align-items: center;"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/calendar.svg" style="width: .6rem; height: .6rem; filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">
          ${t('sla_calendario_titulo') || 'Calendario SLA'}
        </p>
        ${heatmap}
      </div>

      <!-- Columna 2: Donuts 2x2 -->
      <div class="sla-col-donuts">
        <p class="sla-section-title" style="display: flex; gap: 5px; align-items: center;"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/record-circle.svg" style="width: .6rem; height: .6rem; filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">
          ${t('resumen') || 'Resumen'}
        </p>
        <div class="sla-donuts-grid">
          ${summaryRow}
        </div>
      </div>

      <!-- Columna 3: Lista de prioridades -->
      <div class="sla-col-reco">
        <p class="sla-section-title" style="display: flex; gap: 5px align-items:center;"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/lightning.svg" style="width: .6rem; height: .6rem; filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">${t('prioridades')||'Prioridades'}</p>
        <ul class="sla-reco-list">
          ${recoItems}
        </ul>
      </div>

    </div>

    <!-- CARRUSEL de entregables -->
    <p class="sla-section-title" style="display: flex; gap: 5px; align-items: center;">
      <img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/record-circle.svg" style="width: .6rem; height: .6rem; filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">
      ${t('SLA') || 'SLA'}
      <span style="color:var(--soft); font-size:9px">(${deliverables.length})</span>
    </p>
    ${carouselHTML}

  </div>`;
}
