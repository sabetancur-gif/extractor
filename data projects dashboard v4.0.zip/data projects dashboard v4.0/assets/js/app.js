/** Módulo 10 · arranque
  * Responsabilidad: 
    - Inicializar el fondo animado matamático (canvas)
    - Ejecutar el bootstrap del dashboard cuando el DOM esté listo
*/

/**
 * Inicializa el fondo animado basado en símbolos matemáticos.
 * 
 * Características:
 * - Renderizado en canvas HTML5
 * - Animación continua con requestAnimationFrame
 * - Símbolos flotantes con movimiento vertical + oscilación horizontal
 * - Adaptación automática a light/dark theme
 * 
 * Implementado como IIFE para ejecutarse automáticamente
 * sin contaminar el scope global.
*/
(function initMathBg(){
  // Canvas base
  const c = document.getElementById('mbg');
  if(!c) return; // No se ejecuta si jno existe el canvas

  const ctx = c.getContext('2d');

  // Set de símbolos matemáticos usados en la animación
  const SYM = [
    '∑','∫','∂','π','∞','√','Δ','θ','λ','σ','μ','∇','≈','≡','∈','∀','∃','∮',
    'ℝ','ℕ','⊗','⊕','∥','⊥','∧','∨','∇²','f(x)','x²','eˣ','logn','∂²f',
    'det(A)','∫₀¹','Σᵢ','P(B|A)','O(n)','∈ℝⁿ','lim→','∮C','α+β','λₙ','ψ(x)',
    'E[X]','Ax=b','∇f=0','F=ma','E=mc²'
  ];

  // Dimensiones del canvas
  let W = 0, H = 0,
  // Lista de partículas (símbolos)
  items = [],
  // Frame counter global (usando para animación sinusoidal)
  F = 0;

  /**
   * Ajusta el tamaño del canvas al viewport actual
   */
  function resize(){
    W = c.width = window.innerWidth;
    H = c.height = window.innerHeight;
  }

  /**
   * Genera las "partículas" (símbolos)
   * proporcional al tamaño de pantalla.
   * 
   * Cada item tiene:
   * - posicion (x,y)
   * - símbolo
   * - tamaño
   * - velocidad
   * - opacidad
   * - desplazamiento horizontal
   * - fase (para animación orgánica)
   */
  function spawn(){
    items = [];
    // Densidad adaptativa
    const n = Math.floor(W * H / 14000);

    for(let i = 0; i < n; i++){
      items.push({
        x: Math.random() * W,
        y: Math.random() * H,
        s: SYM[Math.floor(Math.random() * SYM.length)],
        sz: 12 + Math.random() * 18,
        sp: .1 + Math.random() * .24,
        op: .4 + Math.random() * .6,
        dr: (Math.random() - .5) * .35,
        ph: Math.random() * Math.PI * 2
      });
    }
  }

  /**
   * Loop principal de animación
   * 
   * - Limpia el canvas
   * - Actualiza posición de cada símbolo
   * - Aplica efectos de oscilación (sin)
   * - Maneja wrapping (cuando sale de pantalla)
   * - Renderiza texto
   */
  function draw(){
    ctx.clearRect(0,0,W,H);
    // Determina el tema actual (oscuro por defecto)
    const dark = document.documentElement.getAttribute('data-theme') !== 'light';

    // Color dinámico según tema
    const col = dark ? '91,189,255' : '20,90,180';

    // Alpha base configurable vía CSS variable
    const base = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--math-alpha')) || 0.11;
    F++; // frame counter

    for(const it of items){
      // Movimiento vertical (subida lenta)
      it.y -= it.sp;
      // Movimiento horizontal oscilante (efecto orgánico)
      it.x += it.dr * Math.sin(F * .012 + it.ph);
      // Reposicionamiento vertical (loop infinito)
      if(it.y < -50){ it.y = H + 20; it.x = Math.random() * W; }

      // Wrap horizontal
      if(it.x < -80) it.x = W + 30;
      if(it.x > W + 80) it.x = -30;

      // Pulsación visual (respiración)
      const pulse = 0.65 + 0.35 * Math.sin(F * .018 + it.ph);
      ctx.save();
      ctx.globalAlpha = base * it.op * pulse;
      ctx.fillStyle = `rgb(${col})`;
      ctx.font = `${it.sz}px 'JetBrains Mono',monospace`;
      ctx.fillText(it.s, it.x, it.y);
      ctx.restore();
    }
    // Loop animado
    requestAnimationFrame(draw);
  }

  // Inicialización
  resize();
  spawn();
  draw();

  // Reacción ante resize (responsivo)
  window.addEventListener('resize', () => { resize(); spawn(); });
})();

/** Inicializa el dashboard principal.
 * Responsabilidad:
 * - ejecutar la función `load()` cuando el DOM este listo
 * - Evitar errores si el script se carga antes del DOM
 * 
 * Usa patrón seguro:
 * - Si DOM aún no está listo, entonces escuchar DOMContendLoaded
 * - Si ya está listo, entonces ejecutar inmediatamente
*/
(function boot(){
  const start = () => {
    // Restaurar sesión si existe (sessionStorage se borra al cerrar pestaña)
    const u = sessionStorage.getItem('dash-user');
    const d = sessionStorage.getItem('dash-dept');
    const a = sessionStorage.getItem('dash-area');
    if (u && d && a) {
      WLC.active = false;
      WLC.user   = u;
      WLC.dept   = d;
      WLC.area   = a;
      if (typeof load === 'function') load();
    } else {
      if (typeof renderWelcome === 'function') renderWelcome();
    }
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
