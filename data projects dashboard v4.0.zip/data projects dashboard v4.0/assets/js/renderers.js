/** Módulo 4 · renderizado de vistas
  * Responsabilidad:
    * - Generar HTML del dashboard ejecutivo
    * - Renderizar tarjetas, pestañas, gráficos y panel de detalle
    * - Montar y destruir instancias de Chart.js
 */

/**
 * Colores base usados en todos los charts del dashboard.
 * Centralizar aquí evita hardcode y facilita cambios de tema. 
 */
const CHART_COLORS = {
  blue:   '#5bbdff',
  green:  '#2ee89a',
  amber:  '#ffb547',
  red:    '#ff5c5c',
  purple: '#b47cff',
  cyan:   '#2de8d0',
  pink:   '#ff6fae',
  indigo: '#6c7cff',
  teal:   '#00bfae',
  lime:   '#a3e635',
  orange: '#ff8a3d',
  slate:  '#64748b',
  gold:   '#facc15',
  magenta:'#d946ef',
};

/**
 * Asigna un color consistente a un nombre
 */
function memberColor(name){
  // Lista de colores disponibles
  const colors = Object.values(CHART_COLORS)

  // Hash simple basado en el nombre (consistente siempre)
  // Inicializa el hash en 0
  let hash = 3381;

  // Recorre cada carácter del string 'name'
  for(let i = 0; i < name.length; i++){
    // Genera un hash usando el código ASCII del carácter
    // (hash << 5) - hash equivale a hash * 31
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  // Devuelve un color basado en el hash:
  // - Math.abs evita valores negativos
  // - % colors.length asegura que el índice sea válido
  return colors[Math.abs(hash) % colors.length];
}

/**
 * Funcion que genera un avatar en HTML
 */
function av(i){
  // Obtiene el color asignado al valor 'i'
  const color = memberColor(i);

  // Retorna un string HTML
  return `<div class="av" 
    style="background:${color}22;color:${color};border:1px solid ${color}" 
    title="${esc(fn(i))}" 
    aria-label="${esc(fn(i))}">
    ${esc(i)}
  </div>`;
}

/**
 * Destruye todas las instancias de gráficos activos.
 * Importante para evitar fugas de memoria al rerenderizar.
 */
function clearCharts(){
  if(window._charts){
    for(const ch of window._charts){
      try{ ch.destroy(); }catch(e){}
    }
    window._charts = [];
  }
}

/**
 * Registra una nueva instancia de Chart.js
 * @param {Chart} ch - Instancia del gráfico 
 */
function regCh(ch){
  if(!window._charts) window._charts = [];
  window._charts.push(ch);
}

/**
 * Estilo de tooltip adaptado al tema actual
 * @returns {Object} configuración Chart.js tooltip
 */
function ttStyle(){
  const dk = isDark();
  return {
    backgroundColor: dk ? '#101c2a' : '#fff',
    titleColor: dk ? '#ddeeff' : '#0a1f35',
    bodyColor: dk ? '#7a9db8' : '#3a6080',
    borderColor: dk ? '#1a2e42' : '#ccdaec',
    borderWidth: 1,
    padding: 10,
    cornerRadius: 8
  };
}

/** Grid común para ejes */
function gridStyle(){
  return { color: isDark() ? 'rgba(26,46,66,.7)' : 'rgba(204,218,236,.5)' };
}

/** Estilo estándar de ticks */
function tickStyle(){
  return { color: isDark() ? '#3d5f7a' : '#8aa8c4', font: { family: "'JetBrains Mono',monospace", size: 10 } };
}

/** Leyenda consistente entre gráficos */
function legendStyle(){
  return {
    display: true,
    position: 'bottom',
    labels: { color: isDark() ? '#7a9db8' : '#3a6080', font: { family: "'JetBrains Mono',monospace", size: 10 }, boxWidth: 10, padding: 12 }
  };
}

/**
 * Genera un SVG tipo donut para distribución ejecutiva
 * No usa canvas. Mejor performance en render inicial
 * 
 * @param {Object} data - Conteo por estado (active, risk, delivered, paused) 
 * @returns {string} SVG como string HTML
 */
function donutSVG(data){
  // Definición de segmentos visibles
  const items = [
    { k:'active', color: CHART_COLORS.green },
    { k:'risk', color: CHART_COLORS.amber },
    { k:'delivered', color: CHART_COLORS.blue },
    { k:'paused', color: '#7a9db8' }
  ];

  // Total con guard clause para evitar div/0
  const total = items.reduce((acc, x) => acc + (data[x.k] || 0), 0) || 1;

  // Parámetros geométricos
  let start = -90;
  const cx = 56, cy = 56, r = 38, sw = 13, circ = 2 * Math.PI * r;

  // Construcción de segmentos SVG 
  const parts = items.filter(x => (data[x.k] || 0) > 0).map(x => {
    const val = data[x.k] || 0;
    const len = circ * val / total;
    const off = circ * (start + 90) / 360;
    const angle = (val / total) * 360;
    const seg = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${x.color}" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${len} ${circ - len}" stroke-dashoffset="${-off}"></circle>`;
    start += angle;

    return seg;
  }).join('');

  const dk = isDark();

  // SVG final
  return `
    <svg viewBox="0 0 112 112" width="106" height="106" aria-label="Distribución ejecutiva">
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${dk ? '#1a2e42' : '#ccdaec'}" stroke-width="${sw}"></circle>
      ${parts}
      <circle cx="${cx}" cy="${cy}" r="24" fill="${dk ? '#0c1520' : '#fff'}"></circle>
      <text x="56" y="53" text-anchor="middle" fill="${dk ? '#ddeeff' : '#0a1f35'}" font-size="17" font-family="'JetBrains Mono',monospace" font-weight="700">${total}</text>
      <text x="56" y="67" text-anchor="middle" fill="#3d5f7a" font-size="8" font-family="'JetBrains Mono',monospace" letter-spacing=".1em">TOTAL</text>
    </svg>`;
}

/**
 * Renderiza el header principal del dashboard.
 * Incluye:
 * - Fecha actual localizada
 * - Título y descripción ejecutiva
 * - KPIs agregados del portafolio
 * - Riesgp promedio ponderado de proyectos
 * @returns {string} HTML del header
 */
function renderHeader(){
  const today = new Date().toLocaleDateString('es-CO', { weekday:'short', day:'numeric', month:'short', year:'numeric' });
  const avgR  = S.projects.length ? Math.round(S.projects.reduce((a,p) => a + riskScore(p), 0) / S.projects.length) : 0;
  const rCol  = avgR >= 60 ? 'var(--danger)' : avgR >= 35 ? 'var(--warn)' : 'var(--ok)';
  const userColor = WLC.user ? memberColor(WLC.user) : 'var(--accent)';

  return `
    <div class="hdr">
      <div>
        <p class="team-tag"><span class="pulse-dot"></span>${t('header_etiqueta')}</p>
        <p class="hdr-title">${t('titulo_principal')}</p>
        <p class="hdr-desc">${t('subtitulo')}</p>
      </div>
      <div class="hdr-right">
        <div class="ctrl-btns">
          <button class="tog tog-theme" onclick="toggleTheme()" aria-label="Cambiar tema">
            <span id="tog-lbl"></span>
          </button>
          <button id="btn-idioma" class="tog tog-lang" onclick="cambiarIdioma()" aria-label="Cambiar idioma"></button>
          ${WLC.user ? `
            <button class="tog tog-user" onclick="wlcLogout()" title="Cerrar sesión · ${esc(MNAMES[WLC.user]||WLC.user)}"
              style="border-color:${userColor};color:${userColor}">
              <span style="font-size:13px;font-weight:800">${esc(WLC.user)}</span>
              <span style="font-size:9px;opacity:.7">✕</span>
            </button>` : ''}
        </div>
        <div class="hdr-meta">
          <div><span style="color:var(--accent);margin-right:8px">${t('sprint_activo')}</span><span>${esc(today)}</span></div>
        </div>
      </div>
    </div>
    <div class="kpis">
      ${execKpis().map(k => `
        <div class="kpi ${k.cls}">
          <div class="kpi-ico">${k.ico}</div>
          <p class="kpi-lbl">${esc(k.l)}</p>
          <p class="kpi-val">${esc(k.v)}<span style="font-size:13px;font-family:var(--mono);color:var(--soft)">${k.u}</span></p>
          <p class="kpi-sub">${esc(k.s)}</p>
        </div>
      `).join('')}
    </div>`;
}

/**
 * Renderiza la fila de analítica ejecutiva:
 * - Distribución de estados (donut SVG)
 * - Carga por miembro
 * - Próximos vencimientos
 * @returns {string} HTML analítico
 */
function renderAnalytics(){
  const counts = statusCounts();  // Conteo por estado
  const mem = memberCounts();     // Asignaciones por miembro

  // Próximos 4 deadlines más cercanos
  const deadlines = [...S.projects].sort((a,b) => daysTo(a.deadline) - daysTo(b.deadline)).slice(0,4);

  const cap = loadVsCapacity(); // Capacidad total vs asignada

  return `
    <div class="an-row">
      <div class="card">
        <p class="card-title"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/bullseye.svg" style="filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg); margin-right: .4rem;">${t('panel_distribucion')}</p>
        <div class="donut-wrap">
          ${donutSVG(counts)}
          <div class="donut-legend">
            <div class="leg"><span class="leg-left"><span class="dot" style="background:${CHART_COLORS.green}"></span>${t('estado_activos')}</span><span>${counts.active || 0}</span></div>
            <div class="leg"><span class="leg-left"><span class="dot" style="background:${CHART_COLORS.amber}"></span>${t('estado_riesgo')}</span><span>${counts.risk || 0}</span></div>
            <div class="leg"><span class="leg-left"><span class="dot" style="background:${CHART_COLORS.blue}"></span>${t('estado_entregados')}</span><span>${counts.delivered || 0}</span></div>
            <div class="leg"><span class="leg-left"><span class="dot" style="background:#7a9db8"></span>${t('estado_pausados')}</span><span>${counts.paused || 0}</span></div>
          </div>
        </div>
      </div>
      <div class="card">
        <p class="card-title"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/people.svg" style="width:1rem;height:1rem;vertical-align:-0.15em;margin-right:.35rem; filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">${t('panel_carga_miembro')}<span style="margin-left:auto;font-size:11px;color:var(--soft)">${cap.assigned}/${cap.cap}</span></p>
        <div class="mbars">
          ${mem.length ? mem.map(([m,c]) => {
            const color = memberColor(m);

            return `
              <div class="mbrow">
                <div class="mblbl">${esc(fn(m).split(' ')[0])}</div>
                <div class="mbtrack">
                  <div class="mbfill" style="
                    width:${Math.max(8, Math.round(c / Math.max(...mem.map(x => x[1]), 1) * 100))}%;
                    background:${color};
                  "></div>
                </div>
                <div class="mbnum">${c}</div>
              </div>
            `;
          }).join('') : '<div style="font-size:12px;color:var(--soft)">Sin asignaciones</div>'}
        </div>
      </div>
      <div class="card">
        <p class="card-title"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/calendar-event.svg" style="width:1rem;height:1rem;margin-right:.4rem;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">${t('panel_proximos')}</p>
        <div class="deadlist">
          ${deadlines.map(p => {
            const d = fmtDate(p.deadline);
            const pr = pct(p);
            return `
              <div class="deaditem">
                <div class="deadtop">
                  <p class="deadname">${esc(p.name.slice(0,44))}${p.name.length > 44 ? '…' : ''}</p>
                  <span class="deadmeta ${d.c}">${esc(d.s)}</span>
                </div>
                <div class="deadprog"><div class="${pbCls(p)} pb" style="width:${pr}%"></div></div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    </div>`;
}

/**
 * Renderiza los contenedores HTML de los gráficos principales.
 * NOTA: no cregráficos, solo canvas.
 */
function renderChartsRow1(){
  return `
    <div class="sec3">
      <div class="card">
        <p class="card-title"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/fire.svg" style="width:14px;height:14px;vertical-align:-2px; filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);">${t('chart_radar_titulo')}</p>
        <div class="chart-wrap" style="height:260px"><canvas id="ch-radar" role="img" aria-label="Radar de riesgo por proyecto"></canvas></div>
      </div>
      <div class="card">
        <p class="card-title"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/graph-up.svg" style="filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg); margin-right:.4rem;">${t('chart_burndown_titulo')}</p>
        <div class="chart-wrap" style="height:260px"><canvas id="ch-burn" role="img" aria-label="Burndown de entregables"></canvas></div>
      </div>
      <div class="card">
        <p class="card-title"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/bar-chart-line.svg" style="filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg); margin-right:.4rem;">${t('chart_estados_titulo')}</p>
        <div class="chart-wrap" style="height:260px"><canvas id="ch-dough" role="img" aria-label="Entregables por estado"></canvas></div>
      </div>
    </div>`;
}

/**
 * Inicializa los gráficos Chart.js de la primera fila analítica.
 * - Radar de riesgo por proyecto
 * - Burndown de entregables
 * - Donut de entregables por estado
 * 
 * Se ejecuta tras el render (requestAnimationFrame).
 * Usa la bandera `_mounted` en cada canvas para evitar recrear gráficos existentes y generar fugas de memoria.
 */
function mountChartsRow1(){
  // Estilos reutilizables dependientes del tema (dark / light)
  const tt = ttStyle();
  const grid = gridStyle();
  const ticks = tickStyle();
  const legend = legendStyle();

  /** Radar de riesgo por royecto
   * Visualiza, por proyecto, los principales factores de riesgo:
   * - Prioridad de negocio
   * - Severidad técnica
   * - Urgencia
   * - Dependencias críticas
   * - Blockers activos (normalizados)
   * - progreso general (normalizado)
   * 
   * Se limita a los primeros 3 proyectos para mantener legibilidad.
   */
  const rCtx = document.getElementById('ch-radar');
  if(rCtx && !rCtx._mounted){
    rCtx._mounted = true;
    const ch = new Chart(rCtx, {
      type: 'radar',
      data: {
        labels: [t('eje_prioridad'), t('eje_severidad'), t('eje_urgencia'), t('eje_dependencia'), t('eje_blockers'), t('eje_progreso')],
        datasets: S.projects.slice(0,3).map((p, i) => ({
          label: `${p.name.slice(0,16)}…`,
          data: [
            p.businessPriority || 0,
            p.technicalSeverity || 0,
            p.urgency || 0,
            p.dependencyCriticality || 0,
            // Blockers limitados a 5 para evitar picos extremos
            Math.min((p.blockers || []).length, 5),
            // Progreso normalizado a escala 0-5
            Math.round(pct(p) / 20)
          ],
          borderColor: [CHART_COLORS.blue, CHART_COLORS.green, CHART_COLORS.amber][i],
          backgroundColor: [CHART_COLORS.blue + '22', CHART_COLORS.green + '22', CHART_COLORS.amber + '22'][i],
          borderWidth: 2,
          pointBackgroundColor: [CHART_COLORS.blue, CHART_COLORS.green, CHART_COLORS.amber][i],
          pointRadius: 4
        }))
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend, tooltip: { ...tt } },
        scales: {
          r: {
            grid: { color: isDark() ? 'rgba(26,46,66,.9)' : 'rgba(204,218,236,.5)' },
            angleLines: { color: isDark() ? 'rgba(26,46,66,.9)' : 'rgba(204,218,236,.5)' },
            ticks: { color: isDark() ? '#3d5f7a' : '#8aa8c4', font: { size: 9 }, backdropColor: 'transparent' },
            pointLabels: { color: isDark() ? '#7a9db8' : '#3a6080', font: { family: "'JetBrains Mono',monospace", size: 10 } },
            min: 0,
            max: 5
          }
        }
      }
    });
    regCh(ch);
  }

  /** Burndown de entregables
   * Compara la curva ideal de quema de entregables
   * contra la curva real basada en entregables completados.
   * 
   * - Ideal: Línea descendente uniforme
   * - Real: progreso observado del equipo
   */
  const bCtx = document.getElementById('ch-burn');
  if(bCtx && !bCtx._mounted){
    bCtx._mounted = true;

    // Total de entregables del portafolio (guard clause incluida)
    const totalD = S.projects.flatMap(p => p.deliverables || []).length || 1;
    // Entregables marcados como completados
    const doneD = S.projects.flatMap(p => p.deliverables || []).filter(d => d.done).length;
    // Etiquetas temporales simuladas (sprints / semanas)
    const labels = ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4', 'Sem 5', 'Sem 6', 'Actual'];
    // Curva ideal: disminución lineal
    const ideal = labels.map((_, i) => Math.round(totalD - (totalD / 6) * i));
    // Curva real: aproximación basada en progreso actual
    const actual = [
      totalD,
      ...Array(5).fill(null).map((_, i) => Math.max(0, totalD - Math.round(doneD / 2 * (i / 4)))),
      totalD - doneD
    ];
    const ch = new Chart(bCtx, {
      type: 'line',
      data: {
        labels,
        datasets: [
          { label: 'Ideal', data: ideal, borderColor: CHART_COLORS.blue + '88', borderDash: [6,3], borderWidth: 1.5, pointRadius: 0, fill: false },
          { label: 'Real', data: actual, borderColor: CHART_COLORS.green, backgroundColor: CHART_COLORS.green + '18', borderWidth: 2.5, pointBackgroundColor: CHART_COLORS.green, pointRadius: 4, fill: true, tension: .3 }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend, tooltip: { ...tt } },
        scales: {
          x: { grid, ticks },
          y: { grid, ticks, title: { display: true, text: 'Pendientes', color: isDark() ? '#3d5f7a' : '#8aa8c4', font: { size: 10 } } }
        }
      }
    });
    regCh(ch);
  }

  /** Donut de entregables por estado
   * Muestra la distribución actual:
   * - Completados
   * - Pendientes
   * - Vencidos
   */
  const dCtx = document.getElementById('ch-dough');
  if(dCtx && !dCtx._mounted){
    dCtx._mounted = true;
    const { completed, pending, overdue } = deliverableStatusCounts();
    const dk = isDark();
    const ch = new Chart(dCtx, {
      type: 'doughnut',
      data: {
        labels: [t('chart_completados'), t('chart_pendientes'), t('chart_vencidos')],
        datasets: [{ data: [completed, pending, overdue], backgroundColor: [CHART_COLORS.green + 'cc', CHART_COLORS.blue + 'cc', CHART_COLORS.red + 'cc'], borderColor: dk ? '#0c1520' : '#fff', borderWidth: 3, hoverOffset: 6 }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        plugins: { legend: legendStyle(), tooltip: { ...ttStyle() } }
      }
    });
    regCh(ch);
  }
}
