/**  Módulo 6 · Dashboard principal
 * Responsabilidad:
 *  - Render del dashboard principal: tarjetas, detalle y formulario
 */

/** Renderiza el panel global de blockers activos del portafolio.
 * - Consolida blockers de todos los proyectos NO entregados
 * - Distingue entre críticos y medios
 * - Permite navegación directa al proyecto afectado
 * - Se muestra como sección colapsable para no saturar la vista
 * 
 * @returns {string} HTML del panel del blockers o string vacío si no hay blockers
 */
function renderBlockers(){
  // Recolecta todos los blockers de proyectos activos / en riesgo / pausados
  // Se enriquece cada blocker con nombre e id del proyecto 
  const all = S.projects
    .filter(p => p.status !== 'delivered')
    .flatMap(p => (p.blockers || []).map(b => ({ ...b, proj: p.name, projId: p.id })));

  // Si no hay blockers activos, no se renderiza la sección
  if(!all.length) return '';

  // Clasificación por severidad
  const crits = all.filter(b => b.severity === 'crit');
  const meds = all.filter(b => b.severity !== 'crit');

  return `
    <div class="sec-full">
      <details class="card collapsible" open>
        <summary>
          <div class="collapsible-head">
            <div class="collapsible-title">
              <span style="display:inline-flex;align-items:center;"><img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/cone-striped.svg" style="width:16px;height:16px;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);"alt="En progreso"></span>
              <span>${t('blockers_titulo')}</span>
              <span style="font-size:10px;padding:3px 9px;border-radius:999px;background:rgba(255,92,92,.12);color:var(--danger);border:1px solid rgba(255,92,92,.2)">${crits.length} ${t('blockers_criticos')}</span>
              <span style="font-size:10px;padding:3px 9px;border-radius:999px;background:rgba(255,181,71,.1);color:var(--warn);border:1px solid rgba(255,181,71,.2)">${meds.length} ${t('blockers_medios')}</span>
            </div>
            <span class="collapse-arrow" style="font-family:var(--mono);color:var(--soft)">▾</span>
          </div>
        </summary>
        <div class="collapsible-body">
          <div class="blocker-grid">
            ${
              // Renderizado de cada blocker como tarjeta clicable
              all.map(b => `
              <div class="blocker-item ${b.severity !== 'crit' ? 'warn-blk' : ''}" onclick="pick('${esc(b.projId)}')">
                <div class="bl-top">
                  <p class="bl-name">${esc(b.text)}</p>
                  <span class="bl-badge ${b.severity === 'crit' ? 'crit' : 'med'}">${b.severity === 'crit' ? t('badge_critico') : t('badge_medio')}</span>
                </div>
                <p class="bl-proj">↗ ${esc(b.proj.slice(0,58))}${b.proj.length > 58 ? '…' : ''}</p>
              </div>
            `).join('')}
          </div>
        </div>
      </details>
    </div>`;
}

/** Renderiza la tarjeta resumida de un proyecto en la grilla principal.
 * La tarjeta muestra información clave de estado:
 * - Nombre, descripción y estado actual
 * - Progreso visual y fecha límite 
 * - Stack tecnológico
 * - Blockers relevantes
 * - Métricas rápidas (risk score, notas, blockers)
 * 
 * La tarjeta es clicable y permite seleccionar el proyecto
 * para mostrar el panel de detalle.
 * 
 * @param {Object} p - Proyecto a renderizar
 * @returns {string} HTML de la tarjeta del proyecto
 */
function renderCard(p){
  // Fecha de deadline formateada y clasificada visualmente
  const dl = fmtDate(p.deadline);
  // Porcentaje de avance calculado a partir de entregables
  const pc = pct(p);
  // Indica si la tarjeta Corresponde al proyecto actualmente seleccionado
  const sel = S.sel === p.id;
  // Risk score agregado del proyecto (0-100)
  const rs = riskScore(p);

  /** Renderizado compacto de blockers
   * - Se muestran máximo 2
   * - El resto se resume con un contador
   * - Diferente color según severidad
   */
  const blkHtml = (p.blockers || []).length ? `
    <div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:11px">
      ${
        // Primeros dos blockers visibles
        (p.blockers || []).slice(0,2).map(b => `
        <span style="font-size:10px;font-family:var(--mono);padding:3px 8px;border-radius:999px;background:rgba(255,${b.severity === 'crit' ? '92,92' : '181,71'},.1);color:var(--${b.severity === 'crit' ? 'danger' : 'warn'});border:1px solid rgba(255,${b.severity === 'crit' ? '92,92' : '181,71'},.2)">⚠ ${esc(b.text.slice(0,28))}${b.text.length > 28 ? '…' : ''}</span>
      `).join('')}
      ${
        // Indicador de blockers adicionales no visibles
        (p.blockers || []).length > 2 ? `<span style="font-size:10px;font-family:var(--mono);padding:3px 8px;border-radius:999px;color:var(--soft)">+${(p.blockers || []).length - 2} más</span>` : ''}
    </div>` : '';

  return `
    <div class="pcard${sel ? ' sel' : ''}" onclick="pick('${p.id}')">
      <div class="pc-top"><p class="pc-name">${esc(p.name)}</p>${sbadge(p.status)}</div>
      <p class="pc-desc">${esc(p.description.slice(0,100))}${p.description.length > 100 ? '…' : ''}</p>
      <div class="tech-row">${(p.tech || []).map(t => `<span class="tt">${esc(t)}</span>`).join('')}</div>
      <div class="prog-bar"><div class="${pbCls(p)} pb" style="width:${pc}%"></div></div>
      <div class="pc-meta"><span class="dl ${dl.c}">${esc(dl.s)}</span><span style="font-size:11px;color:var(--soft);font-family:var(--mono)">${pc}%</span></div>
      ${blkHtml}
      <div class="pc-foot">
        <div class="avs">${(p.assignees || []).map(a => av(a)).join('')}</div>
        <div class="pill-row"><span class="rpill ${riskCls(rs)}">RS ${rs}</span><span class="rpill">${(p.comments || []).length} ${t('label_notas')}</span><span class="rpill">${(p.blockers || []).length} ${t('label_blockers')}</span></div>
      </div>
    </div>`;
}

/** Renderiza la pestaña ejecutiva del detalle del proyecto.
 * 
 * Está pensada para stakeholders y toma de decisiones rápidas.
 * Resume:
 * - Progreso general
 * - Risk score y factores que lo componen
 * - Fechas clave (deadline, SLA, enntrega real)
 * - Capacidad, blockers y dependencias
 * 
 * @param {Object} p - Proyecto seleccionado
 * @returns {string} HTML de la vista ejecutiva
 */
function tabExec(p){
  // Risk score agregado del proyecto
  const rs = riskScore(p);
  return `
    <div class="exec-grid">
      <div class="mcard">
        <p class="mcard-title">${t('Resumen general')}</p>
        <p class="mcard-val">${pct(p)}<span>% ${t('avance')}</span></p>
        <p class="mcard-desc">${riskLabel(rs)} · ${t('combinación de prioridad, severidad, urgencia, dependencias, blockers y vencimiento.')}</p>
        <div class="badge-stack">
          <span class="rpill ${riskCls(rs)}">RS ${rs}</span>
          <span class="rpill">${Math.max(0, daysTo(p.deadline))}d ${t('para deadline')}</span>
          <span class="rpill">${p.deliverables.filter(d => d.done).length}/${p.deliverables.length} ${t('entregables')}</span>
        </div>
        <div class="mrows">
          <div class="mrow"><span>${t('Estado')}</span>${sbadge(p.status)}</div>
          <div class="mrow"><span>${t('Deadline')}</span><strong>${esc(fmtDate(p.deadline).s)}</strong></div>
          <div class="mrow"><span>${t('SLA comprometido')}</span><strong>${esc(p.committedAt || t('nd'))}</strong></div>
          <div class="mrow"><span>${t('Entrega real')}</span><strong>${esc(p.actualAt || t('entregable_pendiente'))}</strong></div>
        </div>
      </div>
      <div class="mcard">
        <p class="mcard-title">${t('Factor de riesgo')}</p>
        <div class="score-bars">
          ${[
            [t('Prioridad negocio'), p.businessPriority || 0, 5],
            [t('Severidad técnica'), p.technicalSeverity || 0, 5],
            [t('Urgencia'), p.urgency || 0, 5],
            [t('Dependencia crítica'), p.dependencyCriticality || 0, 5]
          ].map(([lbl, val, max]) => `
            <div class="sbar-row">
              <div class="sbar-lbl">${lbl}</div>
              <div class="sbar-track"><div class="sbar-fill" style="width:${Math.round((val / max) * 100)}%;background:linear-gradient(90deg,var(--accent),var(--purple))"></div></div>
              <div class="sbar-num">${val}</div>
            </div>
          `).join('')}
        </div>
      </div>
      <div class="mcard">
        <p class="mcard-title">${t('Capacidad y bloqueo')}</p>
        <p class="mcard-val">${(p.blockers || []).length}<span> ${t('label_blockers')}</span></p>
        <p class="mcard-desc">${t('Blockers activos, dependencias y señales de riesgo operativo para priorizar decisiones.')}</p>
        <div class="mrows">
          <div class="mrow"><span>${t('Miembros')}</span><strong>${(p.assignees || []).map(a => fn(a)).join(', ')}</strong></div>
          <div class="mrow"><span>${t('Tech')}</span><strong>${(p.tech || []).join(', ')}</strong></div>
          <div class="mrow"><span>${t('Dependencias')}</span><strong>${(p.dependencies || []).join(', ') || t('Ninguna')}</strong></div>
        </div>
      </div>
    </div>`;
}

function tabDelivs(p){
  /**
   * Renderiza la pestaña de entregables de un proyecto.
   * 
   * Permite:
   * - Ver el estado global (completados / pendientes / vencidos)
   * - Marcar entregables como completados
   * - Consultar detalle de cada entregable (SLA, responsable, notas)
   * - Añadir nuevos entregables rápidamente
   * 
   * @param {Object} p -Proyecto seleccionado
   * @returns {string} HTML de la pestaña de entregables
   */
  const done = p.deliverables.filter(d => d.done).length;
  const total = p.deliverables.length;
  return `
    <div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap">
      <div style="background:rgba(46,232,154,.08);border:1px solid rgba(46,232,154,.2);padding:8px 11px;border-radius:999px;font-family:var(--mono);font-size:11px;color:var(--ok)">${done} ${t('chart_completados').toLowerCase()}</div>
      <div style="background:rgba(91,189,255,.08);border:1px solid rgba(91,189,255,.2);padding:8px 11px;border-radius:999px;font-family:var(--mono);font-size:11px;color:var(--info)">${total - done} ${t('chart_pendientes').toLowerCase()}</div>
      <div style="background:rgba(255,181,71,.08);border:1px solid rgba(255,181,71,.2);padding:8px 11px;border-radius:999px;font-family:var(--mono);font-size:11px;color:var(--warn)">${p.deliverables.filter(d => !d.done && d.sla && daysTo(d.sla) < 0).length} ${t('chart_vencidos').toLowerCase()}</div>
    </div>
    <div style="display:grid;gap:9px">
      ${p.deliverables.map(d => {
        const sl = d.sla ? fmtDate(d.sla) : { s:t('sin_sla'), c:'' };
        const ddlClass = d.done ? 'soon' : (daysTo(d.sla) < 0 ? 'past' : '');
        return `
          <details class="deliv-item">
            <summary class="deliv-sum">
              <input type="checkbox" ${d.done ? 'checked' : ''} onclick="event.stopPropagation()" onchange="toggleD('${p.id}','${d.id}')">
              <div class="deliv-main">
                <span class="dt ${d.done ? 'done' : ''}">${esc(d.text)}</span>
                <div class="dhint">${d.done ? t('entregable_completado') : t('entregable_pendiente')} · ${t('responsable').toLowerCase()} ${esc(fn(d.owner || ''))}</div>
              </div>
              <span class="darrow">▾</span>
            </summary>
            <div class="dextra">
              <div class="kv"><span class="kv-k">${t('responsable')}</span><span>${esc(d.owner ? fn(d.owner) : t('sin_definir'))}</span></div>
              <div class="kv"><span class="kv-k">${t('objetivo')}</span><span>${esc(d.goal || t('no_definido'))}</span></div>
              <div class="kv"><span class="kv-k">${t('criterio')}</span><span>${esc(d.criteria || t('no_definido'))}</span></div>
              <div class="kv"><span class="kv-k">${t('notas')}</span><span>${esc(d.notes || t('sin_notas'))}</span></div>
              <div class="kv"><span class="kv-k">SLA</span><span class="${ddlClass}">${esc(sl.s || t('nd'))}</span></div>
              <div class="kv"><span class="kv-k">${t('compromiso')}</span><span>${esc(d.committed || t('nd'))}</span></div>
              <div class="kv"><span class="kv-k">${t('real')}</span><span>${esc(d.actual || t('nd'))}</span></div>
            </div>
          </details>
        `;
      }).join('')}
      <div style="margin-top:12px">
        <input id="nd" placeholder="${t('agregar_entregable')}" onkeydown="if(event.key==='Enter')addDel('${p.id}')">
      </div>
    </div>`;
}

/** Renderiza la pestaña de comentarios del proyecto.
 * 
 * Muestra:
 * - Historial de comentarios
 * - Autor y fecha
 * - Input para añadir nuevos comentarios
 * 
 * @param {Object} p - Proyecto seleccionado
 * @returns {string} HTML de la pestaña de comentarios
 */
function tabComments(p){
  return `
    ${p.comments.length ? p.comments.map(c => `
      <div class="cmt">
        <div class="cmt-hd"><span class="cmt-a">${esc(c.author)}</span><span class="cmt-d">${esc(c.date)}</span></div>
        <p class="cmt-t">${esc(c.text)}</p>
      </div>
    `).join('') : '<p style="font-size:12px;color:var(--soft);font-family:var(--mono)">' + t('sin_comentarios') + '</p>'}
    <div class="add-cmt">
      <input id="nc" placeholder="${t('anadir_comentario')}" onkeydown="if(event.key==='Enter')addCmt('${p.id}')">
      <button class="btn-p" onclick="addCmt('${p.id}')">${t('enviar')}</button>
    </div>`;
}

/** Renderiza la pestaña de timeline del proyecto.
 * 
 * Renderiza la pestaña de timeline del proyecto.
 *
 * Combina tres vistas complementarias:
 * 1. Gantt simplificado para distribución temporal de hitos
 * 2. Timeline visual animado
 * 3. Panel lateral con historial y actividad reciente
 *
 * El objetivo es dar contexto temporal completo del proyecto
 * (planificado + ejecutado + eventos humanos).
 *
 * @param {Object} p - Proyecto seleccionado
 * @returns {string} HTML del timeline
*/
function tabTimeline(p){
  const tl = p.timeline || [];
  // Si no hay hitos definidos, se informa explícitamente
  if(!tl.length) return `<div class="empty">${t('sin_hitos')}</div>`;

  // Normalización temporal para cálculo de posiciones
  const dates = tl.map(t => new Date(t.date)).filter(d => isVD(d));
  const minD = dates.length ? Math.min(...dates) : Date.now();
  const maxD = dates.length ? Math.max(...dates, Date.now()) : Date.now();
  const rng = (maxD - minD) || 1;
  // Paleta rotativa para diferenciar nodos temporalmente
  const nodeColors = [CHART_COLORS.blue, CHART_COLORS.green, CHART_COLORS.amber, CHART_COLORS.purple, CHART_COLORS.cyan, CHART_COLORS.red];
  
  // Gantt simplificado
  const ganttRows = tl.map((t, i) => {
    const d = new Date(t.date);
    // Posicion horizontal (0-85%) según fecha relativa
    const pos = isVD(d) ? Math.round((d - minD) / rng * 85) : 0;
    // Ancho estimado hasta el siguiente hito o mínimo visual
    const w = Math.max(10, i < tl.length - 1 ? Math.round(((new Date(tl[i + 1].date)) - d) / rng * 75) : 12);
    const c = nodeColors[i % nodeColors.length];
    return `<div class="gantt-row"><div class="gantt-lbl">${esc(t.title.slice(0,11))}…</div><div class="gantt-track"><div class="gantt-bar" style="left:${pos}%;width:${Math.min(w,100-pos)}%;background:${c}22;border-left:3px solid ${c}"><span class="gantt-bar-txt">${esc(t.date.slice(5))}</span></div></div></div>`;
  }).join('');

  /** Timeline visual animado
   * Representa eventos como nodos consecutivos con animaciones secuencial.
   */
  const items = tl.map((t, i) => {
    const c = nodeColors[i % nodeColors.length];
    return `<div class="tl-item" style="animation-delay:${i * .08}s"><div class="tl-node" style="background:${c}20;border-color:${c}"><div class="tl-dot-inner" style="background:${c}"></div></div><div class="tl-box"><div class="tl-bhead"><p class="tl-bname">${esc(t.title)}</p><span class="tl-date">${esc(t.date)}</span></div><p class="tl-bdesc">${esc(t.desc)}</p></div></div>`;
  }).join('');
  return `
    <div class="gantt-wrap"><p class="gantt-title">${t('distribucion_temporal')}</p>${ganttRows}</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="tl-wrap"><div class="tl-axis"></div>${items}</div>
      <div>
        <p style="font-size:10px;font-family:var(--mono);color:var(--soft);text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px">${t('historial')}</p>
        <div style="display:grid;gap:9px">${(p.history || []).map(h => `
          <div style="border:1px solid var(--line);border-radius:var(--rsm);background:var(--s2);padding:11px 13px">
            <div style="display:flex;justify-content:space-between;gap:8px;margin-bottom:5px"><p style="font-size:12px;font-weight:600;color:var(--text)">${esc(h.action)}</p><span style="font-size:10px;font-family:var(--mono);color:var(--soft);white-space:nowrap">${esc(h.date)}</span></div>
            <p style="font-size:11px;color:var(--muted);line-height:1.4"><strong>${esc(h.author)}</strong> · ${esc(h.detail)}</p>
          </div>
        `).join('') || '<p style="font-size:12px;color:var(--soft)">' + t('sin_historial') + '</p>'}</div>
        <p style="font-size:10px;font-family:var(--mono);color:var(--soft);text-transform:uppercase;letter-spacing:.08em;margin:14px 0 10px">${t('actividad_reciente')}</p>
        <div style="display:grid;gap:9px">${(p.recentActivity || []).map(r => `
          <div style="border:1px solid var(--line);border-radius:var(--rsm);background:var(--s2);padding:11px 13px">
            <div style="display:flex;justify-content:space-between;gap:8px;margin-bottom:5px"><p style="font-size:12px;font-weight:600;color:var(--text)">${esc(r.author)}</p><span style="font-size:10px;font-family:var(--mono);color:var(--soft)">${esc(r.date)}</span></div>
            <p style="font-size:11px;color:var(--muted)">${esc(r.text)}</p>
          </div>
        `).join('') || '<p style="font-size:12px;color:var(--soft)">' + t('sin_actividad') + '</p>'}</div>
      </div>
    </div>`;
}

/** Renderiza la pestaña de información general del proyecto.
 * Se organiza en acordeones para agrupar:
 * - Resumen del estado y alertas
 * - Equipo y stack tecnológico
 * - Información de gestión (comentarios, blockers, acciones)
 * 
 * @param {Object} p - Proyecto seleccionado 
 * @returns {string} HTML de la pestaña de información
 */
function tabInfo(p){
  // Proyecto vencido si la fecha límite ya pasó
  const ov = daysTo(p.deadline) < 0;
  // Proyecto en ventana crítica (<= 7 días)
  const near = daysTo(p.deadline) >= 0 && daysTo(p.deadline) <= 7;
  return `
    <details class="acc" open>
      <summary>${t('Resumen general')}</summary>
      <div class="acc-body">
        <div class="kv"><span class="kv-k">${t('info_estado')}</span>${sbadge(p.status)}</div>
        <div class="kv"><span class="kv-k">${t('info_progreso')}</span><span>${pct(p)}% (${p.deliverables.filter(d => d.done).length}/${p.deliverables.length})</span></div>
        <div class="kv"><span class="kv-k">${t('info_deadline')}</span><span style="font-family:var(--mono)">${esc(p.deadline)}</span></div>
        <div class="kv"><span class="kv-k">${t('info_alerta')}</span><span style="color:${ov ? 'var(--danger)' : near ? 'var(--warn)' : 'var(--ok)'}">${ov ? t('info_vencido') : near ? t('info_proximo') : t('info_ok')}</span></div>
        <div class="kv"><span class="kv-k">${t('info_riesgo')}</span><span>${riskScore(p)} · ${riskLabel(riskScore(p))}</span></div>
      </div>
    </details>
    <details class="acc">
      <summary>${t('info_equipo')}</summary>
      <div class="acc-body">
        <div class="kv"><span class="kv-k">${t('info_miembros')}</span><span>${(p.assignees || []).map(a => fn(a)).join(', ')}</span></div>
        <div class="kv"><span class="kv-k">${t('info_tech')}</span><div style="display:flex;gap:5px;flex-wrap:wrap">${(p.tech || []).map(t => `<span class="tt">${esc(t)}</span>`).join('')}</div></div>
      </div>
    </details>
    <details class="acc">
      <summary>${t('gestion')}</summary>
      <div class="acc-body">
        <div class="kv"><span class="kv-k">${t('Comentarios')}</span><span>${p.comments.length}</span></div>
        <div class="kv"><span class="kv-k">${t('Blockers')}</span><span style="color:${(p.blockers || []).length ? 'var(--danger)' : 'var(--ok)'}">${(p.blockers || []).length}</span></div>
        <div class="kv"><span class="kv-k">${t('Dependencias')}</span><span>${(p.dependencies || []).join(', ') || t('blocker_ninguno')}</span></div>
        <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
          <button class="btn-p" onclick="editP('${p.id}')">${t('editar_proyecto')}</button>
          <button class="btn-s btn-d" onclick="delP('${p.id}')">${t('eliminar_proyecto')}</button>
        </div>
      </div>
    </details>`;
}

/** Renderiza el panel lateral de detalle del proyecto  seleccionado.
 * Incluye:
 * - Header con nombre, descripción y estado
 * - Navegación por pestañas
 * - Contenido dinámico según la pestaña activa
 * 
 * Si no hay proyecto seleccionado, no renderiza nada.
 * 
 * @returns {string} HTML del panel de detalle
*/
function renderDetail(){
  // Proyecto actualmente seleccionado
  const p = S.projects.find(x => x.id === S.sel);
  if(!p) return '';

  // DEfinición centralizada de pestañas
  const tabs = [
    ['executive', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/bullseye.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('Ejecutivo')}"> ${t('Ejecutivo')}`],
    ['deliverables', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/box-seam.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('Entregables')}"> ${t('Entregables')}`],
    ['timeline', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/calendar.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('Timeline')}"> ${t('Timeline')}`],
    ['blockers', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/cone-striped.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('Blockers')}"> ${t('Blockers')}`],
    ['comments', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/chat-dots.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('Comentarios')}"> ${t('Comentarios')}`],
    ['sla', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/list-check.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('SLA')}"> ${t('SLA')}`],
    ['info', `<img src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/icons/info-circle.svg" style="width:10px;height:10px;vertical-align:middle;margin-right:6px;display:inline-block;filter: invert(43%) sepia(92%) saturate(464%) hue-rotate(178deg);" alt="${t('Info')}"> ${t('Info')}`]
  ];

  // Resolución del cpntenido según la pestaña activa
  let body = '';
  if(S.tab === 'executive') body = tabExec(p);
  else if(S.tab === 'deliverables') body = tabDelivs(p);
  else if(S.tab === 'timeline') body = tabTimeline(p);
  else if(S.tab === 'blockers') body = tabBlockers(p);
  else if(S.tab === 'comments') body = tabComments(p);
  else if(S.tab === 'sla') body = tabSla(p);
  else body = tabInfo(p);

  return `
    <div class="detail">
      <div class="dp-hdr">
        <div style="flex:1;min-width:0">
          <p class="dp-title">${esc(p.name)}</p>
          <p class="dp-sub">${esc(p.description.slice(0,130))}${p.description.length > 130 ? '…' : ''}</p>
        </div>
        <div style="display:flex;gap:8px;align-items:center;flex-shrink:0">${sbadge(p.status)}<button onclick="pick(null)" class="tiny-btn">✕</button></div>
      </div>
      <div class="dp-tabs">
        ${tabs.map(([k,l]) => `<div class="dpt ${S.tab === k ? 'on' : ''}" onclick="setTab('${k}')">${l}</div>`).join('')}
      </div>
      ${body}
    </div>`;
}

/** Renderiza la pestaña de blockers de un proyecto específico.
 * 
 * Clasifica los blockers en:
 * - Críticos: impacto directo en producción/entrega
 * - Medios: impacto en velocidad/calidad
 * 
 * Adicionalmente muestra:
 * - Dependencias externas del proyecto
 * 
 * @param {Object} p - Proyecto seleccionado
 * @returns {string} HTML de la pestaña de blockers 
 */
function tabBlockers(p){
  // Separación por severidad
  const crit = (p.blockers || []).filter(b => b.severity === 'crit');
  const med = (p.blockers || []).filter(b => b.severity !== 'crit');
  return `
    <p style="font-size:10px;font-family:var(--mono);color:var(--danger);text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px">${t('blocker_critico_titulo')}</p>
    <div class="blocker-grid">
      ${crit.map(b => `<div class="blocker-item"><div class="bl-top"><p class="bl-name">${esc(b.text)}</p><span class="bl-badge crit">${t('blocker_critico_badge')}</span></div><p class="bl-proj">${t('blocker_impacto_critico')}</p></div>`).join('') || '<p style="font-size:12px;color:var(--soft)">' + t('blocker_ninguno') + '</p>'}
    </div>
    <p style="font-size:10px;font-family:var(--mono);color:var(--warn);text-transform:uppercase;letter-spacing:.08em;margin:16px 0 10px">${t('blocker_medio_titulo')}</p>
    <div class="blocker-grid">
      ${med.map(b => `<div class="blocker-item warn-blk"><div class="bl-top"><p class="bl-name">${esc(b.text)}</p><span class="bl-badge med">${t('blocker_medio_badge')}</span></div><p class="bl-proj">${t('blocker_impacto_medio')}</p></div>`).join('') || '<p style="font-size:12px;color:var(--soft)">' + t('blocker_ninguno') + '</p>'}
    </div>
    <p style="font-size:10px;font-family:var(--mono);color:var(--soft);text-transform:uppercase;letter-spacing:.08em;margin:16px 0 10px">${t('blocker_dependencias')}</p>
    <div style="display:flex;gap:7px;flex-wrap:wrap">${(p.dependencies || []).map(d => `<span style="font-size:11px;font-family:var(--mono);padding:5px 12px;border-radius:999px;background:rgba(180,124,255,.1);border:1px solid rgba(180,124,255,.2);color:var(--purple)">${esc(d)}</span>`).join('') || '<span style="font-size:12px;color:var(--soft)">' + t('blocker_sin_dependencias') + '</span>'}</div>`;
}

/** Renderiza el formulario de creación o edición de proyectos.
 * 
 * Comportamiento:
 * - Si S.showForm = false, entonces no renderiza
 * - Si S.editId existe, entonces modo edición
 * - Si no, entonces modo creación
 * 
 * Soporta edición completa de:
 * - Metadata del proyecto
 * - Factores de riesgo
 * - Fechas
 * - Equipo
 * - Stack
 * - Blockers, dependencias y entregables
 * 
 * @returns {string} HTML del formulario o vacío
 */
function renderForm(){
  // Si el formulario está ocsulto, no0 se renderiza
  if(!S.showForm) return '';

  // Proyecto en edición (si existe)
  const ed = S.editId ? S.projects.find(p => p.id === S.editId) : null;

  // Estado actual del formulario
  const f = S.form || {};
  return `
    <div class="fs">
      <p style="font-size:11px;font-family:var(--mono);text-transform:uppercase;letter-spacing:.08em;color:var(--accent);margin-bottom:18px">${ed ? t('form_editar_modo') : t('form_nuevo_modo')}</p>
      <div class="fg">
        <div class="full"><label class="flabel">${t('form_nombre')}</label><input id="fn" value="${esc(f.name || '')}" placeholder="${t('form_nombre_placeholder')}"></div>
        <div class="full"><label class="flabel">${t('form_descripcion')}</label><textarea id="fd" placeholder="${t('form_descripcion_placeholder')}">${esc(f.description || '')}</textarea></div>
        <div><label class="flabel">${t('form_estado')}</label><select id="fst"><option value="active" ${(f.status || 'active') === 'active' ? 'selected' : ''}>${t('form_estado_activo')}</option><option value="risk" ${f.status === 'risk' ? 'selected' : ''}>${t('form_estado_riesgo')}</option><option value="delivered" ${f.status === 'delivered' ? 'selected' : ''}>${t('form_estado_entregado')}</option><option value="paused" ${f.status === 'paused' ? 'selected' : ''}>${t('form_estado_pausado')}</option></select></div>
        <div><label class="flabel">${t('form_prioridad_negocio')}</label><select id="fbp">${[5,4,3,2,1].map(n => `<option value="${n}" ${String(f.businessPriority || 3) === String(n) ? 'selected' : ''}>${n}/5</option>`).join('')}</select></div>
        <div><label class="flabel">${t('form_severidad_tecnica')}</label><select id="fts">${[5,4,3,2,1].map(n => `<option value="${n}" ${String(f.technicalSeverity || 3) === String(n) ? 'selected' : ''}>${n}/5</option>`).join('')}</select></div>
        <div><label class="flabel">${t('form_urgencia')}</label><select id="fur">${[5,4,3,2,1].map(n => `<option value="${n}" ${String(f.urgency || 3) === String(n) ? 'selected' : ''}>${n}/5</option>`).join('')}</select></div>
        <div><label class="flabel">${t('form_dependencia_critica')}</label><select id="fdc">${[5,4,3,2,1].map(n => `<option value="${n}" ${String(f.dependencyCriticality || 3) === String(n) ? 'selected' : ''}>${n}/5</option>`).join('')}</select></div>
        <div><label class="flabel">${t('form_fecha_entrega')}</label><input type="date" id="fdl" value="${esc(f.deadline || '')}"></div>
        <div><label class="flabel">${t('form_sla_comprometido')}</label><input type="date" id="fca" value="${esc(f.committedAt || '')}"></div>
        <div><label class="flabel">${t('form_fecha_real')}</label><input type="date" id="fra" value="${esc(f.actualAt || '')}"></div>
        <div><label class="flabel">${t('form_miembros')}</label><input id="fass" value="${esc(f.assignees || '')}" placeholder="${t('form_miembros_placeholder')}"></div>
        <div class="full"><label class="flabel">${t('form_tech_stack')}</label><input id="ftc" value="${esc(f.tech || '')}" placeholder="${t('form_tech_stack_placeholder')}"></div>
        <div class="full"><label class="flabel">${t('form_blockers')}</label><textarea id="fblk" placeholder="${t('form_blockers_placeholder')}">${esc(f.blockers || '')}</textarea></div>
        <div class="full"><label class="flabel">${t('form_dependencias')}</label><textarea id="fdep" placeholder="${t('form_dependencias_placeholder')}">${esc(f.dependencies || '')}</textarea></div>
        <div class="full"><label class="flabel">${t('form_entregables')}</label><textarea id="fdels" placeholder="${t('form_entregables_placeholder')}">${esc(f.deliverables || '')}</textarea></div>
      </div>
      <div class="fa">
        <button class="btn-s" onclick="cancelF()">${t('form_cancelar')}</button>
        <button class="btn-p" onclick="saveP()">${ed ? t('form_guardar_cambios') : t('form_crear_proyecto')}</button>
      </div>
    </div>`;
}

/**
 * Renderiza las tarjetas en un carrusel tipo coverflow.
 * @param {Array} projects - Lista de proyectos filtrados
 */
function renderCarousel(projects) {
  if (!projects.length) return `<div class="cflow-empty">// no hay proyectos en esta vista</div>`;

  const cards = projects.map(renderCard).join('');
  const dots  = projects.map((_, i) =>
    `<div class="cflow-dot${i === S.cflowIdx ? ' active' : ''}" onclick="cflowGoto(${i})"></div>`
  ).join('');

  return `
    <div class="cflow-wrap">
      <button class="cflow-btn prev" onclick="cflowPrev()" aria-label="Anterior">&#8249;</button>
      <div class="cflow-track">
        <div class="cflow-inner" id="cflow-inner">${cards}</div>
      </div>
      <button class="cflow-btn next" onclick="cflowNext()" aria-label="Siguiente">&#8250;</button>
    </div>
    <div class="cflow-dots" id="cflow-dots">${dots}</div>
  `;
}

/** Función principal de render del dashboard.
 * Responsabilidades:
 * - Limpiar gráficos existentes
 * - Filtrar Proyectos según el estado activo
 * - Renderizar todas las secciones principales:
 *   Header, analytics, charts, blockers, form, grid y detalle
 * - Montar gráficos despues del render (next frame)
 * 
 * Es el punto central de actualizacion del UI.
*/
function render(){
  clearCharts();

  const fil = S.projects.filter(p => {
    const statusOk = S.filter === 'all' || p.status === S.filter;
    if (S.personQuery) {
      const q = S.personQuery;
      return (p.assignees||[]).some(a =>
        a.toUpperCase().includes(q) ||
        (MNAMES[a]||'').toUpperCase().includes(q)
      );
    }
    return statusOk;
  });

  const root = document.getElementById('root');
  if (!root) return;
  root.style.marginTop = '';

  const idxGuard = S.cflowIdx;  // preservar índice

  root.innerHTML = `
    ${renderHeader()}
    ${renderAnalytics()}
    ${renderChartsRow1()}
    <div class="fbar">
      <div class="filters">
        ${[['all','Todos'],['active','Activos'],['risk','En riesgo'],['delivered','Entregados'],['paused','Pausados']].map(
          ([k,l]) => `<button class="fb ${S.filter===k && !S.personQuery ? 'on' : ''}" onclick="setF('${k}')">${l}</button>`
        ).join('')}
        <span class="fb-person-wrap">
          <button class="fb ${S.personQuery ? 'on' : ''}" onclick="togglePersonFilter()">👤 ${t('personas')}</button>
          ${S.showPersonInput ? `<input class="person-input" id="person-filter-input" type="text"
            maxlength="4" placeholder="Ej: SB" value="${esc(S.personQuery)}"
            oninput="applyPersonFilter(this.value)" autofocus />` : ''}
        </span>
      </div>
      <button class="add-btn" onclick="tgForm()">${S.showForm && !S.editId ? '✕ Cancelar' : '+ Nuevo proyecto'}</button>
    </div>
    ${renderForm()}
    <div class="proj-grid" id="proj-grid-wrap">${renderCarousel(fil)}</div>
    ${renderDetail()}
  `;

  requestAnimationFrame(() => {
    mountChartsRow1();
    setThemeLabel();
    S.cflowIdx = idxGuard;   // restaurar índice antes de layout
    cflowLayout();
    const idioma = localStorage.getItem('idioma') || 'es';
    if (typeof aplicarIdioma === 'function') aplicarIdioma(idioma);
    updateLangBtn(idioma);
  });
}
