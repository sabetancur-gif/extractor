/** Módulo 7 · Welcome
 * Responsabilidad:
 *  - Pantallas de bienvenida: org-chart 3D, selector de área y usuario
 */

/** Pantalla de bienvenida.
 * Grafo 3D + Selector de usuario
 */
function renderWelcome() {
  const root = document.getElementById('root');
  if (!root) return;
  root.style.marginTop = '0';
  clearCharts();

  root.innerHTML = WLC.stage === 1
    ? buildWelcomeStage1()
    : buildWelcomeStage2();

  requestAnimationFrame(() => {
    setThemeLabel();
    const idioma = localStorage.getItem('idioma') || 'es';
    updateLangBtn(idioma);
    if (WLC.stage === 1) initOrgChart3D();
    else                  initUserCards3D();
    // Aplicar traducción a los elementos recién renderizados
    if (typeof aplicarIdioma === 'function') aplicarIdioma(idioma);
  });
}

/* Barra de control (botones tema/idioma)*/
function ctrlBar() {
  return `
    <div class="ctrl-btns ctrl-btns-wlc">
      <button class="tog tog-theme" onclick="toggleTheme()" aria-label="Cambiar tema">
        <span id="tog-lbl"></span>
      </button>
      <button id="btn-idioma" class="tog tog-lang" onclick="cambiarIdioma()" aria-label="Cambiar idioma"></button>
      <button class="wlc-panel-btn" onclick="openProjectPanel()" title="${t('wlc_procesar_btn')}">
        ${t('wlc_procesar_btn')}
      </button>
    </div>`;
}

/*  ETAPA 1 — Org-chart 3D: selectores + grafo */
function buildWelcomeStage1() {
  const depts    = Object.keys(ORG);
  const selDept  = WLC.dept || '';

  // Construir filas del árbol de departamentos
  const treeRows = depts.map(dk => {
    const dept   = ORG[dk];
    const areas  = Object.keys(dept.areas);
    const isOpen = dk === selDept;
    const totalM = areas.reduce((s, ak) => s + (dept.areas[ak].members || []).length, 0);

    const areaChips = areas.map(ak => {
      const isSelArea = isOpen && WLC.area === ak;
      return `<button class="wlc-area-chip ${isSelArea ? 'active' : ''}"
        onclick="wlcSelectArea('${dk}','${ak}')"
        style="${isSelArea ? `--ac:${dept.color}` : ''}">
        <span>${dept.areas[ak].icon || '→'}</span>
        <span>${ak}</span>
        <span class="wlc-chip-count">${(dept.areas[ak].members || []).length}</span>
      </button>`;
    }).join('');

    return `
      <div class="wlc-tree-dept ${isOpen ? 'open' : ''}">
        <button class="wlc-tree-hdr" onclick="wlcPickDept('${dk}')"
          style="${isOpen ? `--dc:${dept.color}` : ''}">
          <span class="wlc-tree-icon" style="background:${dept.color}18;color:${dept.color}">${dept.icon}</span>
          <span class="wlc-tree-name">${dk}</span>
          <span class="wlc-tree-meta">
            ${areas.length} ${t(areas.length === 1 ? 'area' : 'areas')}
            ·
            ${totalM} ${t(totalM === 1 ? 'persona' : 'personas')}
          </span>
          <span class="wlc-tree-arrow" aria-hidden="true">›</span>
        </button>
        ${isOpen ? `<div class="wlc-tree-areas">${areaChips}</div>` : ''}
      </div>`;
  }).join('');

  return `
    <div class="wlc-wrap" id="wlc-wrap">
      ${ctrlBar()}

      <div class="wlc-hero">
        <div class="wlc-orb" aria-hidden="true"></div>
        <p class="wlc-tag"><span class="pulse-dot"></span> DATA TEAM · PORTFOLIO</p>
        <h1 class="wlc-title">
          <span class="wlc-line wlc-line1">${t('wlc_selecciona')}</span>
          <span class="wlc-line wlc-line2 wlc-grad">${t('wlc_departamento')}</span>
        </h1>
        <p class="wlc-sub">${t('wlc_elige_sub')}</p>
      </div>

      <div class="wlc-stage1-layout">

        <!-- Columna izquierda: árbol de navegación -->
        <div class="wlc-nav-col">
          <div class="wlc-search-wrap">
            <input class="wlc-search-input" type="text"
              placeholder="Buscar departamento o área..."
              i18n="busqueda_departamento"
              oninput="wlcSearch(this.value)"
              id="wlc-search-input" />
          </div>
          <div class="wlc-tree" id="wlc-tree">
            ${treeRows}
          </div>
          <p class="wlc-hint-text">${t('wlc_graph_hint')}</p>
        </div>

        <!-- Columna derecha: grafo 3D contextual -->
        <div class="wlc-graph-col">
          <div class="wlc-graph-scene" id="wlc-scene">
            <svg id="wlc-svg" class="wlc-svg" xmlns="http://www.w3.org/2000/svg"></svg>
            <div id="wlc-tooltip" class="wlc-tooltip" style="display:none"></div>
          </div>
        </div>

      </div>
    </div>`;
}

/* ETAPA 2 — Selector de usuario con tarjetas flotantes 3D */

function buildWelcomeStage2() {
  const deptObj = ORG[WLC.dept] || {};
  const areaObj = deptObj.areas?.[WLC.area] || {};
  const members = (areaObj.members || []).filter(m => MNAMES[m]);

  const cards = members.length
    ? members.map((m, i) => {
        const color = memberColor(m);
        const caps  = (MCAPS && MCAPS[m]) || [];
        const capChips = caps.slice(0, 3).map(c =>
          `<span class="wlc-cap-chip">${c}</span>`
        ).join('');
        return `
          <div class="wlc-mcard-v2" onclick="wlcSelectMember('${esc(m)}')">
            <div class="wlc-mcard-v2-av" style="background:${color}18;color:${color};border:1.5px solid ${color}44">${esc(m)}</div>
            <p class="wlc-mcard-v2-name">${esc(MNAMES[m])}</p>
            <p class="wlc-mcard-v2-area" style="color:${color}">${esc(WLC.area)}</p>
            ${capChips ? `<div class="wlc-cap-chips">${capChips}</div>` : ''}
          </div>`;
      }).join('')
    : `<div class="wlc-empty">${t('wlc_sin_miembros')}</div>`;

  return `
    <div class="wlc-wrap wlc-stage2" id="wlc-wrap">
      ${ctrlBar()}

      <div class="wlc-hero">
        <div class="wlc-orb wlc-orb2" aria-hidden="true"></div>
        <p class="wlc-tag">
          <span class="pulse-dot"></span>
          ${esc(WLC.dept)} &nbsp;·&nbsp; ${esc(WLC.area)}
        </p>
        <h1 class="wlc-title">
          <span class="wlc-line wlc-line1">${t('wlc_quien')}</span>
          <span class="wlc-line wlc-line2 wlc-grad">${t('wlc_eres_tu')}</span>
        </h1>
      </div>

      <!-- Grid de tarjetas compactas -->
      <div class="wlc-member-grid">
        ${cards}
      </div>

      <button class="wlc-back-btn" onclick="wlcBack()">← ${t('wlc_cambiar_area')}</button>
    </div>`;
}

/* MOTOR ORG-CHART 3D — Canvas 3D con perspectiva real y rotación continua */

/**
 * ORG-CHART 3D 
 * Implementación basada en:
 *   - SVG para los nodos y aristas (nodos rectangulares con bordes redondeados)
 *   - d3-force para el layout automático (separación natural de nodos)
 *   - CSS perspective + rotateX/Y para la ilusión de profundidad 3D real
 *   - Drag para rotar el grafo con inercia
 *   - Tooltip flotante al hacer hover sobre cualquier nodo
 *   - Click en dept → resalta sus áreas; click en área → navega
 */
function initOrgChart3D() {
  /*
   * ORG-CHART 3D v5 — Canvas 2D con proyección perspectiva matemática real
   *
   * Por qué canvas y no SVG+CSS:
   *   Los navegadores NO aplican CSS perspective a elementos <svg>.
   *   rotateX/Y en un SVG solo hace shear 2D, no perspectiva real.
   *   Con canvas calculamos la proyección Z manualmente:
   *     sx = cx + (x3d * cos(rotY) + z3d * sin(rotY)) * fov / (fov + zCam)
   *   Esto produce profundidad genuina: los nodos lejanos se ven pequeños
   *   y los cercanos grandes, con parallax real al arrastrar.
   *
   * Características:
   *   - Nodos rectangulares estilo bumbeishvili con bordes redondeados
   *   - Líneas conectoras curvas (bezier quadratic)
   *   - Proyección perspectiva Z real
   *   - Profundidad visible: nodos delanteros más grandes y opacos
   *   - Rotación X/Y con drag + inercia + auto-rotate
   *   - Hover con hit-test en espacio 2D proyectado
   *   - Click limpio separado de drag (flag didMove)
   *   - Tooltip flotante en HTML overlay
   */
  const scene = document.getElementById('wlc-scene');
  if (!scene) return;

  if (window._orgAnim) { cancelAnimationFrame(window._orgAnim); window._orgAnim = null; }

  // Reemplazar contenido del scene con canvas + tooltip
  scene.style.perspective = '';        // limpiar cualquier perspective CSS previo
  scene.style.cursor      = 'grab';
  scene.innerHTML = `
    <canvas id="oc-canvas" style="display:block;width:100%;height:100%;cursor:inherit"></canvas>
    <div id="oc-tip" style="
      position:absolute;pointer-events:none;display:none;z-index:50;
      background:rgba(8,18,30,0.95);border:1px solid rgba(91,189,255,0.35);
      border-radius:9px;padding:8px 13px;backdrop-filter:blur(8px);
      box-shadow:0 4px 24px rgba(0,0,0,0.5);min-width:120px;
    "></div>`;

  const canvas = document.getElementById('oc-canvas');
  const tip    = document.getElementById('oc-tip');
  const ctx    = canvas.getContext('2d');

  // Dimensiones
  function resize() {
    canvas.width  = scene.offsetWidth  || 760;
    canvas.height = scene.offsetHeight || 400;
  }
  resize();
  const W = () => canvas.width;
  const H = () => canvas.height;

  const dk = isDark();

  // Construir grafo
  const nodes = [];
  const edges = [];

  // Posición 3D inicial: raíz al centro, depts en órbita, áreas más abajo
  nodes.push({
    id:'root', type:'root', label:'DATA\nTEAM', sub:'Portfolio', icon:'◈',
    color:'#5bbdff', fillA:'rgba(91,189,255,0.15)', stroke:'#5bbdff',
    x3:0, y3:-60, z3:0, w:110, h:50
  });

  const dkeys = Object.keys(ORG);
  dkeys.forEach((dkey, di) => {
    const d     = ORG[dkey];
    const angle = (di / dkeys.length) * Math.PI * 2;
    const R     = 220;
    const dId   = 'dept::' + dkey;
    const dx3   = Math.cos(angle) * R;
    const dz3   = Math.sin(angle) * R;
    nodes.push({
      id:dId, type:'dept', fullKey:dkey,
      label: dkey.split(' - ')[1] || dkey,
      sub:   Object.keys(d.areas).length + ' área(s)',
      icon:  d.icon || '▸',
      color: d.color, fillA: d.color + '22', stroke: d.color,
      x3: dx3, y3: 30, z3: dz3, w:128, h:50
    });
    edges.push({ a:'root', b:dId, color: d.color + 'aa' });

    const akeys = Object.keys(d.areas);
    akeys.forEach((akey, ai) => {
      const aId    = 'area::' + dkey + '::' + akey;
      const spread = (ai - (akeys.length - 1) / 2) * 130;
      // Perpendicular al vector dept-raíz para separar áreas del mismo dept
      const px = -Math.sin(angle), pz = Math.cos(angle);
      const mem = (d.areas[akey].members || []).length;
      nodes.push({
        id:aId, type:'area', fullKey:dkey, areaKey:akey,
        label: akey, sub: mem + ' miembro(s)',
        icon:  d.areas[akey].icon || '→',
        color: d.color, fillA: d.color + '12', stroke: d.color + 'cc',
        x3: dx3 + px * spread, y3: 130, z3: dz3 + pz * spread * 0.5,
        w:116, h:44
      });
      edges.push({ a: dId, b: aId, color: d.color + '66' });
    });
  });

  const nodeMap = {};
  nodes.forEach(n => { nodeMap[n.id] = n; });

  // Proyección perspectiva
  // rotX: inclinación vertical (mirar desde arriba/abajo)
  // rotY: giro horizontal
  // Retorna { sx, sy, scale, zCam } — coordenadas de pantalla + escala de profundidad
  function project(x3, y3, z3, rotX, rotY) {
    // Rotar en Y (yaw)
    const cosY = Math.cos(rotY), sinY = Math.sin(rotY);
    const rx   = x3 * cosY + z3 * sinY;
    const rz   = -x3 * sinY + z3 * cosY;
    // Rotar en X (pitch)
    const cosX = Math.cos(rotX), sinX = Math.sin(rotX);
    const ry   = y3 * cosX - rz * sinX;
    const rzf  = y3 * sinX + rz * cosX;
    // Proyección perspectiva
    const fov   = 650;
    const depth = fov + rzf + 350;   // distancia Z a la cámara
    const scale = fov / Math.max(depth, 1);
    return {
      sx:    W() / 2 + rx * scale,
      sy:    H() / 2 + ry * scale,
      scale,
      zCam: rzf
    };
  }

  // Estado de rotación
  let rotX = -0.22, rotY = 0;          // radianes
  let autoY = 0;                        // auto-rotate acumulado
  let vx = 0, vy = 0;                  // inercia
  let isDrag = false, didMove = false;
  let lastMx = 0, lastMy = 0;
  let hoveredNode = null;

  // Dibujar rectángulo con bordes redondeados en canvas
  function roundRect(cx, cy, w, h, r) {
    const x = cx - w/2, y = cy - h/2;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  // Frame de render
  function draw() {
    ctx.clearRect(0, 0, W(), H());

    const rX = rotX;
    const rY = rotY + autoY;

    // Proyectar todos los nodos
    const proj = nodes.map(n => {
      const p = project(n.x3, n.y3, n.z3, rX, rY);
      return { n, ...p };
    });

    // Ordenar por Z (más lejos primero → pintar detrás)
    proj.sort((a, b) => a.zCam - b.zCam);

    // Dibujar aristas
    edges.forEach(e => {
      const pa = proj.find(p => p.n.id === e.a);
      const pb = proj.find(p => p.n.id === e.b);
      if (!pa || !pb) return;
      // Punto de control elevado para curva bezier
      const mcx = (pa.sx + pb.sx) / 2;
      const mcy = (pa.sy + pb.sy) / 2 - Math.abs(pb.sx - pa.sx) * 0.12;
      ctx.beginPath();
      ctx.moveTo(pa.sx, pa.sy);
      ctx.quadraticCurveTo(mcx, mcy, pb.sx, pb.sy);
      ctx.strokeStyle = e.color;
      ctx.lineWidth   = 1.2;
      ctx.setLineDash([5, 5]);
      ctx.stroke();
      ctx.setLineDash([]);
    });

    // Dibujar nodos
    proj.forEach(({ n, sx, sy, scale, zCam }) => {
      const isHov = hoveredNode && hoveredNode.id === n.id;
      const w = n.w * scale * (isHov ? 1.12 : 1);
      const h = n.h * scale * (isHov ? 1.12 : 1);
      const r = (n.type === 'root' ? 14 : 10) * scale;

      // Opacidad basada en profundidad: nodos más adelante = más opacos
      const depth01 = Math.max(0, Math.min(1, (zCam + 350) / 700));
      const opacity = 0.45 + 0.55 * depth01;

      // Glow en hover
      if (isHov && n.type !== 'root') {
        ctx.save();
        ctx.shadowColor = n.color;
        ctx.shadowBlur  = 18 * scale;
      }

      // Fondo del nodo
      roundRect(sx, sy, w, h, r);
      ctx.fillStyle   = n.fillA;
      ctx.globalAlpha = opacity;
      ctx.fill();
      ctx.globalAlpha = 1;

      // Borde
      roundRect(sx, sy, w, h, r);
      ctx.strokeStyle = isHov ? n.color : n.stroke;
      ctx.lineWidth   = (isHov ? 2.5 : 1.5) * scale;
      ctx.globalAlpha = opacity + 0.15;
      ctx.stroke();
      ctx.globalAlpha = 1;

      if (isHov) ctx.restore();

      // Texto
      const fs    = Math.max(7, (n.type === 'root' ? 12 : 10) * scale);
      const fsSub = Math.max(6, 8 * scale);

      ctx.globalAlpha = Math.min(1, opacity + 0.25);

      // Icono
      ctx.font         = `${Math.max(8, 13 * scale)}px serif`;
      ctx.fillStyle    = n.color;
      ctx.textAlign    = n.type === 'root' ? 'center' : 'left';
      ctx.textBaseline = 'middle';
      const ix = n.type === 'root' ? sx : sx - w/2 + 12 * scale;
      const iy = sy - h * 0.18;
      ctx.fillText(n.icon, ix, iy);

      // Nombre principal (puede ser multilínea con \n)
      ctx.font      = `700 ${fs}px 'JetBrains Mono', monospace`;
      ctx.fillStyle = dk ? '#ddeeff' : '#0a1f35';
      const nameLines = n.label.split('\n');
      const nx = n.type === 'root' ? sx : sx - w/2 + 28 * scale;
      ctx.textAlign = n.type === 'root' ? 'center' : 'left';
      if (nameLines.length === 1) {
        ctx.fillText(nameLines[0].slice(0, 16), nx, sy - h * 0.06);
      } else {
        nameLines.forEach((line, li) => {
          ctx.fillText(line.slice(0, 12), nx,
            sy - h * 0.12 + li * fs * 1.25);
        });
      }

      // Subtítulo
      ctx.font      = `${fsSub}px 'JetBrains Mono', monospace`;
      ctx.fillStyle = n.color;
      ctx.textAlign = n.type === 'root' ? 'center' : 'left';
      const subX = n.type === 'root' ? sx : sx - w/2 + 28 * scale;
      ctx.fillText(n.sub.slice(0, 18), subX, sy + h * 0.25);

      ctx.globalAlpha = 1;
    });
  }

  // Animación
  function rafLoop() {
    if (!isDrag) {
      autoY += 0.004;                   // auto-rotate lento
      vx *= 0.92; vy *= 0.92;          // inercia
      rotY += vx;
      rotX = Math.max(-0.65, Math.min(0.65, rotX + vy));
    }
    draw();
    window._orgAnim = requestAnimationFrame(rafLoop);
  }
  if (window._orgAnim) cancelAnimationFrame(window._orgAnim);
  rafLoop();

  // Hit-test: ¿qué nodo está bajo (mx, my)?
  function hitTest(mx, my) {
    const rX = rotX, rY = rotY + autoY;
    let best = null, bestZ = -Infinity;
    nodes.forEach(n => {
      const { sx, sy, scale, zCam } = project(n.x3, n.y3, n.z3, rX, rY);
      const hw = (n.w * scale) / 2 + 4;
      const hh = (n.h * scale) / 2 + 4;
      if (mx >= sx - hw && mx <= sx + hw && my >= sy - hh && my <= sy + hh) {
        if (zCam > bestZ) { best = n; bestZ = zCam; }
      }
    });
    return best;
  }

  // Eventos de mouse
  function getXY(e) {
    const r = canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  canvas.addEventListener('mousemove', e => {
    const { x, y } = getXY(e);
    if (isDrag) {
      const dx = e.clientX - lastMx, dy = e.clientY - lastMy;
      if (Math.abs(dx) > 2 || Math.abs(dy) > 2) didMove = true;
      vx = dx * 0.008; vy = -dy * 0.006;
      rotY += dx * 0.008;
      rotX = Math.max(-0.65, Math.min(0.65, rotX - dy * 0.006));
      autoY = 0;
      lastMx = e.clientX; lastMy = e.clientY;
    } else {
      const hit = hitTest(x, y);
      hoveredNode = hit;
      canvas.style.cursor = hit && hit.type !== 'root' ? 'pointer' : 'grab';

      if (hit && hit.type !== 'root') {
        const r = scene.getBoundingClientRect();
        tip.style.left    = (e.clientX - r.left + 14) + 'px';
        tip.style.top     = (e.clientY - r.top  - 56) + 'px';
        tip.style.display = 'block';
        tip.innerHTML = `
          <div style="font-size:8px;color:#3d5f7a;font-family:'JetBrains Mono',monospace;text-transform:uppercase;letter-spacing:.1em;margin-bottom:3px">
            ${hit.type === 'dept' ? 'Departamento' : 'Área'}
          </div>
          <div style="color:${hit.color};font-weight:700;font-family:'JetBrains Mono',monospace;font-size:12px">
            ${hit.label}
          </div>
          <div style="color:#ff8a3d;font-size:9px;font-family:'JetBrains Mono',monospace;margin-top:3px">
            ${hit.type === 'area' ? '→ Clic para entrar' : '→ Clic para ver áreas'}
          </div>`;
      } else {
        tip.style.display = 'none';
      }
    }
  });

  canvas.addEventListener('mousedown', e => {
    isDrag = true; didMove = false;
    lastMx = e.clientX; lastMy = e.clientY;
    vx = 0; vy = 0;
    scene.style.cursor = 'grabbing';
  });

  window.addEventListener('mouseup', () => {
    isDrag = false;
    scene.style.cursor = 'grab';
  });

  canvas.addEventListener('mouseleave', () => {
    hoveredNode = null;
    tip.style.display = 'none';
  });

  // Click: solo si no fue drag
  canvas.addEventListener('click', e => {
    if (didMove) { didMove = false; return; }
    const { x, y } = getXY(e);
    const n = hitTest(x, y);
    if (!n) return;
    tip.style.display = 'none';
    if (n.type === 'dept') {
      WLC.dept = n.fullKey; WLC.area = null;
      renderWelcome();
    } else if (n.type === 'area') {
      wlcSelectArea(n.fullKey, n.areaKey);
    }
  });

  // Touch
  canvas.addEventListener('touchstart', e => {
    const t = e.touches[0];
    isDrag = true; didMove = false;
    lastMx = t.clientX; lastMy = t.clientY; vx = 0; vy = 0;
  }, { passive: true });

  canvas.addEventListener('touchmove', e => {
    if (!isDrag) return;
    const t = e.touches[0];
    const dx = t.clientX - lastMx, dy = t.clientY - lastMy;
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) didMove = true;
    vx = dx * 0.009; vy = -dy * 0.007;
    rotY += dx * 0.009; rotX = Math.max(-0.65, Math.min(0.65, rotX - dy * 0.007));
    autoY = 0; lastMx = t.clientX; lastMy = t.clientY;
  }, { passive: true });

  canvas.addEventListener('touchend', e => {
    isDrag = false;
    if (!didMove && e.changedTouches.length > 0) {
      const t = e.changedTouches[0];
      const r = canvas.getBoundingClientRect();
      const n = hitTest(t.clientX - r.left, t.clientY - r.top);
      if (n && n.type === 'dept') { WLC.dept = n.fullKey; WLC.area = null; renderWelcome(); }
      else if (n && n.type === 'area') wlcSelectArea(n.fullKey, n.areaKey);
    }
  });

  // Resize
  window.addEventListener('resize', () => { resize(); });
}

/**
 * Filtra el árbol de departamentos y áreas según el texto ingresado.
 * Oculta los depts que no coincidan ni en nombre ni en ninguna de sus áreas.
 * @param {string} query - Texto del input de búsqueda
 */
function wlcSearch(query) {
  const q = query.trim().toLowerCase();
  const tree = document.getElementById('wlc-tree');
  if (!tree) return;

  tree.querySelectorAll('.wlc-tree-dept').forEach(row => {
    const deptName = row.querySelector('.wlc-tree-name')?.textContent.toLowerCase() || '';
    const areaNames = [...row.querySelectorAll('.wlc-area-chip')]
      .map(c => c.textContent.toLowerCase()).join(' ');
    const match = !q || deptName.includes(q) || areaNames.includes(q);
    row.style.display = match ? '' : 'none';

    // Si hay búsqueda activa, expandir los depts que coincidan en área
    if (q && areaNames.includes(q) && !deptName.includes(q)) {
      row.classList.add('open');
      const areasDiv = row.querySelector('.wlc-tree-areas');
      if (areasDiv) {
        areasDiv.querySelectorAll('.wlc-area-chip').forEach(chip => {
          chip.style.display = chip.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
      }
    }
  });
}

// Selección de dept desde botones píldora (refresca sin cambiar etapa)
function wlcPickDept(key) {
  WLC.dept = key;
  WLC.area = null;
  renderWelcome();
}

/* MOTOR TARJETAS 3D — Anillo giratorio (stage 2) */
function initUserCards3D() {
  const ring = document.getElementById('wlc-cards-ring');
  if (!ring) return;
  const cards = Array.from(ring.querySelectorAll('.wlc-mcard'));
  const total = cards.length;
  if (!total) return;

  let rotY = 0;
  let vel  = 0;
  let dragging = false;
  let lastX = 0;
  let rafId = null;

  function layout() {
    const radius = Math.max(180, total * 72);
    cards.forEach((c,i) => {
      const angle = (i/total)*360 + rotY;
      const rad   = angle * Math.PI / 180;
      const x     = Math.sin(rad) * radius;
      const z     = Math.cos(rad) * radius;
      const norm  = (z + radius)/(2*radius); // 0..1
      const scale = 0.62 + 0.38*norm;
      const opa   = 0.28 + 0.72*norm;
      c.style.transform = `translateX(${x}px) translateZ(${z}px) scale(${scale})`;
      c.style.opacity   = opa;
      c.style.zIndex    = Math.round(scale*100);
      c.style.pointerEvents = z > 0 ? 'auto' : 'none';
    });
  }

  function inertia() {
    if (Math.abs(vel) < 0.05) return;
    rotY += vel;
    vel  *= 0.93;
    layout();
    rafId = requestAnimationFrame(inertia);
  }

  // Mouse
  ring.addEventListener('mousedown', e => {
    dragging=true; lastX=e.clientX; vel=0;
    cancelAnimationFrame(rafId);
  });
  document.addEventListener('mousemove', e => {
    if(!dragging) return;
    const dx = e.clientX-lastX;
    rotY += dx*0.35; vel=dx*0.35; lastX=e.clientX;
    layout();
  });
  document.addEventListener('mouseup', () => {
    if(!dragging) return;
    dragging=false;
    rafId = requestAnimationFrame(inertia);
  });

  // Touch
  ring.addEventListener('touchstart', e=>{dragging=true;lastX=e.touches[0].clientX;vel=0;cancelAnimationFrame(rafId);},{passive:true});
  ring.addEventListener('touchmove', e=>{
    if(!dragging) return;
    const dx=e.touches[0].clientX-lastX;
    rotY+=dx*0.4;vel=dx*0.4;lastX=e.touches[0].clientX;
    layout();
  },{passive:true});
  ring.addEventListener('touchend',()=>{dragging=false;rafId=requestAnimationFrame(inertia);});

  layout();

  // Animación de entrada — las tarjetas aparecen con fade+slide
  cards.forEach((c,i) => {
    c.style.opacity = '0';
    c.style.transform += ' translateY(40px)';
    setTimeout(()=>{ c.style.transition='opacity 0.55s cubic-bezier(.22,1,.36,1), transform 0.55s cubic-bezier(.22,1,.36,1)'; layout(); },60+i*90);
  });
}
