/* Módulo 1 · datos base y estado
    Aquí viven las constantes, el estado global y la capa de almacenamiento.
    Los proyectos ya NO se definen aquí como DEFAULTS, sino que se cargan
    desde archivos JSON en assets/data/<NombreArea>.json según el área
    que el usuario seleccionó en la pantalla de bienvenida.
*/

// Colores de avatar y capacidades por miembro.
const AVC = [
  ['#1D9E75', '#E1F5EE'],
  ['#378ADD', '#E6F1FB'],
  ['#D85A30', '#FAECE7'],
  ['#D4537E', '#FBEAF0'],
  ['#BA7517', '#FAEEDA'],
  ['#7F77DD', '#EEEDFE']
];

const MNAMES = {
  SB: 'Santiago Betancur',
  FQ: 'Fernanda Quintero',
  YS: 'Yoryam Sanchez',
  TM: 'Tomas Muñoz',
};

const MCAPS = {
  SB: ['Python', 'JS', 'HTML'],
  FQ: ['PowerBI', 'Python', 'JS'],
  YS: ['Python', 'JS', 'HTML'],
  TM: ['Automate'],
}

const MCAP = {
  SB: 7,
  FQ: 7,
  YS: 10,
  TM: 5,
};

// Estructura organizacional
const ORG = {
  '4000 - Compliance': {
    color: '#5bbdff',
    accent: '#2de8d0',
    icon: ``,
    areas: {
      'Data Analysis': {
        members: ['SB','FQ','YS'],
        icon: ``,
      },
      'Add or Term': {
        members: ['SB','FQ'],
        icon: ``,
      }
    }
  },
  '7000 - IT': {
    color: '#2ee89a',
    accent: '#b47cff',
    icon: ``,
    areas: {
      'Infrastructure': {
        members: [],
        icon: ``,
      }
    }
  },
  '1000 - Executive': {
    color: '#b47cff',
    accent: '#ff7cb4',
    icon: ``,
    areas: {
      'Strategy': {
        members: [],
        icon: ``,
      }
    }
  }
};

// Estado de sesión de bienvenida
const WLC = {
  stage: 1,    // 1=depto+área, 2=persona
  dept:  null,
  area:  null,
  user:  null,
  active: true // true = mostrando welcome, false = dashboard
};

// Almacenamiento compatible con localStorage o con un storage inyectado por el entorno.
const storage = (window.storage && typeof window.storage.get === 'function')
  ? window.storage
  : {
      async get(key){ const v = localStorage.getItem(key); return v ? { value: v } : null; },
      async set(key, value){ localStorage.setItem(key, value); }
    };

// Estado global de la interfaz.
const S = {
  projects: [],
  filter: 'all',
  sel: null,
  tab: 'executive',
  showForm: false,
  editId: null,
  form: {},
  cflowIdx: 0,          // índice activo del carrusel
  personQuery: '',       // texto del filtro por persona
  showPersonInput: false // controla visibilidad del input
};

if(!window._charts) window._charts = [];

/**
 * Construye el nombre de archivo JSON a partir del nombre del área.
 * Reemplaza espacios y caracteres especiales por guiones bajos.
 * Ejemplo: "Data Analysis" → "Data_Analysis.json"
 *
 * @param {string} area - Nombre del área seleccionada
 * @returns {string} Ruta relativa al archivo JSON del área
 */
function areaToJsonPath(area) {
  const safe = (area || '').replace(/[^a-zA-Z0-9À-ÿ]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');
  return `./assets/data/${safe}.json`;
}

/**
 * Carga los proyectos desde el archivo JSON del área actual (WLC.area).
 * Si no existe el archivo, retorna un arreglo vacío.
 * Normaliza la estructura de cada proyecto de la misma forma que antes.
 *
 * @returns {Promise<Array>} Arreglo de proyectos normalizados
 */
async function loadProjectsFromArea() {
  const path = areaToJsonPath(WLC.area);
  try {
    const resp = await fetch(path);
    if (!resp.ok) {
      console.warn(`[data] No se encontró el archivo ${path} (HTTP ${resp.status}). Área sin proyectos.`);
      return [];
    }
    const data = await resp.json();
    if (!Array.isArray(data)) return [];
    return data;
  } catch (e) {
    console.warn(`[data] Error cargando proyectos de ${path}:`, e.message);
    return [];
  }
}
