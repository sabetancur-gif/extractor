r"""
╔══════════════════════════════════════════════════════════════════════════════════╗
║         PANEL DE GESTIÓN DE PROYECTOS - Dashboard Data Team                      ║ # noqa: E501
╠══════════════════════════════════════════════════════════════════════════════════╣
║                                                                                  ║
║  Herramienta de escritorio para crear, editar y eliminar proyectos en los        ║
║  archivos JSON que alimentaran los respectivos dashboards asociados a c/area.    ║
║                                                                                  ║
║  ARQUITECTURA DE LA INTERFAZ                                                     ║
║  ─────────────────────────────                                                   ║
║  ┌──────────────┬────────────────────────────────────────────────────────────┐   ║
║  │  IZQUIERDA   │                    DERECHA (Notebook)                      │   ║
║  │              │  ┌──────────┬──────────┬──────────┬──────────┬──────────┐  │   ║
║  │  Selector    │  │ General  │  Equipo  │ Blockers │ Timeline │ Entreg.  │  │   ║
║  │  de área     │  ├──────────┴──────────┴──────────┴──────────┴──────────┤  │   ║
║  │              │  │                                                      │  │   ║
║  │  Lista de    │  │   Formulario con scroll vertical para cada pestaña   │  │   ║
║  │  proyectos   │  │   Filas dinámicas (+/-) en secciones estructuradas   │  │   ║
║  │              │  │   Placeholders descriptivos en todos los campos      │  │   ║
║  │  [+ Nuevo]   │  │                                                      │  │   ║
║  │  [Eliminar]  │  └──────────────────────────────────────────────────────┘  │   ║
║  │              │    [ ✔ Guardar ]                      [ ✕ Cancelar ]      │   ║
║  └──────────────┴────────────────────────────────────────────────────────────┘   ║
║                                                                                  ║
║  ARCHIVOS QUE GESTIONA                                                           ║
║    assets/data/<Nombre_Area>.json  →  Ej: Data_Analysis.json                     ║
║                                                                                  ║
║  ESTRUCTURA JSON DE CADA PROYECTO (p1, p2, ...)                                  ║
║    id, idiom, name, description, status,                                         ║
║    businessPriority, technicalSeverity, urgency, dependencyCriticality,          ║
║    deadline, committedAt, actualAt,                                              ║
║    assignees[], tech[], blockers[{text,severity}], dependencies[],               ║
║    timeline[{date,title,desc}], history[{date,author,action,detail}],            ║
║    recentActivity[{author,date,text}], deliverables[{id,text,done,owner,         ║
║      sla,committed,actual,goal,criteria,notes}], comments[{author,date,text}]    ║
║                                                                                  ║
║  USO                                                                             ║
║    python panel_proyectos.py                                                     ║
║                                                                                  ║
║  REQUISITOS                                                                      ║
║    Python 3.8+  -  Solo usa la librería estándar (tkinter incluido)              ║
╚══════════════════════════════════════════════════════════════════════════════════╝
"""

# panel/config.py — Constantes, paleta de colores, templates y utilidades JSON
from pathlib import Path
import json
from datetime import datetime

# CONSTANTES Y CONFIGURACIÓN

# Directorio raíz donde viven los archivos JSON de cada área.
# Se calcula relativo a la ubicación del propio script para portabilidad.
DATA_DIR = Path(__file__).parent.parent / "assets" / "data"

# Paleta de colores oscura (coherente con el dashboard style)
# Cada clave corresponde a un rol semántico en la interfaz.
C = {
    "bg":         "#0a1520",   # Fondo global más oscuro
    "bg2":        "#0f1e2e",   # Fondo de la barra superior y barra de estado
    "bg3":        "#111826",   # Fondo de inputs y areas de texto
    "card":       "#0d1a28",   # Fondo de los paneles (tarjetas)
    "card2":      "#111c2a",   # Fondo secundario dentro de tarjetas
    "border":     "#1a2e42",   # Borde exterior de tarjetas
    "border2":    "#1f3550",   # Borde de hover / activo
    "line":       "#162438",   # Línea separadora sutil
    "accent":     "#5bbdff",   # Azul cian - color principal de interacción
    "orange":     "#ff8a3d",   # Naranja - títulos y acciones primarias
    "red":        "#ff5c5c",   # Rojo - eliminación y errores
    "green":      "#2ee89a",   # Verde - confirmación y éxito
    "warn":       "#ffb547",   # Amarillo - advertencias
    "purple":     "#b47cff",   # Violeta - acciones secundarias
    "text":       "#ddeeff",   # Texto principal (casi blanco azulado)
    "muted":      "#7a9db8",   # Texto secundario (gris azulado)
    "soft":       "#3d5f7a",   # Texto terciario muy tenue
    "ph":         "#2a4a62",   # Color del placeholder (texto gris-azul)
    "mono":       "JetBrains Mono",   # Fuente monoespaciada para el panel
    "sans":       "Segoe UI",         # Fuente sans-serif del sistema
}

# Opciones para campos con valores predefinidos
STATUS_OPTS   = ["active", "risk", "delivered", "paused"]  # noqa: E221
SEVERITY_OPTS = ["crit", "med", "low"]
IDIOM_OPTS    = ["En", "Es"]  # noqa: E221
DONE_OPTS     = ["true", "false"]  # noqa: E221

# Plantilla vacía de un proyecto nuevo
# Los campos que puede tener un proyecto; el id se genera automáticamente.
PROYECTO_TEMPLATE = {
    "id":                       "",         # Generado automáticamente
    "idiom":                    "En",       # Idioma del proyecto
    "name":                     "",
    "description":              "",
    "status":                   "active",
    "businessPriority":         3,
    "technicalSeverity":        3,
    "urgency":                  3,
    "dependencyCriticality":    3,
    "deadline":                 "",
    "committedAt":              "",
    "actualAt":                 "",
    "assignees":                [],
    "tech":                     [],
    "blockers":                 [],
    "dependencies":             [],
    "timeline":                 [],
    "history":                  [],
    "recentActivity":           [],
    "deliverables":             [],
    "comments":                 [],
}

# Plantillas vacías para cada sub-elemento estructurado
BLOCKER_TEMPLATE = {"text": "", "severity": "med"}
TIMELINE_TEMPLATE = {"date": "", "title": "", "desc": ""}
HISTORY_TEMPLATE = {"date": "", "author": "", "action": "", "detail": ""}
ACTIVITY_TEMPLATE = {"author": "", "date": "", "text": ""}
DELIVERABLE_TEMPLATE = {
    "id":        "",    # Generado automáticamente (d1, d2, …)
    "text":      "", "done":      "false",
    "owner":     "", "sla":       "",
    "committed": "", "actual":    "",
    "goal":      "", "criteria":  "",
    "notes":     "",
}
COMMENT_TEMPLATE = {"author": "", "date": "", "text": ""}


# UTILIDADES JSON Y DE DATOS
def listar_archivos_json() -> list:
    r"""
    Devuelve una lista ordenada de rutas Path a todos los .json en DATA_DIR.
    Si el directorio no existe, retorna lista vacía (el panel mostrará aviso).
    """
    if not DATA_DIR.exists():
        return []
    return sorted(DATA_DIR.glob("*.json"))


def cargar_json(ruta: Path) -> list:
    r"""
    Carga y parsea el archivo JSON de proyectos indicado.
    Retorna lista vacía si el archivo no existe o está vacío.
    Lanza ValueError si el JSON es inválido.
    """
    if not ruta.exists():
        return []
    with open(ruta, "r", encoding="utf-8") as f:
        texto = f.read().strip()
    if not texto:
        return []
    data = json.loads(texto)
    return data if isinstance(data, list) else []


def guardar_json(ruta: Path, proyectos: list) -> None:
    r"""
    Serializa la lista de proyectos como JSON indentado y la escribe en disco.
    Usa ensure_ascii=False para preservar caracteres especiales (tildes, etc.).
    """
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(proyectos, f, ensure_ascii=False, indent=2)


def generar_id_proyecto(proyectos: list) -> str:
    r"""
    Genera el siguiente ID de proyecto manteniendo el orden correlativo.
    Lee los IDs existentes del patrón 'pN', toma el máximo N y retorna p(N+1).
    Si no hay proyectos, retorna 'p1'.
    Ejemplo: proyectos con p1, p2, p4  →  retorna p5 (máximo + 1)
    """
    nums = []
    for p in proyectos:
        pid = str(p.get("id", ""))
        if pid.startswith("p") and pid[1:].isdigit():
            nums.append(int(pid[1:]))
    return f"p{max(nums) + 1}" if nums else "p1"


def generar_id_entregable(entregables: list) -> str:
    r"""
    Genera el siguiente ID de entregable con el patrón 'dN'.
    Mismo mecanismo que generar_id_proyecto pero con prefijo 'd'.
    Ejemplo: d1, d2, d5  →  retorna d6
    """
    nums = []
    for d in entregables:
        did = str(d.get("id", ""))
        if did.startswith("d") and did[1:].isdigit():
            nums.append(int(did[1:]))
    return f"d{max(nums) + 1}" if nums else "d1"


def timestamp_ahora() -> str:
    r"""Retorna el timestamp actual formateado como 'YYYY-MM-DD HH:MM'."""
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def lista_desde_csv(texto: str) -> list:
    r"""
    Convierte un string CSV a lista, limpiando espacios.
    Ejemplo: "SB, FQ, YS" → ["SB", "FQ", "YS"]
    Entradas vacías o de solo espacios se omiten.
    """
    return [x.strip() for x in texto.split(",") if x.strip()]
