r"""panel/widgets.py— Widgets reutilizables:
    PlaceholderEntry y DynamicRowManager
"""

import tkinter as tk
from tkinter import ttk
from panel.config import C


# WIDGET AUXILIAR: ENTRY CON PLACEHOLDER
class PlaceholderEntry(tk.Entry):
    r"""
    Entry de tkinter con soporte de placeholder (texto descriptivo en gris
    que desaparece al enfocar el campo y vuelve si queda vacío al perder foco).

    Uso:
        e = PlaceholderEntry(parent, placeholder="YYYY-MM-DD", width=18)
        valor = e.get_value()  # devuelve "" si solo hay placeholder
    """

    def __init__(self, parent, placeholder: str = "", **kwargs):
        r"""
        Inicializa el Entry con el color de placeholder (C["ph"]) y texto gris.

        Args:
            parent:         Widget padre de tkinter.
            placeholder:    Texto descriptivo a mostrar cuando el
                            campo está vacío.
            **kwargs:       Argumentos adicionales para tk.Entry
                            (width, font, etc.).
        """
        # Estilos base para el Entry oscuro del panel
        defaults = {
            "bg":                   C["bg3"],
            "fg":                   C["text"],
            "insertbackground":     C["accent"],
            "relief":               "flat",
            "bd":                   0,
            "font":                 (C["mono"], 9),
            "highlightthickness":   1,
            "highlightcolor":       C["accent"],
            "highlightbackground":  C["border"],
        }
        # Permite sobreescribir cualquier estilo desde el exterior
        defaults.update(kwargs)
        super().__init__(parent, **defaults)

        self._placeholder = placeholder
        self._has_ph = False      # True cuando el campo muestra el placeholder
        self._normal_fg = defaults.get("fg", C["text"])

        # Mostrar placeholder inicial
        if placeholder:
            self._show_placeholder()

        # Vincular eventos de foco para gestionar el placeholder
        self.bind("<FocusIn>",  self._on_focus_in)
        self.bind("<FocusOut>", self._on_focus_out)

    def _show_placeholder(self):
        r"""Muestra el texto placeholder en color tenue."""
        self._has_ph = True
        self.config(fg=C["ph"])
        self.delete(0, tk.END)
        self.insert(0, self._placeholder)

    def _hide_placeholder(self):
        r"""Elimina el texto placeholder para permitir edición real."""
        if self._has_ph:
            self._has_ph = False
            self.config(fg=self._normal_fg)
            self.delete(0, tk.END)

    def _on_focus_in(self, _event):
        r"""Al ganar foco: ocultar placeholder si está activo."""
        if self._has_ph:
            self._hide_placeholder()

    def _on_focus_out(self, _event):
        r"""Al perder foco: si el campo quedó vacío, volver a mostrar
        placeholder."""
        if not self.get().strip():
            self._show_placeholder()

    def get_value(self) -> str:
        r"""
        Retorna el valor real del campo (cadena vacía si solo hay placeholder).
        Usar este método en lugar de .get() para evitar confundir placeholder
        con datos.
        """
        if self._has_ph:
            return ""
        return self.get().strip()

    def set_value(self, valor: str):
        r"""
        Establece un valor en el campo. Si el valor es vacío, muestra el
        placeholder. Usar este método en lugar de .insert() para mantener
        coherencia del estado.

        Args:
            valor: String a establecer en el campo.
        """
        self._has_ph = False
        self.config(fg=self._normal_fg)
        self.delete(0, tk.END)
        if valor:
            self.insert(0, str(valor))
        elif self._placeholder:
            self._show_placeholder()


# WIDGET AUXILIAR: GESTOR DE FILAS DINÁMICAS
class DynamicRowManager(tk.Frame):
    r"""
    Panel scrollable que gestiona una lista dinámica de filas con campos
    de texto. Cada fila corresponde a un elemento de una sección
    estructurada del proyecto (blocker, timeline event, deliverable, etc.).

    Permite:
        - Agregar una nueva fila vacía con el botón "+"
        - Eliminar una fila específica con el botón "-" de esa fila
        - Leer todas las filas como una lista de diccionarios

    Los campos de cada fila se definen mediante la lista `field_defs`:
        [("clave", "Etiqueta", tipo, opciones_o_placeholder), ...]

    Tipos soportados:
        "entry" → PlaceholderEntry (campo de texto de una línea)
        "combo" → ttk.Combobox (selector con opciones predefinidas)
        "text"  → tk.Text     (área de texto de varias líneas, height=2)
        "readonly" → PlaceholderEntry deshabilitado (para IDs generados)
        "check" → Combobox con opciones ["true", "false"] (para campo "done")
    """

    def __init__(self, parent, field_defs: list, id_generator=None,
                 id_field: str = None, section_title: str = "", **kwargs):
        r"""
        Args:
            parent:         Widget padre de tkinter.
            field_defs:     Lista de tuplas (key, label, type, opts) que
                            definen los campos de cada fila.
            id_generator:   Función callable que recibe la lista actual
                            de dicts y retorna un nuevo ID. Si es None,
                            no se generan IDs automáticos.
            id_field:       Nombre del campo que almacena el ID (ej: "id").
                            Usado con id_generator.
            section_title:  Título de la sección (aparece como encabezado
                            interno).
            **kwargs:       Argumentos adicionales para tk.Frame.
        """
        super().__init__(parent, bg=C["card"], **kwargs)
        self._field_defs = field_defs  # Definición de los campos por fila
        self._id_generator = id_generator  # Generador de IDs para nuevas filas
        self._id_field = id_field  # Nombre del campo ID (ej: "id")
        self._rows: list = []  # Lista de dicts {campo: widget} por fila

        # Encabezado de la sección
        if section_title:
            hdr = tk.Frame(self, bg=C["card"])
            hdr.pack(fill="x", padx=6, pady=(6, 2))
            tk.Label(
                hdr,
                text=section_title,
                font=(C["mono"], 9, "bold"),
                bg=C["card"],
                fg=C["orange"],
                anchor="w"
            ).pack(side="left")
            self._btn_add(hdr, "+ Agregar", self._add_row).pack(side="right")

        # Canvas + Scrollbar para el área scrollable de filas
        frame_outer = tk.Frame(self, bg=C["card"])
        frame_outer.pack(fill="both", expand=True, padx=4)

        self._canvas = tk.Canvas(
            frame_outer,
            bg=C["card"],
            bd=0,
            highlightthickness=0
        )
        sb = tk.Scrollbar(
            frame_outer, orient="vertical",
            command=self._canvas.yview,
            bg=C["bg2"], troughcolor=C["bg"]
        )
        sb.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)
        self._canvas.configure(yscrollcommand=sb.set)

        # Frame interior que contiene todas las filas
        self._inner = tk.Frame(self._canvas, bg=C["card"])
        self._win_id = self._canvas.create_window(
            (0, 0),
            window=self._inner,
            anchor="nw"
        )

        # Actualizar scrollregion al cambiar el tamaño del frame interior
        self._inner.bind(
            "<Configure>",
            lambda e: self._canvas.configure(scrollregion=self._canvas.bbox("all"))  # noqa: E501
        )
        self._canvas.bind(
            "<Configure>",
            lambda e: self._canvas.itemconfig(self._win_id, width=e.width)
        )
        # Scroll con rueda del mouse
        self._canvas.bind_all(
            "<MouseWheel>",
            lambda e: self._canvas.yview_scroll(int(-1*(e.delta/120)), "units")
        )

    # API pública

    def load_data(self, data: list):
        r"""
        Carga una lista de diccionarios como filas en el gestor.
        Borra todas las filas existentes antes de cargar las nuevas.

        Args:
            data: Lista de dicts, cada uno corresponde a una fila del gestor.
        """
        self._clear_rows()
        for item in (data or []):
            self._add_row(initial_data=item)

    def get_data(self) -> list:
        r"""
        Lee todos los campos de todas las filas y retorna una lista de dicts.
        Los campos de tipo "check" se convierten a boolean (True/False).
        Los campos de tipo "text" se leen con .get("1.0", tk.END).strip().

        Returns:
            Lista de dicts con los valores actuales de cada fila.
        """
        result = []
        for row_widgets in self._rows:
            item = {}
            for key, _, tipo, _ in self._field_defs:
                w = row_widgets.get(key)
                if w is None:
                    item[key] = ""
                    continue
                if tipo == "text":
                    # tk.Text: leer todo el contenido
                    item[key] = w.get("1.0", tk.END).strip()
                elif tipo in ("entry", "readonly"):
                    # PlaceholderEntry: usar get_value() evitar placeholder
                    item[key] = w.get_value() if hasattr(w, "get_value") else w.get().strip()  # noqa: E501
                elif tipo in ("combo", "check"):
                    # StringVar ligada al Combobox
                    raw = w.get()
                    if tipo == "check":
                        # Convertir "true"/"false" a bool de Python
                        item[key] = (raw.lower() == "true")
                    else:
                        item[key] = raw
                else:
                    item[key] = w.get().strip() if hasattr(w, "get") else ""
            result.append(item)
        return result

    # Métodos internos
    def _clear_rows(self):
        r"""Elimina todos los widgets de fila del frame interior."""
        for child in self._inner.winfo_children():
            child.destroy()
        self._rows.clear()

    def _add_row(self, initial_data: dict = None):
        r"""
        Agrega una nueva fila de campos al gestor.
        Si se pasa initial_data, rellena los campos con esos valores.
        Si se tiene id_generator y la fila nueva no tiene ID, lo genera
        automáticamente.

        Args:
            initial_data: Dict con valores iniciales para la nueva
            fila (opcional).
        """
        if initial_data is None:
            initial_data = {}

        # Generar ID automático si aplica y la fila no tiene uno
        if self._id_generator and self._id_field and not initial_data.get(
            self._id_field
        ):
            existing = self.get_data()
            initial_data = dict(initial_data)
            initial_data[self._id_field] = self._id_generator(existing)

        # Contenedor visual de la fila (borde sutil + separación)
        row_frame = tk.Frame(
            self._inner,
            bg=C["card2"],
            highlightthickness=1,
            highlightbackground=C["border"]
        )
        row_frame.pack(fill="x", padx=6, pady=6, ipady=6)

        # Botón "−" para eliminar esta fila (en la esquina superior derecha)
        btn_del = tk.Button(
            row_frame, text="✕", font=(C["mono"], 9, "bold"),
            bg=C["bg3"], fg=C["red"], relief="flat", bd=0,
            cursor="hand2", padx=8, pady=4,
            command=lambda f=row_frame,
            idx=len(self._rows): self._remove_row(f, idx)
        )
        btn_del.pack(side="right", anchor="ne", padx=6, pady=6)

        # Construir campos de la fila según field_defs
        row_widgets = {}
        for key, label, tipo, opts in self._field_defs:
            # Sub-frame para etiqueta + widget
            cell = tk.Frame(row_frame, bg=C["card2"])
            cell.pack(fill="x", padx=12, pady=3)

            tk.Label(
                cell, text=label, font=(C["mono"], 8),
                bg=C["card2"], fg=C["muted"], anchor="w",
                width=18
            ).pack(side="left")

            val = str(initial_data.get(key, ""))
            # Normalizar booleanos a string para el display
            if isinstance(initial_data.get(key), bool):
                val = "true" if initial_data[key] else "false"

            if tipo == "entry":
                w = PlaceholderEntry(
                    cell, placeholder=opts or "", width=28,
                    font=(C["mono"], 9)
                )
                w.pack(side="left", fill="x", expand=True, ipady=5)
                if val and val not in ("None", ""):
                    w.set_value(val)

            elif tipo == "readonly":
                # Campo de solo lectura para IDs generados automáticamente
                w = PlaceholderEntry(
                    cell, placeholder="(auto)", width=10,
                    font=(C["mono"], 9),
                    state="readonly",
                    readonlybackground=C["bg3"],
                    fg=C["soft"]
                )
                w.pack(side="left", ipady=3)
                if val and val not in ("None", ""):
                    w.config(state="normal")
                    w.set_value(val)
                    w.config(state="readonly")
                row_widgets[key] = w
                continue  # No sobrescribir con el set_value al final

            elif tipo == "combo" or tipo == "check":
                var = tk.StringVar(
                    value=val if val else (opts[0] if opts else "")
                )
                w = ttk.Combobox(
                    cell, textvariable=var,
                    values=opts or [],
                    font=(C["mono"], 9), width=14, state="readonly"
                )
                # Styling del Combobox (no se puede personalizar mucho en ttk)
                w.pack(side="left", ipady=2)
                # Guardamos la StringVar, no el widget, para .get() consistente
                row_widgets[key] = var
                continue  # get_data() usará var.get()

            elif tipo == "text":
                w = tk.Text(cell, bg=C["bg3"], fg=C["text"],
                            insertbackground=C["accent"],
                            font=(C["mono"], 9),
                            relief="flat", bd=0, wrap="word",
                            height=2, width=30)
                w.pack(side="left", fill="x", expand=True, ipady=2)
                if val and val not in ("None", ""):
                    w.insert("1.0", val)
                row_widgets[key] = w
                continue

            row_widgets[key] = w

        # Registrar la fila
        self._rows.append(row_widgets)

        # Actualizar los comandos de eliminación con el índice correcto
        self._refresh_delete_commands()

    def _remove_row(self, frame: tk.Frame, idx: int):
        r"""
        Elimina la fila indicada por su frame widget y su posición en
        self._rows. Después de eliminar, refresca los comandos de los
        botones "-" restantes.

        Args:
            frame: Frame tkinter de la fila a eliminar.
            idx:   Índice de la fila en self._rows (puede estar desactualizado;
                buscamos por widget para mayor seguridad).
        """
        # Buscar la fila por su frame (el frame está dentro de self._inner)
        children = list(self._inner.winfo_children())
        for i, child in enumerate(children):
            if child is frame:
                frame.destroy()
                if i < len(self._rows):
                    self._rows.pop(i)
                break
        self._refresh_delete_commands()

    def _refresh_delete_commands(self):
        r"""
        Reconstruye los comandos de los botones "-" de cada fila con
        sus índices y referencias de frame actualizados.
        Necesario después de cualquier adición o eliminación de filas.
        """
        children = list(self._inner.winfo_children())
        for i, child in enumerate(children):
            # Buscar el botón "−" dentro del frame de la fila
            for widget in child.winfo_children():
                if isinstance(widget, tk.Button) and widget.cget("text") == "-":  # noqa: E501
                    # Re-asignar el command con el frame e índice actuales
                    widget.config(
                        command=lambda f=child,
                        idx=i: self._remove_row(f, idx)
                    )

    def _btn_add(self, parent, text: str, cmd) -> tk.Button:
        r"""
        Crea el botón de agregar fila con el estilo del panel.

        Args:
            parent: Widget padre del botón.
            text:   Texto del botón (ej: "+ Agregar").
            cmd:    Callback al hacer clic.

        Returns:
            tk.Button configurado.
        """
        btn = tk.Button(
            parent, text=text, command=cmd,
            font=(C["mono"], 8, "bold"),
            bg=C["bg3"], fg=C["green"],
            activebackground=C["border2"], activeforeground=C["green"],
            relief="flat", bd=0, cursor="hand2", padx=8, pady=3
        )
        btn.bind("<Enter>", lambda e: btn.config(bg=C["border"]))
        btn.bind("<Leave>", lambda e: btn.config(bg=C["bg3"]))
        return btn
