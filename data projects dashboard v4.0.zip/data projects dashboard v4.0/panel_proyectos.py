r"""
Panel de Gestión de Proyectos — Data Team Dashboard v5.0
Punto de entrada principal. Ejecutar: python panel_proyectos.py
"""

import tkinter as tk
from panel.main_panel import PanelProyectos
from panel.config import DATA_DIR


def main():
    r"""
    Punto de entrada principal del panel.

        1. Verifica que DATA_DIR exista y avisa si no se encuentra.
        2. Crea la ventana raíz de tkinter con fondo oscuro.
        3. Instancia PanelProyectos y arranca el bucle principal.
    """
    # Advertencia si no se encuentra el directorio de datos
    if not DATA_DIR.exists():
        print(f"""
┌─ ADVERTENCIA ──────────────────────────────────────────────────┐
│  No se encontró el directorio de datos:                        │
│                   {str(DATA_DIR):<62}                          │
│                                                                │
│  Asegúrate de ejecutar el script desde la raíz del proyecto.   │
│  Puedes usar el botón 'Abrir otro JSON' para cargar un archivo │
│  desde cualquier ubicación del sistema.                        │
└────────────────────────────────────────────────────────────────┘
        """)

    root = tk.Tk()
    root.configure(bg="#0a1520")

    # Suprimir el ícono de tkinter (no es crítico si falla)
    try:
        root.iconbitmap(default="")
    except Exception:
        pass

    # Iniciar la aplicación
    PanelProyectos(root)
    root.mainloop()


if __name__ == "__main__":
    main()
