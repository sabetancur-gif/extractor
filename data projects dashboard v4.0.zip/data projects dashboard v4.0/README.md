# Engineering Dashboard · estructura modular

## Estructura

- `index.html`: punto de entrada.
- `assets/css/styles.css`: estilos globales y componentes.
- `assets/js/data.js`: datos de ejemplo, estado global y almacenamiento.
- `assets/js/utils.js`: funciones auxiliares reutilizables.
- `assets/js/calculations.js`: métricas del portafolio.
- `assets/js/renderers.js`: renderizado de secciones, tarjetas y vistas.
- `assets/js/actions.js`: acciones de usuario, persistencia y mutaciones.
- `assets/js/app.js`: animación de fondo y arranque.

## Ejecución

- Abre `index.html` en un navegador moderno.
-
-


## Nota

Ten presente limpiar la caché del navegador si ya has ejecutado versiones anteriores del proyecto.
