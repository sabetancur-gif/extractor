r"""
Server.py

Servidor HTTP local que:
1. Sirve un dashboard estático en http://localhost:8000
2. Expone un endpoint POST (/open-panel) para abrir un panel externo

Uso:
    Ejecutar: python server.py
Luego abrir en el el navegador:
    http://localhost:8000

Notas:
    - El panel se ejecuta en un proceso independiente.
    - Se habilita CORS (Cross-Origin Resource Sharing)
        Para permitir llamadas desde el frontend.

"""
import sys
import threading
import webbrowser
import subprocess
from http.server import SimpleHTTPRequestHandler, HTTPServer
from pathlib import Path

PORT = 8000  # Puerto de ejecución del HTTP sercer

# Ruta al script del panel que se abrirá bajo demanda
PANEL_SCRIPT = Path(__file__).parent / "panel_proyectos.py"


class Handler(SimpleHTTPRequestHandler):
    r"""
    Manejador de peticiones HTTP.

    Extiende SimpleHTTPRequestHandler para:
        - Servir archivos estáticos (frontend/dashboard)
        - Manejar endpoint POST personalizado para abrir el panel

    Nota:
        SimpleHTTPRequestHandler es una clase del módulo 'http.server'
        Que ya sebe hacer cosas como:
            - Servir archivos (HTML, JC, CSS)
            - Responder peticiones GET
            - Manejar rutas básicas
        Es decir, ya implementa un servidor web simple
    """
    def do_POST(self):
        r"""
        Maneja solicitudes HTTP POST.

        Endpoint soportado:
            POST / open-panel

        Acción:
            Lanza el script del panel en un proceso independiente.
        """
        if self.path == '/open-panel':
            try:
                # Lanza el panel sin bloquear el main servidor
                subprocess.Popen(
                    [sys.executable, str(PANEL_SCRIPT)],
                    cwd=str(PANEL_SCRIPT.parent)
                )
                self._respond(200, b'ok')
            except Exception as e:
                # Devuelve error si falla la ejecución
                self._respond(500, str(e).encode())
        else:
            self._respond(404, b'not found')

    def _respond(self, code, body):
        r"""
        Envía una respuesta HTTP simple.

        Args:
            - code (int): código de estado HTTP.
            - body (bytes): Cuerpo de la respuesta.
        """
        self.send_response(code)
        self.send_header('Content-Type', 'text/plain')

        # Permite llamadas desde otros orígenes (ej: frontend en otro puerto)
        self.send_header('Access-Control-Allow-Origin', '*')

        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        r"""
        Personaliza el logging del servidor.

        Solo muestra logs de errores para evitar ruido excesivo
        (omite respuestas 200 y 304)
        """
        if args and str(args[1]) not in ('200', '304'):
            super().log_message(fmt, *args)


def main():
    r"""
    Inicializa y ejecuta el servidor HTTP.

    - Inicia el servidor en localhost:PORT
    - Abre automáticamente el navegador
    - Mantiene el servicio en ejecución indefinida
    """
    server = HTTPServer(('localhost', PORT), Handler)
    url = f'http://localhost:{PORT}'
    print(f'  Dashboard corriendo en {url}')
    print(f'  Panel: {PANEL_SCRIPT.name}')
    print('   Ctrl+C para detener\n')

    # Abrir el navegador automáticamente tras 1 segundo
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()

    # Ejecuta el servidor indefinidamente
    server.serve_forever()


if __name__ == '__main__':
    main()
