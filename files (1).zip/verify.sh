#!/usr/bin/env bash
# ================================================================
#  verify.sh — Verificación completa del entorno local
#  Ejecutar antes de iniciar para asegurarse de que todo esté listo
#  Uso: bash verify.sh
# ================================================================
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Colores ──────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

PASS=0; FAIL=0; WARN=0

ok()   { echo -e "  ${GREEN}✓${NC}  $*"; ((PASS++)) || true; }
fail() { echo -e "  ${RED}✗${NC}  $*"; ((FAIL++)) || true; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $*"; ((WARN++)) || true; }
hdr()  { echo -e "\n${BOLD}${CYAN}$*${NC}"; }

echo -e "${BOLD}${CYAN}"
echo "  MailAI Pro — Verificación del entorno"
echo -e "${NC}"

# ── Cargar .env ──────────────────────────────────────────────
ENV_FILE="$DIR/.env"
if [[ -f "$ENV_FILE" ]]; then
    set -a; source "$ENV_FILE"; set +a
    OLLAMA_URL="${OLLAMA_BASE_URL:-http://localhost:11434}"
    OLLAMA_MODEL="${OLLAMA_MODEL:-llama3.2:3b}"
else
    OLLAMA_URL="http://localhost:11434"
    OLLAMA_MODEL="llama3.2:3b"
fi

# ── 1. Sistema ───────────────────────────────────────────────
hdr "1. Dependencias del sistema"

check_ver() {
    local cmd="$1"; local min_ver="$2"; local get_ver="$3"
    if command -v "$cmd" &>/dev/null; then
        local ver; ver=$(eval "$get_ver" 2>/dev/null | head -1 || echo "?")
        ok "$cmd encontrado: $ver"
    else
        fail "$cmd no instalado (mínimo $min_ver)"
    fi
}

check_ver python3 "3.10" "python3 --version"
check_ver node    "18"   "node --version"
check_ver npm     "9"    "npm --version"
check_ver curl    "-"    "curl --version | head -1"

if command -v ollama &>/dev/null; then
    ok "ollama: $(ollama --version 2>/dev/null | head -1 || echo 'instalado')"
else
    warn "ollama no encontrado como comando (puede estar en Docker)"
fi

# ── 2. Archivos del proyecto ──────────────────────────────────
hdr "2. Archivos del proyecto"

check_file() {
    local path="$DIR/$1"
    if [[ -f "$path" ]]; then
        ok "$1"
    else
        fail "$1 — FALTA"
    fi
}

check_file ".env"
check_file "backend/main.py"
check_file "backend/classifier.py"
check_file "backend/ollama_client.py"
check_file "backend/config.py"
check_file "backend/database.py"
check_file "backend/email_fetcher.py"
check_file "backend/rules_engine.py"
check_file "backend/scheduler.py"
check_file "backend/requirements.txt"
check_file "frontend/package.json"
check_file "frontend/vite.config.js"
check_file "frontend/index.html"
check_file "frontend/src/main.jsx"
check_file "frontend/src/App.jsx"
check_file "frontend/src/index.css"

# ── 3. Entorno Python ────────────────────────────────────────
hdr "3. Entorno Python (backend)"

if [[ -d "$DIR/backend/venv" ]]; then
    ok "Entorno virtual existe"
    source "$DIR/backend/venv/bin/activate"

    for pkg in fastapi uvicorn httpx pydantic apscheduler chardet; do
        if python3 -c "import $pkg" 2>/dev/null; then
            ok "  Python: $pkg"
        else
            fail "  Python: $pkg — NO instalado (pip install $pkg)"
        fi
    done

    # Verificar que anthropic NO esté instalado (no queremos deps externas)
    if python3 -c "import anthropic" 2>/dev/null; then
        warn "  anthropic está instalado (no es necesario en modo Ollama)"
    else
        ok "  anthropic NO instalado (correcto para modo local)"
    fi

    deactivate
else
    fail "Entorno virtual no encontrado en backend/venv"
    fail "Ejecuta: cd backend && python3 -m venv venv && source venv/bin/activate && pip install -r requirements.txt"
fi

# ── 4. Frontend Node ─────────────────────────────────────────
hdr "4. Frontend (Node.js)"

if [[ -d "$DIR/frontend/node_modules" ]]; then
    ok "node_modules existe"
    for pkg in react recharts zustand; do
        if [[ -d "$DIR/frontend/node_modules/$pkg" ]]; then
            ok "  npm: $pkg"
        else
            fail "  npm: $pkg — NO instalado (cd frontend && npm install)"
        fi
    done
else
    fail "node_modules no encontrado"
    fail "Ejecuta: cd frontend && npm install"
fi

# ── 5. Ollama ────────────────────────────────────────────────
hdr "5. Ollama (IA local)"

OLLAMA_RUNNING=false
if curl -sf "$OLLAMA_URL/api/tags" > /dev/null 2>&1; then
    ok "Ollama respondiendo en $OLLAMA_URL"
    OLLAMA_RUNNING=true

    # Verificar modelo
    MODELS_JSON=$(curl -sf "$OLLAMA_URL/api/tags" 2>/dev/null || echo '{"models":[]}')
    MODEL_BASE=$(echo "$OLLAMA_MODEL" | cut -d: -f1)
    if echo "$MODELS_JSON" | grep -q "$MODEL_BASE"; then
        ok "Modelo $OLLAMA_MODEL disponible"
    else
        fail "Modelo $OLLAMA_MODEL NO descargado"
        warn "  Descárgalo: ollama pull $OLLAMA_MODEL"

        # Listar modelos disponibles
        echo "  Modelos instalados actualmente:"
        echo "$MODELS_JSON" | grep -o '"name":"[^"]*"' | cut -d: -f2 | tr -d '"' \
            | sed 's/^/    - /' || echo "    (ninguno)"
    fi

    # Test rápido de clasificación
    echo ""
    info "  Probando clasificación con Ollama..."
    TEST_RESULT=$(curl -sf -X POST "$OLLAMA_URL/api/generate" \
        -H "Content-Type: application/json" \
        -d "{\"model\":\"$OLLAMA_MODEL\",\"prompt\":\"Responde solo con: {\\\"ok\\\":true}\",\"stream\":false,\"format\":\"json\"}" \
        2>/dev/null || echo "ERROR")

    if echo "$TEST_RESULT" | grep -q '"response"'; then
        ok "  Test de generación JSON: EXITOSO"
    else
        warn "  Test de generación: sin respuesta (el modelo puede estar cargando)"
    fi
else
    fail "Ollama NO responde en $OLLAMA_URL"
    warn "  Inicia Ollama: ollama serve"
    warn "  O en Docker: docker compose up ollama -d"
fi

# ── 6. Variables de entorno ──────────────────────────────────
hdr "6. Variables de entorno (.env)"

check_env() {
    local key="$1"; local val="${!key:-}"
    if [[ -n "$val" ]]; then
        # Ocultar valores sensibles
        if [[ "$key" == *"KEY"* || "$key" == *"PASSWORD"* ]]; then
            ok "$key = ***"
        else
            ok "$key = $val"
        fi
    else
        warn "$key no definida (usando valor por defecto)"
    fi
}

check_env OLLAMA_BASE_URL
check_env OLLAMA_MODEL
check_env OLLAMA_TIMEOUT
check_env DATABASE_URL
check_env SECRET_KEY

# Verificar que NO hay API keys externas
if [[ -n "${ANTHROPIC_API_KEY:-}" ]]; then
    warn "ANTHROPIC_API_KEY encontrada — no es necesaria en modo Ollama"
fi

# ── 7. Red y puertos ─────────────────────────────────────────
hdr "7. Puertos"

check_port() {
    local port="$1"; local name="$2"
    if command -v lsof &>/dev/null; then
        if lsof -ti ":$port" &>/dev/null; then
            warn "Puerto $port ($name) ya en uso"
        else
            ok "Puerto $port ($name) disponible"
        fi
    elif command -v ss &>/dev/null; then
        if ss -tlnp | grep -q ":$port "; then
            warn "Puerto $port ($name) ya en uso"
        else
            ok "Puerto $port ($name) disponible"
        fi
    else
        ok "Puerto $port ($name) — no se puede verificar"
    fi
}

check_port 3000  "Frontend"
check_port 8000  "Backend"
check_port 11434 "Ollama"

# ── Resumen final ─────────────────────────────────────────────
echo ""
echo -e "${BOLD}══════════════════════════════════════${NC}"
echo -e "  Resultados: ${GREEN}$PASS OK${NC} | ${YELLOW}$WARN advertencias${NC} | ${RED}$FAIL errores${NC}"
echo -e "${BOLD}══════════════════════════════════════${NC}"
echo ""

if [[ $FAIL -eq 0 ]]; then
    echo -e "${GREEN}${BOLD}✅ Todo listo. Puedes iniciar con:${NC}"
    echo "   bash start-dev.sh"
elif [[ $FAIL -le 3 ]]; then
    echo -e "${YELLOW}${BOLD}⚠  Algunos problemas menores. Revisa los errores arriba.${NC}"
    echo "   Después inicia con: bash start-dev.sh"
else
    echo -e "${RED}${BOLD}✗  Hay errores que corregir antes de iniciar.${NC}"
    echo "   Ejecuta: bash setup_ollama.sh"
fi
echo ""
