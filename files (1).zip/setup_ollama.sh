#!/usr/bin/env bash
# ================================================================
#  setup.sh — Instalación completa MailAI Pro con Ollama local
#  Sin APIs externas. Todo corre en tu máquina.
#
#  Uso: chmod +x setup.sh && ./setup.sh
# ================================================================
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

ok()     { echo -e "${GREEN}✓${NC}  $*"; }
info()   { echo -e "${BLUE}ℹ${NC}  $*"; }
warn()   { echo -e "${YELLOW}⚠${NC}  $*"; }
err()    { echo -e "${RED}✗${NC}  $*" >&2; }
header() { echo -e "\n${BOLD}${CYAN}── $* ──${NC}"; }

# ── Banner ───────────────────────────────────────────────────
echo -e "${BOLD}${CYAN}"
cat << 'EOF'
  __  __       _ _   _    _____   _____
 |  \/  | __ _(_) | /_\  |_ _| | |  _ \ _ __ ___
 | |\/| |/ _` | | |/ _ \  | |  |_| |_) | '__/ _ \
 | |  | | (_| | | / ___ \ | | |_ |  __/| | | (_) |
 |_|  |_|\__,_|_|_/_/   \_\___(_)|_|   |_|  \___/

  Modo LOCAL con Ollama — Sin APIs externas
EOF
echo -e "${NC}"

# ── Verificar SO ─────────────────────────────────────────────
OS="$(uname -s)"
info "Sistema operativo: $OS"

# ── Verificar dependencias ───────────────────────────────────
header "Verificando dependencias"

need_cmd() {
    if command -v "$1" &>/dev/null; then
        ok "$1 → $(command -v "$1")"
    else
        err "$1 no encontrado. Instálalo y vuelve a ejecutar."
        exit 1
    fi
}

need_cmd python3
need_cmd pip3
need_cmd node
need_cmd npm
need_cmd curl

PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
NODE_VER=$(node --version)
info "Python $PY_VER | Node $NODE_VER"

if python3 -c "import sys; exit(0 if sys.version_info >= (3,10) else 1)"; then
    ok "Python >= 3.10"
else
    err "Se requiere Python 3.10+. Tienes $PY_VER"; exit 1
fi

# ── Instalar / verificar Ollama ──────────────────────────────
header "Configurando Ollama (IA local)"

if command -v ollama &>/dev/null; then
    OLLAMA_VER=$(ollama --version 2>/dev/null | head -1 || echo "instalado")
    ok "Ollama ya instalado: $OLLAMA_VER"
else
    info "Instalando Ollama..."
    if [[ "$OS" == "Darwin" ]]; then
        if command -v brew &>/dev/null; then
            brew install ollama
        else
            curl -fsSL https://ollama.com/install.sh | sh
        fi
    elif [[ "$OS" == "Linux" ]]; then
        curl -fsSL https://ollama.com/install.sh | sh
    else
        warn "Windows detectado. Descarga Ollama desde: https://ollama.com/download"
        warn "Instálalo y vuelve a ejecutar este script."
        read -rp "¿Ya instalaste Ollama? (s/N): " ans
        [[ "$ans" =~ ^[sS]$ ]] || exit 1
    fi
    ok "Ollama instalado"
fi

# ── Iniciar Ollama si no está corriendo ─────────────────────
if ollama list &>/dev/null 2>&1; then
    ok "Ollama está corriendo"
else
    info "Iniciando Ollama en background..."
    if [[ "$OS" == "Darwin" ]]; then
        open -a Ollama 2>/dev/null || ollama serve &>/dev/null &
    else
        ollama serve &>/dev/null &
    fi
    sleep 3
    ok "Ollama iniciado"
fi

# ── Seleccionar modelo ───────────────────────────────────────
header "Selección de modelo de IA"

echo ""
echo "  Modelos disponibles (de menor a mayor calidad/recursos):"
echo ""
echo "  1) llama3.2:1b  — Muy rápido, calidad básica        (~800 MB)"
echo "  2) llama3.2:3b  — Rápido, buena calidad              (~2 GB)   ← Recomendado inicio"
echo "  3) llama3.1:8b  — Mejor clasificación                (~5 GB)   ← Recomendado producción"
echo "  4) mistral:7b   — Excelente para español              (~4 GB)"
echo "  5) qwen2.5:7b   — Multilingüe, muy bueno             (~5 GB)"
echo "  6) gemma3:4b    — Compacto y eficiente               (~3 GB)"
echo "  7) Otro         — Ingresar manualmente"
echo ""

read -rp "  Elige un modelo [2]: " MODEL_CHOICE
MODEL_CHOICE="${MODEL_CHOICE:-2}"

case "$MODEL_CHOICE" in
    1) SELECTED_MODEL="llama3.2:1b" ;;
    2) SELECTED_MODEL="llama3.2:3b" ;;
    3) SELECTED_MODEL="llama3.1:8b" ;;
    4) SELECTED_MODEL="mistral:7b"  ;;
    5) SELECTED_MODEL="qwen2.5:7b"  ;;
    6) SELECTED_MODEL="gemma3:4b"   ;;
    7) read -rp "  Nombre del modelo: " SELECTED_MODEL ;;
    *) SELECTED_MODEL="llama3.2:3b" ;;
esac

info "Modelo seleccionado: $SELECTED_MODEL"

# Descargar modelo si no está disponible
if ollama list 2>/dev/null | grep -q "$(echo "$SELECTED_MODEL" | cut -d: -f1)"; then
    ok "Modelo $SELECTED_MODEL ya disponible"
else
    info "Descargando $SELECTED_MODEL (puede tardar varios minutos)..."
    ollama pull "$SELECTED_MODEL"
    ok "Modelo $SELECTED_MODEL descargado"
fi

# ── Crear estructura de proyecto ─────────────────────────────
header "Creando estructura del proyecto"

PROJECT="mailai-pro"
mkdir -p "$PROJECT/backend"
mkdir -p "$PROJECT/frontend/src/pages"
mkdir -p "$PROJECT/frontend/src/components"
mkdir -p "$PROJECT/frontend/src/services"
mkdir -p "$PROJECT/frontend/src/store"
mkdir -p "$PROJECT/data"

ok "Estructura creada en ./$PROJECT/"

# ── Configurar .env ──────────────────────────────────────────
header "Generando .env"

SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")

cat > "$PROJECT/.env" <<EOF
# MailAI Pro — Configuración local (generado por setup.sh)
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=$SELECTED_MODEL
OLLAMA_TIMEOUT=120
DATABASE_URL=emails.db
DEBUG=false
PORT=8000
SECRET_KEY=$SECRET
EOF

ok ".env generado con modelo $SELECTED_MODEL"

# ── Backend ──────────────────────────────────────────────────
header "Instalando Backend Python"

cd "$PROJECT/backend"
python3 -m venv venv
source venv/bin/activate

pip install --quiet --upgrade pip
pip install --quiet \
    "fastapi==0.115.0" \
    "uvicorn[standard]==0.30.6" \
    "httpx==0.27.2" \
    "pydantic==2.9.2" \
    "pydantic-settings==2.5.2" \
    "apscheduler==3.10.4" \
    "chardet==5.2.0" \
    "python-multipart==0.0.12" \
    "websockets==13.1" \
    "python-dotenv==1.0.1"

pip freeze > requirements.txt
deactivate
cd ../..

ok "Backend Python instalado"

# ── Frontend ─────────────────────────────────────────────────
header "Instalando Frontend React"

cd "$PROJECT/frontend"

# Crear package.json si no existe
if [[ ! -f "package.json" ]]; then
cat > package.json << 'PKGJSON'
{
  "name": "mailai-pro",
  "version": "2.0.0",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "recharts": "^2.12.7",
    "zustand": "^5.0.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.3.1",
    "vite": "^5.4.8"
  }
}
PKGJSON
fi

# Crear vite.config.js
cat > vite.config.js << 'VITECONF'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '')
      },
      '/ws': {
        target: 'ws://localhost:8000',
        ws: true,
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/ws/, '/ws')
      }
    }
  }
})
VITECONF

# index.html
cat > index.html << 'HTML'
<!DOCTYPE html>
<html lang="es" data-theme="dark">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MailAI Pro — Local</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
HTML

mkdir -p src
cat > src/main.jsx << 'MAINJSX'
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode><App /></React.StrictMode>
)
MAINJSX

npm install --silent
cd ../..
ok "Frontend instalado"

# ── Scripts de inicio ────────────────────────────────────────
header "Creando scripts de inicio"

# start-dev.sh — Levanta todo
cat > "$PROJECT/start-dev.sh" << 'STARTSH'
#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

# Verificar Ollama
if ! ollama list &>/dev/null 2>&1; then
    echo "⚠  Ollama no está corriendo. Iniciando..."
    ollama serve &>/dev/null &
    sleep 3
fi

# Backend
cd "$DIR/backend"
source venv/bin/activate
cp "$DIR/.env" .env 2>/dev/null || true
uvicorn main:app --reload --port 8000 &
BACKEND_PID=$!
deactivate

# Frontend
cd "$DIR/frontend"
npm run dev &
FRONTEND_PID=$!

echo ""
echo "✅ MailAI Pro corriendo (modo local — Ollama):"
echo "   🌐 App:     http://localhost:3000"
echo "   ⚙  API:     http://localhost:8000"
echo "   📖 Docs:    http://localhost:8000/docs"
echo "   🤖 Ollama:  http://localhost:11434"
echo ""
echo "Presiona Ctrl+C para detener todo."

trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; echo '⛔ Detenido.'" EXIT INT TERM
wait
STARTSH
chmod +x "$PROJECT/start-dev.sh"

ok "Scripts creados"

# ── Verificación final ───────────────────────────────────────
header "Verificación final"

OLLAMA_OK=false
if ollama list 2>/dev/null | grep -q "$(echo "$SELECTED_MODEL" | cut -d: -f1)"; then
    ok "Ollama: corriendo con modelo $SELECTED_MODEL"
    OLLAMA_OK=true
else
    warn "Ollama: modelo no detectado (puede tardar un momento)"
fi

if [[ -f "$PROJECT/backend/venv/bin/activate" ]]; then
    ok "Backend: entorno Python listo"
fi

if [[ -d "$PROJECT/frontend/node_modules" ]]; then
    ok "Frontend: dependencias instaladas"
fi

# ── Instrucciones finales ────────────────────────────────────
echo ""
echo -e "${BOLD}${CYAN}════════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}  ¡Instalación completa!${NC}"
echo -e "${BOLD}${CYAN}════════════════════════════════════════${NC}"
echo ""
echo -e "${BOLD}Copia los archivos del proyecto:${NC}"
echo "  (ver INDICE_ARCHIVOS.txt para el mapa completo)"
echo ""
echo -e "${BOLD}Inicia la aplicación:${NC}"
echo "  cd $PROJECT && bash start-dev.sh"
echo ""
echo -e "${BOLD}O con Docker (Ollama incluido):${NC}"
echo "  cd $PROJECT && docker compose up -d"
echo ""
echo -e "${BOLD}Gestión de modelos Ollama:${NC}"
echo "  ollama list                    # modelos disponibles"
echo "  ollama pull llama3.1:8b        # mejor calidad"
echo "  ollama run $SELECTED_MODEL     # probar en terminal"
echo ""
