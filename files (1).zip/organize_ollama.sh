#!/usr/bin/env bash
# ================================================================
#  organize_ollama.sh — Organiza TODOS los archivos del proyecto
#  MailAI Pro en modo Ollama (sin APIs externas)
#
#  Uso:
#    1. Descarga todos los archivos en una carpeta (ej: ~/Downloads/mailai/)
#    2. Ejecuta: bash organize_ollama.sh ~/Downloads/mailai/
#    3. El proyecto queda en ./mailai-pro/
#    4. Luego ejecuta: bash setup_ollama.sh
# ================================================================
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[1;36m'; BOLD='\033[1m'; NC='\033[0m'

ok()   { echo -e "  ${GREEN}✓${NC}  $*"; }
skip() { echo -e "  ${YELLOW}⚠${NC}  $* — no encontrado (cópialo manualmente)"; }
hdr()  { echo -e "\n${BOLD}${CYAN}── $* ──${NC}"; }

SRC="${1:-.}"       # carpeta con archivos descargados
DST="./mailai-pro"  # destino

echo -e "${BOLD}${CYAN}"
echo "  MailAI Pro — Organizador de archivos (modo Ollama)"
echo "  Origen : $SRC"
echo "  Destino: $DST"
echo -e "${NC}"

# ── Crear estructura completa ────────────────────────────────
mkdir -p "$DST/backend"
mkdir -p "$DST/frontend/src/pages"
mkdir -p "$DST/frontend/src/components"
mkdir -p "$DST/frontend/src/services"
mkdir -p "$DST/frontend/src/store"
mkdir -p "$DST/data"
ok "Estructura de carpetas creada"

# ── Función de copia segura ───────────────────────────────────
cp_file() {
    local src_name="$1"; local dst_rel="$2"
    local src="$SRC/$src_name"; local dst="$DST/$dst_rel"
    if [[ -f "$src" ]]; then
        mkdir -p "$(dirname "$dst")"
        cp "$src" "$dst"
        ok "$src_name → $dst_rel"
    else
        skip "$src_name"
    fi
}

# ═══ RAÍZ DEL PROYECTO ═══════════════════════════════════════
hdr "Raíz del proyecto"

# .env desde el archivo Ollama
if [[ -f "$SRC/dot_env_ollama.txt" ]]; then
    cp "$SRC/dot_env_ollama.txt" "$DST/.env"
    ok "dot_env_ollama.txt → .env"
elif [[ -f "$SRC/.env" ]]; then
    cp "$SRC/.env" "$DST/.env"
    ok ".env copiado"
else
    # Generar .env mínimo
    cat > "$DST/.env" << 'EOF'
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama3.2:3b
OLLAMA_TIMEOUT=120
DATABASE_URL=emails.db
DEBUG=false
PORT=8000
SECRET_KEY=cambia-esto-por-clave-aleatoria-segura
EOF
    ok ".env generado con valores por defecto (edita OLLAMA_MODEL si quieres)"
fi

# docker-compose: preferir la versión Ollama
if [[ -f "$SRC/docker-compose-ollama.yml" ]]; then
    cp "$SRC/docker-compose-ollama.yml" "$DST/docker-compose.yml"
    ok "docker-compose-ollama.yml → docker-compose.yml"
else
    cp_file "docker-compose.yml" "docker-compose.yml"
fi

cp_file "docker-compose.override.yml"  "docker-compose.override.yml"
cp_file "start-dev.sh"                 "start-dev.sh"
cp_file "setup_ollama.sh"              "setup.sh"
cp_file "verify.sh"                    "verify.sh"
cp_file "README_ollama.md"             "README.md"
cp_file "INDICE_OLLAMA.txt"            "INDICE.txt"

# .gitignore
if [[ -f "$SRC/dot_gitignore.txt" ]]; then
    cp "$SRC/dot_gitignore.txt" "$DST/.gitignore"
    ok "dot_gitignore.txt → .gitignore"
fi

# ═══ BACKEND — archivos Ollama (nuevos / reemplazados) ═══════
hdr "Backend — Archivos Ollama (nuevos)"

cp_file "backend__ollama_client.py"      "backend/ollama_client.py"
cp_file "backend__classifier_ollama.py"  "backend/classifier.py"
cp_file "backend__config_ollama.py"      "backend/config.py"
cp_file "backend__main_ollama.py"        "backend/main.py"
cp_file "backend__Dockerfile_ollama"     "backend/Dockerfile"

# requirements.txt Ollama (sin anthropic)
if [[ -f "$SRC/backend__requirements_ollama.txt" ]]; then
    cp "$SRC/backend__requirements_ollama.txt" "$DST/backend/requirements.txt"
    ok "backend__requirements_ollama.txt → backend/requirements.txt"
else
    # Generar requirements.txt mínimo
    cat > "$DST/backend/requirements.txt" << 'EOF'
fastapi==0.115.0
uvicorn[standard]==0.30.6
httpx==0.27.2
pydantic==2.9.2
pydantic-settings==2.5.2
apscheduler==3.10.4
chardet==5.2.0
python-multipart==0.0.12
websockets==13.1
python-dotenv==1.0.1
EOF
    ok "requirements.txt generado (sin anthropic)"
fi

# ═══ BACKEND — archivos sin cambios ══════════════════════════
hdr "Backend — Archivos sin cambios"

cp_file "backend__database.py"     "backend/database.py"
cp_file "backend__email_fetcher.py" "backend/email_fetcher.py"
cp_file "backend__rules_engine.py" "backend/rules_engine.py"
cp_file "backend__scheduler.py"    "backend/scheduler.py"

# .env del backend (copia del raíz)
cp "$DST/.env" "$DST/backend/.env" 2>/dev/null && ok ".env → backend/.env" || true

# ═══ FRONTEND — configuración ════════════════════════════════
hdr "Frontend — Configuración"

cp_file "frontend__nginx.conf"   "frontend/nginx.conf"
cp_file "frontend__Dockerfile"   "frontend/Dockerfile"
cp_file "frontend__index.css"    "frontend/src/index.css"

# package.json, vite.config.js, main.jsx, index.html desde txt combinado
PKG_SRC="$SRC/frontend__package_vite_main.txt"
if [[ -f "$PKG_SRC" ]]; then
    # Extraer secciones usando marcadores de comentario
    python3 - "$PKG_SRC" "$DST/frontend" << 'PYEOF' 2>/dev/null || {
import sys, re, os

src = open(sys.argv[1]).read()
out_dir = sys.argv[2]
os.makedirs(out_dir + "/src", exist_ok=True)

# Detectar bloques por marcadores de comentario
sections = {
    "package.json":     r'(?s)\{[^{}]*"name":\s*"mailai-pro".*?\}(?=\s*//)' ,
    "vite.config.js":   r'(?s)import \{ defineConfig \}.*?(?=// ═|$)',
    "src/main.jsx":     r'(?s)import React from.*?(?=// ═|$)',
    "index.html":       r'(?s)<!DOCTYPE html>.*?</html>',
}

# Estrategia simple: dividir por comentarios de sección
parts = re.split(r'// ═+.*?═+\n', src)
files_map = ["package.json", "vite.config.js", "src/main.jsx", "index.html"]
for i, part in enumerate(parts):
    if i < len(files_map) and part.strip():
        fpath = os.path.join(out_dir, files_map[i])
        os.makedirs(os.path.dirname(fpath), exist_ok=True)
        open(fpath, 'w').write(part.strip() + '\n')
        print(f"  Extraído: {files_map[i]}")
PYEOF
    # Si python3 falló, copiar todo el archivo como referencia
    cp "$PKG_SRC" "$DST/frontend/SEPARAR_MANUALMENTE.txt"
    echo -e "  ${YELLOW}⚠${NC}  Copia manual: revisa frontend/SEPARAR_MANUALMENTE.txt"
}
    ok "frontend__package_vite_main.txt → extraído"
fi

# Crear package.json si no existe
if [[ ! -f "$DST/frontend/package.json" ]]; then
    cat > "$DST/frontend/package.json" << 'PKGJSON'
{
  "name": "mailai-pro",
  "version": "2.0.0",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "recharts": "^2.12.7",
    "zustand": "^5.0.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.3.1",
    "vite": "^5.4.8"
  }
}
PKGJSON
    ok "package.json generado"
fi

# Crear vite.config.js si no existe
if [[ ! -f "$DST/frontend/vite.config.js" ]]; then
    cat > "$DST/frontend/vite.config.js" << 'VITECONF'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '')
      },
      '/ws': {
        target: 'ws://localhost:8000',
        ws: true,
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/ws/, '/ws')
      }
    }
  }
})
VITECONF
    ok "vite.config.js generado"
fi

# index.html
if [[ ! -f "$DST/frontend/index.html" ]]; then
    cat > "$DST/frontend/index.html" << 'HTML'
<!DOCTYPE html>
<html lang="es" data-theme="dark">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MailAI Pro — Local</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
HTML
    ok "index.html generado"
fi

# main.jsx
if [[ ! -f "$DST/frontend/src/main.jsx" ]]; then
    mkdir -p "$DST/frontend/src"
    cat > "$DST/frontend/src/main.jsx" << 'MAINJSX'
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode><App /></React.StrictMode>
)
MAINJSX
    ok "src/main.jsx generado"
fi

# ═══ FRONTEND — servicios y estado ═══════════════════════════
hdr "Frontend — Servicios y Estado"

cp_file "frontend__api.js"    "frontend/src/services/api.js"
cp_file "frontend__store.js"  "frontend/src/store/index.js"

# ═══ FRONTEND — App root ═════════════════════════════════════
hdr "Frontend — App Root"
cp_file "frontend__App.jsx" "frontend/src/App.jsx"

# ═══ FRONTEND — Componentes ══════════════════════════════════
hdr "Frontend — Componentes"

cp_file "frontend__AIInsights.jsx"    "frontend/src/components/AIInsights.jsx"
cp_file "frontend__Topbar.jsx"        "frontend/src/components/Topbar.jsx"
cp_file "frontend__CommandPalette.jsx" "frontend/src/components/CommandPalette.jsx"

# Sidebar y Toast desde components_core
CORE_SRC="$SRC/frontend__components_core.jsx"
if [[ -f "$CORE_SRC" ]]; then
    cp "$CORE_SRC" "$DST/frontend/src/components/_components_core.jsx"

    # Extraer Sidebar
    python3 - "$CORE_SRC" "$DST/frontend/src/components" << 'PYEOF' 2>/dev/null || \
        echo -e "  ${YELLOW}⚠${NC}  Extrae Sidebar.jsx y Toast.jsx de _components_core.jsx manualmente"

import sys, re, os
src = open(sys.argv[1]).read()
out = sys.argv[2]

# Sidebar: desde 'export default function Sidebar' hasta el siguiente export
m = re.search(r'(import.*?from.*?store.*?\n+export default function Sidebar.*?)(?=\n// ═|$)', src, re.DOTALL)
if m:
    content = "import { useStore } from '../store'\n\n" + m.group(1)
    open(os.path.join(out, 'Sidebar.jsx'), 'w').write(content)
    print("  Extraído: Sidebar.jsx")

# Toast
m = re.search(r'(export function Toast.*?export default function ToastContainer.*?\})', src, re.DOTALL)
if m:
    content = "import { useStore } from '../store'\n\n" + m.group(1)
    open(os.path.join(out, 'Toast.jsx'), 'w').write(content)
    print("  Extraído: Toast.jsx")
PYEOF
    ok "frontend__components_core.jsx → Sidebar.jsx + Toast.jsx"
else
    skip "frontend__components_core.jsx"
fi

# ═══ FRONTEND — Páginas ═══════════════════════════════════════
hdr "Frontend — Páginas"

cp_file "frontend__Dashboard.jsx" "frontend/src/pages/Dashboard.jsx"
cp_file "frontend__Inbox.jsx"     "frontend/src/pages/Inbox.jsx"
cp_file "frontend__Contacts.jsx"  "frontend/src/pages/Contacts.jsx"

# Analytics y Settings desde archivo combinado
ANSET_SRC="$SRC/frontend__Analytics_Settings.jsx"
if [[ -f "$ANSET_SRC" ]]; then
    cp "$ANSET_SRC" "$DST/frontend/src/pages/_Analytics_Settings.jsx"

    python3 - "$ANSET_SRC" "$DST/frontend/src/pages" << 'PYEOF' 2>/dev/null || \
        echo -e "  ${YELLOW}⚠${NC}  Extrae Analytics.jsx y Settings.jsx de _Analytics_Settings.jsx"

import sys, re, os
src  = open(sys.argv[1]).read()
out  = sys.argv[2]
head = "import { useEffect } from 'react'\nimport { useStore } from '../store'\n"

# Analytics: hasta el comentario de Settings
m = re.search(r'(// src/pages/Analytics\.jsx.*?)(?=// ═+\n// src/pages/Settings)', src, re.DOTALL)
if not m:
    m = re.search(r'(export default function Analytics.*?\n\})', src, re.DOTALL)
if m:
    open(os.path.join(out, 'Analytics.jsx'), 'w').write(head + m.group(1) + '\n')
    print("  Extraído: Analytics.jsx")

# Settings
m = re.search(r'(// src/pages/Settings\.jsx.*)', src, re.DOTALL)
if not m:
    m = re.search(r'(export function Settings.*)', src, re.DOTALL)
if m:
    open(os.path.join(out, 'Settings.jsx'), 'w').write(head + m.group(1) + '\n')
    print("  Extraído: Settings.jsx")
PYEOF
    ok "frontend__Analytics_Settings.jsx → Analytics.jsx + Settings.jsx"
else
    skip "frontend__Analytics_Settings.jsx"
fi

# ── Permisos de scripts ───────────────────────────────────────
for script in setup.sh start-dev.sh verify.sh; do
    [[ -f "$DST/$script" ]] && chmod +x "$DST/$script"
done

# ── Resumen ───────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${CYAN}══════════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}  Proyecto organizado en: $DST/${NC}"
echo -e "${BOLD}${CYAN}══════════════════════════════════════════${NC}"
echo ""

echo "Estructura del proyecto:"
find "$DST" \
    ! -path '*/node_modules/*' ! -path '*/.git/*' \
    ! -path '*/venv/*'        ! -path '*/dist/*'  \
    ! -path '*/__pycache__/*' \
    | sort | sed "s|$DST/||" | awk '{
        depth = gsub(/\//, "/")
        indent = ""
        for(i=0;i<depth;i++) indent = indent "  "
        name = $0
        sub(/.*\//, "", name)
        print indent "├── " name
    }' | head -50

echo ""
echo -e "${BOLD}Próximos pasos:${NC}"
echo "  1. cd $DST"
echo "  2. bash setup.sh              # instala Ollama + Python + Node"
echo "  3. bash verify.sh             # verifica que todo esté listo"
echo "  4. bash start-dev.sh          # inicia la app"
echo ""
echo -e "${BOLD}O con Docker (todo en uno):${NC}"
echo "  cd $DST && docker compose up -d"
echo ""
echo -e "${BOLD}App en:${NC} http://localhost:3000"
echo -e "${BOLD}API en:${NC} http://localhost:8000/docs"
