# MailAI Pro v2.0 — Modo Local con Ollama

Clasificador inteligente de emails que corre **100% en tu máquina**.
Sin envío de datos a Anthropic ni a ningún servidor externo.
Sin costos de API. Sin límites de uso.

---

## Cómo funciona el modo local

```
Tu email (IMAP/SSL)
       │
       ▼
EmailFetcher (Python)
  Conexión IMAP cifrada — los emails nunca salen de tu red
       │
       ▼
Ollama (localhost:11434)
  Modelo de IA corriendo en tu CPU/GPU
  Los emails se analizan localmente
       │
       ▼
SQLite (emails.db)
  Base de datos local en tu disco
       │
       ▼
Frontend React (localhost:3000)
  Todo en tu navegador
```

**Nada sale de tu máquina.**

---

## Requisitos mínimos

| Componente | Mínimo         | Recomendado       |
|-----------|----------------|-------------------|
| RAM       | 4 GB           | 8+ GB             |
| CPU       | 4 núcleos      | 8+ núcleos        |
| Disco     | 3 GB libres    | 10+ GB libres     |
| Python    | 3.10+          | 3.11+             |
| Node.js   | 18+            | 20+               |
| OS        | Linux/Mac/Win  | Linux/Mac         |

GPU opcional pero acelera significativamente (NVIDIA con CUDA o Apple Silicon).

---

## Instalación rápida

```bash
# 1. Clonar / descomprimir el proyecto
cd mailai-pro

# 2. Ejecutar setup automático
chmod +x setup_ollama.sh
./setup_ollama.sh

# 3. Copiar archivos (ver INDICE_ARCHIVOS.txt)

# 4. Iniciar
./start-dev.sh
```

---

## Instalación manual paso a paso

### 1. Instalar Ollama

**Linux / Mac:**
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

**Windows:**
Descarga desde https://ollama.com/download

**Verificar:**
```bash
ollama --version
ollama serve   # inicia el servidor en localhost:11434
```

### 2. Descargar un modelo

```bash
# Recomendado para empezar (rápido, buena calidad)
ollama pull llama3.2:3b

# Mayor calidad (requiere más RAM/disco)
ollama pull llama3.1:8b
ollama pull mistral:7b
ollama pull qwen2.5:7b

# Ver modelos instalados
ollama list

# Probar el modelo en terminal
ollama run llama3.2:3b
```

### 3. Backend Python

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Linux/Mac
# venv\Scripts\activate         # Windows

pip install -r requirements.txt

# Configurar .env
cp .env.example .env
# Editar OLLAMA_MODEL si quieres cambiar el modelo

# Iniciar
uvicorn main:app --reload --port 8000
# API Docs: http://localhost:8000/docs
# Estado Ollama: http://localhost:8000/ollama/status
```

### 4. Frontend React

```bash
cd frontend
npm install
npm run dev
# App: http://localhost:3000
```

---

## Archivos del proyecto

```
mailai-pro/
├── .env                         ← Variables locales (sin API keys)
├── docker-compose-ollama.yml    ← Docker con Ollama incluido
├── setup_ollama.sh              ← Instalación automática
├── start-dev.sh                 ← Inicio rápido (generado por setup)
│
├── backend/
│   ├── main.py                  ← API FastAPI + WebSocket
│   ├── classifier.py            ← Clasificación con Ollama (10+ dims)
│   ├── ollama_client.py         ← Cliente HTTP para Ollama
│   ├── database.py              ← SQLite local
│   ├── email_fetcher.py         ← IMAP multi-proveedor
│   ├── rules_engine.py          ← Motor de reglas IF/THEN
│   ├── scheduler.py             ← Sync automático
│   ├── config.py                ← Config sin API keys externas
│   └── requirements.txt         ← Sin anthropic, solo httpx
│
└── frontend/                    ← Igual que antes (sin cambios)
    └── src/
        ├── pages/               Dashboard, Inbox, Analytics...
        └── components/          Sidebar, AIInsights, etc.
```

---

## Mapa de archivos descargados → proyecto

```
DESCARGADO                            → DESTINO
──────────────────────────────────────────────────────
backend__main_ollama.py               → backend/main.py
backend__classifier_ollama.py         → backend/classifier.py
backend__ollama_client.py             → backend/ollama_client.py
backend__config_ollama.py             → backend/config.py
backend__requirements_ollama.txt      → backend/requirements.txt
dot_env_ollama.txt                    → .env  (editar modelo)
docker-compose-ollama.yml             → docker-compose.yml
setup_ollama.sh                       → setup.sh

# Los siguientes NO CAMBIAN (mismo frontend):
backend__database.py                  → backend/database.py
backend__email_fetcher.py             → backend/email_fetcher.py
backend__rules_engine.py              → backend/rules_engine.py
backend__scheduler.py                 → backend/scheduler.py
backend__Dockerfile                   → backend/Dockerfile
frontend__* (todos)                   → frontend/src/... (igual)
docker-compose-ollama.yml             → docker-compose.yml
```

---

## Docker con Ollama incluido

```bash
# Copiar docker-compose-ollama.yml como docker-compose.yml
cp docker-compose-ollama.yml docker-compose.yml

# Iniciar todo (Ollama + Backend + Frontend)
docker compose up -d

# La primera vez descarga el modelo automáticamente
docker compose logs -f ollama-pull

# Ver estado
docker compose ps

# Cambiar modelo
docker compose exec ollama ollama pull llama3.1:8b
# Actualizar .env: OLLAMA_MODEL=llama3.1:8b
docker compose restart backend
```

---

## Comparación de modelos

| Modelo        | RAM   | Disco | Velocidad  | Calidad clasificación |
|---------------|-------|-------|------------|-----------------------|
| llama3.2:1b   | 2 GB  | 800MB | Muy rápido | Básica                |
| llama3.2:3b   | 4 GB  | 2 GB  | Rápido     | Buena ← inicio        |
| gemma3:4b     | 4 GB  | 3 GB  | Rápido     | Buena                 |
| mistral:7b    | 6 GB  | 4 GB  | Medio      | Muy buena (español)   |
| llama3.1:8b   | 8 GB  | 5 GB  | Medio      | Excelente ← producción|
| qwen2.5:7b    | 6 GB  | 5 GB  | Medio      | Excelente (multilingüe)|
| llama3.1:70b  | 48 GB | 40 GB | Lento      | Máxima (requiere GPU) |

---

## Endpoints de la API

```bash
# Estado de Ollama y modelo
curl http://localhost:8000/health
curl http://localhost:8000/ollama/status

# Descargar un modelo desde la API
curl -X POST "http://localhost:8000/ollama/pull?model=llama3.1:8b"

# Sincronizar emails
curl -X POST http://localhost:8000/sync \
  -H "Content-Type: application/json" \
  -d '{"email":"tu@gmail.com","password":"xxxx xxxx xxxx xxxx","limit":20,"days_back":7}'

# Ver emails clasificados
curl http://localhost:8000/emails?limit=5

# Estadísticas
curl http://localhost:8000/stats

# Documentación interactiva
# http://localhost:8000/docs
```

---

## Configurar Gmail para IMAP

1. Activa verificación en 2 pasos: myaccount.google.com/security
2. Crea App Password: myaccount.google.com/apppasswords
3. Selecciona "Mail" → copia los 16 caracteres
4. Activa IMAP: Gmail → Configuración → Reenvío e IMAP
5. Usa esa clave de 16 caracteres como password en MailAI

---

## Privacidad y seguridad

- Los emails **nunca** salen de tu red local
- El modelo de IA corre en tu CPU/GPU
- La base de datos es un archivo SQLite en tu disco
- No hay telemetría ni logging externo
- El código es auditabe — no hay dependencias de Anthropic

---

## Solución de problemas

**Ollama no responde:**
```bash
ollama serve   # iniciarlo manualmente
ollama list    # verificar modelos
curl http://localhost:11434/api/tags  # probar la API
```

**Clasificación muy lenta:**
- Usa un modelo más pequeño: `llama3.2:1b` o `llama3.2:3b`
- Aumenta `OLLAMA_TIMEOUT` en `.env`
- Verifica RAM disponible: `free -h` (Linux) / Activity Monitor (Mac)

**Respuestas JSON inválidas:**
- Ollama con `format: json` garantiza JSON válido
- Si persiste, prueba un modelo diferente: `mistral:7b`

**Error de conexión IMAP:**
- Para Gmail usa App Password (no tu contraseña normal)
- Verifica que IMAP esté activado en la configuración de Gmail
- Prueba con `limit: 5` primero
