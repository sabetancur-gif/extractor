"""
config.py — Configuración para ejecución 100% local con Ollama
Sin API keys externas. Sin envío de datos a terceros.
"""
from pydantic_settings import BaseSettings
from typing import Optional
import os


class Settings(BaseSettings):

    # ─── OLLAMA (IA local) ────────────────────────────────────────────
    # URL base de Ollama. Por defecto corre en localhost:11434
    # En Docker usa el nombre del servicio: http://ollama:11434
    ollama_base_url: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")

    # Modelo a usar. Opciones recomendadas (de menor a mayor calidad/velocidad):
    #   llama3.2:1b   → muy rápido, calidad básica  (~1 GB RAM)
    #   llama3.2:3b   → rápido, buena calidad        (~2 GB RAM)  ← recomendado inicio
    #   llama3.1:8b   → mejor calidad                (~5 GB RAM)  ← recomendado producción
    #   mistral:7b    → muy bueno para español        (~5 GB RAM)
    #   qwen2.5:7b    → excelente multilingüe         (~5 GB RAM)
    #   gemma3:4b     → compacto y eficiente          (~3 GB RAM)
    #   llama3.1:70b  → máxima calidad (GPU potente) (~40 GB RAM)
    ollama_model: str = os.getenv("OLLAMA_MODEL", "llama3.2:3b")

    # Timeout en segundos para llamadas al modelo (aumentar si el modelo es grande)
    ollama_timeout: float = float(os.getenv("OLLAMA_TIMEOUT", "120"))

    # ─── BASE DE DATOS ────────────────────────────────────────────────
    database_url: str = os.getenv("DATABASE_URL", "emails.db")

    # ─── APP ──────────────────────────────────────────────────────────
    debug: bool = os.getenv("DEBUG", "false").lower() == "true"
    secret_key: str = os.getenv("SECRET_KEY", "cambia-esto-en-produccion-clave-segura-32chars")

    # Puerto del backend
    port: int = int(os.getenv("PORT", "8000"))

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
