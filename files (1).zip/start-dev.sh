#!/usr/bin/env bash
# ================================================================
#  start-dev.sh — Levanta MailAI Pro en modo desarrollo local
#  Uso: bash start-dev.sh [--model llama3.1:8b] [--port 8000]
# ================================================================
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_PORT=8000
FRONTEND_PORT=3000

# ── Parsear argumentos ───────────────────────────────────────
while [[ $# -gt 0 ]]; do
    case "$1" in
        --model)  OVERRIDE_MODEL="$2"; shift 2 ;;
        --port)   BACKEND_PORT="$2";   shift 2 ;;
        --help|-h)
            echo "Uso: bash start-dev.sh [--model <nombre>] [--port <número>]"
            echo "  --model   Sobreescribir modelo Ollama (ej: llama3.1:8b)"
            echo "  --port    Puerto del backend (default: 8000)"
            exit 0 ;;
        *) echo "Argumento desconocido: $1"; exit 1 ;;
    esac
done

# ── Colores ──────────────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'
BOLD='\033[1m'; NC='\033[0m'

ok()   { echo -e "${GREEN}✓${NC}  $*"; }
warn() { echo -e "${YELLOW}⚠${NC}  $*"; }
info() { echo -e "${CYAN}ℹ${NC}  $*"; }

echo -e "${BOLD}${CYAN}"
echo "  MailAI Pro — Inicio local (Ollama)"
echo -e "${NC}"

# ── Verificar .env ───────────────────────────────────────────
if [[ ! -f "$DIR/.env" ]]; then
    warn ".env no encontrado. Generando uno básico..."
    cat > "$DIR/.env" << 'EOF'
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama3.2:3b
OLLAMA_TIMEOUT=120
DATABASE_URL=emails.db
DEBUG=false
PORT=8000
SECRET_KEY=clave-local-temporal-cambia-en-produccion
EOF
    ok ".env creado con valores por defecto"
fi

# Cargar variables del .env
set -a
source "$DIR/.env"
set +a

# Sobreescribir modelo si se pasó por argumento
if [[ -n "${OVERRIDE_MODEL:-}" ]]; then
    export OLLAMA_MODEL="$OVERRIDE_MODEL"
    info "Modelo sobreescrito por argumento: $OLLAMA_MODEL"
fi

OLLAMA_URL="${OLLAMA_BASE_URL:-http://localhost:11434}"
OLLAMA_MODEL="${OLLAMA_MODEL:-llama3.2:3b}"

# ── Verificar Ollama ─────────────────────────────────────────
info "Verificando Ollama en $OLLAMA_URL..."

if ! curl -sf "$OLLAMA_URL/api/tags" > /dev/null 2>&1; then
    warn "Ollama no responde en $OLLAMA_URL"
    if command -v ollama &>/dev/null; then
        info "Iniciando Ollama en background..."
        ollama serve > /tmp/ollama.log 2>&1 &
        OLLAMA_PID=$!
        sleep 4
        if curl -sf "$OLLAMA_URL/api/tags" > /dev/null 2>&1; then
            ok "Ollama iniciado (PID $OLLAMA_PID)"
        else
            warn "Ollama tardó en iniciar. Continúa de todas formas..."
        fi
    else
        warn "Ollama no está instalado. Instálalo con:"
        warn "  curl -fsSL https://ollama.com/install.sh | sh"
        warn "Continuando sin verificar..."
    fi
else
    ok "Ollama corriendo en $OLLAMA_URL"
fi

# Verificar modelo
if curl -sf "$OLLAMA_URL/api/tags" 2>/dev/null | grep -q "$(echo "$OLLAMA_MODEL" | cut -d: -f1)"; then
    ok "Modelo $OLLAMA_MODEL disponible"
else
    warn "Modelo $OLLAMA_MODEL no encontrado."
    warn "Descárgalo con: ollama pull $OLLAMA_MODEL"
    warn "Continuando — la clasificación fallará hasta que el modelo esté disponible."
fi

# ── Backend ──────────────────────────────────────────────────
info "Iniciando backend (puerto $BACKEND_PORT)..."

BACKEND_DIR="$DIR/backend"

if [[ ! -d "$BACKEND_DIR/venv" ]]; then
    warn "Entorno virtual no encontrado en $BACKEND_DIR/venv"
    warn "Ejecuta setup_ollama.sh primero."
    exit 1
fi

# Copiar .env al backend
cp "$DIR/.env" "$BACKEND_DIR/.env"

cd "$BACKEND_DIR"
source venv/bin/activate

uvicorn main:app \
    --host 0.0.0.0 \
    --port "$BACKEND_PORT" \
    --reload \
    --log-level info &
BACKEND_PID=$!
deactivate
cd "$DIR"

# Esperar que el backend responda
sleep 3
if curl -sf "http://localhost:$BACKEND_PORT/health" > /dev/null 2>&1; then
    ok "Backend listo en http://localhost:$BACKEND_PORT"
else
    warn "Backend tardando en iniciar..."
fi

# ── Frontend ─────────────────────────────────────────────────
info "Iniciando frontend (puerto $FRONTEND_PORT)..."

FRONTEND_DIR="$DIR/frontend"

if [[ ! -d "$FRONTEND_DIR/node_modules" ]]; then
    warn "node_modules no encontrado. Instalando..."
    cd "$FRONTEND_DIR" && npm install --silent && cd "$DIR"
fi

cd "$FRONTEND_DIR"
npm run dev -- --port "$FRONTEND_PORT" &
FRONTEND_PID=$!
cd "$DIR"

sleep 3

# ── Resumen ──────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}✅ MailAI Pro corriendo (modo 100% local):${NC}"
echo ""
echo -e "  🌐 App:        ${CYAN}http://localhost:$FRONTEND_PORT${NC}"
echo -e "  ⚙  API:        ${CYAN}http://localhost:$BACKEND_PORT${NC}"
echo -e "  📖 API Docs:   ${CYAN}http://localhost:$BACKEND_PORT/docs${NC}"
echo -e "  🤖 Ollama:     ${CYAN}$OLLAMA_URL${NC}"
echo -e "  🧠 Modelo:     ${CYAN}$OLLAMA_MODEL${NC}"
echo ""
echo -e "  Ctrl+C para detener todo."
echo ""

# ── Trap para limpiar al salir ───────────────────────────────
cleanup() {
    echo ""
    info "Deteniendo servicios..."
    kill "$BACKEND_PID"  2>/dev/null && ok "Backend detenido"  || true
    kill "$FRONTEND_PID" 2>/dev/null && ok "Frontend detenido" || true
    if [[ -n "${OLLAMA_PID:-}" ]]; then
        kill "$OLLAMA_PID" 2>/dev/null && ok "Ollama detenido" || true
    fi
    echo -e "${GREEN}¡Hasta luego!${NC}"
}

trap cleanup EXIT INT TERM
wait "$BACKEND_PID" "$FRONTEND_PID"
