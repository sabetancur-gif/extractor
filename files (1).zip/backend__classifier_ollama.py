"""
classifier.py — Clasificador con Ollama (IA 100% local)
Sin llamadas a APIs de pago. Sin envío de datos a terceros.
Modelos recomendados: llama3.2:3b (rápido), llama3.1:8b (mejor calidad),
                      mistral:7b, qwen2.5:7b, gemma3:4b
"""
import json
import re
from typing import Dict, Optional
from ollama_client import OllamaClient


CATEGORIES = {
    "trabajo":          "Emails laborales: reuniones, proyectos, reportes, contratos",
    "ventas_marketing": "Ofertas, newsletters, campañas, promociones comerciales",
    "finanzas":         "Facturas, pagos, extractos bancarios, transacciones",
    "soporte_tecnico":  "Tickets de soporte, errores, incidentes, mantenimiento",
    "personal":         "Mensajes personales: amigos, familia",
    "legal":            "Contratos, notificaciones legales, gobierno, DIAN",
    "educacion":        "Cursos, certificados, universidades, capacitaciones",
    "redes_sociales":   "Notificaciones de LinkedIn, Instagram, Twitter, etc.",
    "spam":             "Spam, phishing, emails no solicitados",
    "otro":             "No encaja claramente en otra categoría",
}

PRIORITIES   = ["urgente", "alta", "media", "baja"]
SENTIMENTS   = ["positivo", "negativo", "neutral", "mixto"]
TONES        = ["formal", "informal", "agresivo", "urgente", "amigable", "neutral", "corporativo", "tecnico"]
URGENCIES    = ["critica", "alta", "media", "baja", "ninguna"]
THREAD_TYPES = ["nuevo", "necesita_respuesta", "esperando_respuesta", "informativo", "seguimiento", "resuelto"]


# Prompt de sistema: instruye al modelo a ser un clasificador de emails
SYSTEM_PROMPT = """Eres un clasificador experto de emails. Tu única función es analizar emails y responder con un JSON estructurado.

REGLAS OBLIGATORIAS:
1. Responde ÚNICAMENTE con JSON válido. Sin texto antes ni después.
2. Nunca uses bloques ```json ```. Solo el objeto JSON puro.
3. Completa TODOS los campos del esquema dado.
4. Si no hay información suficiente para un campo, usa valores por defecto razonables.
5. Los textos de resumen y respuesta van en el mismo idioma del email."""


class EmailClassifier:
    def __init__(self):
        self.client = OllamaClient()

    def classify_email(self, email_data: Dict) -> Dict:
        """
        Clasifica un email con 10+ dimensiones usando Ollama local.
        Retorna un dict con todos los campos de análisis.
        """
        prompt = self._build_prompt(email_data)
        try:
            # Usamos chat con system prompt para mejor control
            raw = self.client.chat(
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user",   "content": prompt},
                ],
                temperature=0.05,   # baja temperatura = más determinismo
                max_tokens=1400,
                force_json=True,    # Ollama garantiza JSON válido
            )
            return self._parse(raw)
        except Exception as e:
            print(f"⚠️  Classifier error: {e}")
            return self._default()

    def _build_prompt(self, e: Dict) -> str:
        body     = (e.get("body") or "")[:1500]
        cats_str = "\n".join(f"  - {k}: {v}" for k, v in CATEGORIES.items())
        thread   = ""
        if e.get("thread_context"):
            thread = f"\n\nCONTEXTO DEL HILO PREVIO:\n{e['thread_context'][:400]}"

        return f"""Analiza este email y devuelve el JSON de clasificación.

═══ EMAIL ═══
De      : {e.get('sender_name', '')} <{e.get('sender_email', '')}>
Para    : {e.get('to', '')}
Asunto  : {e.get('subject', '')}
Fecha   : {e.get('date', '')}
Adjuntos: {e.get('has_attachments', False)}{thread}

Cuerpo:
{body}

═══ CATEGORÍAS ═══
{cats_str}

═══ ESQUEMA JSON REQUERIDO ═══
Devuelve exactamente este objeto JSON con todos los campos completados:

{{
  "category": "<una de las categorías>",
  "subcategory": "<subcategoría específica ej: reuniones, factura, soporte>",
  "priority_score": <número entero 1-100>,
  "priority_label": "<urgente|alta|media|baja>",
  "sentiment": {{
    "label": "<positivo|negativo|neutral|mixto>",
    "score": <decimal -1.0 a 1.0>,
    "tone": "<formal|informal|agresivo|urgente|amigable|neutral|corporativo|tecnico>"
  }},
  "urgency": {{
    "level": "<critica|alta|media|baja|ninguna>",
    "reason": "<explicación breve de por qué es urgente o no>",
    "deadline": "<fecha ISO si hay plazo explícito, o null>"
  }},
  "entities": {{
    "people": ["<nombre1>", "<nombre2>"],
    "companies": ["<empresa1>"],
    "dates": ["<fecha o plazo mencionado>"],
    "amounts": ["<monto o precio>"],
    "locations": ["<lugar>"]
  }},
  "action_items": ["<acción concreta 1>", "<acción 2>"],
  "suggested_reply": "<borrador de respuesta profesional en el mismo idioma del email, máx 3 oraciones. null si no aplica>",
  "key_topics": ["<tema1>", "<tema2>", "<tema3>"],
  "language": "<es|en|pt|fr|otro>",
  "spam_score": <decimal 0.0 a 1.0>,
  "thread_type": "<nuevo|necesita_respuesta|esperando_respuesta|informativo|seguimiento|resuelto>",
  "summary": "<resumen objetivo de 1-2 oraciones>",
  "requires_action": <true|false>,
  "confidence": <decimal 0.0 a 1.0>
}}"""

    def _parse(self, raw: str) -> Dict:
        """Parsea la respuesta JSON de Ollama con validación robusta."""
        try:
            # Ollama con format=json devuelve JSON puro, pero por si acaso limpiamos
            text = raw.strip()
            # Eliminar posibles fences aunque Ollama no debería generarlas
            text = re.sub(r"^```(?:json)?\s*", "", text)
            text = re.sub(r"\s*```$", "", text)
            # Extraer objeto JSON
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if not match:
                return self._default()
            data = json.loads(match.group())

            sentiment = data.get("sentiment") or {}
            urgency   = data.get("urgency")   or {}
            entities  = data.get("entities")  or {}

            def clamp_float(v, lo=0.0, hi=1.0):
                try: return max(lo, min(hi, float(v)))
                except: return (lo + hi) / 2

            def clamp_int(v, lo=1, hi=100):
                try: return max(lo, min(hi, int(v)))
                except: return (lo + hi) // 2

            def safe_list(v):
                return [str(x) for x in v] if isinstance(v, list) else []

            def safe_str(v, maxlen=500):
                return str(v)[:maxlen] if v else ""

            return {
                "category":       self._valid_cat(data.get("category", "otro")),
                "subcategory":    safe_str(data.get("subcategory", "general"), 60),
                "priority_score": clamp_int(data.get("priority_score", 50)),
                "priority_label": self._valid(data.get("priority_label"), PRIORITIES, "media"),
                "sentiment": {
                    "label": self._valid(sentiment.get("label"), SENTIMENTS, "neutral"),
                    "score": clamp_float(sentiment.get("score", 0.0), -1.0, 1.0),
                    "tone":  self._valid(sentiment.get("tone"), TONES, "neutral"),
                },
                "urgency": {
                    "level":    self._valid(urgency.get("level"), URGENCIES, "ninguna"),
                    "reason":   safe_str(urgency.get("reason"), 250),
                    "deadline": urgency.get("deadline") if isinstance(urgency.get("deadline"), str) else None,
                },
                "entities": {
                    "people":    safe_list(entities.get("people",    []))[:10],
                    "companies": safe_list(entities.get("companies", []))[:10],
                    "dates":     safe_list(entities.get("dates",     []))[:10],
                    "amounts":   safe_list(entities.get("amounts",   []))[:10],
                    "locations": safe_list(entities.get("locations", []))[:10],
                },
                "action_items":   safe_list(data.get("action_items",  []))[:10],
                "suggested_reply":safe_str(data.get("suggested_reply") or "", 900) or None,
                "key_topics":     safe_list(data.get("key_topics",    []))[:8],
                "language":       safe_str(data.get("language", "es"), 10),
                "spam_score":     clamp_float(data.get("spam_score", 0.0)),
                "thread_type":    self._valid(data.get("thread_type"), THREAD_TYPES, "nuevo"),
                "summary":        safe_str(data.get("summary", ""), 500),
                "requires_action":bool(data.get("requires_action", False)),
                "confidence":     clamp_float(data.get("confidence", 0.7)),
            }
        except Exception as ex:
            print(f"⚠️  Parse error: {ex}\nRaw: {raw[:300]}")
            return self._default()

    def _valid_cat(self, v: str) -> str:
        v = (v or "").lower().strip()
        if v in CATEGORIES:
            return v
        for k in CATEGORIES:
            if k in v or v in k:
                return k
        return "otro"

    def _valid(self, v, options: list, default: str) -> str:
        v = (v or "").lower().strip()
        return v if v in options else default

    def _default(self) -> Dict:
        return {
            "category": "otro", "subcategory": "general",
            "priority_score": 50, "priority_label": "media",
            "sentiment": {"label": "neutral", "score": 0.0, "tone": "neutral"},
            "urgency":   {"level": "ninguna", "reason": "", "deadline": None},
            "entities":  {"people": [], "companies": [], "dates": [], "amounts": [], "locations": []},
            "action_items": [], "suggested_reply": None, "key_topics": [],
            "language": "es", "spam_score": 0.0,
            "thread_type": "nuevo",
            "summary": "No clasificado (error de modelo)",
            "requires_action": False, "confidence": 0.0,
        }

    # ── Métodos de utilidad ────────────────────────────────────────────
    def get_available_models(self) -> list:
        """Lista modelos instalados en Ollama."""
        try:
            return self.client.list_models()
        except Exception:
            return []

    def health_check(self) -> dict:
        """Verifica estado de Ollama y el modelo configurado."""
        available  = self.client.is_available()
        model_ok   = self.client.model_is_loaded() if available else False
        all_models = self.get_available_models() if available else []
        return {
            "ollama_running":    available,
            "model_configured":  self.client.model,
            "model_available":   model_ok,
            "installed_models":  all_models,
            "ollama_url":        self.client.base_url,
        }
