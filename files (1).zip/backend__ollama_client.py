"""
ollama_client.py — Cliente HTTP para Ollama local
Ollama corre en http://localhost:11434 (o el host configurado)
Sin dependencias externas de pago, sin datos enviados a terceros.
"""
import httpx
import json
import asyncio
from typing import Optional, AsyncIterator
from config import Settings

settings = Settings()


class OllamaClient:
    """
    Cliente para la API REST de Ollama.
    Ollama expone una API compatible con OpenAI en /v1/ y su propia en /api/
    Usamos /api/ nativa para máximo control.
    """

    def __init__(self):
        self.base_url = settings.ollama_base_url.rstrip("/")
        self.model    = settings.ollama_model
        self.timeout  = httpx.Timeout(
            connect=10.0,
            read=settings.ollama_timeout,
            write=30.0,
            pool=5.0,
        )

    # ── Sincrónico (para clasificación en background tasks) ────────────
    def generate(
        self,
        prompt: str,
        system: str = "",
        model: Optional[str] = None,
        temperature: float = 0.05,
        max_tokens: int = 1400,
        force_json: bool = True,
    ) -> str:
        """
        Llama a /api/generate y devuelve el texto completo.
        force_json=True activa el modo JSON nativo de Ollama
        (garantiza salida JSON válida sin markdown fences).
        """
        payload: dict = {
            "model":  model or self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature":   temperature,
                "num_predict":   max_tokens,
                "top_p":         0.9,
                "repeat_penalty": 1.1,
            },
        }
        if system:
            payload["system"] = system
        if force_json:
            payload["format"] = "json"

        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(f"{self.base_url}/api/generate", json=payload)
            resp.raise_for_status()
            return resp.json().get("response", "")

    def chat(
        self,
        messages: list[dict],
        model: Optional[str] = None,
        temperature: float = 0.05,
        max_tokens: int = 1400,
        force_json: bool = True,
    ) -> str:
        """
        Llama a /api/chat con historial de mensajes.
        Más controlable que /api/generate para prompts complejos.
        """
        payload: dict = {
            "model":    model or self.model,
            "messages": messages,
            "stream":   False,
            "options": {
                "temperature":   temperature,
                "num_predict":   max_tokens,
                "top_p":         0.9,
                "repeat_penalty": 1.1,
            },
        }
        if force_json:
            payload["format"] = "json"

        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(f"{self.base_url}/api/chat", json=payload)
            resp.raise_for_status()
            data = resp.json()
            return data.get("message", {}).get("content", "")

    # ── Utilidades ──────────────────────────────────────────────────────
    def list_models(self) -> list[str]:
        """Lista los modelos disponibles en Ollama."""
        with httpx.Client(timeout=httpx.Timeout(10.0)) as client:
            resp = client.get(f"{self.base_url}/api/tags")
            resp.raise_for_status()
            return [m["name"] for m in resp.json().get("models", [])]

    def pull_model(self, model: Optional[str] = None) -> bool:
        """Descarga un modelo si no está disponible (bloqueante)."""
        target = model or self.model
        print(f"📥 Descargando modelo {target}...")
        with httpx.Client(timeout=httpx.Timeout(600.0)) as client:
            with client.stream("POST", f"{self.base_url}/api/pull",
                               json={"name": target}) as resp:
                for line in resp.iter_lines():
                    if line:
                        data = json.loads(line)
                        status = data.get("status", "")
                        if "pulling" in status or "verifying" in status:
                            total = data.get("total", 0)
                            done  = data.get("completed", 0)
                            if total > 0:
                                pct = int(done / total * 100)
                                print(f"\r  {status} {pct}%", end="", flush=True)
        print(f"\n✅ Modelo {target} listo")
        return True

    def is_available(self) -> bool:
        """Verifica si Ollama está corriendo."""
        try:
            with httpx.Client(timeout=httpx.Timeout(5.0)) as client:
                resp = client.get(f"{self.base_url}/api/tags")
                return resp.status_code == 200
        except Exception:
            return False

    def model_is_loaded(self, model: Optional[str] = None) -> bool:
        """Verifica si el modelo solicitado ya está disponible."""
        target = (model or self.model).split(":")[0]   # ignorar tag
        return any(target in m for m in self.list_models())

    def ensure_model(self) -> None:
        """Asegura que el modelo esté disponible, descargándolo si hace falta."""
        if not self.is_available():
            raise RuntimeError(
                f"Ollama no está corriendo en {self.base_url}. "
                "Ejecuta: ollama serve"
            )
        if not self.model_is_loaded():
            print(f"⚠  Modelo '{self.model}' no encontrado. Descargando...")
            self.pull_model()
