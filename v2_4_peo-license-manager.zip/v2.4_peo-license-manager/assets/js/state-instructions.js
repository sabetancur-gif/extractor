/* global PEO */
/* state-instructions.js — state info cards with SVG state map shapes — v2.4 */
"use strict";

// ═══════════════════════════════════════════════════════════════════════════
//  STATE INSTRUCTIONS — customize per state here
// ═══════════════════════════════════════════════════════════════════════════
PEO.STATE_INSTRUCTIONS = {

    DEFAULT: {
        ADD: [
            "Enter the employee data in registros.xlsm (Name, SSN, Start Date, State).",
            "Open the state licensing portal for this state.",
            "Log in with your PEO credentials and navigate to Add Employee.",
            "Upload or manually enter the information from the Excel row.",
            "Generate the ADD PDF using the Generate button in PEO License Manager.",
            "Attach the generated PDF to the portal submission.",
            "Submit the form and note the confirmation number.",
            "Update the 'Creado' column in registros.xlsm to 'SI' for this record.",
        ],
        TERM: [
            "Enter the termination data in registros.xlsm (Name, Termination Date, Reason).",
            "Open the state licensing portal for this state.",
            "Navigate to Terminate Employee and search by SSN or Case #.",
            "Verify the effective date matches the Excel record.",
            "Generate the TERM PDF using the Generate button in PEO License Manager.",
            "Attach the generated PDF and submit the termination.",
            "Record the confirmation number and update 'Creado' to 'SI'.",
        ],
    },

    TX: {
        ADD: [
            "Enter employer and employee data in registros.xlsm.",
            "Access the Texas Workforce Commission (TWC) portal.",
            "Navigate to: Employer Portal > PEO Registration > Add Covered Employee.",
            "Complete all required fields: EIN, Client Name, Employee SSN, Start Date.",
            "Generate the TX ADD PDF from PEO License Manager.",
            "Upload the PDF in the Documents section of the TWC form.",
            "Submit and copy the TWC confirmation number to the Excel Notes column.",
            "Mark 'Creado = SI' in registros.xlsm.",
        ],
        TERM: [
            "Confirm termination date in registros.xlsm matches the client notification.",
            "Access the TWC portal > Employer Portal > PEO > Terminate Employee.",
            "Search by Employee SSN and select the correct record.",
            "Enter separation reason code (per TWC guidelines).",
            "Generate the TX TERM PDF from PEO License Manager.",
            "Attach PDF and submit; save the confirmation number.",
            "Update 'Creado = SI' in registros.xlsm.",
        ],
    },
};

// ═══════════════════════════════════════════════════════════════════════════
//  SVG STATE MAP SHAPES
//  Simplified but recognizable geographic outlines for each US state.
//  Each path is normalized to fit in a ~220x160 viewBox.
// ═══════════════════════════════════════════════════════════════════════════
const STATE_PATHS = {
  // ── Rectangular / simple states ──────────────────────────────────────
  WY: "M 30,20 L 190,20 L 190,140 L 30,140 Z",
  CO: "M 30,20 L 190,20 L 190,140 L 30,140 Z",
  UT: "M 40,20 L 150,20 L 150,90 L 120,90 L 120,140 L 40,140 Z",
  NM: "M 40,20 L 185,20 L 185,110 L 140,110 L 140,140 L 40,140 Z",
  ND: "M 25,30 L 195,30 L 195,140 L 25,140 Z",
  SD: "M 25,30 L 195,30 L 195,140 L 25,140 Z",
  NE: "M 25,40 L 185,40 L 185,100 L 155,100 L 155,140 L 25,140 Z",
  KS: "M 30,40 L 190,40 L 190,140 L 30,140 Z",
  IA: "M 30,30 L 185,30 L 190,50 L 190,130 L 35,135 L 25,110 L 30,30 Z",
  MO: "M 30,20 L 180,20 L 185,60 L 185,100 L 160,120 L 155,140 L 100,145 L 30,140 L 25,80 Z",
  // ── West Coast ───────────────────────────────────────────────────────
  CA: "M 30,10 L 90,10 L 105,30 L 115,50 L 120,90 L 115,130 L 100,150 L 70,158 L 40,148 L 25,120 L 20,80 L 25,40 Z",
  OR: "M 20,20 L 170,20 L 185,35 L 185,110 L 170,120 L 130,125 L 90,120 L 30,115 L 20,95 Z",
  WA: "M 20,30 L 120,25 L 170,20 L 190,40 L 190,100 L 150,110 L 100,115 L 60,120 L 20,110 L 15,80 Z",
  // ── Mountain states ──────────────────────────────────────────────────
  ID: "M 50,10 L 120,10 L 125,30 L 130,60 L 120,80 L 180,90 L 180,140 L 75,140 L 50,90 L 40,60 Z",
  MT: "M 20,20 L 185,20 L 195,25 L 195,120 L 155,120 L 145,130 L 80,130 L 40,120 L 20,100 Z",
  NV: "M 40,15 L 120,15 L 130,30 L 135,80 L 140,130 L 110,155 L 70,155 L 35,125 L 30,80 Z",
  AZ: "M 30,20 L 160,20 L 170,30 L 175,120 L 150,140 L 95,140 L 30,120 Z",
  // ── Great Plains ─────────────────────────────────────────────────────
  MN: "M 55,15 L 140,15 L 155,20 L 185,30 L 190,70 L 185,100 L 175,115 L 155,125 L 130,130 L 80,130 L 40,120 L 30,90 L 35,60 L 50,40 Z",
  OK: "M 20,30 L 185,30 L 195,50 L 195,120 L 155,125 L 155,150 L 100,150 L 50,140 L 20,130 Z",
  AR: "M 30,30 L 185,25 L 190,60 L 185,110 L 160,125 L 100,130 L 30,125 Z",
  LA: "M 25,20 L 175,20 L 185,40 L 180,100 L 155,130 L 130,145 L 110,158 L 80,155 L 55,140 L 25,120 L 20,80 Z",
  // ── South Central ────────────────────────────────────────────────────
  TX: "M 20,15 L 155,15 L 175,30 L 195,60 L 200,100 L 185,130 L 165,155 L 135,165 L 95,165 L 60,150 L 30,135 L 10,100 L 15,60 Z",
  // ── Southeast ────────────────────────────────────────────────────────
  FL: "M 30,10 L 155,10 L 165,25 L 165,80 L 175,100 L 160,135 L 130,155 L 100,162 L 75,158 L 55,145 L 35,115 L 20,85 L 20,45 Z",
  GA: "M 30,15 L 170,15 L 185,30 L 185,110 L 160,130 L 130,145 L 90,140 L 50,120 L 25,90 L 25,50 Z",
  AL: "M 40,15 L 150,15 L 160,30 L 165,120 L 150,145 L 100,150 L 55,130 L 35,100 Z",
  MS: "M 45,15 L 155,15 L 160,40 L 160,110 L 140,135 L 100,140 L 60,125 L 40,90 L 40,50 Z",
  TN: "M 20,40 L 190,35 L 200,55 L 200,110 L 160,115 L 100,120 L 40,115 L 15,100 L 15,65 Z",
  KY: "M 15,40 L 175,35 L 195,55 L 190,100 L 155,115 L 100,120 L 45,115 L 15,100 Z",
  // ── Mid-Atlantic ─────────────────────────────────────────────────────
  NC: "M 15,45 L 185,35 L 195,55 L 185,90 L 145,110 L 100,115 L 55,110 L 20,95 L 10,70 Z",
  SC: "M 30,25 L 170,20 L 185,45 L 175,100 L 140,130 L 90,130 L 40,100 L 25,65 Z",
  VA: "M 15,30 L 185,25 L 200,50 L 185,90 L 155,110 L 110,115 L 60,105 L 20,80 Z",
  WV: "M 35,20 L 165,20 L 185,50 L 180,90 L 150,115 L 110,120 L 70,110 L 35,80 L 25,55 Z",
  MD: "M 20,40 L 180,35 L 190,60 L 185,95 L 150,105 L 100,110 L 50,100 L 20,80 Z",
  DE: "M 55,20 L 155,20 L 165,60 L 160,130 L 50,130 L 45,70 Z",
  NJ: "M 50,15 L 150,15 L 165,50 L 160,120 L 120,140 L 70,130 L 40,100 L 35,60 Z",
  PA: "M 20,30 L 185,30 L 195,50 L 190,120 L 25,125 L 15,80 Z",
  NY: "M 15,25 L 170,20 L 190,40 L 195,80 L 165,110 L 120,125 L 70,120 L 25,100 L 10,70 Z",
  CT: "M 30,25 L 175,25 L 180,100 L 165,130 L 50,130 L 25,95 Z",
  RI: "M 40,20 L 160,20 L 170,80 L 155,145 L 55,145 L 35,80 Z",
  MA: "M 20,35 L 170,25 L 190,50 L 195,90 L 165,110 L 110,115 L 50,110 L 20,85 Z",
  VT: "M 50,15 L 150,15 L 160,50 L 155,130 L 55,135 L 45,80 Z",
  NH: "M 55,10 L 150,10 L 160,50 L 150,130 L 55,135 L 45,90 L 40,50 Z",
  ME: "M 40,10 L 170,10 L 190,40 L 185,130 L 140,150 L 90,145 L 45,120 L 30,80 Z",
  // ── Midwest ──────────────────────────────────────────────────────────
  OH: "M 30,20 L 175,20 L 185,40 L 190,120 L 170,140 L 100,145 L 40,130 L 20,100 L 25,55 Z",
  IN: "M 45,15 L 160,15 L 165,40 L 165,130 L 140,145 L 70,145 L 40,125 L 35,80 Z",
  IL: "M 50,10 L 155,10 L 170,35 L 175,90 L 160,130 L 120,155 L 80,150 L 45,125 L 30,85 L 35,45 Z",
  MI: "M 40,20 L 130,15 L 175,25 L 195,60 L 175,80 L 140,90 L 100,90 L 80,120 L 60,135 L 40,110 L 20,80 L 25,50 Z",
  WI: "M 45,15 L 145,10 L 170,25 L 180,70 L 165,110 L 130,130 L 80,130 L 45,110 L 30,75 L 35,40 Z",
  // ── Non-contiguous ───────────────────────────────────────────────────
  AK: "M 15,20 L 110,15 L 175,25 L 195,55 L 185,100 L 155,130 L 110,145 L 60,140 L 20,115 L 10,75 Z",
  HI: "M 20,60 L 65,50 L 80,65 L 70,95 L 40,100 L 20,85 Z M 90,45 L 120,40 L 130,55 L 120,75 L 95,75 Z M 135,55 L 155,50 L 162,65 L 152,80 L 135,78 Z M 165,65 L 185,62 L 190,75 L 180,85 L 165,82 Z M 193,50 L 207,48 L 210,58 L 200,65 L 192,60 Z",
};

// ═══════════════════════════════════════════════════════════════════════════
//  Render SVG state map shape (replaces old 3D bar chart)
// ═══════════════════════════════════════════════════════════════════════════
function _svgStateMap(abbr, stateData) {
  const pathData = STATE_PATHS[abbr];
  const adds     = stateData ? ((stateData.adds  || []).length + (stateData.addsDone  || 0)) : 0;
  const terms    = stateData ? ((stateData.terms || []).length + (stateData.termsDone || 0)) : 0;
  const addPend  = stateData ? (stateData.adds  || []).length : 0;
  const termPend = stateData ? (stateData.terms || []).length : 0;
  const total    = adds + terms;

  // Color state fill based on activity
  const fillColor   = total === 0 ? "#E5E7EB" : adds > terms ? "#DBEAFE" : terms > adds ? "#FEE2E2" : "#EDE9FE";
  const strokeColor = total === 0 ? "#9CA3AF" : adds > terms ? "#1D4ED8" : terms > adds ? "#DC2626" : "#7C3AED";

  const mapSVG = pathData
    ? `<svg viewBox="0 0 220 170" width="220" height="170" xmlns="http://www.w3.org/2000/svg" style="display:block;filter:drop-shadow(2px 3px 6px rgba(0,0,0,.18))">
        <!-- Shadow layer -->
        <path d="${pathData}" fill="rgba(0,0,0,.08)" transform="translate(4,5)"/>
        <!-- State fill -->
        <path d="${pathData}" fill="${fillColor}" stroke="${strokeColor}" stroke-width="2.5" stroke-linejoin="round"/>
        <!-- Subtle inner highlight -->
        <path d="${pathData}" fill="url(#stateGradient)" opacity=".4"/>
        <defs>
          <linearGradient id="stateGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="white" stop-opacity=".6"/>
            <stop offset="100%" stop-color="white" stop-opacity="0"/>
          </linearGradient>
        </defs>
      </svg>`
    : `<div style="width:220px;height:170px;display:flex;align-items:center;justify-content:center;
            background:#F3F4F6;border-radius:10px;font-size:48px;font-weight:900;
            color:#9CA3AF;border:2px dashed #D1D5DB">${abbr}</div>`;

  // Mini stats bar
  const statsBar = `
    <div style="display:flex;gap:12px;justify-content:center;margin-top:10px">
      <div style="text-align:center;background:#EFF6FF;border-radius:6px;padding:6px 14px;min-width:64px">
        <div style="font-size:20px;font-weight:900;color:#1D4ED8">${adds}</div>
        <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#93C5FD;margin-top:1px">ADD</div>
        ${addPend > 0 ? `<div style="font-size:9px;color:#6B7280">${addPend} pending</div>` : ""}
      </div>
      <div style="text-align:center;background:#FEF2F2;border-radius:6px;padding:6px 14px;min-width:64px">
        <div style="font-size:20px;font-weight:900;color:#DC2626">${terms}</div>
        <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#FCA5A5;margin-top:1px">TERM</div>
        ${termPend > 0 ? `<div style="font-size:9px;color:#6B7280">${termPend} pending</div>` : ""}
      </div>
      ${total > 0 ? `<div style="text-align:center;background:#F9FAFB;border:1px solid #E5E7EB;border-radius:6px;padding:6px 14px;min-width:64px">
        <div style="font-size:20px;font-weight:900;color:#374151">${total}</div>
        <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#9CA3AF;margin-top:1px">TOTAL</div>
      </div>` : ""}
    </div>`;

  if (!stateData) {
    return `<div style="display:flex;flex-direction:column;align-items:center;padding:16px 8px">
      ${mapSVG}
      <p style="color:#9CA3AF;font-size:12px;margin-top:10px">No data for ${PEO.esc(abbr)} this cycle</p>
    </div>`;
  }

  return `<div style="display:flex;flex-direction:column;align-items:center;padding:16px 8px">
    ${mapSVG}
    ${statsBar}
  </div>`;
}

// ═══════════════════════════════════════════════════════════════════════════
//  Open / close state card
// ═══════════════════════════════════════════════════════════════════════════
PEO.openStateCard = function(abbr, stateData) {
    const fullName = PEO.ABBR_TO_NAME[abbr] || abbr;
    const instSet  = PEO.STATE_INSTRUCTIONS[abbr] || PEO.STATE_INSTRUCTIONS.DEFAULT;

    function stepList(steps) {
        return steps.map((s, i) =>
            `<div class="sc-step">
                <span class="sc-step-num">${i+1}</span>
                <span class="sc-step-txt">${PEO.esc(s)}</span>
            </div>`
        ).join("");
    }

    const card = document.createElement("div");
    card.id        = "stateInfoCard";
    card.className = "state-card-overlay";
    card.innerHTML = `
        <div class="state-card-modal">
            <div class="scm-header">
                <div>
                    <div class="scm-abbr">${PEO.esc(abbr)}</div>
                    <div class="scm-title">${PEO.esc(fullName)}</div>
                </div>
                <button class="scm-close" id="stateCardClose" title="Close">✕</button>
            </div>
            <div class="scm-chart">${_svgStateMap(abbr, stateData)}</div>
            <div class="scm-body">
                <div class="scm-col">
                    <div class="scm-proc-header scm-add">ADD</div>
                    ${stepList(instSet.ADD || [])}
                </div>
                <div class="scm-col">
                    <div class="scm-proc-header scm-term">TERM</div>
                    ${stepList(instSet.TERM || [])}
                </div>
            </div>
            <div class="scm-footer">
                Instructions for ${PEO.esc(fullName)} · Click outside or ✕ to close
            </div>
        </div>`;

    document.body.appendChild(card);
    card.addEventListener("click", e => { if (e.target === card) PEO.closeStateCard(); });
    document.getElementById("stateCardClose")?.addEventListener("click", PEO.closeStateCard);
};

PEO.closeStateCard = function() {
    document.getElementById("stateInfoCard")?.remove();
};
