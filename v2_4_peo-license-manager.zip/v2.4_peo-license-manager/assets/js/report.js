/* global PEO, XLSX */
/* report.js — session PDF report, Excel session log, historic accumulator — v2.4 */
"use strict";

// ═══════════════════════════════════════════════════════════════════════════
//  SECTION 1 — Session Statistics Builder
// ═══════════════════════════════════════════════════════════════════════════

PEO.buildSessionStats = function () {
  const events   = PEO.state._kpiQueue.filter(e => e.action === "GENERATE");
  const operator = PEO.state.selectedUser || PEO.state.session.username || "—";
  const now      = new Date();
  const byState  = {}, byProcess = { ADD: 0, TERM: 0 };

  for (const e of events) {
    const st = e.state || "Unknown", pr = e.process || "—";
    if (!byState[st]) byState[st] = { ADD: 0, TERM: 0, total: 0, totalSec: 0 };
    byState[st][pr]       = (byState[st][pr] || 0) + 1;
    byState[st].total++;
    byState[st].totalSec += parseFloat(e.duration_sec || 0);
    byProcess[pr]         = (byProcess[pr] || 0) + 1;
  }

  const totalSec   = events.reduce((s, e) => s + parseFloat(e.duration_sec || 0), 0);
  const avgSec     = events.length > 0 ? totalSec / events.length : 0;
  const timestamps = events.map(e => e.timestamp).filter(Boolean).sort();
  const formsPerHr = totalSec > 0 ? ((events.length / totalSec) * 3600).toFixed(1) : "—";

  return {
    operator,
    date:         now.toISOString().slice(0, 10),
    datetime:     now.toISOString().slice(0, 16).replace("T", " "),
    totalForms:   events.length,
    byState, byProcess,
    stateCount:   Object.keys(byState).length,
    totalSec:     totalSec.toFixed(1),
    avgSec:       avgSec.toFixed(1),
    formsPerHr,
    sessionStart: timestamps[0]                     || now.toISOString().slice(0, 19),
    sessionEnd:   timestamps[timestamps.length - 1] || now.toISOString().slice(0, 19),
  };
};

// ═══════════════════════════════════════════════════════════════════════════
//  SECTION 2 — Historic Cutoff Modal
// ═══════════════════════════════════════════════════════════════════════════

PEO.showHistoricoCutoffModal = function (filename) {
  return new Promise(resolve => {
    const today       = new Date().toISOString().slice(0, 10);
    const oneMonthAgo = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);
    const ov = document.createElement("div");
    ov.className    = "modal-overlay open";
    ov.style.zIndex = "600";
    ov.innerHTML = `
      <div style="background:var(--surface);border-radius:14px;padding:30px 34px;
                  max-width:480px;width:90vw;display:flex;flex-direction:column;gap:18px;
                  border:1px solid var(--border);box-shadow:0 24px 60px rgba(0,0,0,.5)">
        <div style="display:flex;align-items:center;gap:14px">
          <div style="font-size:30px">📈</div>
          <div>
            <div style="font-size:15px;font-weight:800;color:var(--text)">Historic file found</div>
            <code style="font-size:11px;color:var(--add)">${PEO.esc(filename)}</code>
          </div>
        </div>
        <div style="font-size:13px;color:var(--muted);line-height:1.7">
          From which date should prior data be included in the report?
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          <label style="font-size:11px;font-weight:700;text-transform:uppercase;
                        letter-spacing:.06em;color:var(--muted)">Include from:</label>
          <input type="date" id="cutoffDateInput" value="${oneMonthAgo}" max="${today}"
                  style="padding:9px 12px;border:1px solid var(--border);border-radius:var(--radius);
                        background:var(--surface2);color:var(--text);font-size:13px;
                        font-family:inherit;width:100%">
          <div style="font-size:11px;color:var(--muted)">
            Leave empty for <strong style="color:var(--text)">all history</strong>.
          </div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="main-btn cta" id="cutoffConfirmBtn" style="flex:1">Confirm date</button>
          <button class="main-btn" id="cutoffAllBtn">All history</button>
          <button class="main-btn" id="cutoffIgnoreBtn">Skip</button>
        </div>
      </div>`;
    document.body.appendChild(ov);
    document.getElementById("cutoffConfirmBtn").addEventListener("click", () => {
      const val = document.getElementById("cutoffDateInput").value.trim();
      ov.remove(); resolve(val || null);
    });
    document.getElementById("cutoffAllBtn").addEventListener("click",  () => { ov.remove(); resolve(null); });
    document.getElementById("cutoffIgnoreBtn").addEventListener("click", () => {
      PEO.state.historicoFile = null; ov.remove(); resolve(undefined);
    });
  });
};

// ═══════════════════════════════════════════════════════════════════════════
//  SECTION 3 — Color Palette & SVG Helpers
// ═══════════════════════════════════════════════════════════════════════════

const RPT_C = {
  blue900: "#0C1F4A", blue800: "#1E3A5F", blue700: "#1D4ED8",
  blue600: "#2563EB", blue500: "#3B82F6", blue300: "#93C5FD",
  blue100: "#DBEAFE", blue50:  "#EFF6FF",
  red700:  "#B91C1C", red600:  "#DC2626", red500:  "#EF4444", red100: "#FEE2E2",
  gray900: "#111827", gray700: "#374151", gray500: "#6B7280",
  gray400: "#9CA3AF", gray300: "#D1D5DB", gray200: "#E5E7EB",
  gray100: "#F3F4F6", gray50:  "#F9FAFB", white:   "#FFFFFF",
};

function _svgBarChart(byState) {
  const entries = Object.entries(byState).sort((a, b) => b[1].total - a[1].total);
  if (!entries.length)
    return "<p style='color:" + RPT_C.gray400 + ";font-size:12px;padding:16px 0'>No forms generated this session.</p>";

  const maxVal  = Math.max(...entries.map(([, v]) => v.total), 1);
  const BAR_W   = Math.max(28, Math.min(52, Math.floor(520 / entries.length) - 6));
  const GAP = 6, CHART_H = 190, LABEL_H = 24, PAD_L = 34;
  const totalW  = PAD_L + entries.length * (BAR_W + GAP) + 20;
  let bars = "";

  entries.forEach(([state, data], i) => {
    const x = PAD_L + i * (BAR_W + GAP);
    const addH  = data.ADD  > 0 ? Math.max(8, Math.round((data.ADD  / maxVal) * (CHART_H - 40))) : 0;
    const termH = data.TERM > 0 ? Math.max(8, Math.round((data.TERM / maxVal) * (CHART_H - 40))) : 0;
    const totalH = addH + termH;
    const yBase  = CHART_H - LABEL_H;

    if (termH > 0)
      bars += '<rect x="' + x + '" y="' + (yBase-totalH) + '" width="' + BAR_W + '" height="' + termH + '" fill="' + RPT_C.red600 + '" rx="3" opacity=".9"/>';
    if (addH > 0) {
      const addY = yBase - totalH + termH;
      bars += '<rect x="' + x + '" y="' + addY + '" width="' + BAR_W + '" height="' + addH + '" fill="' + RPT_C.blue600 + '" rx="' + (termH===0?3:0) + '" opacity=".95"/>';
      if (termH > 0)
        bars += '<rect x="' + x + '" y="' + addY + '" width="' + BAR_W + '" height="4" fill="' + RPT_C.blue600 + '" opacity=".95"/>';
    }
    bars += '<text x="' + (x+BAR_W/2) + '" y="' + (yBase-totalH-7) + '" text-anchor="middle" font-size="10" font-weight="800" fill="' + RPT_C.gray700 + '">' + data.total + '</text>';
    const lbl = state.length > 8 ? state.slice(0, 8) + "…" : state;
    bars += '<text x="' + (x+BAR_W/2) + '" y="' + (yBase+17) + '" text-anchor="middle" font-size="9" font-weight="700" fill="' + RPT_C.gray500 + '">' + lbl + '</text>';
  });

  const refs = [0.25, 0.5, 0.75, 1].map(pct => {
    const y = CHART_H - LABEL_H - Math.round(pct * (CHART_H - 40));
    const v = Math.round(pct * maxVal);
    return '<line x1="' + (PAD_L-4) + '" y1="' + y + '" x2="' + (totalW-4) + '" y2="' + y + '" stroke="' + RPT_C.gray200 + '" stroke-width="1" stroke-dasharray="4,3"/>' +
           '<text x="' + (PAD_L-7) + '" y="' + (y+4) + '" text-anchor="end" font-size="8" fill="' + RPT_C.gray400 + '">' + v + '</text>';
  }).join("");

  return '<svg width="' + totalW + '" height="' + (CHART_H+4) + '" xmlns="http://www.w3.org/2000/svg" style="overflow:visible;display:block">' +
    refs + bars +
    '<line x1="' + PAD_L + '" y1="0" x2="' + PAD_L + '" y2="' + (CHART_H-LABEL_H) + '" stroke="' + RPT_C.gray300 + '" stroke-width="1"/>' +
    '<line x1="' + PAD_L + '" y1="' + (CHART_H-LABEL_H) + '" x2="' + (totalW-4) + '" y2="' + (CHART_H-LABEL_H) + '" stroke="' + RPT_C.gray300 + '" stroke-width="1"/>' +
    '</svg>';
}

function _svgSparkline(values, color) {
  if (!values || values.length < 2) return "";
  const W = 120, H = 36, pad = 4;
  const max = Math.max(...values, 1), min = Math.min(...values, 0);
  const range = max - min || 1;
  const pts = values.map((v, i) => {
    const x = pad + (i / (values.length - 1)) * (W - pad * 2);
    const y = H - pad - ((v - min) / range) * (H - pad * 2);
    return x.toFixed(1) + "," + y.toFixed(1);
  }).join(" ");
  const lastPt = pts.split(" ").pop().split(",");
  return '<svg width="' + W + '" height="' + H + '" xmlns="http://www.w3.org/2000/svg">' +
    '<polyline points="' + pts + '" fill="none" stroke="' + color + '" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" opacity=".8"/>' +
    '<circle cx="' + lastPt[0] + '" cy="' + lastPt[1] + '" r="3" fill="' + color + '"/>' +
    '</svg>';
}

function _svgDonut(adds, terms) {
  const total = adds + terms || 1;
  const addPct = adds / total;
  const R = 38, cx = 48, cy = 48, thickness = 12;
  const r = R - thickness / 2;
  const circumference = 2 * Math.PI * r;
  const addArc  = circumference * addPct;
  const termArc = circumference * (1 - addPct);
  return '<svg width="96" height="96" xmlns="http://www.w3.org/2000/svg">' +
    '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" stroke="' + RPT_C.red100 + '" stroke-width="' + thickness + '"/>' +
    '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" stroke="' + RPT_C.blue600 + '" stroke-width="' + thickness + '" stroke-dasharray="' + addArc + ' ' + circumference + '" stroke-dashoffset="' + (circumference * 0.25) + '" stroke-linecap="round"/>' +
    '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" stroke="' + RPT_C.red600 + '" stroke-width="' + thickness + '" stroke-dasharray="' + termArc + ' ' + circumference + '" stroke-dashoffset="' + (circumference * (0.25 - addPct)) + '" stroke-linecap="round" opacity=".85"/>' +
    '<text x="' + cx + '" y="' + (cy-6) + '" text-anchor="middle" font-size="13" font-weight="800" fill="' + RPT_C.gray900 + '">' + Math.round(addPct * 100) + '%</text>' +
    '<text x="' + cx + '" y="' + (cy+8) + '" text-anchor="middle" font-size="9" fill="' + RPT_C.gray500 + '">ADD</text>' +
    '</svg>';
}

// ═══════════════════════════════════════════════════════════════════════════
//  SECTION 4 — Comparison Block Builder
// ═══════════════════════════════════════════════════════════════════════════

function _buildComparison(stats, historicoRows) {
  const norm = v => String(v ?? "").trim().toLowerCase();
  const myH = historicoRows.filter(h =>
    norm(h["Operator"] || h.operador) === norm(stats.operator));

  function getNum(row) {
    var keys = Array.prototype.slice.call(arguments, 1);
    for (var i = 0; i < keys.length; i++) {
      var v = row[keys[i]];
      if (v !== undefined && v !== "") return Number(v) || 0;
    }
    return 0;
  }
  function avg(arr) {
    var fields = Array.prototype.slice.call(arguments, 1);
    if (!arr.length) return null;
    return arr.reduce(function(s, h) { return s + getNum.apply(null, [h].concat(fields)); }, 0) / arr.length;
  }
  function fmt(v, sfx) { sfx = sfx || ""; return v === null ? "—" : Number(v).toFixed(1) + sfx; }
  function delta(session, ref, hib) {
    if (ref === null) return { html: "—", cls: "" };
    const d = session - ref;
    const good = hib ? d >= 0 : d <= 0;
    const arr  = Math.abs(d) < 0.05 ? "→" : d > 0 ? "▲" : "▼";
    const sign = d >= 0 ? "+" : "";
    return {
      html: arr + " " + sign + Math.abs(d).toFixed(1),
      cls:  Math.abs(d) < 0.05 ? "delta-neu" : good ? "delta-pos" : "delta-neg",
    };
  }

  const metrics = [
    { label:"Total Forms",    session:stats.totalForms,          myAvg:avg(myH,"Total Forms","total_formularios"),  teamAvg:avg(historicoRows,"Total Forms","total_formularios"),  hib:true,  sfx:"" },
    { label:"ADDs",           session:stats.byProcess.ADD || 0,  myAvg:avg(myH,"ADDs","adds"),                      teamAvg:avg(historicoRows,"ADDs","adds"),                      hib:true,  sfx:"" },
    { label:"TERMs",          session:stats.byProcess.TERM || 0, myAvg:avg(myH,"TERMs","terms"),                    teamAvg:avg(historicoRows,"TERMs","terms"),                    hib:true,  sfx:"" },
    { label:"States Covered", session:stats.stateCount,          myAvg:avg(myH,"States","estados"),                 teamAvg:avg(historicoRows,"States","estados"),                 hib:true,  sfx:"" },
    { label:"Avg Sec / Form", session:parseFloat(stats.avgSec),
      myAvg:avg(myH,"Avg Sec/Form","tiempo_promedio_seg"),
      teamAvg:avg(historicoRows,"Avg Sec/Form","tiempo_promedio_seg"),
      hib:false, sfx:"s" },
  ];
  return { metrics, mySessionCount: myH.length, teamSessionCount: historicoRows.length, fmt, delta, myH };
}

// ═══════════════════════════════════════════════════════════════════════════
//  SECTION 5 — Common CSS for reports
// ═══════════════════════════════════════════════════════════════════════════

function _reportCSS(isLeader) {
  const C = RPT_C;
  const pageSize = isLeader ? "A4 landscape" : "A4";
  return "@page { margin:15mm 13mm; size:" + pageSize + "; }" +
    "*,*::before,*::after { box-sizing:border-box; margin:0; padding:0; }" +
    "body { font-family:'Segoe UI',system-ui,Arial,sans-serif; color:" + C.gray900 + "; background:" + C.white + "; font-size:13px; line-height:1.55; }" +
    ".pbar { background:" + C.blue900 + "; color:#E2E8F0; padding:10px 36px; display:flex; justify-content:space-between; align-items:center; }" +
    ".pbar button { background:" + C.blue700 + "; color:" + C.white + "; border:none; padding:7px 22px; border-radius:6px; font-size:12px; font-weight:700; cursor:pointer; font-family:inherit; }" +
    ".pbar button:hover { background:#1E40AF; }" +
    "@media print { .pbar{display:none;} body{-webkit-print-color-adjust:exact;print-color-adjust:exact;} }" +
    ".hdr { background:linear-gradient(135deg," + C.blue900 + " 0%," + C.blue800 + " 55%," + C.blue700 + " 100%); color:" + C.white + "; padding:28px 40px 24px; display:flex; justify-content:space-between; align-items:flex-start; }" +
    ".hdr-badge { background:rgba(255,255,255,.15); border:1px solid rgba(255,255,255,.3); border-radius:20px; padding:3px 14px; font-size:10px; font-weight:800; text-transform:uppercase; letter-spacing:.1em; margin-bottom:10px; display:inline-block; }" +
    ".hdr-title { font-size:24px; font-weight:900; letter-spacing:-.3px; }" +
    ".hdr-sub { font-size:12px; color:rgba(255,255,255,.55); margin-top:5px; }" +
    ".hdr-right { text-align:right; }" +
    ".hdr-op { font-size:18px; font-weight:800; color:" + C.blue300 + "; }" +
    ".hdr-detail { font-size:11px; color:rgba(255,255,255,.55); margin-top:6px; line-height:2; }" +
    ".kpi-strip { display:grid; grid-template-columns:repeat(6,1fr); background:" + C.gray50 + "; border-bottom:2px solid " + C.gray200 + "; }" +
    ".kpi-strip.five { grid-template-columns:repeat(5,1fr); }" +
    ".kc { padding:16px 6px; text-align:center; border-right:1px solid " + C.gray200 + "; }" +
    ".kc:last-child { border-right:none; }" +
    ".kv { font-size:26px; font-weight:900; line-height:1.1; color:" + C.gray900 + "; }" +
    ".kv.blue { color:" + C.blue700 + "; } .kv.red { color:" + C.red700 + "; }" +
    ".kl { font-size:10px; color:" + C.gray400 + "; text-transform:uppercase; letter-spacing:.06em; margin-top:4px; }" +
    ".block { margin:0 28px 22px; border:1px solid " + C.gray200 + "; border-radius:10px; overflow:hidden; box-shadow:0 1px 4px rgba(0,0,0,.06); }" +
    ".block-header { display:flex; align-items:center; gap:12px; padding:12px 22px; }" +
    ".bh1 { background:" + C.blue900 + "; color:" + C.white + "; }" +
    ".bh2 { background:" + C.blue800 + "; color:" + C.white + "; }" +
    ".bh3 { background:" + C.blue700 + "; color:" + C.white + "; }" +
    ".bh4 { background:" + C.gray900 + "; color:" + C.white + "; }" +
    ".block-num { font-size:22px; font-weight:900; opacity:.28; }" +
    ".block-title { font-size:15px; font-weight:800; flex:1; }" +
    ".block-sub { font-size:11px; opacity:.65; }" +
    ".chart-title { font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:.08em; color:" + C.gray500 + "; margin-bottom:12px; }" +
    ".viz-row { display:flex; gap:20px; padding:18px 22px 8px; align-items:flex-start; }" +
    ".viz-main { flex:1; min-width:0; }" +
    ".viz-side { width:152px; flex-shrink:0; display:flex; flex-direction:column; gap:7px; }" +
    ".sc { background:" + C.gray50 + "; border:1px solid " + C.gray200 + "; border-radius:6px; padding:8px 10px; border-left:3px solid " + C.gray300 + "; }" +
    ".sc.blue { border-left-color:" + C.blue600 + "; } .sc.red { border-left-color:" + C.red600 + "; }" +
    ".sc-l { font-size:9px; color:" + C.gray400 + "; text-transform:uppercase; letter-spacing:.05em; }" +
    ".sc-v { font-size:15px; font-weight:800; color:" + C.gray900 + "; margin-top:1px; }" +
    ".dt { width:100%; border-collapse:collapse; font-size:12px; }" +
    ".dt thead tr { background:" + C.gray900 + "; color:" + C.white + "; }" +
    ".dt thead th { padding:9px 13px; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:.06em; font-weight:700; }" +
    ".dt tbody tr:nth-child(even),.dt tbody tr.even { background:" + C.gray50 + "; }" +
    ".dt tbody tr:hover { background:" + C.blue50 + "; }" +
    ".td-l { padding:8px 13px; font-weight:600; }" +
    ".td-c { padding:8px 13px; text-align:center; }" +
    ".fw7 { font-weight:700; } .mu { color:" + C.gray400 + "; }" +
    ".ba { background:" + C.blue100 + "; color:" + C.blue700 + "; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:700; }" +
    ".bt { background:" + C.red100 + "; color:" + C.red700 + "; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:700; }" +
    ".comp-tbl thead th:nth-child(2) { background:" + C.blue700 + "; }" +
    ".cmp-lbl { padding:9px 13px; font-weight:600; }" +
    ".cmp-val { padding:9px 13px; text-align:center; }" +
    ".cmp-me { font-weight:800; color:" + C.blue700 + "; background:" + C.blue50 + "; }" +
    ".cmp-d { padding:9px 13px; text-align:center; font-size:11px; font-weight:700; }" +
    ".delta-pos { color:#166534; } .delta-neg { color:" + C.red700 + "; } .delta-neu { color:" + C.gray400 + "; }" +
    ".no-data { padding:18px 22px; font-size:12px; color:" + C.gray400 + "; }" +
    ".leg { display:flex; gap:14px; padding:6px 22px 12px; flex-wrap:wrap; }" +
    ".li { display:flex; align-items:center; gap:5px; font-size:11px; color:" + C.gray500 + "; }" +
    ".ld { width:11px; height:11px; border-radius:2px; flex-shrink:0; }" +
    ".hl-row { display:grid; grid-template-columns:repeat(5,1fr); background:" + C.white + "; border-bottom:1px solid " + C.gray200 + "; padding:14px 22px; gap:12px; }" +
    ".hl { background:" + C.gray50 + "; border:1px solid " + C.gray200 + "; border-radius:8px; padding:12px 14px; border-top:3px solid " + C.blue700 + "; }" +
    ".hl.red { border-top-color:" + C.red600 + "; }" +
    ".hl-v { font-size:15px; font-weight:800; color:" + C.gray900 + "; margin-bottom:3px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }" +
    ".hl-l { font-size:9px; text-transform:uppercase; letter-spacing:.07em; color:" + C.gray400 + "; }" +
    ".chart-area { padding:20px 22px 10px; background:" + C.white + "; }" +
    ".ftr { padding:12px 40px; background:" + C.gray50 + "; border-top:1px solid " + C.gray200 + "; display:flex; justify-content:space-between; font-size:10px; color:" + C.gray400 + "; }";
}

// ═══════════════════════════════════════════════════════════════════════════
//  SECTION 6 — Leader Report (standalone, no PDF needed first)
// ═══════════════════════════════════════════════════════════════════════════

PEO.generateLeaderReport = async function () {
  const histRows = await _readHistoricoRows(PEO.state.historicoCutoffDate);
  if (!histRows.length) {
    PEO.notify("No historic data. Load historico_informe.xlsx first.", "err");
    return;
  }
  const operator = PEO.state.session.username || PEO.state.selectedUser || "Leader";
  const now      = new Date();
  const datetime = now.toISOString().slice(0, 16).replace("T", " ");
  const date     = now.toISOString().slice(0, 10);
  const C        = RPT_C;

  // Aggregate by operator
  const byOp = {};
  for (const r of histRows) {
    const op = String(r["Operator"] || r.operador || "—").trim();
    if (!byOp[op]) byOp[op] = { op, sessions:0, forms:0, adds:0, terms:0, sec:0, dates:[] };
    byOp[op].sessions++;
    byOp[op].forms  += Number(r["Total Forms"] || r.total_formularios) || 0;
    byOp[op].adds   += Number(r["ADDs"] || r.adds) || 0;
    byOp[op].terms  += Number(r["TERMs"] || r.terms) || 0;
    byOp[op].sec    += Number(r["Total Sec"] || r.tiempo_total_seg) || 0;
    const d = String(r["Date"] || r.fecha_realizacion || "").slice(0, 10);
    if (d) byOp[op].dates.push(d);
  }
  const ops = Object.values(byOp).map(o => ({
    ...o,
    avgForms:   o.sessions ? (o.forms / o.sessions).toFixed(1)       : "0",
    avgSec:     o.forms    ? (o.sec   / o.forms).toFixed(1)          : "0",
    formsPerHr: o.sec > 0  ? (o.forms / (o.sec / 3600)).toFixed(1)  : "0",
    lastSession: o.dates.sort().pop() || "—",
  })).sort((a, b) => b.forms - a.forms);

  const totalForms = ops.reduce((s, o) => s + o.forms, 0);
  const totalAdds  = ops.reduce((s, o) => s + o.adds,  0);
  const totalTerms = ops.reduce((s, o) => s + o.terms, 0);
  const totalSess  = ops.reduce((s, o) => s + o.sessions, 0);
  const allSec     = ops.reduce((s, o) => s + o.sec,   0);
  const teamAvgSec = totalForms > 0 ? (allSec / totalForms).toFixed(1) : "—";

  const best      = ops[0];
  const mostAdds  = [...ops].sort((a, b) => b.adds    - a.adds)[0];
  const mostTerms = [...ops].sort((a, b) => b.terms   - a.terms)[0];
  const fastest   = [...ops].sort((a, b) => parseFloat(a.avgSec) - parseFloat(b.avgSec))[0];
  const mostAct   = [...ops].sort((a, b) => b.sessions - a.sessions)[0];

  // Leader bar chart
  function leaderBarSVG(ops) {
    const maxF = Math.max(...ops.map(o => o.forms), 1);
    const W = 560, H = 220, PAD_L = 36, PAD_B = 44;
    const BAR_W = Math.max(24, Math.min(60, Math.floor((W - PAD_L - 20) / ops.length) - 8));
    const GAP   = (W - PAD_L - 20 - ops.length * BAR_W) / (ops.length + 1);
    let svgBars = "";

    ops.forEach((o, i) => {
      const x      = PAD_L + GAP + i * (BAR_W + GAP);
      const fullH  = H - PAD_B - 20;
      const formH  = Math.round((o.forms / maxF) * fullH);
      const addH   = o.forms > 0 ? Math.round((o.adds / o.forms) * formH) : 0;
      const termH  = formH - addH;
      const yBase  = H - PAD_B;

      if (termH > 0)
        svgBars += '<rect x="' + x + '" y="' + (yBase-formH) + '" width="' + BAR_W + '" height="' + termH + '" fill="' + C.red600 + '" rx="3" opacity=".85"/>';
      if (addH > 0) {
        const addY = yBase - formH + termH;
        svgBars += '<rect x="' + x + '" y="' + addY + '" width="' + BAR_W + '" height="' + addH + '" fill="' + C.blue600 + '" rx="' + (termH===0?3:0) + '" opacity=".95"/>';
        if (termH > 0) svgBars += '<rect x="' + x + '" y="' + addY + '" width="' + BAR_W + '" height="4" fill="' + C.blue600 + '" opacity=".95"/>';
      }
      if (i === 0) svgBars += '<text x="' + (x+BAR_W/2) + '" y="' + (yBase-formH-18) + '" text-anchor="middle" font-size="14">👑</text>';
      svgBars += '<text x="' + (x+BAR_W/2) + '" y="' + (yBase-formH-6) + '" text-anchor="middle" font-size="10" font-weight="800" fill="' + C.gray700 + '">' + o.forms + '</text>';
      const lbl = o.op.split(" ")[0];
      svgBars += '<text x="' + (x+BAR_W/2) + '" y="' + (yBase+16) + '" text-anchor="middle" font-size="9" font-weight="700" fill="' + C.gray500 + '">' + PEO.esc(lbl) + '</text>';
      svgBars += '<text x="' + (x+BAR_W/2) + '" y="' + (yBase+28) + '" text-anchor="middle" font-size="8" fill="' + C.gray400 + '">' + o.sessions + ' sess</text>';
    });

    const gridLines = [0.25, 0.5, 0.75, 1].map(pct => {
      const y = H - PAD_B - Math.round(pct * (H - PAD_B - 20));
      const v = Math.round(pct * maxF);
      return '<line x1="' + PAD_L + '" y1="' + y + '" x2="' + W + '" y2="' + y + '" stroke="' + C.gray200 + '" stroke-width="1" stroke-dasharray="4,3"/>' +
             '<text x="' + (PAD_L-6) + '" y="' + (y+4) + '" text-anchor="end" font-size="8" fill="' + C.gray400 + '">' + v + '</text>';
    }).join("");

    return '<svg width="' + W + '" height="' + H + '" xmlns="http://www.w3.org/2000/svg" style="display:block;overflow:visible">' +
      gridLines + svgBars +
      '<line x1="' + PAD_L + '" y1="' + (H-PAD_B) + '" x2="' + W + '" y2="' + (H-PAD_B) + '" stroke="' + C.gray300 + '" stroke-width="1.5"/>' +
      '</svg>';
  }

  const tableRows = ops.map((o, i) => {
    const rank  = i + 1;
    const medal = rank===1?"🥇":rank===2?"🥈":rank===3?"🥉":(rank+".");
    return '<tr class="' + (i%2?"even":"") + '">' +
      '<td class="td-l" style="font-weight:700">' + medal + ' ' + PEO.esc(o.op) + '</td>' +
      '<td class="td-c">' + o.sessions + '</td>' +
      '<td class="td-c fw7">' + o.forms + '</td>' +
      '<td class="td-c"><span class="ba">' + o.adds + '</span></td>' +
      '<td class="td-c"><span class="bt">' + o.terms + '</span></td>' +
      '<td class="td-c">' + o.avgForms + '</td>' +
      '<td class="td-c mu">' + o.avgSec + 's</td>' +
      '<td class="td-c" style="color:' + C.blue700 + ';font-weight:700">' + o.formsPerHr + '/hr</td>' +
      '<td class="td-c" style="color:' + C.gray500 + ';font-size:10px">' + o.lastSession + '</td>' +
      '</tr>';
  }).join("");

  const html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">' +
    '<title>Leader Report · PEO License Manager · ' + date + '</title>' +
    '<style>' + _reportCSS(true) + '</style></head><body>' +
    '<div class="pbar"><span>⚖ PEO License Manager &nbsp;·&nbsp; Leader Dashboard &nbsp;·&nbsp; ' + PEO.esc(operator) + '</span>' +
    '<button onclick="window.print()">⬇ Save as PDF</button></div>' +
    '<div class="hdr"><div>' +
    '<div class="hdr-badge">Leader Dashboard</div>' +
    '<div class="hdr-title">PEO License Manager</div>' +
    '<div class="hdr-sub">Team Performance Report · ' + datetime + '</div>' +
    '</div><div class="hdr-right">' +
    '<div class="hdr-op">' + PEO.esc(operator) + '</div>' +
    '<div class="hdr-detail">' + histRows.length + ' sessions analyzed<br>' + ops.length + ' active operators<br>Generated: ' + datetime + '</div>' +
    '</div></div>' +
    '<div class="kpi-strip five">' +
    '<div class="kc"><div class="kv">' + totalForms + '</div><div class="kl">Total Forms (All Time)</div></div>' +
    '<div class="kc"><div class="kv blue">' + totalAdds  + '</div><div class="kl">Total ADDs</div></div>' +
    '<div class="kc"><div class="kv red">'  + totalTerms + '</div><div class="kl">Total TERMs</div></div>' +
    '<div class="kc"><div class="kv">' + totalSess + '</div><div class="kl">Total Sessions</div></div>' +
    '<div class="kc"><div class="kv">' + teamAvgSec + 's</div><div class="kl">Team Avg Sec / Form</div></div>' +
    '</div>' +
    '<div style="margin:24px 28px 0">' +
    '<div class="block">' +
    '<div class="block-header bh1"><span class="block-num">01</span><span class="block-title">Team Highlights</span><span class="block-sub">Top performers across all sessions</span></div>' +
    '<div class="hl-row">' +
    '<div class="hl"><div class="hl-v">' + PEO.esc(best.op) + '</div><div class="hl-l">🏆 Most Forms · ' + best.forms + ' total</div></div>' +
    '<div class="hl"><div class="hl-v">' + PEO.esc(mostAdds.op) + '</div><div class="hl-l">➕ Most ADDs · ' + mostAdds.adds + ' total</div></div>' +
    '<div class="hl red"><div class="hl-v">' + PEO.esc(mostTerms.op) + '</div><div class="hl-l">❌ Most TERMs · ' + mostTerms.terms + ' total</div></div>' +
    '<div class="hl"><div class="hl-v">' + PEO.esc(fastest.op) + '</div><div class="hl-l">⚡ Fastest · ' + fastest.avgSec + 's avg</div></div>' +
    '<div class="hl"><div class="hl-v">' + PEO.esc(mostAct.op) + '</div><div class="hl-l">📅 Most Active · ' + mostAct.sessions + ' sessions</div></div>' +
    '</div></div></div>' +
    '<div style="margin:0 28px">' +
    '<div class="block"><div class="block-header bh2"><span class="block-num">02</span><span class="block-title">Team Forms Comparison</span><span class="block-sub">Stacked ADD (blue) + TERM (red) per operator</span></div>' +
    '<div class="chart-area"><div class="chart-title">Total Forms per Operator — All Historical Sessions</div>' + leaderBarSVG(ops) + '</div>' +
    '<div class="leg"><div class="li"><div class="ld" style="background:' + C.blue600 + '"></div>ADD forms</div><div class="li"><div class="ld" style="background:' + C.red600 + '"></div>TERM forms</div></div>' +
    '</div></div>' +
    '<div style="margin:0 28px 28px">' +
    '<div class="block"><div class="block-header bh3"><span class="block-num">03</span><span class="block-title">Operator Detail Table</span><span class="block-sub">Ranked by total forms processed</span></div>' +
    '<table class="dt"><thead><tr><th>Operator</th><th>Sessions</th><th>Total Forms</th><th>ADDs</th><th>TERMs</th><th>Avg/Session</th><th>Avg Sec/Form</th><th>Forms/hr</th><th>Last Session</th></tr></thead>' +
    '<tbody>' + tableRows + '</tbody></table></div></div>' +
    '<div class="ftr"><span>PEO License Manager · Leader Report · Auto-generated · ' + datetime + '</span><span>Prepared by: ' + PEO.esc(operator) + ' · ' + histRows.length + ' session(s)</span></div>' +
    '</body></html>';

  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url  = URL.createObjectURL(blob);
  const win  = window.open(url, "_blank");
  if (!win) PEO.notify("Enable pop-ups to view the Leader Report.", "err");
  setTimeout(() => URL.revokeObjectURL(url), 15000);
};

// ═══════════════════════════════════════════════════════════════════════════
//  SECTION 7 — Individual Operator PDF Report (Redesigned)
// ═══════════════════════════════════════════════════════════════════════════

PEO.generatePdfReport = function (stats, historicoRows) {
  historicoRows = historicoRows || [];
  const comp    = _buildComparison(stats, historicoRows);
  const hasComp = historicoRows.length > 0;
  const byState = stats.byState;
  const C       = RPT_C;

  const topState = Object.entries(byState).sort((a, b) => b[1].total - a[1].total)[0]?.[0] || "—";
  const soloAdd  = Object.values(byState).filter(d => d.ADD > 0 && d.TERM === 0).length;
  const soloTerm = Object.values(byState).filter(d => d.TERM > 0 && d.ADD === 0).length;
  const both     = Object.values(byState).filter(d => d.ADD > 0 && d.TERM > 0).length;
  const addRatio = stats.totalForms > 0 ? Math.round(((stats.byProcess.ADD || 0) / stats.totalForms) * 100) : 0;

  const avgS       = parseFloat(stats.avgSec);
  const speedLabel = avgS === 0 ? "—" : avgS < 60 ? "Excellent" : avgS < 120 ? "Good" : avgS < 180 ? "Average" : "Needs Improvement";
  const speedColor = avgS === 0 ? C.gray400 : avgS < 60 ? "#166534" : avgS < 120 ? C.blue700 : avgS < 180 ? "#92400E" : C.red700;

  const compRows = comp.metrics.map(m => {
    const dMy   = comp.delta(m.session, m.myAvg,   m.hib);
    const dTeam = comp.delta(m.session, m.teamAvg, m.hib);
    return '<tr>' +
      '<td class="cmp-lbl">' + m.label + '</td>' +
      '<td class="cmp-val cmp-me">' + m.session + m.sfx + '</td>' +
      '<td class="cmp-val">' + comp.fmt(m.myAvg, m.sfx) + '</td>' +
      '<td class="cmp-val">' + comp.fmt(m.teamAvg, m.sfx) + '</td>' +
      '<td class="cmp-d ' + dMy.cls + '">' + dMy.html + '</td>' +
      '<td class="cmp-d ' + dTeam.cls + '">' + dTeam.html + '</td>' +
      '</tr>';
  }).join("");

  // BLOCK 1: Session overview
  const block1 =
    '<div class="block">' +
    '<div class="block-header bh1"><span class="block-num">01</span><span class="block-title">Session Overview</span><span class="block-sub">' + stats.datetime + ' · ' + PEO.esc(stats.operator) + '</span></div>' +
    '<div class="kpi-strip"><div class="kc"><div class="kv">' + stats.totalForms + '</div><div class="kl">Total Forms</div></div>' +
    '<div class="kc"><div class="kv blue">' + (stats.byProcess.ADD||0) + '</div><div class="kl">ADD Forms</div></div>' +
    '<div class="kc"><div class="kv red">' + (stats.byProcess.TERM||0) + '</div><div class="kl">TERM Forms</div></div>' +
    '<div class="kc"><div class="kv">' + stats.stateCount + '</div><div class="kl">States Covered</div></div>' +
    '<div class="kc"><div class="kv">' + stats.avgSec + 's</div><div class="kl">Avg / Form</div></div>' +
    '<div class="kc"><div class="kv">' + stats.totalSec + 's</div><div class="kl">Total Time</div></div>' +
    '</div>' +
    '<div class="viz-row"><div class="viz-main"><div class="chart-title">Forms by State — ADD vs TERM</div>' +
    _svgBarChart(stats.byState) + '</div>' +
    '<div class="viz-side">' +
    '<div style="margin-bottom:6px">' + _svgDonut(stats.byProcess.ADD||0, stats.byProcess.TERM||0) + '</div>' +
    '<div class="sc"><div class="sc-l">Top State</div><div class="sc-v">' + topState + '</div></div>' +
    '<div class="sc blue"><div class="sc-l">ADD Only</div><div class="sc-v">' + soloAdd + '</div></div>' +
    '<div class="sc red"><div class="sc-l">TERM Only</div><div class="sc-v">' + soloTerm + '</div></div>' +
    '<div class="sc"><div class="sc-l">Both</div><div class="sc-v">' + both + '</div></div>' +
    '<div class="sc"><div class="sc-l">Speed Rating</div><div class="sc-v" style="color:' + speedColor + ';font-size:12px">' + speedLabel + '</div></div>' +
    '<div class="sc"><div class="sc-l">ADD Ratio</div><div class="sc-v" style="color:' + C.blue700 + '">' + addRatio + '%</div></div>' +
    '<div class="sc"><div class="sc-l">Forms/hr</div><div class="sc-v">' + stats.formsPerHr + '</div></div>' +
    '</div></div>' +
    '<div class="leg"><div class="li"><div class="ld" style="background:' + C.blue600 + '"></div>ADD</div>' +
    '<div class="li"><div class="ld" style="background:' + C.red600 + '"></div>TERM</div></div>' +
    '</div>';

  // BLOCK 2: Your history
  const myHist8    = comp.myH.slice(-8);
  const histForms  = myHist8.map(h => Number(h["Total Forms"]||h.total_formularios)||0);
  const myTotalSes = comp.myH.length;
  const myAvgForms = myTotalSes > 0
    ? (comp.myH.reduce((s, h) => s+(Number(h["Total Forms"]||h.total_formularios)||0),0)/myTotalSes).toFixed(1)
    : "—";
  const myBestForms = histForms.length > 0 ? Math.max(...histForms) : "—";

  const histRows8 = myHist8.map((h, i) => {
    const f   = Number(h["Total Forms"]||h.total_formularios)||0;
    const sec = Number(h["Total Sec"]||h.tiempo_total_seg)||0;
    const fph = f > 0 && sec > 0 ? (f/(sec/3600)).toFixed(1) : "—";
    return '<tr class="' + (i%2?"even":"") + '">' +
      '<td class="td-l">' + PEO.esc(String(h["Date"]||h.fecha_realizacion||"").slice(0,16)) + '</td>' +
      '<td class="td-c fw7">' + f + '</td>' +
      '<td class="td-c"><span class="ba">' + (h["ADDs"]||h.adds||0) + '</span></td>' +
      '<td class="td-c"><span class="bt">' + (h["TERMs"]||h.terms||0) + '</span></td>' +
      '<td class="td-c">' + (h["States"]||h.estados||0) + '</td>' +
      '<td class="td-c mu">' + ((h["Avg Sec/Form"]||h.tiempo_promedio_seg)?Number(h["Avg Sec/Form"]||h.tiempo_promedio_seg).toFixed(1)+"s":"—") + '</td>' +
      '<td class="td-c" style="color:' + C.blue700 + ';font-weight:700">' + (fph!=="—"?fph+"/hr":"—") + '</td>' +
      '</tr>';
  }).join("");

  const block2 =
    '<div class="block">' +
    '<div class="block-header bh2"><span class="block-num">02</span><span class="block-title">Your History</span><span class="block-sub">Last ' + myHist8.length + ' of your recorded sessions</span></div>' +
    (myHist8.length ? (
      '<div style="padding:10px 22px 4px;display:flex;align-items:center;gap:16px">' +
      '<div><div class="chart-title">Forms Trend</div>' + _svgSparkline(histForms, C.blue600) + '</div>' +
      '<div style="display:flex;gap:10px;flex-wrap:wrap">' +
      '<div class="sc" style="min-width:90px"><div class="sc-l">Best Session</div><div class="sc-v">' + myBestForms + '</div></div>' +
      '<div class="sc" style="min-width:90px"><div class="sc-l">Your Avg Forms</div><div class="sc-v">' + myAvgForms + '</div></div>' +
      '<div class="sc" style="min-width:90px"><div class="sc-l">Total Sessions</div><div class="sc-v">' + myTotalSes + '</div></div>' +
      '</div></div>' +
      '<table class="dt"><thead><tr><th>Date</th><th>Forms</th><th>ADD</th><th>TERM</th><th>States</th><th>Avg Sec</th><th>Forms/hr</th></tr></thead>' +
      '<tbody>' + histRows8 + '</tbody></table>'
    ) : '<p class="no-data">No previous sessions found. Load historico_informe.xlsx to see your history.</p>') +
    '</div>';

  // BLOCK 3: Me vs Team
  const block3 = hasComp ? (
    '<div class="block">' +
    '<div class="block-header bh3"><span class="block-num">03</span><span class="block-title">Me vs Team Performance</span><span class="block-sub">' + comp.mySessionCount + ' my sessions · ' + comp.teamSessionCount + ' team sessions total</span></div>' +
    '<div style="padding:14px 22px"><table class="dt comp-tbl">' +
    '<thead><tr><th>Metric</th><th>This Session</th><th>My Historical Avg</th><th>Team Average</th><th>Δ vs My Avg</th><th>Δ vs Team Avg</th></tr></thead>' +
    '<tbody>' + compRows + '</tbody></table></div></div>'
  ) : (
    '<div class="block"><div class="block-header bh3"><span class="block-num">03</span><span class="block-title">Me vs Team</span></div>' +
    '<p class="no-data">Load historico_informe.xlsx to enable team comparison.</p></div>'
  );

  // BLOCK 4: State breakdown
  const stateRows = Object.entries(byState)
    .sort((a, b) => b[1].total - a[1].total)
    .map(([st, d], i) => {
      const avgSt  = d.totalSec > 0 ? (d.totalSec / d.total).toFixed(1) : "—";
      const pct    = Math.round((d.total / Math.max(...Object.values(byState).map(x => x.total), 1)) * 100);
      return '<tr class="' + (i%2?"even":"") + '">' +
        '<td class="td-l">' + PEO.esc(st) + '</td>' +
        '<td class="td-c fw7">' + d.total + '</td>' +
        '<td class="td-c"><span class="ba">' + (d.ADD||0) + '</span></td>' +
        '<td class="td-c"><span class="bt">' + (d.TERM||0) + '</span></td>' +
        '<td class="td-c mu">' + (avgSt!=="—"?avgSt+"s":"—") + '</td>' +
        '<td class="td-c"><div style="background:' + C.gray200 + ';border-radius:3px;height:8px;width:80px;display:inline-block;vertical-align:middle"><div style="background:' + C.blue600 + ';height:100%;border-radius:3px;width:' + pct + '%"></div></div></td>' +
        '</tr>';
    }).join("");

  const block4 = Object.keys(byState).length > 0 ? (
    '<div class="block">' +
    '<div class="block-header bh4"><span class="block-num">04</span><span class="block-title">State Breakdown</span><span class="block-sub">' + Object.keys(byState).length + ' states this session</span></div>' +
    '<table class="dt"><thead><tr><th>State</th><th>Total</th><th>ADDs</th><th>TERMs</th><th>Avg Sec</th><th>Volume</th></tr></thead>' +
    '<tbody>' + stateRows + '</tbody></table></div>'
  ) : "";

  // BLOCK 5: Leader summary (leaders only)
  const isLeader = PEO.LEADER_OPERATORS && PEO.LEADER_OPERATORS.includes(stats.operator);
  const block5 = isLeader && historicoRows.length > 0 ? (
    '<div class="block">' +
    '<div class="block-header" style="background:linear-gradient(90deg,' + C.blue900 + ',' + C.blue700 + ');color:' + C.white + '">' +
    '<span class="block-num">05</span><span class="block-title">Leader — Quick Team Summary</span>' +
    '<span class="block-sub">Based on ' + historicoRows.length + ' sessions · Use Leader Report for full dashboard</span></div>' +
    '<div style="padding:10px 22px 6px;background:' + C.blue50 + ';border-bottom:1px solid ' + C.gray200 + '">' +
    '<span style="font-size:12px;color:' + C.blue700 + '">💡 Click <strong>Leader Report</strong> in the toolbar for the full team dashboard with charts.</span></div>' +
    _buildLeaderBlock(historicoRows) +
    '</div>'
  ) : "";

  const html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">' +
    '<title>Session Report · ' + PEO.esc(stats.operator) + ' · ' + stats.date + '</title>' +
    '<style>' + _reportCSS(false) + '</style></head><body>' +
    '<div class="pbar"><span>⚖ PEO License Manager &nbsp;·&nbsp; Session Report &nbsp;·&nbsp; ' + PEO.esc(stats.operator) + '</span>' +
    '<button onclick="window.print()">⬇ Save as PDF</button></div>' +
    '<div class="hdr"><div>' +
    '<div class="hdr-badge">Session Report</div>' +
    '<div class="hdr-title">PEO License Manager</div>' +
    '<div class="hdr-sub">Operator Activity · ' + stats.datetime + '</div>' +
    '</div><div class="hdr-right">' +
    '<div class="hdr-op">' + PEO.esc(stats.operator) + '</div>' +
    '<div class="hdr-detail">Session: ' + stats.sessionStart.slice(11,16) + ' → ' + stats.sessionEnd.slice(11,16) + '<br>' + stats.datetime + '</div>' +
    '</div></div>' +
    '<div style="margin:22px 28px 0">' + block1 + '</div>' +
    block2 + block3 + block4 + block5 +
    '<div class="ftr"><span>PEO License Manager · Session Report · Auto-generated · ' + stats.datetime + '</span>' +
    '<span>Operator: ' + PEO.esc(stats.operator) + ' · ' + stats.totalForms + ' form(s) · ' + stats.stateCount + ' state(s)</span></div>' +
    '</body></html>';

  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url  = URL.createObjectURL(blob);
  const win  = window.open(url, "_blank");
  if (!win) PEO.notify("Enable pop-ups to view the Session Report.", "err");
  setTimeout(() => URL.revokeObjectURL(url), 15000);
};

// ═══════════════════════════════════════════════════════════════════════════
//  SECTION 8 — Leader Quick Table (used inside operator report)
// ═══════════════════════════════════════════════════════════════════════════

function _buildLeaderBlock(historicoRows) {
  if (!historicoRows.length) return "";
  const C = RPT_C;
  const byOp = {};
  for (const r of historicoRows) {
    const op = String(r["Operator"] || r.operador || "—").trim();
    if (!byOp[op]) byOp[op] = { op, sessions:0, forms:0, adds:0, terms:0, sec:0 };
    byOp[op].sessions++;
    byOp[op].forms  += Number(r["Total Forms"] || r.total_formularios) || 0;
    byOp[op].adds   += Number(r["ADDs"] || r.adds) || 0;
    byOp[op].terms  += Number(r["TERMs"] || r.terms) || 0;
    byOp[op].sec    += Number(r["Total Sec"] || r.tiempo_total_seg) || 0;
  }
  const ops = Object.values(byOp).map(o => ({
    ...o,
    avgForms:   o.sessions ? (o.forms / o.sessions).toFixed(1)       : "0",
    avgSec:     o.forms    ? (o.sec   / o.forms).toFixed(1)          : "0",
    formsPerHr: o.sec > 0  ? (o.forms / (o.sec / 3600)).toFixed(1)  : "0",
  })).sort((a, b) => b.forms - a.forms);

  const rows = ops.map((o, i) => '<tr class="' + (i%2?"even":"") + '">' +
    '<td class="td-l" style="font-weight:' + (i===0?"900":"600") + ';color:' + (i===0?C.blue700:C.gray900) + '">' + PEO.esc(o.op) + '</td>' +
    '<td class="td-c">' + o.sessions + '</td>' +
    '<td class="td-c fw7">' + o.forms + '</td>' +
    '<td class="td-c"><span class="ba">' + o.adds + '</span></td>' +
    '<td class="td-c"><span class="bt">' + o.terms + '</span></td>' +
    '<td class="td-c">' + o.avgForms + '</td>' +
    '<td class="td-c mu">' + o.avgSec + 's</td>' +
    '<td class="td-c" style="color:' + C.blue700 + ';font-weight:700">' + o.formsPerHr + '/hr</td>' +
    '</tr>').join("");

  return '<table class="dt"><thead><tr><th>Operator</th><th>Sessions</th><th>Total Forms</th>' +
    '<th>ADDs</th><th>TERMs</th><th>Avg/Session</th><th>Avg Sec</th><th>Forms/hr</th></tr></thead>' +
    '<tbody>' + rows + '</tbody></table>';
}

// ═══════════════════════════════════════════════════════════════════════════
//  SECTION 9 — Historic Excel Accumulator
// ═══════════════════════════════════════════════════════════════════════════

async function _readHistoricoRows(cutoffDate) {
  const hf = PEO.state.historicoFile;
  if (!hf) return [];
  try {
    const wb   = XLSX.read(await hf.arrayBuffer(), { type: "array" });
    const ws   = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(ws, { defval: "" });
    if (!cutoffDate) return rows;
    return rows.filter(r => {
      const d = String(r["Date"] || r.fecha_realizacion || "").slice(0, 10);
      return d >= cutoffDate;
    });
  } catch (e) {
    PEO.notify("Error reading historic file: " + e.message, "err");
    return [];
  }
}

PEO.buildHistorico = async function (stats, sessionFileName) {
  const existingRows = await _readHistoricoRows(PEO.state.historicoCutoffDate);
  const estadosStr   = Object.entries(stats.byState).map(([s, d]) => s + ":" + d.total).join(" | ");

  const newRow = {
    "Date":          stats.datetime,
    "Operator":      stats.operator,
    "Total Forms":   stats.totalForms,
    "ADDs":          stats.byProcess.ADD  || 0,
    "TERMs":         stats.byProcess.TERM || 0,
    "States":        stats.stateCount,
    "State Detail":  estadosStr,
    "Total Sec":     parseFloat(stats.totalSec),
    "Avg Sec/Form":  parseFloat(stats.avgSec),
    "Forms/hr":      stats.formsPerHr,
    "Start Time":    stats.sessionStart.slice(11, 16),
    "End Time":      stats.sessionEnd.slice(11, 16),
    "Session File":  sessionFileName || "—",
  };
  const allRows = [...existingRows, newRow];

  const historicoExistia = !!PEO.state.historicoFile;
  const fname = historicoExistia ? "historico_informe_actualizado.xlsx" : "historico_informe.xlsx";

  const wb = XLSX.utils.book_new();
  const wsHist = XLSX.utils.json_to_sheet(allRows);
  wsHist["!cols"] = [{wch:18},{wch:16},{wch:12},{wch:7},{wch:7},{wch:8},{wch:42},{wch:12},{wch:13},{wch:10},{wch:11},{wch:10},{wch:42}];
  XLSX.utils.book_append_sheet(wb, wsHist, "History");

  const byOp = {};
  for (const r of allRows) {
    const op = r["Operator"] || r.operador || "—";
    if (!byOp[op]) byOp[op] = { Operator:op, Sessions:0, "Total Forms":0, ADDs:0, TERMs:0, "Total Sec":0, _states: new Set() };
    byOp[op].Sessions++;
    byOp[op]["Total Forms"] += Number(r["Total Forms"] || r.total_formularios) || 0;
    byOp[op].ADDs  += Number(r["ADDs"]  || r.adds)  || 0;
    byOp[op].TERMs += Number(r["TERMs"] || r.terms) || 0;
    byOp[op]["Total Sec"] += Number(r["Total Sec"] || r.tiempo_total_seg) || 0;
    const det = r["State Detail"] || r.detalle_estados || "";
    det.split(" | ").forEach(s => { if (s.includes(":")) byOp[op]._states.add(s.split(":")[0]); });
  }
  const summaryRows = Object.values(byOp).map(o => ({
    "Operator":          o.Operator,
    "Sessions":          o.Sessions,
    "Total Forms":       o["Total Forms"],
    "ADDs":              o.ADDs,
    "TERMs":             o.TERMs,
    "Avg Forms/Session": o.Sessions > 0 ? (o["Total Forms"] / o.Sessions).toFixed(1) : 0,
    "Unique States":     o._states.size,
    "Total Sec":         o["Total Sec"].toFixed(1),
    "Avg Sec/Form":      o["Total Forms"] > 0 ? (o["Total Sec"] / o["Total Forms"]).toFixed(1) : 0,
    "Forms/hr":          o["Total Sec"] > 0 ? (o["Total Forms"] / (o["Total Sec"] / 3600)).toFixed(1) : 0,
  }));
  const wsSum = XLSX.utils.json_to_sheet(summaryRows);
  XLSX.utils.book_append_sheet(wb, wsSum, "By Operator");

  const buf  = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const blob = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href = url; a.download = fname; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  PEO.notify("Historic updated: " + allRows.length + " session(s) → " + fname, "ok");
};

// ═══════════════════════════════════════════════════════════════════════════
//  SECTION 10 — Session Excel Log
// ═══════════════════════════════════════════════════════════════════════════

PEO.buildSessionExcel = function (stats) {
  const events      = PEO.state._kpiQueue.filter(e => e.action === "GENERATE");
  const outputLabel = PEO.state.outputDirLabel || "ZIP downloaded";

  const rows = events.map(e => ({
    "State":            e.state     || "—",
    "Process":          e.process   || "—",
    "# Case":           e.case      || "—",
    "PDF File Created": e.file      || "—",
    "Download Path":    outputLabel,
    "Date Completed":   String(e.timestamp || stats.datetime).slice(0, 16).replace("T", " "),
    "Operator":         e.username  || stats.operator,
    "Duration (sec)":   parseFloat(e.duration_sec || 0).toFixed(1),
  }));

  const wb  = XLSX.utils.book_new();
  const ws1 = XLSX.utils.json_to_sheet(rows.length ? rows : [{
    "State":"—","Process":"—","# Case":"—","PDF File Created":"—",
    "Download Path":"—","Date Completed":"—","Operator":"—","Duration (sec)":"—"
  }]);
  ws1["!cols"] = [{wch:12},{wch:8},{wch:18},{wch:42},{wch:36},{wch:18},{wch:16},{wch:14}];
  XLSX.utils.book_append_sheet(wb, ws1, "Session Records");

  const fname = "registros_actualizados_" + stats.operator + "_" + stats.date + ".xlsx";
  const buf   = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const blob  = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  const url   = URL.createObjectURL(blob);
  const a     = document.createElement("a");
  a.href = url; a.download = fname; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  PEO.notify("Session log: " + fname, "ok");
  return fname;
};

// ═══════════════════════════════════════════════════════════════════════════
//  SECTION 11 — Main Coordinator
// ═══════════════════════════════════════════════════════════════════════════

PEO.generateAllReports = async function () {
  const generated = PEO.state._kpiQueue.filter(e => e.action === "GENERATE");
  if (!generated.length) {
    PEO.notify("No forms generated this session — nothing to report.", "info");
    return;
  }
  PEO.notify("Generating session reports…", "info");
  const stats    = PEO.buildSessionStats();
  const histRows = await _readHistoricoRows(PEO.state.historicoCutoffDate);
  const sessionFileName = PEO.buildSessionExcel(stats);
  await new Promise(r => setTimeout(r, 300));
  PEO.generatePdfReport(stats, histRows);
  await PEO.buildHistorico(stats, sessionFileName);
};
