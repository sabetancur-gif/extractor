from __future__ import annotations

import warnings
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import joblib

from common import (
    ensure_dirs, require_file, RAW_FILE, SHEET_NAME,
    FINAL_STATES, CAT, NUM, TARGET_NAME,
    SPLITS_FILE, ENCODERS_FILE, MEDIANS_FILE, PROCESSED_FILE
)

warnings.filterwarnings("ignore")

def fit_encoder_with_unknown(series: pd.Series) -> LabelEncoder:
    le = LabelEncoder()
    values = pd.Series(series.dropna().astype(str).unique().tolist() + ["Desconocido"])
    le.fit(values)
    return le

def main() -> None:
    ensure_dirs()
    require_file(RAW_FILE, "el archivo de datos original")

    df = pd.read_excel(RAW_FILE, sheet_name=SHEET_NAME)
    print(f"Filas: {df.shape[0]:,}  Columnas: {df.shape[1]}")

    df_m = df[df["Estado"].isin(FINAL_STATES)].copy()
    print(f"Estados finales: {df_m.shape[0]:,}")

    df_m[TARGET_NAME] = (df_m["Estado"] == "Desistida").astype(int)
    print(f"Tasa desistimiento: {df_m[TARGET_NAME].mean():.1%}")

    X = df_m[CAT + NUM].copy()
    y = df_m[TARGET_NAME].copy()

    encoders = {}
    for col in CAT:
        X[col] = X[col].fillna("Desconocido").astype(str)
        le = fit_encoder_with_unknown(X[col])
        X[col] = le.transform(X[col].where(X[col].isin(le.classes_), "Desconocido"))
        encoders[col] = le

    medians = X[NUM].median(numeric_only=True)
    X[NUM] = X[NUM].fillna(medians)

    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"Train: {X_tr.shape[0]:,}  Test: {X_te.shape[0]:,}")

    joblib.dump((X_tr, X_te, y_tr, y_te), SPLITS_FILE)
    joblib.dump(encoders, ENCODERS_FILE)
    joblib.dump(medians, MEDIANS_FILE)
    joblib.dump(df_m, PROCESSED_FILE)

    print(f"Guardado: {SPLITS_FILE}")
    print(f"Guardado: {ENCODERS_FILE}")
    print(f"Guardado: {MEDIANS_FILE}")
    print(f"Guardado: {PROCESSED_FILE}")

if __name__ == "__main__":
    main()
