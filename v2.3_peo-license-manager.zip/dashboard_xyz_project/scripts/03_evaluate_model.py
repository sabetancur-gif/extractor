from __future__ import annotations

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import (
    classification_report, confusion_matrix,
    roc_auc_score, roc_curve, precision_recall_curve
)
import joblib

from common import (
    ensure_dirs, MODEL_FILE, SPLITS_FILE,
    EVALUATION_PLOT, CLASSIFICATION_REPORT_FILE, TABLES_DIR
)

def main() -> None:
    ensure_dirs()
    if not MODEL_FILE.exists():
        raise FileNotFoundError("No existe el modelo final. Ejecuta primero 02_train_models.py.")
    if not SPLITS_FILE.exists():
        raise FileNotFoundError("No existe splits.pkl. Ejecuta primero 01_prepare_data.py.")

    modelo = joblib.load(MODEL_FILE)
    _, X_te, _, y_te = joblib.load(SPLITS_FILE)

    y_pred = modelo.predict(X_te)
    y_prob = modelo.predict_proba(X_te)[:, 1]

    report = classification_report(y_te, y_pred, target_names=["No Desiste", "Desiste"])
    auc = float(roc_auc_score(y_te, y_prob))
    cm = confusion_matrix(y_te, y_pred)

    print(report)
    print(f"AUC-ROC: {auc:.4f}")

    CLASSIFICATION_REPORT_FILE.write_text(report + f"\nAUC-ROC: {auc:.4f}\n", encoding="utf-8")

    fpr, tpr, _ = roc_curve(y_te, y_prob)
    prec, rec, thresh = precision_recall_curve(y_te, y_prob)
    f1 = 2 * (prec * rec) / (prec + rec + 1e-9)
    umbral_opt = float(thresh[np.argmax(f1[:-1])])

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    axes[0].plot(fpr, tpr, label=f"GB AUC={auc:.3f}", lw=2)
    axes[0].plot([0, 1], [0, 1], "--", color="gray")
    axes[0].set_title("Curva ROC")
    axes[0].legend()

    axes[1].plot(thresh, prec[:-1], label="Precision")
    axes[1].plot(thresh, rec[:-1], label="Recall")
    axes[1].plot(thresh, f1[:-1], label="F1", lw=2)
    axes[1].axvline(umbral_opt, linestyle="--", color="red", alpha=0.6)
    axes[1].set_title("Precision–Recall–F1 vs Umbral")
    axes[1].legend()

    plt.tight_layout()
    plt.savefig(EVALUATION_PLOT, dpi=150)
    plt.close(fig)

    metrics = pd.DataFrame([{
        "auc_roc": auc,
        "threshold_opt_f1": umbral_opt,
        "tn": int(cm[0, 0]),
        "fp": int(cm[0, 1]),
        "fn": int(cm[1, 0]),
        "tp": int(cm[1, 1]),
    }])
    metrics.to_csv(TABLES_DIR / "evaluation_metrics.csv", index=False)

    print(f"Umbral óptimo (max F1): {umbral_opt:.3f}")
    print(f"Guardado gráfico en: {EVALUATION_PLOT}")

if __name__ == "__main__":
    main()
