from __future__ import annotations

import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import roc_auc_score
import joblib

from common import (
    ensure_dirs, SPLITS_FILE, MODEL_FILE, MODEL_METRICS_FILE,
    FEATURE_IMPORTANCE_FILE, CAT, NUM, TABLES_DIR
)

def main() -> None:
    ensure_dirs()
    if not SPLITS_FILE.exists():
        raise FileNotFoundError(
            "No existe splits.pkl. Ejecuta primero 01_prepare_data.py."
        )

    X_tr, X_te, y_tr, y_te = joblib.load(SPLITS_FILE)

    modelos = {
        "Regresion Logistica": LogisticRegression(max_iter=1000, random_state=42),
        "Arbol Decision": DecisionTreeClassifier(max_depth=6, random_state=42),
        "Random Forest": RandomForestClassifier(n_estimators=100, n_jobs=-1, random_state=42),
        "Gradient Boosting": GradientBoostingClassifier(n_estimators=100, random_state=42),
    }

    resultados = []
    fitted = {}

    for nombre, modelo in modelos.items():
        modelo.fit(X_tr, y_tr)
        prob = modelo.predict_proba(X_te)[:, 1]
        auc = float(roc_auc_score(y_te, prob))
        resultados.append({"modelo": nombre, "auc_test": auc})
        fitted[nombre] = modelo
        print(f"{nombre:25s}  AUC = {auc:.4f}")

    df_res = pd.DataFrame(resultados).sort_values("auc_test", ascending=False)
    df_res.to_csv(MODEL_METRICS_FILE, index=False)

    mejor = df_res.iloc[0]["modelo"]
    print(f"\nModelo seleccionado: {mejor}")

    modelo_final = fitted[mejor]

    X_all = pd.concat([X_tr, X_te])
    y_all = pd.concat([y_tr, y_te])
    cv = cross_val_score(modelo_final, X_all, y_all, cv=5, scoring="roc_auc", n_jobs=-1)

    summary = pd.DataFrame([{
        "modelo_final": mejor,
        "cv_auc_mean": float(cv.mean()),
        "cv_auc_std": float(cv.std()),
    }])
    summary.to_csv(TABLES_DIR / "cv_summary.csv", index=False)
    print(f"CV AUC: {cv.mean():.4f} ± {cv.std():.4f}")

    rf = fitted["Random Forest"]
    fi = pd.Series(rf.feature_importances_, index=CAT + NUM).sort_values(ascending=False)
    fi.to_csv(FEATURE_IMPORTANCE_FILE, header=["importance"])
    print(fi.head(10))

    joblib.dump(modelo_final, MODEL_FILE)
    print(f"Guardado modelo en: {MODEL_FILE}")

if __name__ == "__main__":
    main()
