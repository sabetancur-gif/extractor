from __future__ import annotations

from pathlib import Path
import json
import joblib

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
RAW_DIR = DATA_DIR / "raw"
INTERMEDIATE_DIR = DATA_DIR / "intermediate"
OUTPUT_DIR = ROOT / "output"
FIGURES_DIR = OUTPUT_DIR / "figures"
MODELS_DIR = OUTPUT_DIR / "models"
TABLES_DIR = OUTPUT_DIR / "tables"

# Original dataset expected by the project
RAW_FILE = RAW_DIR / "Base_PRUEBA_ANALITICA.xlsx"
SHEET_NAME = "BD"

FINAL_STATES = ["Desistida", "Negada", "Aprobada"]
TARGET_NAME = "TARGET"

CAT = [
    "GENERO", "ESTADO_CIVIL", "NIVEL_ESTUDIO", "TIPO_VIVIENDA",
    "ZONA", "CODEUDOR", "SUBTIPO_CLIENTE", "TIPO_CLIENTE",
    "HABITO_PAGO", "CALIFICACION", "TIPO_CONTRATO", "Marca producto"
]
NUM = [
    "MULTAS_SIMIT", "EDAD", "CUOTA_INICIAL", "PERSONAS_CARGO",
    "PLAZO", "VALOR_SOLICITADO", "INGRESOS", "EGRESOS",
    "ENDEUDAMIENTO", "CREDITOS_VIGENTES", "Puntaje Riesgo", "ANTIGUEDAD"
]

SPLITS_FILE = INTERMEDIATE_DIR / "splits.pkl"
ENCODERS_FILE = INTERMEDIATE_DIR / "encoders.pkl"
MEDIANS_FILE = INTERMEDIATE_DIR / "medians.pkl"
PROCESSED_FILE = INTERMEDIATE_DIR / "prepared_data.pkl"
MODEL_FILE = MODELS_DIR / "modelo_final_gb.pkl"
MODEL_METRICS_FILE = TABLES_DIR / "model_metrics.csv"
FEATURE_IMPORTANCE_FILE = TABLES_DIR / "feature_importance.csv"
CLASSIFICATION_REPORT_FILE = TABLES_DIR / "classification_report.txt"
SCORING_FILE = OUTPUT_DIR / "scoring_produccion.csv"
EVALUATION_PLOT = FIGURES_DIR / "curvas_evaluacion.png"

def ensure_dirs() -> None:
    for d in (RAW_DIR, INTERMEDIATE_DIR, OUTPUT_DIR, FIGURES_DIR, MODELS_DIR, TABLES_DIR):
        d.mkdir(parents=True, exist_ok=True)

def require_file(path: Path, label: str | None = None) -> None:
    if not path.exists():
        pretty = label or str(path)
        raise FileNotFoundError(
            f"No se encontró {pretty}. Coloca el archivo en: {path}"
        )

def dump(obj, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(obj, path)

def load(path: Path):
    require_file(path)
    return joblib.load(path)

def save_json(data, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
