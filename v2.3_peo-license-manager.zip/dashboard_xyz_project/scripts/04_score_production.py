from __future__ import annotations

import pandas as pd
import joblib

from common import (
    ensure_dirs, RAW_FILE, SHEET_NAME,
    MODEL_FILE, ENCODERS_FILE, MEDIANS_FILE,
    CAT, NUM, SCORING_FILE
)

def predecir(df_new: pd.DataFrame, modelo, encoders, medians) -> pd.DataFrame:
    X = df_new[CAT + NUM].copy()

    for col in CAT:
        X[col] = X[col].fillna("Desconocido").astype(str)
        known = set(encoders[col].classes_)
        X[col] = X[col].apply(lambda v: v if v in known else "Desconocido")
        X[col] = encoders[col].transform(X[col])

    X[NUM] = X[NUM].fillna(medians)

    probs = modelo.predict_proba(X)[:, 1]

    return pd.DataFrame({
        "SOLICITUD": df_new["SOLICITUD"].values,
        "prob_desistimiento": probs.round(4),
        "segmento": pd.cut(
            probs,
            bins=[0, 0.30, 0.50, 0.70, 1.0],
            labels=["Bajo", "Medio", "Alto", "Critico"],
            include_lowest=True
        )
    })

def main() -> None:
    ensure_dirs()
    for f, label in [
        (MODEL_FILE, "el modelo final"),
        (ENCODERS_FILE, "los codificadores"),
        (MEDIANS_FILE, "las medianas"),
        (RAW_FILE, "el archivo original de datos"),
    ]:
        if not f.exists():
            raise FileNotFoundError(f"Falta {label}. Debes ejecutar los pasos previos o colocar el archivo en su ruta.")

    modelo = joblib.load(MODEL_FILE)
    encoders = joblib.load(ENCODERS_FILE)
    medians = joblib.load(MEDIANS_FILE)

    df = pd.read_excel(RAW_FILE, sheet_name=SHEET_NAME)
    df_en_proceso = df[~df["Estado"].isin(["Desistida", "Negada", "Aprobada"])].copy()

    resultado = predecir(df_en_proceso, modelo, encoders, medians)
    print(resultado["segmento"].value_counts())
    resultado.sort_values("prob_desistimiento", ascending=False).to_csv(
        SCORING_FILE, index=False
    )
    print(f"Guardado scoring en: {SCORING_FILE}")

if __name__ == "__main__":
    main()
