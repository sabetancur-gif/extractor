Coloca aquí el archivo Base_PRUEBA_ANALITICA.xlsx con la hoja BD.
