// ── THEME ──────────────────────────────────────────
function toggleTheme() {
  const html = document.documentElement;
  const isDark = html.getAttribute('data-theme') === 'dark';
  html.setAttribute('data-theme', isDark ? 'light' : 'dark');
  document.getElementById('theme-label').textContent = isDark ? 'Modo Oscuro' : 'Modo Claro';
  updateChartColors();
}

// ── NAVIGATION ─────────────────────────────────────
function showSection(id, btn) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  if (btn) btn.classList.add('active');
}

// ── CODE TABS ──────────────────────────────────────
function showCode(id, el) {
  document.querySelectorAll('.ctab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.code-panel').forEach(p => p.classList.remove('active'));
  document.getElementById('cp-' + id).classList.add('active');
  if (el) el.classList.add('active');
}

// ── CHART DEFAULTS ─────────────────────────────────
const C = {
  orange : '#f97316',
  blue   : '#3b82f6',
  green  : '#10b981',
  yellow : '#f59e0b',
  red    : '#ef4444',
  purple : '#a78bfa',
  slate  : '#475569',
};

function getThemeColor() {
  return document.documentElement.getAttribute('data-theme') === 'light'
    ? { text: '#1a2540', grid: '#d8e0f0', muted: '#7a8fae' }
    : { text: '#dce6f5', grid: '#1e2f4a', muted: '#5a7199' };
}

function applyChartDefaults() {
  const t = getThemeColor();
  Chart.defaults.color = t.muted;
  Chart.defaults.borderColor = t.grid;
  Chart.defaults.font.family = "'DM Sans', sans-serif";
}
applyChartDefaults();

// ── BUILD CHARTS ───────────────────────────────────
let charts = {};

function buildCharts() {
  const t = getThemeColor();

  // 1. Estados (donut)
  charts.cEstados = new Chart(document.getElementById('cEstados'), {
    type: 'doughnut',
    data: {
      labels: ['Desistida','Negada','Aprobada','Anulada'],
      datasets: [{ data:[12265,10310,6939,4154],
        backgroundColor:[C.red,C.orange,C.green,C.slate],
        borderColor: document.documentElement.getAttribute('data-theme')==='light'?'#fff':'#090d16',
        borderWidth:3, hoverOffset:8 }]
    },
    options: {
      responsive:true, maintainAspectRatio:false,
      plugins: {
        legend:{position:'right',labels:{padding:14,usePointStyle:true,font:{size:11}}},
        tooltip:{callbacks:{label:c=>` ${c.label}: ${c.raw.toLocaleString()} (${(c.raw/33668*100).toFixed(1)}%)`}}
      }
    }
  });

  // 2. Hábito de pago
  charts.cHabito = new Chart(document.getElementById('cHabito'), {
    type:'bar',
    data:{
      labels:['E','A','K','B','D','C'],
      datasets:[{label:'% Desistimiento',
        data:[50.3,46.1,41.3,40.0,28.3,14.2],
        backgroundColor:[C.red,C.orange,C.yellow,C.blue,C.green,'#06b6d4'],
        borderRadius:6, borderSkipped:false}]
    },
    options:{responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:false}},
      scales:{y:{min:0,max:60,ticks:{callback:v=>v+'%'},grid:{color:t.grid}},x:{grid:{display:false}}}}
  });

  // 3. Zona
  charts.cZona = new Chart(document.getElementById('cZona'), {
    type:'bar',
    data:{
      labels:['Eje Cafetero','Suroccidente','Oriente','Bogotá','Centro','Antioquia','Costa'],
      datasets:[{data:[49.2,45.0,42.0,39.9,39.9,36.0,35.9],
        backgroundColor:[C.red,C.red+'aa',C.orange,C.yellow,C.yellow,C.green+'cc',C.green],
        borderRadius:5,borderSkipped:false}]
    },
    options:{responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:false}},
      scales:{y:{min:30,max:55,ticks:{callback:v=>v+'%'},grid:{color:t.grid}},
              x:{grid:{display:false},ticks:{font:{size:10}}}}}
  });

  // 4. Calificación (horizontal)
  charts.cCal = new Chart(document.getElementById('cCal'), {
    type:'bar',
    data:{
      labels:['B','C','D','A','E','BB','AA','K'],
      datasets:[{data:[57.8,51.0,47.6,40.1,30.7,16.3,9.5,9.1],
        backgroundColor:[C.red,C.red+'bb',C.orange+'cc',C.orange+'88',C.yellow,C.green+'99',C.green,'#06b6d4'],
        borderRadius:5,borderSkipped:false}]
    },
    options:{responsive:true,maintainAspectRatio:false,indexAxis:'y',
      plugins:{legend:{display:false}},
      scales:{x:{min:0,max:70,ticks:{callback:v=>v+'%'},grid:{color:t.grid}},y:{grid:{display:false}}}}
  });

  // 5. Género
  charts.cGenero = new Chart(document.getElementById('cGenero'), {
    type:'bar',
    data:{
      labels:['Femenino','Masculino'],
      datasets:[{data:[42.1,40.5],
        backgroundColor:[C.purple+'bb',C.blue+'bb'],
        borderColor:[C.purple,C.blue],borderWidth:2,borderRadius:8}]
    },
    options:{responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:false}},
      scales:{y:{min:38,max:45,ticks:{callback:v=>v+'%'},grid:{color:t.grid}},x:{grid:{display:false}}}}
  });

  // 6. Estado civil
  charts.cCivil = new Chart(document.getElementById('cCivil'), {
    type:'doughnut',
    data:{
      labels:['Viudo','Casado','Divorciado','Soltero','Unión Libre'],
      datasets:[{data:[42.5,41.8,41.0,40.0,33.0],
        backgroundColor:[C.red,C.orange,C.yellow,C.blue,C.green],
        borderColor: document.documentElement.getAttribute('data-theme')==='light'?'#fff':'#090d16',
        borderWidth:2}]
    },
    options:{responsive:true,maintainAspectRatio:false,
      plugins:{legend:{position:'right',labels:{font:{size:10},padding:10}},
               tooltip:{callbacks:{label:c=>` ${c.label}: ${c.raw}%`}}}}
  });

  // 7. Radar
  charts.cRadar = new Chart(document.getElementById('cRadar'), {
    type:'radar',
    data:{
      labels:['Desistimiento','Volumen','Riesgo Score','Ingresos Bajos','Sin Codeudor'],
      datasets:[
        {label:'Eje Cafetero',data:[92,55,60,65,10],
         borderColor:C.red,backgroundColor:C.red+'22',pointBackgroundColor:C.red},
        {label:'Costa',data:[52,65,45,50,8],
         borderColor:C.green,backgroundColor:C.green+'22',pointBackgroundColor:C.green},
        {label:'Promedio',data:[70,70,55,55,9],
         borderColor:C.blue,backgroundColor:C.blue+'22',pointBackgroundColor:C.blue,borderDash:[5,5]},
      ]
    },
    options:{responsive:true,maintainAspectRatio:false,
      scales:{r:{min:0,max:100,grid:{color:t.grid},angleLines:{color:t.grid},
                 pointLabels:{font:{size:10}},ticks:{display:false}}},
      plugins:{legend:{position:'bottom',labels:{font:{size:11},padding:14}}}}
  });

  // 8. Modelos
  charts.cModelos = new Chart(document.getElementById('cModelos'), {
    type:'bar',
    data:{
      labels:['Reg. Logística','Árbol Decisión','Random Forest','Gradient Boosting'],
      datasets:[{data:[0.597,0.643,0.695,0.7006],
        backgroundColor:[C.slate,C.yellow,C.blue,C.green],
        borderRadius:6,borderSkipped:false}]
    },
    options:{responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:false}},
      scales:{y:{min:0.5,max:0.75,ticks:{callback:v=>v.toFixed(2)},grid:{color:t.grid}},
              x:{grid:{display:false},ticks:{font:{size:10}}}}}
  });

  // 9. CV Folds
  charts.cCV = new Chart(document.getElementById('cCV'), {
    type:'bar',
    data:{
      labels:['Fold 1','Fold 2','Fold 3','Fold 4','Fold 5'],
      datasets:[
        {type:'bar',label:'AUC por Fold',data:[0.6868,0.6948,0.6772,0.7014,0.6964],
         backgroundColor:C.blue+'99',borderColor:C.blue,borderWidth:2,borderRadius:5},
        {type:'line',label:'Media 0.6913',data:[0.6913,0.6913,0.6913,0.6913,0.6913],
         borderColor:C.orange,borderWidth:2,borderDash:[6,3],pointRadius:0,fill:false},
      ]
    },
    options:{responsive:true,maintainAspectRatio:false,
      plugins:{legend:{position:'top',labels:{font:{size:11}}}},
      scales:{y:{min:0.65,max:0.72,ticks:{callback:v=>v.toFixed(3)},grid:{color:t.grid}},
              x:{grid:{display:false}}}}
  });
}

function updateChartColors() {
  applyChartDefaults();
  Object.values(charts).forEach(ch => {
    const t = getThemeColor();
    if (ch.config.type === 'doughnut') {
      const bg = document.documentElement.getAttribute('data-theme')==='light'?'#ffffff':'#090d16';
      ch.data.datasets[0].borderColor = bg;
    }
    if (ch.options.scales) {
      Object.values(ch.options.scales).forEach(s => {
        if (s.grid) s.grid.color = t.grid;
        if (s.angleLines) s.angleLines.color = t.grid;
      });
    }
    ch.update();
  });
}

// ── MARCA BAR ──────────────────────────────────────
function buildMarcaBar() {
  const data = [
    {name:'Marca D',val:45.7,n:'1,057'},
    {name:'Marca B',val:43.8,n:'1,195'},
    {name:'Marca E',val:43.2,n:'590'},
    {name:'Marca C',val:42.4,n:'1,106'},
    {name:'Marca G',val:41.7,n:'350'},
    {name:'Marca A',val:41.2,n:'25,209'},
    {name:'Marca F',val:28.6,n:'7'},
  ];
  const wrap = document.getElementById('barMarca');
  wrap.className = 'bar-list';
  data.forEach(d => {
    const color = d.val>44?C.red:d.val>42?C.orange:d.val>40?C.yellow:C.green;
    wrap.innerHTML += `
      <div class="bar-item">
        <div class="bar-header">
          <span class="bar-lbl">${d.name} <span style="font-size:11px;color:var(--muted);">(n=${d.n})</span></span>
          <span class="bar-val">${d.val}%</span>
        </div>
        <div class="bar-track"><div class="bar-fill" style="width:${d.val}%;background:${color};"></div></div>
      </div>`;
  });
}

// ── FEATURE IMPORTANCE ─────────────────────────────
function buildFI() {
  const features = [
    {name:'INGRESOS',val:9.91,c:C.red},
    {name:'VALOR_SOLICITADO',val:8.88,c:C.red},
    {name:'Puntaje Riesgo',val:8.71,c:C.orange},
    {name:'EGRESOS',val:8.53,c:C.orange},
    {name:'CUOTA_INICIAL',val:8.15,c:C.orange},
    {name:'ANTIGUEDAD',val:7.90,c:C.yellow},
    {name:'EDAD',val:7.12,c:C.yellow},
    {name:'ENDEUDAMIENTO',val:6.91,c:C.yellow},
    {name:'CREDITOS_VIGENTES',val:3.96,c:C.blue},
    {name:'ZONA',val:3.81,c:C.blue},
    {name:'NIVEL_ESTUDIO',val:3.26,c:C.green},
    {name:'TIPO_CONTRATO',val:3.04,c:C.green},
    {name:'PLAZO',val:2.94,c:C.green},
    {name:'PERSONAS_CARGO',val:2.91,c:C.green},
    {name:'ESTADO_CIVIL',val:2.33,c:C.slate},
  ];
  const wrap = document.getElementById('fiWrap');
  features.forEach((f, i) => {
    wrap.innerHTML += `
      <div class="fi-row">
        <span class="fi-rank">${i+1}</span>
        <span class="fi-name">${f.name}</span>
        <div class="fi-track"><div class="fi-bar" style="width:${(f.val/9.91*100).toFixed(0)}%;background:${f.c};"></div></div>
        <span class="fi-pct">${f.val.toFixed(1)}%</span>
      </div>`;
  });
}

// ── DICTIONARY TABLE ───────────────────────────────
function buildDict() {
  const rows = [
    ['INGRESOS','Numérico','Ingresos mensuales certificados','-','b-red','Muy Alta'],
    ['VALOR_SOLICITADO','Numérico','Monto total del crédito solicitado','-','b-red','Muy Alta'],
    ['Puntaje Riesgo','Numérico','Score interno: menor = mayor riesgo','-','b-red','Muy Alta'],
    ['EGRESOS','Numérico','Egresos mensuales declarados','-','b-red','Muy Alta'],
    ['CUOTA_INICIAL','Numérico','Cuota inicial requerida por el producto','-','b-red','Muy Alta'],
    ['HABITO_PAGO','Categórico','A=Excelente → K=Muy malo','-','b-red','Muy Alta'],
    ['CALIFICACION','Categórico','AA=Mejor → K=Peor (centrales de riesgo)','-','b-red','Muy Alta'],
    ['ANTIGUEDAD','Numérico','Antigüedad laboral en meses','-','b-orange','Alta'],
    ['EDAD','Numérico','Edad del solicitante','-','b-orange','Alta'],
    ['ENDEUDAMIENTO','Numérico','Nivel de deuda actual del cliente','-','b-orange','Alta'],
    ['ZONA','Categórico','7 zonas geográficas de operación','-','b-orange','Alta'],
    ['PLAZO','Numérico','Plazo del crédito en meses (6–48)','-','b-orange','Alta'],
    ['PERSONAS_CARGO','Numérico','Número de dependientes económicos','-','b-orange','Alta'],
    ['NIVEL_ESTUDIO','Categórico','Primaria, Secundaria, Técnico, Universitario, Postgrado','-','b-orange','Alta'],
    ['TIPO_CONTRATO','Categórico','Indefinido, Temporal, Obra/Labor, Prestación Serv.','377','b-orange','Alta'],
    ['CREDITOS_VIGENTES','Numérico','Número de créditos activos','-','b-blue','Media'],
    ['TIPO_CLIENTE','Categórico','Empleado, Independiente c/Estab., Independiente s/Estab.','-','b-blue','Media'],
    ['SUBTIPO_CLIENTE','Categórico','INFO=Informal · FORM=Formal','-','b-blue','Media'],
    ['ESTADO_CIVIL','Categórico','Casado, Divorciado, Soltero, Viudo, Unión Libre','-','b-blue','Media'],
    ['GENERO','Categórico','F=Femenino · M=Masculino','-','b-blue','Media'],
    ['TIPO_VIVIENDA','Categórico','Arrendada, Propia, Familiar, etc.','-','b-blue','Media'],
    ['CODEUDOR','Categórico','Sí / No tiene codeudor','-','b-blue','Media'],
    ['Marca producto','Categórico','Tipo de producto (A–G)','-','b-blue','Media'],
    ['MULTAS_SIMIT','Numérico','Valor de multas de tránsito','-','b-yellow','Baja'],
    ['SOLICITUD','ID','Identificador único de solicitud','-','b-yellow','Baja'],
    ['FECHA_INICIO','Fecha','Fecha de radicación','-','b-yellow','Baja'],
  ];
  const tbody = document.getElementById('dictTbody');
  rows.forEach(r => {
    tbody.innerHTML += `<tr>
      <td style="font-family:'DM Mono',monospace;font-size:11px;color:var(--accent);">${r[0]}</td>
      <td><span class="badge ${r[1].includes('Numérico')||r[1]==='ID'||r[1]==='Fecha'?'b-blue':'b-green'}" style="font-size:10px;">${r[1]}</span></td>
      <td style="font-size:12px;color:var(--muted2);">${r[2]}</td>
      <td style="font-family:'DM Mono',monospace;font-size:11px;color:${r[3]==='377'?'var(--danger)':'var(--muted)'};">${r[3]}</td>
      <td><span class="badge ${r[4]}" style="font-size:10px;">${r[5]}</span></td>
    </tr>`;
  });
}

// ── INIT ───────────────────────────────────────────
buildCharts();
buildMarcaBar();
buildFI();
buildDict();
