# Dashboard XYZ — estructura funcional

## Estructura
- `index.html`: dashboard principal.
- `css/styles.css`: estilos externos.
- `js/dashboard.js`: lógica del dashboard y gráficas.
- `scripts/`: pipeline de Python separado en módulos.
- `data/raw/`: coloca aquí `Base_PRUEBA_ANALITICA.xlsx`.
- `data/intermediate/`: archivos generados entre pasos.
- `output/`: métricas, gráficos, modelo y scoring final.

## Orden de ejecución
1. `python scripts/01_prepare_data.py`
2. `python scripts/02_train_models.py`
3. `python scripts/03_evaluate_model.py`
4. `python scripts/04_score_production.py`

## Dependencias
Instala con:
`pip install -r requirements.txt`

## Nota
Los scripts verifican que exista la data necesaria antes de correr.
