/* global PEO, XLSX */
/* report.js — informe PDF de sesión, histórico Excel y modal de fecha de corte */
"use strict";

// ═══════════════════════════════════════════════════════════════════════════
//  SECCIÓN 1 — Recopilación de estadísticas de sesión
// ═══════════════════════════════════════════════════════════════════════════

PEO.buildSessionStats = function () {
  const events   = PEO.state._kpiQueue.filter(e => e.action === "GENERATE");
  const operator = PEO.state.selectedUser || PEO.state.session.username || "—";
  const now      = new Date();

  const byState   = {};
  const byProcess = { ADD: 0, TERM: 0 };

  for (const e of events) {
    const st = e.state   || "Unknown";
    const pr = e.process || "—";
    if (!byState[st]) byState[st] = { ADD: 0, TERM: 0, total: 0, totalSec: 0 };
    byState[st][pr]       = (byState[st][pr] || 0) + 1;
    byState[st].total++;
    byState[st].totalSec += parseFloat(e.duration_sec || 0);
    byProcess[pr]         = (byProcess[pr] || 0) + 1;
  }

  const totalSec   = events.reduce((s, e) => s + parseFloat(e.duration_sec || 0), 0);
  const avgSec     = events.length > 0 ? totalSec / events.length : 0;
  const timestamps = events.map(e => e.timestamp).filter(Boolean).sort();

  return {
    operator,
    date:         now.toISOString().slice(0, 10),
    datetime:     now.toISOString().slice(0, 16).replace("T", " "),
    totalForms:   events.length,
    byState,
    byProcess,
    stateCount:   Object.keys(byState).length,
    totalSec:     totalSec.toFixed(1),
    avgSec:       avgSec.toFixed(1),
    sessionStart: timestamps[0]                     || now.toISOString().slice(0, 19),
    sessionEnd:   timestamps[timestamps.length - 1] || now.toISOString().slice(0, 19),
  };
};

// ═══════════════════════════════════════════════════════════════════════════
//  SECCIÓN 2 — Modal de fecha de corte para el histórico
// ═══════════════════════════════════════════════════════════════════════════

PEO.showHistoricoCutoffModal = function (filename) {
  return new Promise(resolve => {
    const today       = new Date().toISOString().slice(0, 10);
    const oneMonthAgo = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);

    const ov        = document.createElement("div");
    ov.className    = "modal-overlay open";
    ov.style.zIndex = "600";
    ov.innerHTML    = `
      <div style="
        background:var(--surface);border-radius:14px;padding:30px 34px;
        max-width:480px;width:90vw;display:flex;flex-direction:column;gap:18px;
        border:1px solid var(--border);box-shadow:0 24px 60px rgba(0,0,0,.5)">

        <div style="display:flex;align-items:center;gap:14px">
          <div style="font-size:30px;line-height:1">📊</div>
          <div>
            <div style="font-size:15px;font-weight:800;color:var(--text)">
              Histórico encontrado
            </div>
            <code style="font-size:11px;color:var(--add)">${PEO.esc(filename)}</code>
          </div>
        </div>

        <div style="font-size:13px;color:var(--muted);line-height:1.7">
          Se encontró un archivo de histórico en la carpeta.<br>
          ¿Desde qué fecha quieres incluir esa data previa en el informe?
        </div>

        <div style="display:flex;flex-direction:column;gap:6px">
          <label style="font-size:11px;font-weight:700;text-transform:uppercase;
                        letter-spacing:.06em;color:var(--muted)">
            Incluir histórico desde:
          </label>
          <input type="date" id="cutoffDateInput"
                 value="${oneMonthAgo}" max="${today}"
                 style="padding:9px 12px;border:1px solid var(--border);
                        border-radius:var(--radius);background:var(--surface2);
                        color:var(--text);font-size:13px;font-family:inherit;width:100%">
          <div style="font-size:11px;color:var(--muted)">
            Dejar vacío para incluir
            <strong style="color:var(--text)">todo el histórico disponible</strong>.
          </div>
        </div>

        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="main-btn cta" id="cutoffConfirmBtn" style="flex:1;min-width:120px">
            ✓ Confirmar fecha
          </button>
          <button class="main-btn" id="cutoffAllBtn">↺ Todo</button>
          <button class="main-btn" id="cutoffIgnoreBtn">Ignorar</button>
        </div>
      </div>`;

    document.body.appendChild(ov);

    document.getElementById("cutoffConfirmBtn").addEventListener("click", () => {
      const val = document.getElementById("cutoffDateInput").value.trim();
      ov.remove(); resolve(val || null);
    });
    document.getElementById("cutoffAllBtn").addEventListener("click",  () => { ov.remove(); resolve(null); });
    document.getElementById("cutoffIgnoreBtn").addEventListener("click", () => {
      PEO.state.historicoFile = null; ov.remove(); resolve(undefined);
    });
  });
};

// ═══════════════════════════════════════════════════════════════════════════
//  SECCIÓN 3 — SVG helpers para el informe PDF
// ═══════════════════════════════════════════════════════════════════════════

function _svgBarChart(byState) {
  const entries = Object.entries(byState).sort((a, b) => b[1].total - a[1].total);
  if (!entries.length)
    return "<p style='color:#888;font-size:12px;padding:16px 0'>Sin formularios generados.</p>";

  const maxVal  = Math.max(...entries.map(([, v]) => v.total), 1);
  const BAR_W   = Math.max(28, Math.min(52, Math.floor(520 / entries.length) - 6));
  const GAP     = 6;
  const CHART_H = 180;
  const LABEL_H = 22;
  const PAD_L   = 30;
  const totalW  = PAD_L + entries.length * (BAR_W + GAP) + 20;

  let bars = "";
  entries.forEach(([state, data], i) => {
    const x      = PAD_L + i * (BAR_W + GAP);
    const addH   = Math.round((data.ADD  / maxVal) * (CHART_H - 30));
    const termH  = Math.round((data.TERM / maxVal) * (CHART_H - 30));
    const totalH = addH + termH;
    const yBase  = CHART_H - LABEL_H;

    if (termH > 0)
      bars += `<rect x="${x}" y="${yBase - totalH}" width="${BAR_W}" height="${termH}"
                fill="#C07010" rx="3" opacity=".85"/>`;
    if (addH > 0)
      bars += `<rect x="${x}" y="${yBase - totalH + termH}" width="${BAR_W}" height="${addH}"
                fill="#1A6FBF" rx="3" opacity=".9"/>`;

    bars += `<text x="${x + BAR_W / 2}" y="${yBase - totalH - 5}"
               text-anchor="middle" font-size="10" font-weight="700" fill="#333">${data.total}</text>`;
    const lbl = state.length > 9 ? state.slice(0, 9) + "…" : state;
    bars += `<text x="${x + BAR_W / 2}" y="${yBase + 15}"
               text-anchor="middle" font-size="9" fill="#666">${lbl}</text>`;
  });

  const refLines = [0.25, 0.5, 0.75, 1].map(pct => {
    const y = CHART_H - LABEL_H - Math.round(pct * (CHART_H - 30));
    const v = Math.round(pct * maxVal);
    return `<line x1="${PAD_L - 4}" y1="${y}" x2="${totalW - 4}" y2="${y}"
                  stroke="#e0e0e0" stroke-width="1" stroke-dasharray="3,3"/>
             <text x="${PAD_L - 6}" y="${y + 3}" text-anchor="end" font-size="8" fill="#bbb">${v}</text>`;
  }).join("");

  return `<svg width="${totalW}" height="${CHART_H + 4}"
               xmlns="http://www.w3.org/2000/svg" style="overflow:visible">
    ${refLines}${bars}
    <line x1="${PAD_L}" y1="0" x2="${PAD_L}" y2="${CHART_H - LABEL_H}" stroke="#ccc" stroke-width="1"/>
    <line x1="${PAD_L}" y1="${CHART_H - LABEL_H}" x2="${totalW - 4}" y2="${CHART_H - LABEL_H}" stroke="#ccc" stroke-width="1"/>
  </svg>`;
}

function _svgDonut(add, term) {
  const total  = add + term || 1;
  const cx = 60, cy = 60, r = 46, sw = 20;
  const angle  = (add / total) * 2 * Math.PI;
  const x2 = cx + r * Math.sin(angle);
  const y2 = cy - r * Math.cos(angle);
  const la = add / total > 0.5 ? 1 : 0;
  const arc = add > 0 && add < total
    ? `<path d="M ${cx} ${cy - r} A ${r} ${r} 0 ${la} 1 ${x2.toFixed(2)} ${y2.toFixed(2)}"
              fill="none" stroke="#1A6FBF" stroke-width="${sw}" stroke-linecap="butt"/>`
    : add === total
      ? `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#1A6FBF" stroke-width="${sw}"/>`
      : "";
  return `<svg width="120" height="120" xmlns="http://www.w3.org/2000/svg">
    <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#C07010" stroke-width="${sw}"/>
    ${arc}
    <text x="${cx}" y="${cy - 7}"  text-anchor="middle" font-size="20" font-weight="800" fill="#222">${add + term}</text>
    <text x="${cx}" y="${cy + 11}" text-anchor="middle" font-size="9"  fill="#888">total</text>
  </svg>`;
}

// ═══════════════════════════════════════════════════════════════════════════
//  SECCIÓN 4 — Informe PDF (HTML que se abre en pestaña nueva para imprimir)
// ═══════════════════════════════════════════════════════════════════════════

PEO.generatePdfReport = function (stats, historicoRows = []) {
  const stateEntries = Object.entries(stats.byState).sort((a, b) => b[1].total - a[1].total);

  const stateRows = stateEntries.length
    ? stateEntries.map(([st, d]) => `
        <tr>
          <td class="td-l">${PEO.esc(st)}</td>
          <td class="td-c"><span class="ba">${d.ADD}</span></td>
          <td class="td-c"><span class="bt">${d.TERM}</span></td>
          <td class="td-c fw7">${d.total}</td>
          <td class="td-c mu">${d.totalSec.toFixed(1)}s</td>
          <td class="td-c mu">${d.total ? (d.totalSec / d.total).toFixed(1) : "—"}s</td>
        </tr>`).join("")
    : `<tr><td colspan="6" class="td-empty">Sin registros generados en esta sesión.</td></tr>`;

  const hist5 = historicoRows.slice(-5);
  const historicoSection = hist5.length ? `
    <div class="section">
      <h2 class="stitle">📋 Histórico Reciente (últimas ${hist5.length} sesiones)</h2>
      <table class="dt">
        <thead><tr>
          <th>Fecha</th><th>Operador</th><th>Forms</th>
          <th>ADD</th><th>TERM</th><th>Estados</th><th>Prom.</th>
        </tr></thead>
        <tbody>${hist5.map(h => `<tr>
          <td class="td-l">${PEO.esc(String(h.fecha_realizacion || "").slice(0, 16))}</td>
          <td class="td-l">${PEO.esc(String(h.operador || "—"))}</td>
          <td class="td-c fw7">${h.total_formularios || 0}</td>
          <td class="td-c"><span class="ba">${h.adds || 0}</span></td>
          <td class="td-c"><span class="bt">${h.terms || 0}</span></td>
          <td class="td-c">${h.estados || 0}</td>
          <td class="td-c mu">${h.tiempo_promedio_seg ? Number(h.tiempo_promedio_seg).toFixed(1) + "s" : "—"}</td>
        </tr>`).join("")}</tbody>
      </table>
    </div>` : "";

  const html = `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Informe PEO · ${PEO.esc(stats.operator)} · ${stats.date}</title>
<style>
  @page { margin: 16mm 13mm; size: A4; }
  *,*::before,*::after { box-sizing:border-box; margin:0; padding:0; }
  body { font-family:'Segoe UI',system-ui,Arial,sans-serif; color:#1a1a2e;
         background:#fff; font-size:13px; line-height:1.5; }
  .pbar { background:#0d1117; color:#e6edf3; padding:10px 36px;
          display:flex; justify-content:space-between; align-items:center; font-size:12px; }
  .pbar button { background:#1A6FBF; color:#fff; border:none; padding:7px 20px;
                 border-radius:5px; font-size:12px; font-weight:700; cursor:pointer; font-family:inherit; }
  .pbar button:hover { background:#155fa0; }
  @media print { .pbar { display:none; } body { -webkit-print-color-adjust:exact; print-color-adjust:exact; } }
  .hdr { background:linear-gradient(120deg,#0D1117 0%,#1A3A5C 55%,#1A6FBF 100%);
         color:#fff; padding:30px 36px 26px; display:flex;
         justify-content:space-between; align-items:flex-start; gap:24px; }
  .hdr-title { font-size:21px; font-weight:800; letter-spacing:-.4px; }
  .hdr-sub   { font-size:12px; color:rgba(255,255,255,.6); margin-top:3px; }
  .hdr-meta  { text-align:right; font-size:12px; color:rgba(255,255,255,.8); line-height:2.1; white-space:nowrap; }
  .hdr-meta strong { color:#fff; }
  .kpis { display:grid; grid-template-columns:repeat(6,1fr);
          border-bottom:1px solid #e9ecef; background:#f8f9fa; }
  .kc   { padding:15px 8px; text-align:center; border-right:1px solid #e9ecef; }
  .kc:last-child { border-right:none; }
  .kv   { font-size:25px; font-weight:800; }
  .kl   { font-size:10px; color:#888; text-transform:uppercase; letter-spacing:.05em; margin-top:2px; }
  .blu { color:#1A6FBF; } .amb { color:#C07010; } .grn { color:#1A7A3C; } .drk { color:#1a1a2e; }
  .body   { padding:26px 36px; display:flex; flex-direction:column; gap:30px; }
  .stitle { font-size:11px; font-weight:800; text-transform:uppercase; letter-spacing:.08em;
            color:#1A6FBF; padding-bottom:8px; margin-bottom:14px; border-bottom:2px solid #1A6FBF; }
  .chrow { display:flex; gap:28px; align-items:flex-start; flex-wrap:wrap; }
  .chbox { display:flex; flex-direction:column; gap:8px; }
  .chlbl { font-size:11px; color:#888; font-weight:600; text-transform:uppercase; letter-spacing:.04em; }
  .leg   { display:flex; gap:12px; }
  .li    { display:flex; align-items:center; gap:5px; font-size:11px; color:#555; }
  .ld    { width:10px; height:10px; border-radius:2px; flex-shrink:0; }
  .dt          { width:100%; border-collapse:collapse; font-size:12px; }
  .dt thead tr { background:#1a1a2e; color:#fff; }
  .dt thead th { padding:9px 12px; text-align:left; font-size:10px;
                 text-transform:uppercase; letter-spacing:.04em; font-weight:700; }
  .dt tbody tr:nth-child(even) { background:#f5f7fa; }
  .dt tbody tr:hover           { background:#e8f2fb; }
  .td-l    { padding:8px 12px; font-weight:600; }
  .td-c    { padding:8px 12px; text-align:center; }
  .td-empty { padding:18px; text-align:center; color:#aaa; font-style:italic; }
  .fw7 { font-weight:700; } .mu { color:#888; }
  .ba { background:#dbeafe; color:#1A6FBF; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:700; }
  .bt { background:#fef3c7; color:#C07010; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:700; }
  .sg   { display:grid; grid-template-columns:1fr 1fr 1fr; gap:12px; }
  .sc   { background:#f5f7fa; border-radius:8px; padding:16px; border-left:4px solid #1A6FBF; }
  .sc.a { border-left-color:#C07010; }
  .sc.g { border-left-color:#1A7A3C; }
  .sl   { font-size:10px; color:#888; text-transform:uppercase; letter-spacing:.05em; margin-bottom:3px; }
  .sv   { font-size:22px; font-weight:800; color:#1a1a2e; }
  .ftr  { margin-top:6px; padding:12px 36px; background:#f5f7fa;
          border-top:1px solid #e9ecef; display:flex;
          justify-content:space-between; font-size:10px; color:#aaa; }
</style>
</head>
<body>

<div class="pbar">
  <span>PEO License Manager · Informe de Sesión · ${PEO.esc(stats.operator)} · ${stats.datetime}</span>
  <button onclick="window.print()">⬇ Guardar como PDF</button>
</div>

<div class="hdr">
  <div>
    <div class="hdr-title">⚖ PEO License Manager</div>
    <div class="hdr-sub">Informe de Actividad del Operador</div>
  </div>
  <div class="hdr-meta">
    <div><strong>Operador:</strong> ${PEO.esc(stats.operator)}</div>
    <div><strong>Fecha:</strong> ${stats.datetime}</div>
    <div><strong>Sesión:</strong> ${stats.sessionStart.slice(11,16)} → ${stats.sessionEnd.slice(11,16)}</div>
  </div>
</div>

<div class="kpis">
  <div class="kc"><div class="kv drk">${stats.totalForms}</div><div class="kl">Formularios</div></div>
  <div class="kc"><div class="kv drk">${stats.stateCount}</div><div class="kl">Estados</div></div>
  <div class="kc"><div class="kv blu">${stats.byProcess.ADD  || 0}</div><div class="kl">ADDs</div></div>
  <div class="kc"><div class="kv amb">${stats.byProcess.TERM || 0}</div><div class="kl">TERMs</div></div>
  <div class="kc"><div class="kv grn">${stats.avgSec}s</div><div class="kl">Prom/Form</div></div>
  <div class="kc"><div class="kv drk">${stats.totalSec}s</div><div class="kl">T. Total</div></div>
</div>

<div class="body">

  <div class="section">
    <h2 class="stitle">📈 Distribución por Estado y Proceso</h2>
    <div class="chrow">
      <div class="chbox" style="flex:2">
        <div class="chlbl">Formularios por Estado</div>
        ${_svgBarChart(stats.byState)}
        <div class="leg">
          <div class="li"><div class="ld" style="background:#1A6FBF"></div>ADD</div>
          <div class="li"><div class="ld" style="background:#C07010"></div>TERM</div>
        </div>
      </div>
      <div class="chbox" style="align-items:center">
        <div class="chlbl">ADD vs TERM</div>
        ${_svgDonut(stats.byProcess.ADD || 0, stats.byProcess.TERM || 0)}
        <div class="leg" style="justify-content:center">
          <div class="li"><div class="ld" style="background:#1A6FBF"></div>ADD (${stats.byProcess.ADD || 0})</div>
          <div class="li"><div class="ld" style="background:#C07010"></div>TERM (${stats.byProcess.TERM || 0})</div>
        </div>
      </div>
    </div>
  </div>

  <div class="section">
    <h2 class="stitle">🗺 Detalle por Estado</h2>
    <table class="dt">
      <thead>
        <tr><th>Estado</th><th>ADD</th><th>TERM</th><th>Total</th><th>T. Total</th><th>T. Promedio</th></tr>
      </thead>
      <tbody>${stateRows}</tbody>
    </table>
  </div>

  <div class="section">
    <h2 class="stitle">⏱ Métricas de Tiempo</h2>
    <div class="sg">
      <div class="sc"><div class="sl">Tiempo total de generación</div><div class="sv">${stats.totalSec}s</div></div>
      <div class="sc a"><div class="sl">Tiempo promedio / formulario</div><div class="sv">${stats.avgSec}s</div></div>
      <div class="sc g"><div class="sl">Estados cubiertos</div><div class="sv">${stats.stateCount}</div></div>
    </div>
  </div>

  ${historicoSection}

</div>

<div class="ftr">
  <span>PEO License Manager · ${stats.datetime} · Generado automáticamente</span>
  <span>Operador: ${PEO.esc(stats.operator)} · ${stats.totalForms} formularios</span>
</div>

</body>
</html>`;

  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url  = URL.createObjectURL(blob);
  const win  = window.open(url, "_blank");
  if (!win) PEO.notify("Habilita ventanas emergentes para ver el informe PDF.", "err");
  setTimeout(() => URL.revokeObjectURL(url), 15000);
};

// ═══════════════════════════════════════════════════════════════════════════
//  SECCIÓN 5 — Histórico Excel
// ═══════════════════════════════════════════════════════════════════════════

async function _readHistoricoRows(cutoffDate) {
  const hf = PEO.state.historicoFile;
  if (!hf) return [];
  try {
    const wb   = XLSX.read(await hf.arrayBuffer(), { type: "array" });
    const ws   = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(ws, { defval: "" });
    if (!cutoffDate) return rows;
    return rows.filter(r => String(r.fecha_realizacion || "").slice(0, 10) >= cutoffDate);
  } catch (e) {
    PEO.notify("Error leyendo histórico: " + e.message, "err");
    return [];
  }
}

PEO.buildHistorico = async function (stats) {
  const cutoff       = PEO.state.historicoCutoffDate;
  const existingRows = await _readHistoricoRows(cutoff);

  const estadosStr = Object.entries(stats.byState)
    .map(([s, d]) => `${s}:${d.total}`).join(" | ");

  const newRow = {
    fecha_realizacion:   stats.datetime,
    operador:            stats.operator,
    total_formularios:   stats.totalForms,
    adds:                stats.byProcess.ADD  || 0,
    terms:               stats.byProcess.TERM || 0,
    estados:             stats.stateCount,
    detalle_estados:     estadosStr,
    tiempo_total_seg:    parseFloat(stats.totalSec),
    tiempo_promedio_seg: parseFloat(stats.avgSec),
    hora_inicio:         stats.sessionStart.slice(11, 16),
    hora_fin:            stats.sessionEnd.slice(11, 16),
  };

  const allRows = [...existingRows, newRow];

  const wb     = XLSX.utils.book_new();
  const wsHist = XLSX.utils.json_to_sheet(allRows);
  wsHist["!cols"] = [
    {wch:18},{wch:12},{wch:17},{wch:7},{wch:7},
    {wch:8},{wch:42},{wch:16},{wch:18},{wch:11},{wch:9},
  ];
  XLSX.utils.book_append_sheet(wb, wsHist, "Histórico");

  const byOp = {};
  for (const r of allRows) {
    const op = r.operador || "—";
    if (!byOp[op]) byOp[op] = {
      operador:op, sesiones:0, total_formularios:0,
      adds:0, terms:0, tiempo_total_seg:0, estados_set: new Set(),
    };
    byOp[op].sesiones++;
    byOp[op].total_formularios += Number(r.total_formularios) || 0;
    byOp[op].adds              += Number(r.adds)              || 0;
    byOp[op].terms             += Number(r.terms)             || 0;
    byOp[op].tiempo_total_seg  += Number(r.tiempo_total_seg)  || 0;
    String(r.detalle_estados || "").split(" | ")
      .forEach(s => { if (s.includes(":")) byOp[op].estados_set.add(s.split(":")[0]); });
  }

  const summaryRows = Object.values(byOp).map(o => ({
    operador:             o.operador,
    sesiones:             o.sesiones,
    total_formularios:    o.total_formularios,
    adds:                 o.adds,
    terms:                o.terms,
    promedio_por_sesion:  o.sesiones > 0 ? (o.total_formularios / o.sesiones).toFixed(1) : 0,
    estados_cubiertos:    o.estados_set.size,
    tiempo_total_seg:     o.tiempo_total_seg.toFixed(1),
    tiempo_promedio_form: o.total_formularios > 0
      ? (o.tiempo_total_seg / o.total_formularios).toFixed(1) : 0,
  }));

  const wsSum = XLSX.utils.json_to_sheet(summaryRows);
  wsSum["!cols"] = [
    {wch:12},{wch:9},{wch:17},{wch:7},{wch:7},{wch:18},{wch:16},{wch:15},{wch:18},
  ];
  XLSX.utils.book_append_sheet(wb, wsSum, "Por Operador");

  const buf  = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const blob = new Blob([buf], { type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href = url; a.download = "historico_informe.xlsx"; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);

  PEO.notify(`Histórico: ${allRows.length} sesión(es) acumuladas — descargado.`, "ok");
};

// ═══════════════════════════════════════════════════════════════════════════
//  SECCIÓN 6 — Coordinador principal
// ═══════════════════════════════════════════════════════════════════════════

PEO.generateAllReports = async function () {
  const generated = PEO.state._kpiQueue.filter(e => e.action === "GENERATE");
  if (!generated.length) {
    PEO.notify("No hay formularios generados en esta sesión — sin datos para el informe.", "info");
    return;
  }

  PEO.notify("Generando informe de sesión…", "info");
  const stats    = PEO.buildSessionStats();
  const histRows = await _readHistoricoRows(PEO.state.historicoCutoffDate);

  // 1. Informe PDF (pestaña nueva → Ctrl+P para guardar como PDF)
  PEO.generatePdfReport(stats, histRows);

  // 2. Histórico Excel actualizado y descargado
  await PEO.buildHistorico(stats);
};
