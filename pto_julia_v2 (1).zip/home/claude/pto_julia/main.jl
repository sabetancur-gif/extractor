"""
main.jl
─────────────────────────────────────────────────────────────────────────────
Punto de entrada del sistema PTO Novedades.
Ejecutar con:  julia main.jl

Flujo completo:
  1. Activar entorno Julia del proyecto
  2. Cargar todos los módulos
  3. Descargar datos desde Synapse + SharePoint + archivos locales
  4. Construir IDs únicos (TEXTJOIN)
  5. Cargar Def histórico y detectar IDs nuevos
     → Si no hay nuevos: terminar
     → Si hay nuevos: continuar
  6. Lanzar panel interactivo con 3 núcleos paralelos
  7. Al finalizar: exportar Def.xlsx, Snapshot, Rejected
─────────────────────────────────────────────────────────────────────────────
"""

# ── Activar entorno ───────────────────────────────────────────────────────────
using Pkg
Pkg.activate(@__DIR__)

# ── Cargar módulos (orden de dependencias) ────────────────────────────────────
include("src/Config.jl")
include("src/SynapseConnector.jl")
include("src/SharePointConnector.jl")
include("src/LocalFilesConnector.jl")
include("src/DataLoader.jl")
include("src/IDBuilder.jl")
include("src/DefManager.jl")
include("src/Validator.jl")
include("src/Processor.jl")
include("src/Exporter.jl")
include("src/Panel.jl")

using Dates
using .Config
using .DataLoader
using .IDBuilder
using .DefManager
using .Processor
using .Exporter
using .Panel

# ─────────────────────────────────────────────────────────────────────────────
# Utilidades de consola
# ─────────────────────────────────────────────────────────────────────────────
const B  = "\e[1m"
const R  = "\e[0m"
const GR = "\e[32m"
const RD = "\e[31m"
const YL = "\e[33m"
const CY = "\e[36m"

sep(c="─", n=70) = println(c^n)
header(s) = begin sep("═"); println("  $s"); sep("═") end
step(n, s) = println("\n$(CY)$(B)▶ [$n]$(R)  $s")

# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

function main()
    header("SISTEMA PTO NOVEDADES — Solvo Global  |  $(Dates.today())")

    # ── PASO 1: Descargar y unificar todas las fuentes ─────────────────────────
    step(1, "Conectando a fuentes de datos (Synapse · SharePoint · Local)...")
    unified_raw = DataLoader.load_all_sources()

    if isnothing(unified_raw) || isempty(unified_raw)
        println("\n$(RD)✗ No se obtuvieron datos. Revise credenciales en src/Config.jl$(R)")
        return
    end

    # ── PASO 2: Construir IDs ──────────────────────────────────────────────────
    step(2, "Construyendo IDs únicos (fórmula TEXTJOIN)...")
    unified = IDBuilder.build_unified(unified_raw)

    # ── PASO 3: Cargar Def y detectar novedades nuevas ─────────────────────────
    step(3, "Cargando histórico Def y detectando novedades nuevas...")
    def_df  = DefManager.load_def()
    new_ids = DefManager.find_new(unified, def_df)

    if isempty(new_ids)
        println("\n$(GR)$(B)✅  No hay novedades nuevas para procesar.$(R)")
        println("   El Def está actualizado con $(nrow(def_df)) registros.\n")
        return
    end

    println("\n  $(YL)$(B)→ $(length(new_ids)) novedades nuevas detectadas$(R)")

    # ── PASO 4: Panel de procesamiento ────────────────────────────────────────
    step(4, "Iniciando panel de procesamiento paralelo...")
    results = Panel.run_panel(unified, new_ids, def_df)

    # ── PASO 5: Exportar ──────────────────────────────────────────────────────
    if results.finalized
        step(5, "Exportando archivos...")
        er = Exporter.export_all(
            # Construir un ProcessorState mínimo con los resultados del panel
            _build_export_state(results),
            def_df,
            unified,
        )

        sep("═")
        println("\n$(GR)$(B)  PROCESO COMPLETADO EXITOSAMENTE$(R)\n")
        println("  📄  Def.xlsx          → $(er.def_xlsx)")
        println("  📄  Def.csv           → $(er.def_csv)")
        println("  📋  Snapshot día      → $(er.snapshot_xlsx)  ($(er.n_valid) válidas)")
        println("  ⚠   Rechazadas        → $(er.rejected_xlsx)  ($(er.n_rejected) rechazadas)")
        sep("═")
        println()
    else
        println("\n$(YL)  Proceso cancelado — no se generaron archivos.$(R)\n")
    end
end

# ─────────────────────────────────────────────────────────────────────────────
# Construir un ProcessorState liviano con los datos del PanelResult
# (el Exporter necesita el estado para leer valid_ids / out_ids)
# ─────────────────────────────────────────────────────────────────────────────
function _build_export_state(r::PanelResult)::Processor.ProcessorState
    nuclei = Dict{Symbol, Processor.NucleusState}()
    for ntype in (:VAC, :INC, :AUS)
        nuclei[ntype] = Processor.NucleusState(
            ntype, 0, Processor.SubcoreState[], 0, 0, 0, 0, :done)
    end
    ch = Channel{Any}(1)
    close(ch)
    return Processor.ProcessorState(
        nuclei,
        r.valid_ids, r.out_ids,
        r.rejected_ids, r.rejected_reasons,
        length(r.valid_ids) + length(r.out_ids),
        length(r.valid_ids) + length(r.out_ids),
        now(), true, true, ch,
    )
end

# ── Ejecutar ──────────────────────────────────────────────────────────────────
main()
