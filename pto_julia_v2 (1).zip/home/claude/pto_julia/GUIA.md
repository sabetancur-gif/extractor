# GUÍA COMPLETA — Sistema PTO Novedades en Julia
## Solvo Global · v2.0

---

## ¿Qué hace este sistema?

Reemplaza completamente el proceso manual en Excel/Power Query.  
En lugar de abrir archivos que ya no cargan por el volumen de datos, este sistema:

1. **Se conecta directamente a Azure Synapse** y descarga ausentismos, incapacidades y vacaciones
2. **Se conecta directamente a SharePoint** y descarga Novedades.xlsx
3. **Carga Roster y Types of PTO** desde los archivos locales de OneDrive
4. **Procesa las novedades** con los 3 núcleos paralelos (VAC · INC · AUS)
5. **Genera todos los archivos de salida** (Def.xlsx, Snapshot, Rejected)

El archivo **Def.xlsx** ya no vive dentro de un Excel con 230k filas lentas;  
lo gestiona Julia directamente en la carpeta `output/`.

---

## Estructura del proyecto

```
pto_julia/
├── main.jl                    ← EJECUTAR ESTO cada día
├── setup.jl                   ← Ejecutar solo UNA vez para instalar
├── Project.toml               ← Definición del entorno Julia
├── GUIA.md                    ← Este archivo
│
├── src/
│   ├── Config.jl              ← ⚠ CREDENCIALES Y RUTAS — editar aquí
│   ├── SynapseConnector.jl    ← Conexión directa a Azure Synapse vía ODBC
│   ├── SharePointConnector.jl ← Descarga Novedades.xlsx vía Microsoft Graph API
│   ├── LocalFilesConnector.jl ← Carga Roster.xlsx y TYPES OF PTO.xlsx locales
│   ├── DataLoader.jl          ← Orquesta fuentes + expande Fecha Del Evento
│   ├── IDBuilder.jl           ← Genera columna ID (fórmula TEXTJOIN)
│   ├── DefManager.jl          ← Gestiona histórico Def.xlsx / Def.csv
│   ├── Validator.jl           ← Reglas VAC / INC / AUS + conflictos Column2
│   ├── Processor.jl           ← 3 núcleos paralelos + sub-núcleos + canal eventos
│   ├── Exporter.jl            ← Genera archivos de salida
│   └── Panel.jl               ← Panel terminal profesional con barras de progreso
│
└── output/                    ← Archivos generados (se crea automáticamente)
    ├── Def.xlsx               ← Histórico principal (se actualiza en cada corrida)
    ├── Def.csv
    ├── Def_2025-06-02.xlsx    ← Snapshot del día (solo válidas)
    ├── Def_2025-06-02.csv
    ├── Rejected_2025-06-02.xlsx
    └── Rejected_2025-06-02.csv
```

---

## PASO 1 — Instalar Julia

### Windows
1. Descargue el instalador desde **https://julialang.org/downloads/**  
   → Elija "Current stable release" → Windows (.exe installer)
2. Ejecute el instalador, marque la opción **"Add Julia to PATH"**
3. Abra una terminal nueva (PowerShell o CMD) y verifique:
   ```
   julia --version
   ```
   Debe mostrar: `julia version 1.10.x` (o superior)

### macOS
```bash
# Con Homebrew:
brew install julia

# O descargue el .dmg desde julialang.org
```

### Linux (Ubuntu/Debian)
```bash
wget https://julialang-s3.julialang.org/bin/linux/x64/1.10/julia-1.10.5-linux-x86_64.tar.gz
tar -xzf julia-1.10.5-linux-x86_64.tar.gz
sudo mv julia-1.10.5 /opt/julia
echo 'export PATH="$PATH:/opt/julia/bin"' >> ~/.bashrc
source ~/.bashrc
julia --version
```

---

## PASO 2 — Instalar el driver ODBC para SQL Server

El sistema necesita este driver para conectarse a Azure Synapse.

### Windows
1. Descargue desde: **https://aka.ms/downloadmsodbcsql**  
   → "ODBC Driver 18 for SQL Server" → Windows x64
2. Ejecute el instalador, siga los pasos (todo por defecto)
3. Verifique que quedó instalado:
   - Abra "Administrador de orígenes de datos ODBC" (busque en inicio)
   - Pestaña "Drivers" → debe aparecer "ODBC Driver 18 for SQL Server"

### macOS
```bash
brew tap microsoft/mssql-release https://github.com/Microsoft/homebrew-mssql-release
brew install msodbcsql18
```

### Linux (Ubuntu)
```bash
curl https://packages.microsoft.com/keys/microsoft.asc | sudo apt-key add -
curl https://packages.microsoft.com/config/ubuntu/22.04/prod.list \
     | sudo tee /etc/apt/sources.list.d/mssql-release.list
sudo apt-get update
sudo ACCEPT_EULA=Y apt-get install -y msodbcsql18
```

---

## PASO 3 — Configurar credenciales

Abra `src/Config.jl` con cualquier editor de texto (Notepad, VS Code, etc.)  
y edite las líneas marcadas con `← CAMBIAR`:

```julia
# ─ Azure Synapse ──────────────────────────────────────────────
const SYNAPSE_USER     = "santiago.betancur@employersolutions.com"  # ← su correo
const SYNAPSE_PASSWORD = "SuContraseñaReal"                          # ← su contraseña

# ─ SharePoint ─────────────────────────────────────────────────
const SHAREPOINT_USER     = "santiago.betancur@employersolutions.com"
const SHAREPOINT_PASSWORD = "SuContraseñaReal"

# ─ Azure AD Tenant ────────────────────────────────────────────
# Encuentre su Tenant ID en: portal.azure.com
#   → Azure Active Directory → Properties → Tenant ID
const AZURE_TENANT_ID = "12345678-abcd-efgh-ijkl-123456789012"  # ← su Tenant ID
```

### ¿Dónde encuentro el Tenant ID?
1. Abra https://portal.azure.com con su cuenta corporativa
2. Busque "Azure Active Directory" en el menú
3. Haga clic en "Properties" (Propiedades)
4. Copie el campo "Tenant ID" (formato: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)

### Verificar la ruta de los archivos locales
Confirme que las rutas en `Config.jl` apunten a donde están sus archivos:

```julia
const ROSTER_FILE = raw"C:\Users\Santiago.Betancur\OneDrive - Employer Solutions\Desktop\PTO\Roster.xlsx"
const TYPES_PTO_FILE = raw"C:\Users\Santiago.Betancur\OneDrive - Employer Solutions\Desktop\PTO\PTO\TYPES OF PTO.xlsx"
```

Si su usuario de Windows es diferente, cámbielo. Por ejemplo:
```julia
const ROSTER_FILE = raw"C:\Users\Juan.Perez\OneDrive - Employer Solutions\Desktop\PTO\Roster.xlsx"
```

---

## PASO 4 — Instalar dependencias Julia (solo la primera vez)

Abra una terminal, navegue a la carpeta del proyecto y ejecute:

```bash
# Windows PowerShell o CMD:
cd C:\Users\Santiago.Betancur\Desktop\pto_julia
julia setup.jl

# macOS / Linux:
cd ~/Desktop/pto_julia
julia setup.jl
```

Esto instala automáticamente: CSV, DataFrames, XLSX, ODBC, HTTP, JSON3.  
La primera vez puede tomar **3-8 minutos** dependiendo de la conexión.  
Las siguientes ejecuciones son casi instantáneas (usa caché).

---

## PASO 5 — Ejecutar el sistema

```bash
julia main.jl
```

### Primera corrida (sin Def previo)
- El sistema detecta que no existe `output/Def.xlsx`
- Descarga y procesa TODOS los registros desde Synapse y SharePoint
- Crea `output/Def.xlsx` desde cero con todos los IDs procesados
- Genera el snapshot del día y el archivo de rechazados

### Corridas diarias posteriores
- Lee `output/Def.xlsx` como histórico
- Compara IDs nuevos vs. los ya registrados en el Def
- Si **no hay novedades nuevas**: muestra mensaje y termina
- Si **hay novedades nuevas**: lanza el panel de procesamiento

---

## PASO 6 — Usar el panel

```
╔════════════════════════════════════════════════════════════════════════╗
║  PROCESAMIENTO DE NOVEDADES PTO — Solvo Global   2025-06-02   ⏱ 00:12 ║
║  Total novedades nuevas detectadas:  1 234                             ║
╠════════════════════════════════════════════════════════════════════════╣
║  ◉ [VAC] VACACIONES   │  450 IDs  │  3 sub-núcleos                    ║
║    ████████████░░░░░░  68%   ✓ 306   ✗ 0                              ║
║    Sub-núcleos: ▪ #1(100%)  ▸ #2(44%)  ▫ #3(0%)                      ║
║                                                                        ║
║  ◉ [INC] INCAPACIDADES │  600 IDs  │  3 sub-núcleos                   ║
║    ██████████████████░  90%   ✓ 522   ✗ 18                            ║
║    Sub-núcleos: ▪ #1(100%)  ▪ #2(100%)  ▸ #3(72%)                    ║
║                                                                        ║
║  ● [AUS] AUSENTISMOS  │  184 IDs  │  1 sub-núcleo                     ║
║    ████████████████████ 100%   ✓ 178   ✗ 6                            ║
║    Sub-núcleos: ▪ #1(100%)                                             ║
╠════════════════════════════════════════════════════════════════════════╣
║  ► Rechazados (24):  AUS-00123  │  INC-00456  │  VAC-00789  │  ...    ║
╠════════════════════════════════════════════════════════════════════════╣
║  Progreso total  ████████████████████░░░░  82%   1012 / 1234          ║
║  ⚙  PROCESANDO...                                                      ║
╚════════════════════════════════════════════════════════════════════════╝
```

**Iconos de estado:**
| Icono | Significado |
|-------|-------------|
| `○` | Pendiente (aún no iniciado) |
| `◉` | En proceso |
| `●` | Completado |
| `▫` | Sub-núcleo pendiente |
| `▸` | Sub-núcleo en proceso |
| `▪` | Sub-núcleo completado |

**Al terminar:**
```
║  ✅ COMPLETADO — Válidas: 1210  │  Rechazadas: 24                      ║
║  ▶  [ENTER] Finalizar y exportar     [S] Salir sin guardar             ║
```

- **ENTER** → Exporta todos los archivos y actualiza el Def
- **S** → Sale sin guardar nada (el Def no cambia)

---

## Archivos generados

| Archivo | Descripción |
|---------|-------------|
| `output/Def.xlsx` | Histórico principal. Se actualiza acumulativamente en cada corrida. INDEX = "NOT FOUND" para novedades que desaparecieron del sistema |
| `output/Def.csv` | Mismo contenido del Def.xlsx en formato CSV |
| `output/Def_YYYY-MM-DD.xlsx` | Snapshot del día: solo novedades válidas (sin NOT FOUND, sin OUT) |
| `output/Def_YYYY-MM-DD.csv` | Mismo snapshot en CSV |
| `output/Rejected_YYYY-MM-DD.xlsx` | Novedades rechazadas con columna **Reason** |
| `output/Rejected_YYYY-MM-DD.csv` | Mismo rechazados en CSV |

---

## Columnas del Def

| Columna | Descripción |
|---------|-------------|
| INDEX | Posición en la tabla origen. "NOT FOUND" si el registro desapareció |
| ID | Clave única (TEXTJOIN de todos los campos) |
| Column1 | COUNTIF del ID en la tabla actual (detecta duplicados) |
| LISTO | Siempre "SI" en el Def |
| SOLID | Código del empleado (SOLAxxxx) |
| Fecha Salida | Fecha inicio de la novedad |
| Fecha Llegada | Fecha fin de la novedad |
| Nombre y Apellido | Nombre completo |
| Novedad | Tipo de novedad |
| Numero novedad | Código (VAC-xxx / INC-xxx / AUS-xxx) |
| Dias (Numeros) | Días de la novedad |
| Horas (Numeros) | Horas de la novedad |
| Date of PTO | Fecha del evento (día expandido) |
| Horas | Horas totales del registro |
| Hours of PTO | Tiempo de afectación (máx. 8h/día) |
| Column2 | COUNTIFS SOLID + Date of PTO (detecta conflictos) |
| IN/OUT | "OUT" si fue rechazada / vacío si válida |
| PROCESADA | "SI" cuando fue procesada en este sistema |

---

## Reglas de validación implementadas

### Paso 1 — IN > OUT
Toda novedad donde `Fecha Llegada < Fecha Salida` se marca **OUT**.  
Razón: `"IN>OUT: Fecha Llegada (YYYY-MM-DD) < Fecha Salida (YYYY-MM-DD)"`

### Paso 2 — Bandas de horas
| Horas totales | Diferencia de días esperada |
|--------------|----------------------------|
| ≤ 8h | 0 días (mismo día) |
| ≤ 16h | 1 día |
| ≤ 24h | 2 días |
| ≤ 32h | 3 días |
| ≤ 40h | 4 días |

Las que no encajan en ninguna banda continúan al paso 3 (no se rechazan aquí).

### Paso 3 — Validación por tipo

**VAC (Vacaciones):**  
`Hours_of_PTO × 8 + festivos_en_rango × 8 == Horas_totales`

**INC (Incapacidades):**  
`Hours_of_PTO × 8 + fines_de_semana_en_rango × 16 == Horas_totales`

**AUS (Ausentismos):**  
`Hours_of_PTO ≤ 8`

### Paso 4 — Conflictos (Column2 ≠ 1)
Cuando el mismo SOLID tiene múltiples novedades en la misma fecha:

1. **Misma novedad** → conservar el de mayor INDEX (más reciente), OUT al resto
2. **Mismo prefijo** (ej. dos AUS) → válidos si la suma de Hours_of_PTO ≤ 8
3. **Distintos prefijos** → jerarquía **INC > AUS > VAC**

---

## Problemas frecuentes

### "ODBC.jl: connection failed"
- Verifique que el ODBC Driver 18 esté instalado (Paso 2)
- Confirme usuario y contraseña en `Config.jl`
- Si usa MFA obligatorio en todas las apps, cambie `SYNAPSE_AUTH_MODE = "AAD_INTEGRATED"` para usar el SSO de Windows

### "Error de autenticación SharePoint"
- Verifique `AZURE_TENANT_ID` (debe ser el de su organización, no un ejemplo)
- Si la organización bloquea el flujo ROPC (contraseña directa), contacte a IT para que registren una aplicación Azure AD y le den el Client ID
- Como alternativa temporal, puede descargar manualmente el Novedades.xlsx y ponerlo en `output/novedades_manual.xlsx`, luego descomentando la línea de carga manual en `DataLoader.jl`

### "Archivo no encontrado: Roster.xlsx"
- Verifique que el archivo existe en la ruta de OneDrive
- Si el archivo está en otra ubicación, actualice `ROSTER_FILE` en `Config.jl`
- Si OneDrive no está sincronizado, asegúrese de que la carpeta esté disponible offline

### El panel no muestra colores
- Use **Windows Terminal** (no el CMD clásico)
- En macOS: iTerm2 o el Terminal nativo de macOS Monterey+
- En VS Code: el terminal integrado soporta ANSI

### Primera ejecución muy lenta (60+ segundos)
Julia compila los módulos la primera vez. Las corridas siguientes son ~10× más rápidas. Puede ejecutar `julia --project=. --sysimage=PTO.so main.jl` después de generar una system image para arranques instantáneos (ver documentación de PackageCompiler.jl).

---

## Flujo diario recomendado

```
1. Abrir terminal en la carpeta pto_julia/

2. Ejecutar:
   julia main.jl

3. El sistema se conecta solo a Synapse y SharePoint
   (no necesita hacer nada en Excel)

4. Observar el panel:
   - Los 3 núcleos procesan en paralelo
   - Ver las barras de progreso por tipo y sub-núcleo
   - Los rechazados aparecen en tiempo real

5. Al terminar → pulsar ENTER para exportar

6. Revisar output/Rejected_YYYY-MM-DD.xlsx
   para validación manual de rechazados

7. Listo — el Def.xlsx ya quedó actualizado
```

---

## Actualizar festivos cada año

Edite `src/Config.jl`, sección `FESTIVOS_COLOMBIA`, y añada el bloque del año nuevo:

```julia
# 2028 (ejemplo)
Date(2028,1,1), Date(2028,1,10), ...
```

Los festivos colombianos oficiales se publican en: **https://www.dian.gov.co**

---

## Módulos y responsabilidades (resumen técnico)

| Módulo | Responsabilidad |
|--------|-----------------|
| `Config.jl` | Todas las constantes y credenciales |
| `SynapseConnector.jl` | Conexión ODBC a Azure Synapse, 3 queries SQL |
| `SharePointConnector.jl` | OAuth2 → Graph API → descarga Novedades.xlsx en memoria |
| `LocalFilesConnector.jl` | Lee Roster.xlsx y TYPES OF PTO.xlsx locales |
| `DataLoader.jl` | Une todas las fuentes, expande Fecha Del Evento, hace joins |
| `IDBuilder.jl` | Genera columna ID replicando fórmula TEXTJOIN de Excel |
| `DefManager.jl` | Carga/guarda Def.xlsx; detecta IDs nuevos vs. histórico |
| `Validator.jl` | Reglas IN>OUT, bandas horas, VAC/INC/AUS, conflictos Column2 |
| `Processor.jl` | 3 Tasks paralelos + sub-núcleos + Channel de eventos |
| `Exporter.jl` | Genera 6 archivos de salida al finalizar |
| `Panel.jl` | Render ANSI dinámico, barras de progreso, input usuario |
| `main.jl` | Orquesta todo el flujo de principio a fin |
