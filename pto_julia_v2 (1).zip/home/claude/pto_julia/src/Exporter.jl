"""
src/Exporter.jl
─────────────────────────────────────────────────────────────────────────────
Genera todos los archivos de salida al pulsar "Finalizar":

  1. Def.xlsx + Def.csv
       Histórico completo actualizado (existentes + nuevos + NOT FOUND)

  2. Def_YYYY-MM-DD.xlsx + Def_YYYY-MM-DD.csv
       Solo novedades válidas del procesamiento actual
       (no NOT FOUND, no OUT)

  3. Rejected_YYYY-MM-DD.xlsx + Rejected_YYYY-MM-DD.csv
       Novedades rechazadas con columna Reason explicando el motivo
─────────────────────────────────────────────────────────────────────────────
"""
module Exporter

using DataFrames, XLSX, CSV, Dates, Logging
using ..Config
using ..DefManager
using ..Processor

export export_all, ExportResult

struct ExportResult
    def_xlsx::String
    def_csv::String
    snapshot_xlsx::String
    snapshot_csv::String
    rejected_xlsx::String
    rejected_csv::String
    n_valid::Int
    n_rejected::Int
end

# ─────────────────────────────────────────────────────────────────────────────
# Escritura XLSX genérica
# ─────────────────────────────────────────────────────────────────────────────

function write_df_xlsx(path::String, sheet_name::String, df::DataFrame)
    isdir(dirname(path)) || mkpath(dirname(path))
    XLSX.openxlsx(path; mode=:w) do xf
        sh = XLSX.addsheet!(xf, sheet_name)
        cols = names(df)
        for (ci, col) in enumerate(cols)
            sh[1, ci] = col
        end
        for (ri, row) in enumerate(eachrow(df))
            for (ci, col) in enumerate(cols)
                v = row[col]
                sh[ri+1, ci] = ismissing(v) ? "" : v
            end
        end
    end
end

function write_df_csv(path::String, df::DataFrame)
    isdir(dirname(path)) || mkpath(dirname(path))
    CSV.write(path, df; missingstring="")
end

# ─────────────────────────────────────────────────────────────────────────────
# DataFrame de rechazados
# ─────────────────────────────────────────────────────────────────────────────

function build_rejected_df(
    rejected_ids::Vector{String},
    rejected_reasons::Dict{String,String},
    unified::DataFrame,
)::DataFrame

    cols_schema = (
        ID=String[], SOLID=String[], Novedad=String[],
        Numero_novedad=String[],
        Fecha_Salida=Union{Date,Missing}[],
        Fecha_Llegada=Union{Date,Missing}[],
        Fecha_Del_Evento=Union{Date,Missing}[],
        Horas=Union{Float64,Missing}[],
        Hours_of_PTO=Union{Float64,Missing}[],
        Reason=String[],
    )
    df = DataFrame(cols_schema)

    id_to_i = Dict(row.ID => i for (i,row) in enumerate(eachrow(unified)))

    for id in unique(rejected_ids)
        reason = get(rejected_reasons, id, "")
        i = get(id_to_i, id, nothing)
        if isnothing(i)
            push!(df, (id, "NOT FOUND", "NOT FOUND", "NOT FOUND",
                       missing, missing, missing, missing, missing, reason))
        else
            r = unified[i, :]
            push!(df, (
                id,
                string(coalesce(r.SOLID, "")),
                string(coalesce(r.Novedad, "")),
                string(coalesce(r.Numero_novedad, "")),
                get(r, :Fecha_Salida, missing),
                get(r, :Fecha_Llegada, missing),
                get(r, :Fecha_Del_Evento, missing),
                get(r, :Horas_total, missing),
                get(r, :Tiempo_Afectacion, missing),
                reason,
            ))
        end
    end
    return df
end

# ─────────────────────────────────────────────────────────────────────────────
# API pública
# ─────────────────────────────────────────────────────────────────────────────

"""
    export_all(proc_state, def_df, unified) -> ExportResult

Genera los 6 archivos de salida y retorna sus rutas.
"""
function export_all(
    proc_state::ProcessorState,
    def_df::DataFrame,
    unified::DataFrame,
)::ExportResult

    isdir(Config.OUTPUT_DIR) || mkpath(Config.OUTPUT_DIR)
    stamp = Dates.format(today(), "yyyy-mm-dd")

    # ── 1. Actualizar Def completo ─────────────────────────────────────────────
    println("\n   Actualizando Def histórico...")
    updated_def = DefManager.update_def(
        def_df,
        proc_state.valid_ids,
        proc_state.out_ids,
        unified,
    )
    DefManager.save_def(updated_def)

    # ── 2. Snapshot del día (solo válidos: no NOT FOUND, no OUT) ──────────────
    snap_df = filter(updated_def) do r
        r["IN/OUT"] != "OUT" &&
        string(coalesce(r["INDEX"], "")) != "NOT FOUND"
    end
    snap_xlsx = joinpath(Config.OUTPUT_DIR, "Def_$(stamp).xlsx")
    snap_csv  = joinpath(Config.OUTPUT_DIR, "Def_$(stamp).csv")
    write_df_xlsx(snap_xlsx, "Def", snap_df)
    write_df_csv(snap_csv, snap_df)
    println("   ✓ Snapshot $(stamp): $(nrow(snap_df)) novedades válidas.")

    # ── 3. Rechazados ─────────────────────────────────────────────────────────
    rej_df = build_rejected_df(
        proc_state.rejected_ids,
        proc_state.rejected_reasons,
        unified,
    )
    rej_xlsx = joinpath(Config.OUTPUT_DIR, "Rejected_$(stamp).xlsx")
    rej_csv  = joinpath(Config.OUTPUT_DIR, "Rejected_$(stamp).csv")
    write_df_xlsx(rej_xlsx, "Rejected", rej_df)
    write_df_csv(rej_csv, rej_df)
    println("   ✓ Rechazados $(stamp): $(nrow(rej_df)) novedades.")

    return ExportResult(
        Config.DEF_XLSX, Config.DEF_CSV,
        snap_xlsx, snap_csv,
        rej_xlsx, rej_csv,
        nrow(snap_df), nrow(rej_df),
    )
end

end # module Exporter
