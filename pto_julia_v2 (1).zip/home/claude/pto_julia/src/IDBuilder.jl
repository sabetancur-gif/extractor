"""
src/IDBuilder.jl
─────────────────────────────────────────────────────────────────────────────
Construye la columna ID replicando exactamente la fórmula Excel:

  =TEXTJOIN("/",FALSE,
    SOLID, Fecha Salida (serial Excel), Fecha Llegada (serial Excel),
    Novedad, Numero novedad, Dias(Num), Horas(Num),
    Fecha Del Evento (serial Excel), Horas, Tiempo Afectacion, Weekday)

Los valores missing se convierten en "" (TEXTJOIN con ignore_empty=FALSE).
Las fechas se serializan al número Excel (días desde 1899-12-30).
Los números enteros se formatean sin decimales (ej: 5.0 → "5").
─────────────────────────────────────────────────────────────────────────────
"""
module IDBuilder

using DataFrames, Dates
using ..Config

export build_unified

# ─────────────────────────────────────────────────────────────────────────────
# Serialización de fechas al número Excel
# ─────────────────────────────────────────────────────────────────────────────
const EXCEL_EPOCH = Date(1899, 12, 30)

excel_serial(d::Date)::String     = string(Dates.value(d - EXCEL_EPOCH))
excel_serial(::Missing)::String   = ""
excel_serial(::Nothing)::String   = ""
excel_serial(v)::String           = begin
    v isa DateTime && return excel_serial(Date(v))
    ""
end

# ─────────────────────────────────────────────────────────────────────────────
# Formateo de números (sin decimales si es entero)
# ─────────────────────────────────────────────────────────────────────────────
fmt_num(v)::String = begin
    ismissing(v) || isnothing(v) && return ""
    v isa Bool && return ""
    f = Float64(v)
    isnan(f) || isinf(f) && return ""
    isinteger(f) ? string(Int(f)) : string(f)
end

fmt_str(v)::String = (ismissing(v) || isnothing(v)) ? "" : strip(string(v))

# ─────────────────────────────────────────────────────────────────────────────
# Construcción del ID para un registro
# ─────────────────────────────────────────────────────────────────────────────

"""
    build_id(solid, fs, fl, novedad, num_nov,
             dias_num, horas_num, fde, horas, tiempo_afec, weekday) -> String
"""
function build_id(
    solid, fs, fl, novedad, num_nov,
    dias_num, horas_num, fde, horas, tiempo_afec, weekday,
)::String
    parts = [
        fmt_str(solid),
        excel_serial(fs),
        excel_serial(fl),
        fmt_str(novedad),
        fmt_str(num_nov),
        fmt_num(dias_num),
        fmt_num(horas_num),
        excel_serial(fde),
        fmt_num(horas),
        fmt_num(tiempo_afec),
        fmt_num(weekday),
    ]
    return join(parts, "/")
end

# ─────────────────────────────────────────────────────────────────────────────
# API pública
# ─────────────────────────────────────────────────────────────────────────────

"""
    build_unified(unified_raw) -> DataFrame

Recibe la tabla ya unificada de DataLoader y añade:
  • columna ID    (TEXTJOIN formula)
  • columna INDEX (posición 1-based tras ordenar por Fecha_Salida)
"""
function build_unified(unified_raw::DataFrame)::DataFrame
    isempty(unified_raw) && return unified_raw

    df = copy(unified_raw)

    # Helper para obtener columna con fallback
    gc(name, def=missing) = name ∈ names(df) ? df[!, name] : fill(def, nrow(df))

    solid        = gc("SOLID",             "")
    f_salida     = gc("Fecha_Salida",      missing)
    f_llegada    = gc("Fecha_Llegada",     missing)
    novedad      = gc("Novedad",           "")
    num_nov      = gc("Numero_novedad",    "")
    dias_num     = gc("Dias_Numeros",      missing)
    horas_num    = gc("Horas_Numeros",     missing)
    fde          = gc("Fecha_Del_Evento",  missing)
    horas_total  = gc("Horas_total",       missing)
    tiempo_afec  = gc("Tiempo_Afectacion", missing)
    weekday      = gc("Weekday",           missing)

    # Generar IDs
    ids = Vector{String}(undef, nrow(df))
    for i in 1:nrow(df)
        ids[i] = build_id(
            solid[i], f_salida[i], f_llegada[i],
            novedad[i], num_nov[i],
            dias_num[i], horas_num[i],
            fde[i], horas_total[i], tiempo_afec[i], weekday[i],
        )
    end

    df.ID    = ids
    df.INDEX = 1:nrow(df)

    n_unique = length(unique(ids))
    println("   IDs generados: $(nrow(df)) filas  |  $n_unique únicos")

    return df
end

end # module IDBuilder
