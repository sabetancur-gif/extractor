"""
src/Config.jl
─────────────────────────────────────────────────────────────────────────────
Centraliza TODAS las constantes del sistema:
  • Credenciales de conexión  ← EDITAR ANTES DE EJECUTAR
  • Rutas de archivos locales ← EDITAR si cambian de lugar
  • Parámetros de procesamiento
  • Festivos colombianos
  • Columnas y prefijos de novedades
─────────────────────────────────────────────────────────────────────────────
"""
module Config

using Dates

# ╔══════════════════════════════════════════════════════════════════════════╗
# ║          ⚠  SECCIÓN DE CREDENCIALES — EDITAR ANTES DE EJECUTAR  ⚠      ║
# ╚══════════════════════════════════════════════════════════════════════════╝

# ── Azure Synapse (Midasoft DB) ───────────────────────────────────────────────
# Servidor tomado directamente del Power Query
const SYNAPSE_SERVER   = "asasolvodataecosystemdev-ondemand.sql.azuresynapse.net"
const SYNAPSE_DATABASE = "midasoft"
const SYNAPSE_PORT     = 1433

# Autenticación corporativa Azure Active Directory
# Opciones para SYNAPSE_AUTH_MODE:
#   "AAD_PASSWORD"    → usuario + contraseña corporativa (más común)
#   "AAD_INTEGRATED"  → SSO de Windows (si ya está logueado en el dominio)
#   "SQL"             → usuario y contraseña SQL directo
const SYNAPSE_AUTH_MODE = "AAD_PASSWORD"   # ← CAMBIAR si usa otro modo

# !! EDITAR: ponga su correo corporativo y contraseña !!
const SYNAPSE_USER     = "su.correo@employersolutions.com"   # ← CAMBIAR
const SYNAPSE_PASSWORD = "SuContraseñaAqui"                  # ← CAMBIAR

# Driver ODBC para SQL Server
# Windows: "ODBC Driver 18 for SQL Server" (descargar de Microsoft si no tiene)
# Linux:   "ODBC Driver 18 for SQL Server" (ver GUIA.md para instalación)
const ODBC_DRIVER = "ODBC Driver 18 for SQL Server"   # ← CAMBIAR si su versión es diferente

# ── SharePoint (Novedades.xlsx) ───────────────────────────────────────────────
# URL del sitio tomada directamente del Power Query
const SHAREPOINT_SITE = "https://onesourcecorp.sharepoint.com/sites/SolvoGlobal"

# Ruta relativa al archivo dentro de SharePoint
# Ajuste si el archivo está en una subcarpeta diferente
const SHAREPOINT_FILE_PATH = "/sites/SolvoGlobal/Shared Documents/Novedades.xlsx"  # ← VERIFICAR ruta exacta

# Credenciales corporativas para SharePoint (misma cuenta que Synapse)
# !! EDITAR: mismos datos que arriba !!
const SHAREPOINT_USER     = "su.correo@employersolutions.com"   # ← CAMBIAR
const SHAREPOINT_PASSWORD = "SuContraseñaAqui"                  # ← CAMBIAR

# Tenant ID de Azure AD de su organización
# Encuéntrelo en: portal.azure.com → Azure Active Directory → Properties → Tenant ID
const AZURE_TENANT_ID = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"  # ← CAMBIAR

# Client ID (App ID) para autenticación OAuth2 con SharePoint
# Use el Client ID de la aplicación registrada en Azure AD, o el de Office 365
# Para acceso básico puede usar el ID público de SharePoint Online:
const AZURE_CLIENT_ID = "9bc3ab49-b65d-410a-85ad-de819febfddc"  # ID público SharePoint Online

# ── Archivos locales ──────────────────────────────────────────────────────────
# Rutas exactas tal como aparecen en los Power Queries originales
# !! EDITAR: cambie "Santiago.Betancur" por su usuario de Windows si es diferente !!
const ROSTER_FILE = raw"C:\Users\Santiago.Betancur\OneDrive - Employer Solutions\Desktop\PTO\Roster.xlsx"

const TYPES_PTO_FILE = raw"C:\Users\Santiago.Betancur\OneDrive - Employer Solutions\Desktop\PTO\PTO\TYPES OF PTO.xlsx"

# ╔══════════════════════════════════════════════════════════════════════════╗
# ║              PARÁMETROS DEL SISTEMA — puede dejar los defaults          ║
# ╚══════════════════════════════════════════════════════════════════════════╝

# ── Rutas de salida ───────────────────────────────────────────────────────────
const OUTPUT_DIR    = joinpath(@__DIR__, "..", "output")
const DEF_XLSX      = joinpath(OUTPUT_DIR, "Def.xlsx")
const DEF_CSV       = joinpath(OUTPUT_DIR, "Def.csv")
const LOGS_DIR      = joinpath(@__DIR__, "..", "logs")

# ── Filtro de fecha mínima (igual que Power Query: >= 2025-01-01) ─────────────
const FECHA_MINIMA  = Date(2025, 1, 1)

# ── Filtro SOLID (sólo registros que contengan "SOLA") ───────────────────────
const SOLID_FILTER  = "SOLA"

# ── Tamaño de sub-núcleo de procesamiento ────────────────────────────────────
# Cuántos IDs procesa cada sub-núcleo antes de reportar progreso
# Baje a 100 si quiere más granularidad visual; suba a 500 para menos overhead
const SUBCORE_SIZE  = 200

# ── Prefijos de núcleos ───────────────────────────────────────────────────────
const PREFIX_VAC = "VAC"
const PREFIX_INC = "INC"
const PREFIX_AUS = "AUS"

# Jerarquía de prioridad para resolver conflictos: INC > AUS > VAC
const PRIORITY = Dict(PREFIX_INC => 3, PREFIX_AUS => 2, PREFIX_VAC => 1)

# ── Novedades excluidas del procesamiento (del Power Query Nov Forms) ─────────
const EXCLUDED_NOVEDADES = Set([
    "0", "Actualización de Líder", "Actualización de Supervisor",
    "Apercibimiento", "Ascenso", "Asignacion de Cuenta",
    "Ausencia pendiente por reporte", "Cambio de cargo",
    "Cambio de Departamento", "Cambio de horario", "Cambio de modalidad",
    "Cambio de Sede", "Carta de compromiso", "Cierre de cuenta",
    "Demotion", "Despido", "Festivo Americano laborado",
    "Festivo argentino laborado", "Festivo colombiano laborado",
    "Festivo estadounidense laborado", "Festivo no laborado",
    "Horas extra", "Horas extra nocturna", "Horas extras",
    "Lactancia", "No Call/No Show", "Posicion Ganada",
    "Posición Ganada", "Posicion Perdida", "Promoción",
    "Promocion de Lider", "Reemplazo", "Renuncia", "Reporte de Sede",
    "Salida de cuenta - Ingreso a Transición", "Separación de Cargo",
    "Separación de cargo", "Terminación de práctica", "Warning email",
    "Warning escrito", "Warning verbal", "Workation", "Workstoppage",
])

# ── Festivos Colombia 2024 – 2027 ─────────────────────────────────────────────
# Agregue los años siguientes según necesite
const FESTIVOS_COLOMBIA = Set([
    # 2024
    Date(2024,1,1),  Date(2024,1,8),  Date(2024,3,25), Date(2024,3,28),
    Date(2024,3,29), Date(2024,5,1),  Date(2024,5,13), Date(2024,6,3),
    Date(2024,6,10), Date(2024,7,1),  Date(2024,7,20), Date(2024,8,7),
    Date(2024,8,19), Date(2024,10,14),Date(2024,11,4), Date(2024,11,11),
    Date(2024,12,8), Date(2024,12,25),
    # 2025
    Date(2025,1,1),  Date(2025,1,6),  Date(2025,3,24), Date(2025,4,17),
    Date(2025,4,18), Date(2025,5,1),  Date(2025,6,2),  Date(2025,6,23),
    Date(2025,6,30), Date(2025,7,20), Date(2025,8,7),  Date(2025,8,18),
    Date(2025,10,13),Date(2025,11,3), Date(2025,11,17),Date(2025,12,8),
    Date(2025,12,25),
    # 2026
    Date(2026,1,1),  Date(2026,1,12), Date(2026,3,23), Date(2026,4,2),
    Date(2026,4,3),  Date(2026,5,1),  Date(2026,5,18), Date(2026,6,8),
    Date(2026,6,29), Date(2026,7,20), Date(2026,8,7),  Date(2026,8,17),
    Date(2026,10,12),Date(2026,11,2), Date(2026,11,16),Date(2026,12,8),
    Date(2026,12,25),
    # 2027
    Date(2027,1,1),  Date(2027,1,11), Date(2027,3,22), Date(2027,4,1),
    Date(2027,4,2),  Date(2027,5,1),  Date(2027,5,17), Date(2027,6,7),
    Date(2027,6,28), Date(2027,7,20), Date(2027,8,7),  Date(2027,8,16),
    Date(2027,10,18),Date(2027,11,1), Date(2027,11,15),Date(2027,12,8),
    Date(2027,12,25),
])

# ── Columnas del Def ──────────────────────────────────────────────────────────
const DEF_COLUMNS = [
    "INDEX", "ID", "Column1", "LISTO", "SOLID",
    "Fecha Salida", "Fecha Llegada", "Nombre y Apellido",
    "Novedad", "Numero novedad", "Dias (Numeros)", "Horas (Numeros)",
    "Date of PTO", "Horas", "Hours of PTO", "Column2",
    "IN/OUT", "PROCESADA",
]

end # module Config
