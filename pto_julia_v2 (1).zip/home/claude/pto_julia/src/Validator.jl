"""
src/Validator.jl
─────────────────────────────────────────────────────────────────────────────
Implementa todas las reglas de validación del Proceso_2 (Proceso.docx)
para cada tipo de novedad: VAC · INC · AUS.

Devuelve para cada ID:
  valid  → pasa todas las reglas
  out    → rechazada (se guarda la razón)

Pasos en orden:
  1. check_in_out        → Fecha Llegada >= Fecha Salida
  2. check_hours_band    → bandas 8/16/24/32/40 horas
  3. validate_by_type    → reglas específicas VAC / INC / AUS
  4. resolve_conflicts   → Column2 != 1 (mismo SOLID + fecha)
─────────────────────────────────────────────────────────────────────────────
"""
module Validator

using DataFrames, Dates
using ..Config

export validate_group, ValidResult, IDStatus, valid, out

# ─────────────────────────────────────────────────────────────────────────────
# Tipos
# ─────────────────────────────────────────────────────────────────────────────

@enum IDStatus valid=1 out=2

struct ValidResult
    id::String
    status::IDStatus
    reason::String
end

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

sf64(v) = (ismissing(v) || isnothing(v)) ? 0.0 : Float64(v)

prefix3(s::AbstractString) = length(s) >= 3 ? uppercase(s[1:3]) : uppercase(s)

count_festivos(dates) = count(d -> d ∈ Config.FESTIVOS_COLOMBIA, dates)

count_weekends(fs::Date, fl::Date) =
    count(d -> Dates.dayofweek(d) ∈ (6, 7),
          collect(min(fs, fl):Day(1):max(fs, fl)))

# ─────────────────────────────────────────────────────────────────────────────
# Paso 1 — IN > OUT
# ─────────────────────────────────────────────────────────────────────────────

function check_in_out(rows::DataFrame)
    valid_mask = trues(nrow(rows))
    out_results = ValidResult[]

    for (i, r) in enumerate(eachrow(rows))
        fs = get(r, :Fecha_Salida, missing)
        fl = get(r, :Fecha_Llegada, missing)
        (ismissing(fs) || ismissing(fl)) && continue
        if fl < fs
            valid_mask[i] = false
            push!(out_results,
                ValidResult(r.ID, out,
                    "IN>OUT: Fecha Llegada ($(fl)) < Fecha Salida ($(fs))"))
        end
    end
    return rows[valid_mask, :], out_results
end

# ─────────────────────────────────────────────────────────────────────────────
# Paso 2 — Bandas de horas
# ─────────────────────────────────────────────────────────────────────────────

function check_hours_band(rows::DataFrame)
    pass_mask = falses(nrow(rows))

    for (i, r) in enumerate(eachrow(rows))
        horas = sf64(get(r, :Horas_total, missing))
        fs    = get(r, :Fecha_Salida, missing)
        fl    = get(r, :Fecha_Llegada, missing)
        (ismissing(fs) || ismissing(fl)) && continue
        diff = Dates.value(fl - fs)

        if     (horas <= 8.0  && diff == 0); pass_mask[i] = true
        elseif (horas <= 16.0 && diff == 1); pass_mask[i] = true
        elseif (horas <= 24.0 && diff == 2); pass_mask[i] = true
        elseif (horas <= 32.0 && diff == 3); pass_mask[i] = true
        elseif (horas <= 40.0 && diff == 4); pass_mask[i] = true
        end
    end
    # Las que no pasan la banda igualmente continúan al paso 3 (no son rechazadas aquí)
    return rows[pass_mask, :], rows[.!pass_mask, :]
end

# ─────────────────────────────────────────────────────────────────────────────
# Paso 3 — Validación por tipo
# ─────────────────────────────────────────────────────────────────────────────

function validate_vac(rows::DataFrame)::Vector{ValidResult}
    results = ValidResult[]
    isempty(rows) && return results

    for num_nov in unique(rows.Numero_novedad)
        sub = filter(r -> r.Numero_novedad == num_nov, rows)
        isempty(sub) && continue

        horas_total = sf64(get(sub[1, :], :Horas_total, 0.0))
        hours_pto   = sf64(get(sub[1, :], :Tiempo_Afectacion, 0.0))
        fechas = collect(skipmissing(sub.Fecha_Del_Evento))
        fest   = count_festivos(fechas)
        expected = hours_pto * 8.0 + fest * 8.0

        if abs(expected - horas_total) < 0.01
            for r in eachrow(sub)
                push!(results, ValidResult(r.ID, valid, ""))
            end
        else
            reason = "VAC: esperado=$(expected)h (PTO=$(hours_pto)×8 + festivos=$(fest)×8) ≠ real=$(horas_total)h"
            for r in eachrow(sub)
                push!(results, ValidResult(r.ID, out, reason))
            end
        end
    end
    return results
end

function validate_inc(rows::DataFrame)::Vector{ValidResult}
    results = ValidResult[]
    isempty(rows) && return results

    for num_nov in unique(rows.Numero_novedad)
        sub = filter(r -> r.Numero_novedad == num_nov, rows)
        isempty(sub) && continue

        horas_total = sf64(get(sub[1, :], :Horas_total, 0.0))
        hours_pto   = sf64(get(sub[1, :], :Tiempo_Afectacion, 0.0))
        fs = get(sub[1, :], :Fecha_Salida, missing)
        fl = get(sub[1, :], :Fecha_Llegada, missing)
        wends = (ismissing(fs) || ismissing(fl)) ? 0 : count_weekends(fs, fl)
        expected = hours_pto * 8.0 + wends * 16.0

        if abs(expected - horas_total) < 0.01
            for r in eachrow(sub)
                push!(results, ValidResult(r.ID, valid, ""))
            end
        else
            reason = "INC: esperado=$(expected)h (PTO=$(hours_pto)×8 + weekends=$(wends)×16) ≠ real=$(horas_total)h"
            for r in eachrow(sub)
                push!(results, ValidResult(r.ID, out, reason))
            end
        end
    end
    return results
end

function validate_aus(rows::DataFrame)::Vector{ValidResult}
    results = ValidResult[]
    for r in eachrow(rows)
        pto = sf64(get(r, :Tiempo_Afectacion, 0.0))
        if pto <= 8.0
            push!(results, ValidResult(r.ID, valid, ""))
        else
            push!(results, ValidResult(r.ID, out,
                "AUS: Hours_of_PTO=$(pto) > 8h máximo permitido"))
        end
    end
    return results
end

# ─────────────────────────────────────────────────────────────────────────────
# Paso 4 — Resolver conflictos Column2 != 1
# ─────────────────────────────────────────────────────────────────────────────

"""
    resolve_conflicts(passed_ids, unified) -> Vector{ValidResult}

Para IDs que comparten (SOLID + Fecha Del Evento) aplica:
  1. Mismo Novedad         → keep el más reciente (mayor INDEX), OUT al resto
  2. Mismo prefijo num_nov → válidos si suma Hours_of_PTO ≤ 8
  3. Distinto prefijo      → jerarquía INC > AUS > VAC
"""
function resolve_conflicts(passed_ids::Set{String}, unified::DataFrame)::Vector{ValidResult}
    results = ValidResult[]
    processed = Set{String}()

    id_to_i = Dict(row.ID => i for (i,row) in enumerate(eachrow(unified)))

    for id in passed_ids
        id ∈ processed && continue
        i = get(id_to_i, id, nothing)
        isnothing(i) && continue

        r = unified[i, :]
        solid = string(coalesce(r.SOLID, ""))
        fde   = r.Fecha_Del_Evento

        # Buscar todos los IDs en unified con mismo SOLID + Fecha Del Evento
        conflict_rows = filter(
            u -> string(coalesce(u.SOLID, "")) == solid &&
                 u.Fecha_Del_Evento == fde,
            unified
        )
        isempty(conflict_rows) && continue

        # Solo considerar los que están en passed_ids
        conflict_rows = filter(cr -> cr.ID ∈ passed_ids, conflict_rows)
        isempty(conflict_rows) && continue

        for cr in eachrow(conflict_rows)
            push!(processed, cr.ID)
        end

        n = nrow(conflict_rows)
        if n == 1
            push!(results, ValidResult(conflict_rows[1, :ID], valid, ""))
            continue
        end

        novedades = unique(conflict_rows.Novedad)
        num_novs  = conflict_rows.Numero_novedad
        prefixes  = prefix3.(string.(num_novs))

        if length(unique(novedades)) == 1
            # Misma novedad → conservar mayor INDEX (más reciente), OUT resto
            indices = [
                let v = get(conflict_rows[j,:], :INDEX, 0)
                    isnothing(tryparse(Int, string(v))) ? 0 : parse(Int, string(v))
                end
                for j in 1:n
            ]
            max_idx = argmax(indices)
            for (j, cr) in enumerate(eachrow(conflict_rows))
                if j == max_idx
                    push!(results, ValidResult(cr.ID, valid, ""))
                else
                    push!(results, ValidResult(cr.ID, out,
                        "Conflicto: novedad duplicada SOLID=$(solid) fecha=$(fde), se conserva el más reciente"))
                end
            end

        elseif length(unique(prefixes)) == 1
            # Mismo prefijo → válidos si suma ≤ 8h
            total_pto = sum(sf64(get(conflict_rows[j,:], :Tiempo_Afectacion, 0.0))
                            for j in 1:n)
            if total_pto <= 8.0
                for cr in eachrow(conflict_rows)
                    push!(results, ValidResult(cr.ID, valid, ""))
                end
            else
                # Greedy: ir tomando las de mayor Hours_of_PTO hasta llenar 8h
                sorted_idx = sortperm(
                    [sf64(get(conflict_rows[j,:], :Tiempo_Afectacion, 0.0)) for j in 1:n];
                    rev=true)
                acc = 0.0
                keep_set = Set{String}()
                for j in sorted_idx
                    pto = sf64(get(conflict_rows[j,:], :Tiempo_Afectacion, 0.0))
                    if acc + pto <= 8.0
                        push!(keep_set, conflict_rows[j, :ID])
                        acc += pto
                    end
                end
                for cr in eachrow(conflict_rows)
                    if cr.ID ∈ keep_set
                        push!(results, ValidResult(cr.ID, valid, ""))
                    else
                        push!(results, ValidResult(cr.ID, out,
                            "Conflicto mismo prefijo: suma Hours_of_PTO excede 8h para SOLID=$(solid) fecha=$(fde)"))
                    end
                end
            end

        else
            # Distintos prefijos → jerarquía INC > AUS > VAC
            best_prio = maximum(get(Config.PRIORITY, p, 0) for p in prefixes)
            for (j, cr) in enumerate(eachrow(conflict_rows))
                p    = prefix3(string(num_novs[j]))
                prio = get(Config.PRIORITY, p, 0)
                if prio == best_prio
                    push!(results, ValidResult(cr.ID, valid, ""))
                else
                    push!(results, ValidResult(cr.ID, out,
                        "Conflicto jerarquía: prefijo $(p) pierde ante prioridad $(best_prio) — SOLID=$(solid) fecha=$(fde)"))
                end
            end
        end
    end
    return results
end

# ─────────────────────────────────────────────────────────────────────────────
# API pública
# ─────────────────────────────────────────────────────────────────────────────

"""
    validate_group(ids, unified, nucleus_type) -> Vector{ValidResult}

Valida un lote de IDs según su tipo de núcleo (:VAC, :INC, :AUS).
"""
function validate_group(
    ids::Vector{String},
    unified::DataFrame,
    nucleus_type::Symbol,
)::Vector{ValidResult}

    isempty(ids) && return ValidResult[]

    id_set = Set(ids)
    rows   = filter(r -> r.ID ∈ id_set, unified)

    if isempty(rows)
        return [ValidResult(id, out, "ID no encontrado en tabla unificada") for id in ids]
    end

    all_results = ValidResult[]
    remaining   = copy(rows)

    # ── Paso 1: IN > OUT ─────────────────────────────────────────────────────
    remaining, out1 = check_in_out(remaining)
    append!(all_results, out1)

    isempty(remaining) && return _fill_missing(all_results, ids)

    # ── Paso 2: Bandas de horas (las que no pasan continúan igualmente) ───────
    band_ok, band_skip = check_hours_band(remaining)
    # Unir ambas para el paso de tipo (las bandas son informativas, no rechazan)
    to_type_check = vcat(band_ok, band_skip; cols=:union)

    # ── Paso 3: Validación por tipo ───────────────────────────────────────────
    type_results = if nucleus_type == :VAC
        validate_vac(to_type_check)
    elseif nucleus_type == :INC
        validate_inc(to_type_check)
    else
        validate_aus(to_type_check)
    end
    append!(all_results, type_results)

    # IDs que pasaron el paso 3
    out_ids_3  = Set(vr.id for vr in type_results if vr.status == out)
    passed_ids = Set(vr.id for vr in type_results if vr.status == valid)

    # ── Paso 4: Conflictos ────────────────────────────────────────────────────
    if !isempty(passed_ids)
        conflict_results = resolve_conflicts(passed_ids, unified)
        # Reemplazar los valid del paso 3 con los resultados de conflicto
        # (algunos valid pueden volverse out)
        conflict_id_set = Set(vr.id for vr in conflict_results)
        # Quitar de all_results los que ahora tienen resultado de conflicto
        filter!(vr -> vr.id ∉ conflict_id_set, all_results)
        append!(all_results, conflict_results)
    end

    return _fill_missing(all_results, ids)
end

# Asegurar que todos los IDs de entrada tengan un resultado
function _fill_missing(results::Vector{ValidResult}, ids::Vector{String})::Vector{ValidResult}
    covered = Set(vr.id for vr in results)
    for id in ids
        id ∉ covered && push!(results, ValidResult(id, valid, ""))
    end
    return results
end

end # module Validator
