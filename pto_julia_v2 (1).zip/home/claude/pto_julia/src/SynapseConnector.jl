"""
src/SynapseConnector.jl
─────────────────────────────────────────────────────────────────────────────
Conecta directamente a Azure Synapse (SQL Server on-demand) vía ODBC
y descarga las tablas: ausentismos, incapacidades, vacaciones.

Replica exactamente la lógica de los Power Queries:
  • ausentismos    → dbo.ausentismos
  • incapacidades  → dbo.incapacidades
  • vacaciones     → dbo.vacaciones

Devuelve los DataFrames ya normalizados, listos para DataLoader.
─────────────────────────────────────────────────────────────────────────────
"""
module SynapseConnector

using DataFrames, ODBC, Dates, Logging, Printf
using ..Config

export fetch_all_from_synapse

# ─────────────────────────────────────────────────────────────────────────────
# String de conexión ODBC
# ─────────────────────────────────────────────────────────────────────────────

"""
    build_connection_string() -> String

Construye el connection string según el modo de autenticación configurado.
"""
function build_connection_string()::String
    base = "Driver={$(Config.ODBC_DRIVER)};" *
           "Server=$(Config.SYNAPSE_SERVER),$(Config.SYNAPSE_PORT);" *
           "Database=$(Config.SYNAPSE_DATABASE);" *
           "Encrypt=yes;TrustServerCertificate=no;Connection Timeout=120;"

    if Config.SYNAPSE_AUTH_MODE == "AAD_PASSWORD"
        # Azure Active Directory con usuario + contraseña corporativa
        return base *
               "Authentication=ActiveDirectoryPassword;" *
               "UID=$(Config.SYNAPSE_USER);" *
               "PWD=$(Config.SYNAPSE_PASSWORD);"

    elseif Config.SYNAPSE_AUTH_MODE == "AAD_INTEGRATED"
        # SSO de Windows (no requiere usuario/contraseña explícitos)
        return base * "Authentication=ActiveDirectoryIntegrated;"

    elseif Config.SYNAPSE_AUTH_MODE == "SQL"
        # Autenticación SQL clásica
        return base *
               "UID=$(Config.SYNAPSE_USER);" *
               "PWD=$(Config.SYNAPSE_PASSWORD);"
    else
        error("SYNAPSE_AUTH_MODE desconocido: $(Config.SYNAPSE_AUTH_MODE). " *
              "Use 'AAD_PASSWORD', 'AAD_INTEGRATED' o 'SQL'.")
    end
end

# ─────────────────────────────────────────────────────────────────────────────
# Helpers de conversión
# ─────────────────────────────────────────────────────────────────────────────

safe_str(v) = ismissing(v) ? "" : strip(string(v))
safe_date(v) = begin
    ismissing(v) && return missing
    v isa Date && return v
    v isa DateTime && return Date(v)
    tryparse(Date, string(v))
end
safe_num(v) = begin
    ismissing(v) && return missing
    v isa Number && return Float64(v)
    r = tryparse(Float64, string(v))
    isnothing(r) ? missing : r
end

# ─────────────────────────────────────────────────────────────────────────────
# Queries SQL — replica la lógica de cada Power Query
# ─────────────────────────────────────────────────────────────────────────────

# Replica: ausentismos Power Query
# Selecciona campos, calcula Fecha Llegada, construye Numero novedad
const SQL_AUSENTISMOS = """
SELECT
    UPPER(CAST(Empleado AS NVARCHAR(50)))    AS SOLID,
    CAST(Finir  AS DATE)                     AS Fecha_Salida,
    CAST(ISNULL(Ffinr, Finir) AS DATE)       AS Fecha_Llegada,
    LTRIM(RTRIM(Nombre)) + ' ' +
    LTRIM(RTRIM(Apellido))                   AS Nombre_y_Apellido,
    LTRIM(RTRIM(DescAusencia))               AS Novedad,
    'AUS-' + LTRIM(RTRIM(CAST(NAusencia AS NVARCHAR(20)))) AS Numero_novedad,
    NULL                                     AS Dias_Numeros,
    CAST(Horas AS FLOAT)                     AS Horas_Numeros
FROM dbo.ausentismos
WHERE Finir IS NOT NULL
  AND UPPER(CAST(Empleado AS NVARCHAR(50))) LIKE '%SOLA%'
  AND CAST(Finir AS DATE) >= '2025-01-01'
ORDER BY Fecha_Salida ASC
"""

# Replica: incapacidades Power Query (incluye los ReplaceValue)
const SQL_INCAPACIDADES = """
SELECT
    UPPER(CAST(Empleado AS NVARCHAR(50)))    AS SOLID,
    CAST(Finir  AS DATE)                     AS Fecha_Salida,
    CAST(ISNULL(Ffinr, Finir) AS DATE)       AS Fecha_Llegada,
    LTRIM(RTRIM(Nombre)) + ' ' +
    LTRIM(RTRIM(Apellido))                   AS Nombre_y_Apellido,
    CASE LTRIM(RTRIM(DescInc))
        WHEN 'INC ENFERMEDAD GENERAL INTEGRA' THEN 'INC ENFERMEDAD GENERAL'
        WHEN 'INCAPACIDAD MAYOR 90 DIAS'       THEN 'INC ENFERMEDAD GENERAL'
        WHEN 'INCAPACIDAD MAYOR A 180 DIAS'    THEN 'INC ENFERMEDAD GENERAL'
        WHEN 'INCAPACIDAD MAYOR A 542 DIAS'    THEN 'MATERNIDAD'
        ELSE LTRIM(RTRIM(DescInc))
    END                                      AS Novedad,
    'INC-' + LTRIM(RTRIM(CAST(Cnsine AS NVARCHAR(20)))) AS Numero_novedad,
    CAST(DIncapc AS BIGINT)                  AS Dias_Numeros,
    NULL                                     AS Horas_Numeros
FROM dbo.incapacidades
WHERE Finir IS NOT NULL
  AND UPPER(CAST(Empleado AS NVARCHAR(50))) LIKE '%SOLA%'
  AND CAST(Finir AS DATE) >= '2025-01-01'
ORDER BY Fecha_Salida ASC
"""

# Replica: vacaciones Power Query
# El join con SOLID & NAME se hace en Julia después de bajar ausentismos
const SQL_VACACIONES = """
SELECT
    UPPER(CAST(Empleado AS NVARCHAR(50)))    AS SOLID,
    CAST(Empleado AS NVARCHAR(50))           AS Empleado_Raw,
    CAST(FSalR AS DATE)                      AS Fecha_Salida,
    CAST(ISNULL(FRegR, FSalR) AS DATE)       AS Fecha_Llegada,
    LTRIM(RTRIM(Apellido))                   AS Apellido,
    'VACACIONES'                             AS Novedad,
    'VAC-' + LTRIM(RTRIM(CAST(Cnsvac AS NVARCHAR(20)))) AS Numero_novedad,
    CAST(DiasVac AS BIGINT)                  AS Dias_Numeros,
    NULL                                     AS Horas_Numeros
FROM dbo.vacaciones
WHERE FSalR IS NOT NULL
  AND UPPER(CAST(Empleado AS NVARCHAR(50))) LIKE '%SOLA%'
  AND CAST(FSalR AS DATE) >= '2025-01-01'
ORDER BY Fecha_Salida ASC
"""

# Para construir el mapa SOLID → Nombre y Apellido (usado en vacaciones)
const SQL_SOLID_NAME = """
SELECT DISTINCT
    CAST(Empleado AS NVARCHAR(50))           AS Empleado,
    LTRIM(RTRIM(Nombre)) + ' ' +
    LTRIM(RTRIM(Apellido))                   AS Nombre_y_Apellido
FROM (
    SELECT Empleado, Nombre, Apellido FROM dbo.ausentismos
    UNION ALL
    SELECT Empleado, Nombre, Apellido FROM dbo.incapacidades
) t
WHERE Empleado IS NOT NULL
"""

# ─────────────────────────────────────────────────────────────────────────────
# Ejecución de queries
# ─────────────────────────────────────────────────────────────────────────────

"""
    run_query(conn, sql, label) -> DataFrame | nothing

Ejecuta una query SQL y devuelve un DataFrame.
"""
function run_query(conn, sql::String, label::String)::Union{DataFrame, Nothing}
    try
        df = DBInterface.execute(conn, sql) |> DataFrame
        println("     ✓ $label: $(nrow(df)) filas")
        return df
    catch e
        @error "Error ejecutando query '$label': $e"
        return nothing
    end
end

# ─────────────────────────────────────────────────────────────────────────────
# API pública
# ─────────────────────────────────────────────────────────────────────────────

"""
    fetch_all_from_synapse() -> NamedTuple(aus, inc, vac, solid_name_map)

Abre una conexión ODBC a Azure Synapse, baja las tres tablas y
el mapa SOLID→Nombre, luego cierra la conexión.
Retorna nothing si la conexión falla.
"""
function fetch_all_from_synapse()::Union{NamedTuple, Nothing}
    println("   Conectando a Azure Synapse...")
    println("   Servidor: $(Config.SYNAPSE_SERVER)")
    println("   Base de datos: $(Config.SYNAPSE_DATABASE)")
    println("   Modo de auth: $(Config.SYNAPSE_AUTH_MODE)")

    conn_str = build_connection_string()
    conn = try
        ODBC.connect(conn_str)
    catch e
        @error """
        No se pudo conectar a Azure Synapse.
        Error: $e

        Verifique en src/Config.jl:
          • SYNAPSE_USER / SYNAPSE_PASSWORD  (sus credenciales corporativas)
          • SYNAPSE_AUTH_MODE               (AAD_PASSWORD / AAD_INTEGRATED / SQL)
          • ODBC_DRIVER                     (nombre exacto del driver instalado)
        """
        return nothing
    end

    println("   ✓ Conexión establecida. Descargando tablas...\n")

    aus_df        = run_query(conn, SQL_AUSENTISMOS,   "ausentismos")
    inc_df        = run_query(conn, SQL_INCAPACIDADES, "incapacidades")
    vac_df        = run_query(conn, SQL_VACACIONES,    "vacaciones")
    solid_name_df = run_query(conn, SQL_SOLID_NAME,    "SOLID & NAME map")

    DBInterface.close!(conn)
    println("\n   Conexión cerrada.")

    # Construir mapa Empleado → Nombre_y_Apellido para vacaciones
    solid_name_map = Dict{String,String}()
    if !isnothing(solid_name_df)
        for r in eachrow(solid_name_df)
            k = safe_str(r.Empleado)
            v = safe_str(r.Nombre_y_Apellido)
            !isempty(k) && !isempty(v) && (solid_name_map[k] = v)
        end
    end

    return (
        aus          = aus_df,
        inc          = inc_df,
        vac          = vac_df,
        solid_name_map = solid_name_map,
    )
end

end # module SynapseConnector
