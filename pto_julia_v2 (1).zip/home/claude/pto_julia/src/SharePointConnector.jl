"""
src/SharePointConnector.jl
─────────────────────────────────────────────────────────────────────────────
Descarga el archivo Novedades.xlsx desde SharePoint Online usando
Microsoft Graph API con autenticación OAuth2 (cuenta corporativa).

Flujo:
  1. Obtiene token OAuth2 (Resource Owner Password Credentials)
  2. Busca el archivo Novedades.xlsx en el sitio SharePoint
  3. Lo descarga como bytes
  4. Lo parsea con XLSX.jl en memoria (sin escribir a disco)
  5. Devuelve la hoja Table1 como DataFrame

Replica la fuente: Nov Forms (Power Query paso 8 en nov_midasoft_forms_db.txt)
─────────────────────────────────────────────────────────────────────────────
"""
module SharePointConnector

using HTTP, JSON3, XLSX, DataFrames, Dates, Base64, Logging
using ..Config

export fetch_novedades_from_sharepoint

# ─────────────────────────────────────────────────────────────────────────────
# Constantes Graph API
# ─────────────────────────────────────────────────────────────────────────────
const GRAPH_BASE    = "https://graph.microsoft.com/v1.0"
const TOKEN_URL     = "https://login.microsoftonline.com/$(Config.AZURE_TENANT_ID)/oauth2/v2.0/token"
const GRAPH_SCOPE   = "https://graph.microsoft.com/.default"

# ─────────────────────────────────────────────────────────────────────────────
# Autenticación OAuth2 — Resource Owner Password Credentials (ROPC)
# ─────────────────────────────────────────────────────────────────────────────

"""
    get_access_token() -> String

Obtiene un token de acceso usando las credenciales corporativas.
Usa el flujo ROPC (usuario + contraseña) que es compatible con
cuentas organizacionales sin MFA forzado en todas las apps.
"""
function get_access_token()::String
    println("   Obteniendo token OAuth2 para SharePoint...")

    body = HTTP.Form(Dict(
        "grant_type"    => "password",
        "client_id"     => Config.AZURE_CLIENT_ID,
        "username"      => Config.SHAREPOINT_USER,
        "password"      => Config.SHAREPOINT_PASSWORD,
        "scope"         => "https://graph.microsoft.com/Files.Read.All " *
                           "https://graph.microsoft.com/Sites.Read.All offline_access",
    ))

    resp = try
        HTTP.post(TOKEN_URL; body=body,
                  headers=["Content-Type" => "application/x-www-form-urlencoded"])
    catch e
        error("""
        Error obteniendo token OAuth2: $e

        Verifique en src/Config.jl:
          • SHAREPOINT_USER / SHAREPOINT_PASSWORD  (credenciales corporativas)
          • AZURE_TENANT_ID                        (ID del tenant de su organización)
          • AZURE_CLIENT_ID                        (ID de aplicación Azure AD)
        """)
    end

    data = JSON3.read(String(resp.body))

    if haskey(data, :error)
        error("""
        Error de autenticación SharePoint:
        Código:   $(get(data, :error, ""))
        Mensaje:  $(get(data, :error_description, ""))

        Si su organización tiene MFA obligatorio en todas las apps,
        necesita registrar una app en Azure AD con permisos delegados
        y usar el flujo Device Code o Authorization Code.
        Vea la sección "MFA" en GUIA.md para el procedimiento alternativo.
        """)
    end

    token = string(data.access_token)
    println("   ✓ Token obtenido correctamente.")
    return token
end

# ─────────────────────────────────────────────────────────────────────────────
# Localizar el sitio SharePoint
# ─────────────────────────────────────────────────────────────────────────────

"""
    get_site_id(token) -> String

Obtiene el site_id de SharePoint a partir de la URL del sitio.
"""
function get_site_id(token::String)::String
    # Extraer host y path del sitio
    # Config.SHAREPOINT_SITE = "https://onesourcecorp.sharepoint.com/sites/SolvoGlobal"
    site_url = Config.SHAREPOINT_SITE
    host = replace(split(site_url, "/sites/")[1], "https://" => "")
    site_path = "/sites/" * split(site_url, "/sites/")[2]

    url = "$GRAPH_BASE/sites/$host:$site_path"
    resp = HTTP.get(url;
        headers=["Authorization" => "Bearer $token",
                 "Content-Type"  => "application/json"])

    data = JSON3.read(String(resp.body))
    site_id = string(data.id)
    println("   ✓ Site ID obtenido: $site_id")
    return site_id
end

# ─────────────────────────────────────────────────────────────────────────────
# Buscar y descargar el archivo Novedades.xlsx
# ─────────────────────────────────────────────────────────────────────────────

"""
    find_and_download_novedades(token, site_id) -> Vector{UInt8}

Busca Novedades.xlsx en el sitio y lo descarga como bytes.
"""
function find_and_download_novedades(token::String, site_id::String)::Vector{UInt8}
    println("   Buscando Novedades.xlsx en SharePoint...")

    # Intentar búsqueda por nombre en el drive del sitio
    search_url = "$GRAPH_BASE/sites/$site_id/drive/root/search(q='Novedades.xlsx')"
    resp = HTTP.get(search_url;
        headers=["Authorization" => "Bearer $token"])
    data = JSON3.read(String(resp.body))

    items = get(data, :value, [])
    if isempty(items)
        error("""
        No se encontró Novedades.xlsx en el sitio SharePoint.
        Verifique que el archivo existe en:
        $(Config.SHAREPOINT_SITE)

        Si el archivo está en una carpeta específica, ajuste
        SHAREPOINT_FILE_PATH en src/Config.jl.
        """)
    end

    # Tomar el primero que coincida exactamente
    file_item = nothing
    for item in items
        name = string(get(item, :name, ""))
        if lowercase(name) == "novedades.xlsx"
            file_item = item
            break
        end
    end
    isnothing(file_item) && (file_item = first(items))

    file_name = string(get(file_item, :name, "Novedades.xlsx"))
    println("   ✓ Archivo encontrado: $file_name")

    # Obtener URL de descarga
    item_id = string(file_item.id)
    dl_url_resp = HTTP.get(
        "$GRAPH_BASE/sites/$site_id/drive/items/$item_id";
        headers=["Authorization" => "Bearer $token"])
    item_data = JSON3.read(String(dl_url_resp.body))

    download_url = string(get(item_data, Symbol("@microsoft.graph.downloadUrl"), ""))
    if isempty(download_url)
        # Alternativa: usar el endpoint de contenido
        download_url = "$GRAPH_BASE/sites/$site_id/drive/items/$item_id/content"
    end

    println("   Descargando archivo...")
    dl_resp = HTTP.get(download_url;
        headers=["Authorization" => "Bearer $token"],
        redirect=true)

    bytes = dl_resp.body
    println("   ✓ Descarga completa: $(round(length(bytes)/1024, digits=1)) KB")
    return bytes
end

# ─────────────────────────────────────────────────────────────────────────────
# Parsear el Excel en memoria
# ─────────────────────────────────────────────────────────────────────────────

"""
    parse_novedades_xlsx(bytes) -> DataFrame

Parsea el archivo XLSX desde bytes en memoria y devuelve
la hoja Table1 como DataFrame con las columnas del Power Query Nov Forms.
"""
function parse_novedades_xlsx(bytes::Vector{UInt8})::DataFrame
    println("   Parseando Novedades.xlsx en memoria...")

    # Escribir temporalmente a un archivo temp para que XLSX.jl pueda leerlo
    tmp = tempname() * ".xlsx"
    try
        write(tmp, bytes)
        xf = XLSX.readxlsx(tmp)
        sheet_names = XLSX.sheetnames(xf)
        println("   Hojas disponibles: $(join(sheet_names, ", "))")

        # Buscar la hoja correcta: "Table1" o primera hoja con datos
        target_sheet = nothing
        for sn in sheet_names
            if lowercase(sn) == "table1" || sn == "Table1"
                target_sheet = sn
                break
            end
        end
        isnothing(target_sheet) && (target_sheet = first(sheet_names))

        df = DataFrame(XLSX.eachtablerow(xf[target_sheet]))
        println("   ✓ Hoja '$target_sheet': $(nrow(df)) filas, $(ncol(df)) columnas")
        return df
    finally
        isfile(tmp) && rm(tmp; force=true)
    end
end

# ─────────────────────────────────────────────────────────────────────────────
# Limpieza y normalización del DataFrame de Forms
# (replica los Replaced Value del Power Query Nov Forms)
# ─────────────────────────────────────────────────────────────────────────────

const DIAS_REPLACEMENTS = Dict(
    "indefinido"  => "0", "Indefinido" => "0",
    "3/27/2023-3/28/2023" => "2", "5 días habiles" => "5",
    "13 días" => "13", "14 días " => "14",
    "18 semanas (licencia de maternidad)" => "90",
    "5 días habíles a partir de la ocurrencia del fallecimietno del familiar " => "5",
    "72hs (Viernes 15/03, Sabado 16/03, Domingo 17/03)" => "1",
    "24 horas" => "1", "48h" => "2",
    "5 DIAS" => "5", "15 DIAS" => "15",
    "18 (totalidad de Agosto)" => "18", "90 dias" => "90",
    "10 según la incapacidad, 9 según las fechas reales. " => "9",
    "10 según la incapacidad, 9 días contando las fechas " => "9",
    "30/04/2024" => "1", "2/01/2023" => "1",
    "21 dias de corrido o 15 dias habiles" => "15",
    "4/30/2024" => "0",
)

const HORAS_REPLACEMENTS = Dict(
    "2 h" => "2", "1h" => "1", "2h" => "2", "3h" => "3",
    "2 0.25" => "2.25", "4 0.25" => "4.25",
    "1- 0.16" => "1.16", "1 DIA" => "8",
    "2H" => "2", "2 h " => "2",
)

function clean_num(val, repls::Dict)::Union{Float64, Missing}
    s = ismissing(val) ? "" : strip(string(val))
    isempty(s) && return missing
    s2 = get(repls, s, s)
    r = tryparse(Float64, s2)
    isnothing(r) ? 0.0 : r
end

safe_date(v) = begin
    ismissing(v) && return missing
    v isa Date && return v
    v isa DateTime && return Date(v)
    s = strip(string(v))
    isempty(s) && return missing
    tryparse(Date, s)
end

"""
    normalize_forms_df(df) -> DataFrame

Aplica todos los filtros y limpiezas del Power Query Nov Forms:
  • Excluir novedades irrelevantes
  • Excluir "vacaciones en dinero = Si"
  • Filtrar SOLID que contenga SOLA
  • Excluir filas con Fecha nula
  • Limpiar campos Dias/Horas con texto libre
  • Calcular Fecha Final AD (null → misma fecha inicio)
"""
function normalize_forms_df(df::DataFrame)::DataFrame
    # Estandarizar nombres de columnas (pueden variar según el Excel)
    rename_map = Dict(
        "Fecha (Real/Inicial)" => "Fecha_Salida",
        "Fecha Final"          => "Fecha_Final",
        "Dias (Numeros)"       => "Dias_Numeros",
        "Horas (Numeros)"      => "Horas_Numeros",
        "Nombre y Apellido"    => "Nombre_y_Apellido",
        "Numero novedad"       => "Numero_novedad",
        "El colaborador tomara vacaciones en dinero?" => "Vac_Dinero",
    )
    for (old, new) in rename_map
        old ∈ names(df) && rename!(df, old => new)
    end

    # Coerciones de tipo
    "SOLID"         ∈ names(df) && (df.SOLID = uppercase.(strip.(string.(coalesce.(df.SOLID, "")))))
    "Fecha_Salida"  ∈ names(df) && (df.Fecha_Salida  = safe_date.(df.Fecha_Salida))
    "Fecha_Final"   ∈ names(df) && (df.Fecha_Final   = safe_date.(df.Fecha_Final))
    "Novedad"       ∈ names(df) && (df.Novedad = string.(coalesce.(df.Novedad, "")))
    "Nombre_y_Apellido" ∈ names(df) &&
        (df.Nombre_y_Apellido = strip.(string.(coalesce.(df.Nombre_y_Apellido, ""))))

    # Limpiar Dias/Horas con texto libre
    if "Dias_Numeros" ∈ names(df)
        df.Dias_Numeros = [clean_num(v, DIAS_REPLACEMENTS) for v in df.Dias_Numeros]
    end
    if "Horas_Numeros" ∈ names(df)
        df.Horas_Numeros = [clean_num(v, HORAS_REPLACEMENTS) for v in df.Horas_Numeros]
    end

    # Limpiar comillas de SOLID
    "SOLID" ∈ names(df) && (df.SOLID = replace.(df.SOLID, "\"" => ""))

    # Filtros (replica los Table.SelectRows del Power Query)
    filter!(r -> !ismissing(r.Fecha_Salida), df)
    "Novedad" ∈ names(df) &&
        filter!(r -> r.Novedad ∉ Config.EXCLUDED_NOVEDADES, df)
    filter!(r -> occursin(Config.SOLID_FILTER, r.SOLID), df)
    "Vac_Dinero" ∈ names(df) &&
        filter!(r -> ismissing(r.Vac_Dinero) || string(r.Vac_Dinero) != "Si", df)
    filter!(r -> !occursin("Prueba", string(coalesce(
        get(r, :Nombre_y_Apellido, ""), ""))), df)

    # Fecha Final AD: si Fecha_Final es null → usar Fecha_Salida
    if "Fecha_Final" ∈ names(df)
        df.Fecha_Llegada = [
            ismissing(r.Fecha_Final) ? r.Fecha_Salida : r.Fecha_Final
            for r in eachrow(df)
        ]
    elseif "Fecha_Salida" ∈ names(df)
        df.Fecha_Llegada = df.Fecha_Salida
    end

    # Filtro fecha mínima
    filter!(r -> !ismissing(r.Fecha_Salida) &&
                 r.Fecha_Salida >= Config.FECHA_MINIMA, df)

    println("   Forms normalizado: $(nrow(df)) filas válidas.")
    return df
end

# ─────────────────────────────────────────────────────────────────────────────
# API pública
# ─────────────────────────────────────────────────────────────────────────────

"""
    fetch_novedades_from_sharepoint() -> DataFrame | nothing

Descarga y normaliza Novedades.xlsx desde SharePoint.
Retorna nothing si hay error de conexión.
"""
function fetch_novedades_from_sharepoint()::Union{DataFrame, Nothing}
    println("   Conectando a SharePoint Online...")
    println("   Sitio: $(Config.SHAREPOINT_SITE)")

    token = try
        get_access_token()
    catch e
        @error "Error de autenticación SharePoint: $e"
        return nothing
    end

    site_id = try
        get_site_id(token)
    catch e
        @error "Error obteniendo Site ID: $e"
        return nothing
    end

    bytes = try
        find_and_download_novedades(token, site_id)
    catch e
        @error "Error descargando Novedades.xlsx: $e"
        return nothing
    end

    df = try
        parse_novedades_xlsx(bytes)
    catch e
        @error "Error parseando Novedades.xlsx: $e"
        return nothing
    end

    return normalize_forms_df(df)
end

end # module SharePointConnector
