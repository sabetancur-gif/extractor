"""
src/LocalFilesConnector.jl
─────────────────────────────────────────────────────────────────────────────
Carga los archivos Excel locales:
  • Roster.xlsx          → mapa SOL ID → PRISM ID
  • TYPES OF PTO.xlsx    → mapa Tipo de novedad → Type of PTO

Rutas definidas en Config.jl (corresponden a las del Power Query original).
─────────────────────────────────────────────────────────────────────────────
"""
module LocalFilesConnector

using DataFrames, XLSX, Logging
using ..Config

export load_roster, load_types_of_pto

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
safe_str(v) = ismissing(v) ? "" : strip(string(v))

function read_first_sheet(path::String, label::String)::Union{DataFrame, Nothing}
    !isfile(path) && (@warn "Archivo no encontrado: $path\n  → $label no estará disponible."; return nothing)
    try
        xf = XLSX.readxlsx(path)
        sn = XLSX.sheetnames(xf)
        df = DataFrame(XLSX.eachtablerow(xf[first(sn)]))
        println("   ✓ $label cargado: $(nrow(df)) filas desde '$(basename(path))'")
        return df
    catch e
        @warn "Error leyendo $label ($path): $e"
        return nothing
    end
end

# ─────────────────────────────────────────────────────────────────────────────
# API pública
# ─────────────────────────────────────────────────────────────────────────────

"""
    load_roster() -> DataFrame | nothing

Carga Roster.xlsx y devuelve las columnas SOLID (SOL ID) y PRISM_ID.
Replica el Power Query 'Roster' del archivo nov_midasoft_forms.txt.
"""
function load_roster()::Union{DataFrame, Nothing}
    df = read_first_sheet(Config.ROSTER_FILE, "Roster")
    isnothing(df) && return nothing

    # Renombrar según el Power Query
    "SOL ID"   ∈ names(df) && rename!(df, "SOL ID"   => "SOLID")
    "PRISM ID" ∈ names(df) && rename!(df, "PRISM ID" => "PRISM_ID")

    # Seleccionar solo las columnas necesarias
    cols = intersect(["SOLID", "PRISM_ID"], names(df))
    isempty(cols) && (@warn "Roster no tiene columnas SOLID/PRISM_ID esperadas."; return nothing)

    df = df[!, cols]
    df.SOLID = uppercase.(safe_str.(df.SOLID))

    # Eliminar duplicados (el Power Query hace Removed Other Columns solo con estas dos)
    unique!(df, :SOLID)

    println("   Roster: $(nrow(df)) empleados únicos.")
    return df
end

"""
    load_types_of_pto() -> DataFrame | nothing

Carga TYPES OF PTO.xlsx y devuelve las columnas
  Novedad (Tipo de novedad) y Type_of_PTO.
Replica el Power Query 'Types_of_PTO'.
"""
function load_types_of_pto()::Union{DataFrame, Nothing}
    df = read_first_sheet(Config.TYPES_PTO_FILE, "Types of PTO")
    isnothing(df) && return nothing

    # Renombrar
    "Tipo de novedad" ∈ names(df) && rename!(df, "Tipo de novedad" => "Novedad")
    "Type of PTO"     ∈ names(df) && rename!(df, "Type of PTO"     => "Type_of_PTO")

    cols = intersect(["Novedad", "Type_of_PTO"], names(df))
    isempty(cols) && (@warn "Types of PTO no tiene columnas esperadas."; return nothing)

    df = df[!, cols]
    println("   Types of PTO: $(nrow(df)) tipos cargados.")
    return df
end

end # module LocalFilesConnector
