"""
src/Panel.jl
─────────────────────────────────────────────────────────────────────────────
Panel de terminal profesional con render dinámico ANSI.

Layout:
  ╔══════════════════════════════════════════════════════════════════════╗
  ║  PROCESAMIENTO DE NOVEDADES PTO          2025-06-02   ⏱ 00:00:12  ║
  ║  Total novedades nuevas: 1 234                                       ║
  ╠══════════════════════════════════════════════════════════════════════╣
  ║  ◉ [VAC] VACACIONES   │  450 IDs  │  3 sub-núcleos                  ║
  ║    ████████████░░░░░░  68%   ✓ 306   ✗ 0                           ║
  ║    Sub-núcleos: ▪ #1(100%)  ▸ #2(44%)  ▫ #3(0%)                    ║
  ║                                                                      ║
  ║  ◉ [INC] INCAPACIDADES │  600 IDs  │  3 sub-núcleos                 ║
  ║    ██████████████████░  90%   ✓ 522   ✗ 18                          ║
  ║    Sub-núcleos: ▪ #1(100%)  ▪ #2(100%)  ▸ #3(72%)                   ║
  ║                                                                      ║
  ║  ● [AUS] AUSENTISMOS  │  184 IDs  │  1 sub-núcleo                   ║
  ║    ████████████████████ 100%   ✓ 178   ✗ 6                          ║
  ║    Sub-núcleos: ▪ #1(100%)                                           ║
  ╠══════════════════════════════════════════════════════════════════════╣
  ║  ► Rechazados (24):  AUS-00123  INC-00456  VAC-00789 ...            ║
  ╠══════════════════════════════════════════════════════════════════════╣
  ║  Progreso total  ████████████████████░░░░  82%   1012 / 1234        ║
  ║  ⚙  PROCESANDO...                                                   ║
  ╚══════════════════════════════════════════════════════════════════════╝

Al terminar:
  ║  ✅ COMPLETADO — Válidas: 1210  │  Rechazadas: 24                    ║
  ║  ▶  [ENTER] Finalizar y exportar     [S] Salir sin guardar           ║
─────────────────────────────────────────────────────────────────────────────
"""
module Panel

using Printf, Dates
using ..Processor
using ..Exporter
using ..DefManager

export run_panel, PanelResult

struct PanelResult
    finalized::Bool
    valid_ids::Vector{String}
    out_ids::Vector{String}
    rejected_ids::Vector{String}
    rejected_reasons::Dict{String,String}
end

# ─────────────────────────────────────────────────────────────────────────────
# ANSI helpers
# ─────────────────────────────────────────────────────────────────────────────
const R  = "\e[0m"           # reset
const B  = "\e[1m"           # bold
const D  = "\e[2m"           # dim
const GR = "\e[32m"          # green
const RD = "\e[31m"          # red
const YL = "\e[33m"          # yellow
const CY = "\e[36m"          # cyan
const WH = "\e[97m"          # bright white
const MG = "\e[35m"          # magenta

const W = 72                 # panel width (inner)
const BW = 28                # progress bar width

clear_screen() = print("\e[H\e[2J\e[3J")

# ─────────────────────────────────────────────────────────────────────────────
# Render helpers
# ─────────────────────────────────────────────────────────────────────────────

function pbar(done::Int, total::Int, w::Int=BW)::String
    total <= 0 && return "$(D)$("░"^w)$(R)"
    frac   = clamp(done / total, 0.0, 1.0)
    filled = round(Int, frac * w)
    "$(GR)$("█"^filled)$(D)$("░"^(w-filled))$(R)"
end

# Pad string to fixed width (strip ANSI for length calc)
strip_ansi(s) = replace(s, r"\e\[[0-9;]*m" => "")
function pad_to(s::String, n::Int)::String
    visible = length(strip_ansi(s))
    visible >= n ? s : s * " "^(n - visible)
end

fmt_duration(dt::DateTime)::String = begin
    secs = round(Int, Dates.value(now() - dt) / 1000)
    h, rem = divrem(secs, 3600)
    m, s   = divrem(rem, 60)
    h > 0 ? @sprintf("%02d:%02d:%02d", h, m, s) : @sprintf("%02d:%02d", m, s)
end

# Border rows
top_border()  = "╔$("═"^W)╗"
bot_border()  = "╚$("═"^W)╝"
mid_border()  = "╠$("═"^W)╣"
row(s)        = "║ $(pad_to(s, W-2)) ║"
empty_row()   = "║$(" "^W)║"

nucleus_clr(t) = t == :VAC ? GR : t == :INC ? CY : YL

# ─────────────────────────────────────────────────────────────────────────────
# Renderizado completo
# ─────────────────────────────────────────────────────────────────────────────

function render(state::ProcessorState, rej_window::Vector{String})
    clear_screen()

    elapsed = fmt_duration(state.started_at)
    total_str = lpad(string(state.total_new), 5)

    # ── Header ─────────────────────────────────────────────────────────────────
    println(top_border())
    println(row("$(B)$(WH)  PROCESAMIENTO DE NOVEDADES PTO — Solvo Global$(R)" *
                "$(D)   $(Dates.today())   ⏱ $(elapsed)$(R)"))
    println(row("  Total novedades nuevas detectadas: $(B)$(total_str)$(R)"))
    println(mid_border())

    # ── Núcleos ────────────────────────────────────────────────────────────────
    for ntype in (:VAC, :INC, :AUS)
        nc    = state.nuclei[ntype]
        clr   = nucleus_clr(ntype)
        label = Processor.nucleus_label(ntype)
        done  = nc.valid_total + nc.out_total
        pct   = nc.total_ids > 0 ? round(Int, 100 * done / nc.total_ids) : 0

        status_icon = nc.status == :done    ? "$(GR)●$(R)" :
                      nc.status == :running ? "$(YL)◉$(R)" : "$(D)○$(R)"

        # Línea 1: estado, tipo, conteo
        println(row(
            "  $status_icon $(clr)$(B)[$ntype]$(R) $(B)$label$(R)" *
            "$(D)  │  $(nc.total_ids) IDs  │  $(nc.n_subcores) sub-núcleo(s)$(R)"
        ))

        # Línea 2: barra de progreso
        bar_line = "    $(pbar(done, nc.total_ids))  " *
                   "$(B)$(pct)%$(R)   " *
                   "$(GR)✓ $(nc.valid_total)$(R)   " *
                   "$(RD)✗ $(nc.out_total)$(R)"
        println(row(bar_line))

        # Línea 3: sub-núcleos
        sc_parts = String[]
        for sc in nc.subcores
            sc_done = sc.valid_count + sc.out_count
            sc_pct  = sc.total > 0 ? round(Int, 100*sc_done/sc.total) : 0
            icon = sc.status == :done    ? "$(GR)▪$(R)" :
                   sc.status == :running ? "$(YL)▸$(R)" : "$(D)▫$(R)"
            push!(sc_parts, "$icon$(D)#$(sc.id)($(sc_pct)%)$(R)")
        end
        println(row("    $(D)Sub-núcleos:$(R) " * join(sc_parts, "  ")))
        println(empty_row())
    end

    # ── Rechazados ─────────────────────────────────────────────────────────────
    println(mid_border())
    n_rej = length(state.rejected_ids)
    rej_line = isempty(rej_window) ? "$(D)(ninguno aún)$(R)" :
               join(rej_window[max(1,end-6):end], "  $(D)│$(R)  ")
    println(row("$(RD)$(B)► Rechazados$(R)$(D) ($(n_rej) total):$(R)  $rej_line"))

    # ── Barra global ───────────────────────────────────────────────────────────
    println(mid_border())
    total_done = state.processed
    total      = max(state.total_new, 1)
    pct_global = round(Int, 100 * total_done / total)
    println(row(
        "$(B)Progreso total$(R)  $(pbar(total_done, total, 32))  " *
        "$(B)$(pct_global)%$(R)   $(D)$(total_done) / $(state.total_new)$(R)"
    ))
    println(empty_row())

    # ── Estado / Botón ─────────────────────────────────────────────────────────
    if state.finished
        println(row(
            "$(GR)$(B)  ✅  PROCESAMIENTO COMPLETADO$(R)" *
            "   $(GR)Válidas: $(B)$(length(state.valid_ids))$(R)" *
            "   $(RD)Rechazadas: $(B)$(length(state.out_ids))$(R)"
        ))
        println(empty_row())
        println(row(
            "$(YL)$(B)  ▶  [ENTER]$(R)$(YL) Finalizar y exportar archivos$(R)" *
            "      $(D)[S] Salir sin guardar$(R)"
        ))
    else
        println(row("$(YL)$(B)  ⚙  PROCESANDO...$(R)" *
                    "$(D)  (los núcleos trabajan en paralelo)$(R)"))
    end
    println(bot_border())
    flush(stdout)
end

# ─────────────────────────────────────────────────────────────────────────────
# Loop principal
# ─────────────────────────────────────────────────────────────────────────────

"""
    run_panel(unified, new_ids, def_df) -> PanelResult

1. Inicializa el procesador
2. Muestra resumen de clasificación
3. Lanza process_all! de forma asíncrona
4. Consume el canal de eventos y redibuja el panel
5. Al terminar, espera la decisión del usuario
"""
function run_panel(
    unified::DataFrame,
    new_ids::Vector{String},
    def_df::DataFrame,
)::PanelResult

    state = Processor.init_processor(new_ids, unified)

    # Resumen previo al panel
    println("\n  Clasificación de novedades:")
    for ntype in (:VAC, :INC, :AUS)
        nc = state.nuclei[ntype]
        println("    $(nucleus_clr(ntype))$(Processor.nucleus_label(ntype))$(R): " *
                "$(nc.total_ids) IDs → $(nc.n_subcores) sub-núcleo(s)")
    end
    println("\n  Iniciando panel en 1 segundo...")
    sleep(1)

    rej_window = String[]
    last_render_ms = Ref(0)
    RENDER_INTERVAL = 120   # ms entre redraws

    # Lanzar procesamiento
    @async Processor.process_all!(state, unified)

    # Consumir eventos → redibujar
    for event in state.progress_channel
        ev_type = event[1]

        if ev_type == :progress
            _, ntype, sc_id, id, status, reason = event
            if status == Validator.out
                push!(rej_window, id)
            end
        end

        # Throttle: no redibujar más rápido que RENDER_INTERVAL ms
        now_ms = round(Int, Dates.value(now()) / 1)
        if now_ms - last_render_ms[] >= RENDER_INTERVAL
            render(state, rej_window)
            last_render_ms[] = now_ms
        end
    end

    # Render final obligatorio
    render(state, rej_window)

    # ── Esperar input del usuario ─────────────────────────────────────────────
    print("\n  Tu respuesta > ")
    flush(stdout)
    answer = lowercase(strip(readline()))

    finalized = answer != "s"

    return PanelResult(
        finalized,
        copy(state.valid_ids),
        copy(state.out_ids),
        copy(state.rejected_ids),
        copy(state.rejected_reasons),
    )
end

end # module Panel
