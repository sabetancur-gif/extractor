"""
src/DataLoader.jl
─────────────────────────────────────────────────────────────────────────────
Orquesta todas las fuentes de datos y construye la tabla unificada
Nov Midasoft & Forms con todas las columnas del Power Query original,
incluyendo la expansión de Fecha Del Evento, Horas, Tiempo de Afectacion
y Weekday.

Flujo:
  SynapseConnector  → aus, inc, vac
  SharePointConnector → forms (Novedades.xlsx)
  LocalFilesConnector → roster, types_of_pto

  → expand_and_enrich  (Fecha Del Evento × fila)
  → join Types_of_PTO  (columna Type of PTO)
  → join Roster        (columna PRISM ID)
  → tabla final unificada
─────────────────────────────────────────────────────────────────────────────
"""
module DataLoader

using DataFrames, Dates, Logging
using ..Config
using ..SynapseConnector
using ..SharePointConnector
using ..LocalFilesConnector

export load_all_sources

# ─────────────────────────────────────────────────────────────────────────────
# Novedades de un solo día (Fecha Del Evento = Fecha Salida solamente)
# ─────────────────────────────────────────────────────────────────────────────
const SINGLE_DAY_MIDASOFT = Set([
    "DIA DE LA FAMILIA", "PAID LEAVE BIRTHDAY", "PAID LEAVE BREASTFEEDING",
    "PAID LEAVE EXTERNAL TOPICS", "PAID LEAVE MEDICAL APPOINTMENT",
    "PAID LEAVE PERSONAL TOPICS", "PAID LEAVE TECH ISSUES", "PAID LEAVE TRAINING",
])

const SINGLE_DAY_FORMS = Set([
    "Cita médica", "Día de la Familia", "Día de la Familia (Día libre)",
    "Día de la familia", "Flexisolvo", "Llegada tarde", "Llegadas tarde",
    "PAID LEAVE BIRTHDAY", "Salida temprano", "Salidas temprano",
])

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
safe_f64(v) = ismissing(v) ? 0.0 : Float64(v)

# ─────────────────────────────────────────────────────────────────────────────
# Expansión de Fecha Del Evento
# ─────────────────────────────────────────────────────────────────────────────

"""
    fecha_evento_range_midasoft(novedad, fs, fl, horas) -> Vector{Date}

Replica la columna calculada 'Fecha Del Evento' del Power Query Nov Midasoft.
"""
function fecha_evento_range_midasoft(
    novedad::String, fs::Date, fl::Date, horas::Float64,
)::Vector{Date}
    if horas == 8.0
        return [fs]
    elseif novedad == "VACACIONES"
        return collect(fs:Day(1):(fl - Day(1)))
    elseif novedad in SINGLE_DAY_MIDASOFT
        return [fs]
    elseif novedad == "FLEXI SOLVO" && (horas <= 9 || horas > 18)
        return [fs]
    else
        d1, d2 = min(fs, fl), max(fs, fl)
        return collect(d1:Day(1):d2)
    end
end

"""
    fecha_evento_range_forms(novedad, fs, fl) -> Vector{Date}

Replica la columna calculada 'Fecha Del Evento' del Power Query Nov Forms.
"""
function fecha_evento_range_forms(
    novedad::String, fs::Date, fl::Date,
)::Vector{Date}
    if novedad == "Vacaciones" && fs != fl
        d1, d2 = min(fs, fl), max(fs, fl)
        return collect(d1:Day(1):(d2 - Day(1)))
    elseif novedad in SINGLE_DAY_FORMS
        return [fs]
    else
        d1, d2 = min(fs, fl), max(fs, fl)
        return collect(d1:Day(1):d2)
    end
end

# ─────────────────────────────────────────────────────────────────────────────
# Expansión de un DataFrame (fuente DB o Forms)
# ─────────────────────────────────────────────────────────────────────────────

"""
    expand_rows(df, source) -> DataFrame

Para cada fila genera N filas (una por Fecha Del Evento),
calcula Horas totales, Tiempo de Afectacion y Weekday.
Filtra weekends (Sábado=6, Domingo=7 en Dates).
source = :midasoft | :forms
"""
function expand_rows(df::DataFrame, source::Symbol)::DataFrame
    isempty(df) && return df

    expanded = []

    for r in eachrow(df)
        fs = get(r, :Fecha_Salida, missing)
        fl = get(r, :Fecha_Llegada, missing)
        ismissing(fs) && continue
        ismissing(fl) && (fl = fs)

        novedad  = string(coalesce(get(r, :Novedad, ""), ""))
        dias_num = safe_f64(get(r, :Dias_Numeros, missing))
        horas_num = safe_f64(get(r, :Horas_Numeros, missing))

        # Horas totales del registro
        horas_total = dias_num * 8.0 + horas_num

        # Lista de fechas del evento
        fechas = source == :midasoft ?
            fecha_evento_range_midasoft(novedad, fs, fl, horas_total) :
            fecha_evento_range_forms(novedad, fs, fl)

        for fde in fechas
            # Filtrar fin de semana
            dow = Dates.dayofweek(fde)   # 1=Lun … 7=Dom
            (dow == 6 || dow == 7) && continue

            # Tiempo de Afectacion (replica la fórmula del PQ Nov Midasoft & Forms)
            tiempo_afec = if horas_total >= 8.0
                8.0
            elseif horas_total > 7.0
                ceil(horas_total)
            else
                ceil(horas_total * 100) / 100
            end

            # Weekday al estilo Power Query (0=Dom, 1=Lun … 6=Sab)
            weekday_pq = dow % 7   # Dates: Mon=1→1, Tue=2→2, … Sun=7→0

            push!(expanded, (
                SOLID              = string(coalesce(get(r, :SOLID, ""), "")),
                Fecha_Salida       = fs,
                Fecha_Llegada      = fl,
                Nombre_y_Apellido  = string(coalesce(get(r, :Nombre_y_Apellido, ""), "")),
                Novedad            = novedad,
                Numero_novedad     = string(coalesce(get(r, :Numero_novedad, ""), "")),
                Dias_Numeros       = dias_num > 0 ? dias_num : missing,
                Horas_Numeros      = horas_num > 0 ? horas_num : missing,
                Fecha_Del_Evento   = fde,
                Horas_total        = horas_total,
                Tiempo_Afectacion  = tiempo_afec,
                Weekday            = weekday_pq,
                _source            = source,
            ))
        end
    end

    isempty(expanded) && return DataFrame()
    return DataFrame(expanded)
end

# ─────────────────────────────────────────────────────────────────────────────
# Construcción de tabla Midasoft desde datos Synapse
# ─────────────────────────────────────────────────────────────────────────────

"""
    build_midasoft_table(synapse_data) -> DataFrame

Une ausentismos + incapacidades + vacaciones y expande fechas.
"""
function build_midasoft_table(synapse_data::NamedTuple)::DataFrame
    aus = synapse_data.aus
    inc = synapse_data.inc
    vac = synapse_data.vac
    solid_name_map = synapse_data.solid_name_map

    parts = DataFrame[]

    # Ausentismos
    if !isnothing(aus) && nrow(aus) > 0
        push!(parts, expand_rows(aus, :midasoft))
    end

    # Incapacidades
    if !isnothing(inc) && nrow(inc) > 0
        push!(parts, expand_rows(inc, :midasoft))
    end

    # Vacaciones — enriquecer Nombre_y_Apellido con el mapa
    if !isnothing(vac) && nrow(vac) > 0
        # Resolver Nombre_y_Apellido desde el mapa
        vac.Nombre_y_Apellido = [
            get(solid_name_map,
                string(coalesce(get(r, :Empleado_Raw, ""), "")),
                string(coalesce(get(r, :Apellido, ""), "")))
            for r in eachrow(vac)
        ]
        push!(parts, expand_rows(vac, :midasoft))
    end

    isempty(parts) && return DataFrame()
    combined = vcat(parts...; cols=:union)
    sort!(combined, :Fecha_Salida)
    println("   Nov Midasoft: $(nrow(combined)) filas expandidas.")
    return combined
end

# ─────────────────────────────────────────────────────────────────────────────
# Construcción de tabla Forms desde SharePoint
# ─────────────────────────────────────────────────────────────────────────────

"""
    build_forms_table(forms_df) -> DataFrame
"""
function build_forms_table(forms_df::DataFrame)::DataFrame
    isempty(forms_df) && return DataFrame()
    expanded = expand_rows(forms_df, :forms)
    sort!(expanded, :Fecha_Salida)
    println("   Nov Forms: $(nrow(expanded)) filas expandidas.")
    return expanded
end

# ─────────────────────────────────────────────────────────────────────────────
# Unión y enriquecimiento con Types_of_PTO y Roster
# ─────────────────────────────────────────────────────────────────────────────

"""
    enrich_with_lookups(unified, types_df, roster_df) -> DataFrame

Añade columnas Type_of_PTO y PRISM_ID mediante left join.
"""
function enrich_with_lookups(
    unified::DataFrame,
    types_df::Union{DataFrame,Nothing},
    roster_df::Union{DataFrame,Nothing},
)::DataFrame

    # Join con Types_of_PTO
    if !isnothing(types_df) && "Novedad" ∈ names(unified)
        try
            unified = leftjoin(unified, types_df; on=:Novedad, makeunique=true)
        catch e
            @warn "No se pudo hacer join con Types_of_PTO: $e"
        end
    end

    # Join con Roster
    if !isnothing(roster_df) && "SOLID" ∈ names(unified)
        try
            unified = leftjoin(unified, roster_df; on=:SOLID, makeunique=true)
        catch e
            @warn "No se pudo hacer join con Roster: $e"
        end
    end

    # Trim de columnas de texto
    for col in ["SOLID", "Nombre_y_Apellido", "Novedad", "Numero_novedad"]
        col ∈ names(unified) &&
            (unified[!, col] = strip.(string.(coalesce.(unified[!, col], ""))))
    end

    return unified
end

# ─────────────────────────────────────────────────────────────────────────────
# API pública
# ─────────────────────────────────────────────────────────────────────────────

"""
    load_all_sources() -> DataFrame | nothing

Punto de entrada principal:
  1. Conecta a Synapse y descarga ausentismos/incapacidades/vacaciones
  2. Conecta a SharePoint y descarga Novedades.xlsx
  3. Carga Roster y Types_of_PTO desde archivos locales
  4. Combina, expande y enriquece todo en una sola tabla
  5. Retorna el DataFrame unificado listo para IDBuilder
"""
function load_all_sources()::Union{DataFrame, Nothing}

    # ── 1. Synapse ─────────────────────────────────────────────────────────────
    println("\n  [1/4] Descargando datos de Azure Synapse (Midasoft)...")
    synapse_data = SynapseConnector.fetch_all_from_synapse()
    if isnothing(synapse_data)
        @error "No se pudo conectar a Synapse. Abortando."
        return nothing
    end

    # ── 2. SharePoint ──────────────────────────────────────────────────────────
    println("\n  [2/4] Descargando Novedades.xlsx desde SharePoint...")
    forms_df = SharePointConnector.fetch_novedades_from_sharepoint()
    if isnothing(forms_df)
        @warn "No se pudo obtener Forms de SharePoint. Se procesará solo Midasoft."
        forms_df = DataFrame()
    end

    # ── 3. Archivos locales ────────────────────────────────────────────────────
    println("\n  [3/4] Cargando archivos locales (Roster, Types of PTO)...")
    roster_df    = LocalFilesConnector.load_roster()
    types_pto_df = LocalFilesConnector.load_types_of_pto()

    # ── 4. Construir tablas expandidas ─────────────────────────────────────────
    println("\n  [4/4] Procesando y unificando fuentes...")
    midasoft_expanded = build_midasoft_table(synapse_data)
    forms_expanded    = isempty(forms_df) ? DataFrame() :
                        build_forms_table(forms_df)

    parts = DataFrame[]
    !isempty(midasoft_expanded) && push!(parts, midasoft_expanded)
    !isempty(forms_expanded)    && push!(parts, forms_expanded)

    if isempty(parts)
        @error "No se obtuvieron datos de ninguna fuente."
        return nothing
    end

    unified = vcat(parts...; cols=:union)
    unified = enrich_with_lookups(unified, types_pto_df, roster_df)

    # Ordenar por fecha
    sort!(unified, :Fecha_Salida)

    println("\n  ✓ Tabla unificada: $(nrow(unified)) filas, $(ncol(unified)) columnas.")
    return unified
end

end # module DataLoader
