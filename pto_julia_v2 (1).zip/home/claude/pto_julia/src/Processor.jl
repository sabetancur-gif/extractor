"""
src/Processor.jl
─────────────────────────────────────────────────────────────────────────────
Motor de procesamiento con 3 núcleos principales (VAC · INC · AUS).

Arquitectura:
  • Clasifica los IDs nuevos en 3 colas por prefijo (VAC/INC/AUS)
  • Divide cada cola en sub-núcleos de Config.SUBCORE_SIZE entradas
  • Cada núcleo principal corre en su propio @async Task
  • Dentro de cada núcleo, los sub-núcleos se ejecutan secuencialmente
  • Publica eventos a un Channel{Any} que consume el Panel en tiempo real

Eventos que se publican al canal:
  (:start,        total_new)
  (:nucleus_start, ntype, total_ids, n_subcores)
  (:subcore_start, ntype, sc_id, n_ids)
  (:progress,      ntype, sc_id, id, status, reason)
  (:subcore_done,  ntype, sc_id, valid_count, out_count)
  (:nucleus_done,  ntype, valid_total, out_total)
  (:all_done,      total_valid, total_out)
─────────────────────────────────────────────────────────────────────────────
"""
module Processor

using DataFrames, Dates
using ..Config
using ..Validator

export ProcessorState, NucleusState, SubcoreState,
       nucleus_label, init_processor, process_all!

# ─────────────────────────────────────────────────────────────────────────────
# Estructuras de estado
# ─────────────────────────────────────────────────────────────────────────────

mutable struct SubcoreState
    id::Int
    nucleus::Symbol
    ids::Vector{String}
    total::Int
    done::Int
    valid_count::Int
    out_count::Int
    status::Symbol          # :pending | :running | :done
    results::Vector{ValidResult}
end

mutable struct NucleusState
    type::Symbol
    total_ids::Int
    subcores::Vector{SubcoreState}
    n_subcores::Int
    done_subcores::Int
    valid_total::Int
    out_total::Int
    status::Symbol          # :pending | :running | :done
end

mutable struct ProcessorState
    nuclei::Dict{Symbol, NucleusState}
    valid_ids::Vector{String}
    out_ids::Vector{String}
    rejected_ids::Vector{String}
    rejected_reasons::Dict{String, String}
    total_new::Int
    processed::Int
    started_at::DateTime
    finished::Bool
    finalized::Bool
    progress_channel::Channel{Any}
end

nucleus_label(t::Symbol) =
    t == :VAC ? "VACACIONES" : t == :INC ? "INCAPACIDADES" : "AUSENTISMOS"

# ─────────────────────────────────────────────────────────────────────────────
# Inicialización
# ─────────────────────────────────────────────────────────────────────────────

"""
    init_processor(new_ids, unified) -> ProcessorState

Clasifica IDs y construye la estructura de núcleos + sub-núcleos.
"""
function init_processor(new_ids::Vector{String}, unified::DataFrame)::ProcessorState

    # Mapa ID → Numero_novedad para clasificar
    id_to_num = Dict{String,String}()
    for row in eachrow(unified)
        id_to_num[row.ID] = string(coalesce(row.Numero_novedad, ""))
    end

    # Clasificar en 3 colas
    queues = Dict{Symbol, Vector{String}}(
        :VAC => String[], :INC => String[], :AUS => String[])

    for id in unique(new_ids)
        num = get(id_to_num, id, "")
        p   = length(num) >= 3 ? uppercase(num[1:3]) : ""
        if   p == "VAC"; push!(queues[:VAC], id)
        elseif p == "INC"; push!(queues[:INC], id)
        elseif p == "AUS"; push!(queues[:AUS], id)
        else;              push!(queues[:AUS], id)   # fallback → AUS
        end
    end

    # Construir NucleusState con sub-núcleos
    sc_global_id = Ref(0)
    nuclei = Dict{Symbol, NucleusState}()

    for ntype in (:VAC, :INC, :AUS)
        ids = queues[ntype]
        subcores = SubcoreState[]
        # Dividir en chunks de SUBCORE_SIZE
        for start in 1:Config.SUBCORE_SIZE:max(1, length(ids))
            chunk = ids[start:min(start + Config.SUBCORE_SIZE - 1, length(ids))]
            sc_global_id[] += 1
            push!(subcores, SubcoreState(
                sc_global_id[], ntype, chunk, length(chunk),
                0, 0, 0, :pending, ValidResult[],
            ))
        end
        # Si no hay IDs, igual crear 1 sub-núcleo vacío para mostrar en panel
        if isempty(subcores)
            sc_global_id[] += 1
            push!(subcores, SubcoreState(
                sc_global_id[], ntype, String[], 0,
                0, 0, 0, :pending, ValidResult[],
            ))
        end
        nuclei[ntype] = NucleusState(
            ntype, length(ids), subcores, length(subcores),
            0, 0, 0, :pending,
        )
    end

    return ProcessorState(
        nuclei,
        String[], String[], String[],
        Dict{String,String}(),
        length(unique(new_ids)),
        0,
        now(), false, false,
        Channel{Any}(2048),
    )
end

# ─────────────────────────────────────────────────────────────────────────────
# Procesamiento de un sub-núcleo
# ─────────────────────────────────────────────────────────────────────────────

function process_subcore!(
    sc::SubcoreState,
    nucleus::NucleusState,
    unified::DataFrame,
    state::ProcessorState,
)
    sc.status = :running
    put!(state.progress_channel,
         (:subcore_start, sc.nucleus, sc.id, length(sc.ids)))

    if isempty(sc.ids)
        sc.status = :done
        nucleus.done_subcores += 1
        put!(state.progress_channel,
             (:subcore_done, sc.nucleus, sc.id, 0, 0))
        return
    end

    results = validate_group(sc.ids, unified, sc.nucleus)
    sc.results = results

    for vr in results
        if vr.status == Validator.valid
            sc.valid_count += 1
            push!(state.valid_ids, vr.id)
        else
            sc.out_count += 1
            push!(state.out_ids, vr.id)
            push!(state.rejected_ids, vr.id)
            state.rejected_reasons[vr.id] = vr.reason
        end
        sc.done    += 1
        state.processed += 1
        put!(state.progress_channel,
             (:progress, sc.nucleus, sc.id, vr.id, vr.status, vr.reason))
    end

    sc.status            = :done
    nucleus.valid_total += sc.valid_count
    nucleus.out_total   += sc.out_count
    nucleus.done_subcores += 1

    put!(state.progress_channel,
         (:subcore_done, sc.nucleus, sc.id, sc.valid_count, sc.out_count))

    if nucleus.done_subcores == nucleus.n_subcores
        nucleus.status = :done
        put!(state.progress_channel,
             (:nucleus_done, sc.nucleus, nucleus.valid_total, nucleus.out_total))
    end
end

# ─────────────────────────────────────────────────────────────────────────────
# Lanzar todos los núcleos
# ─────────────────────────────────────────────────────────────────────────────

"""
    process_all!(state, unified)

Lanza los 3 núcleos como Tasks concurrentes.
Cierra el canal al terminar para que el Panel sepa que acabó.
"""
function process_all!(state::ProcessorState, unified::DataFrame)
    put!(state.progress_channel, (:start, state.total_new))

    tasks = Task[]

    for ntype in (:VAC, :INC, :AUS)
        nucleus = state.nuclei[ntype]
        nucleus.status = :running
        put!(state.progress_channel,
             (:nucleus_start, ntype, nucleus.total_ids, nucleus.n_subcores))

        t = @async begin
            for sc in nucleus.subcores
                process_subcore!(sc, nucleus, unified, state)
                yield()   # ceder para que el Panel pueda redibujar
            end
        end
        push!(tasks, t)
    end

    # Watcher: espera todos los núcleos y cierra el canal
    @async begin
        for t in tasks
            wait(t)
        end
        state.finished = true
        put!(state.progress_channel,
             (:all_done, length(state.valid_ids), length(state.out_ids)))
        close(state.progress_channel)
    end
end

end # module Processor
