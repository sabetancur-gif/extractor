"""
src/DefManager.jl
─────────────────────────────────────────────────────────────────────────────
Gestiona el archivo histórico Def.xlsx / Def.csv.

Lógica de primera corrida vs. corridas posteriores:
  • Si Def.xlsx NO existe  → primera corrida, todos los IDs son nuevos
  • Si Def.xlsx SÍ existe  → leer histórico, comparar IDs y retornar solo nuevos

Al finalizar (botón Finalizar):
  • Marcar INDEX = "NOT FOUND" en filas existentes cuyos IDs desaparecieron
  • Agregar filas nuevas procesadas (válidas + OUT)
  • Guardar Def.xlsx + Def.csv actualizados
─────────────────────────────────────────────────────────────────────────────
"""
module DefManager

using DataFrames, XLSX, CSV, Dates, Logging
using ..Config

export load_def, find_new, build_def_rows, update_def, save_def

# ─────────────────────────────────────────────────────────────────────────────
# Valores por defecto de columnas Def
# ─────────────────────────────────────────────────────────────────────────────
const DEF_DEFAULTS = Dict{String,Any}(
    "INDEX"             => "NOT FOUND",
    "ID"                => "",
    "Column1"           => 1,
    "LISTO"             => "SI",
    "SOLID"             => "NOT FOUND",
    "Fecha Salida"      => missing,
    "Fecha Llegada"     => missing,
    "Nombre y Apellido" => "NOT FOUND",
    "Novedad"           => "NOT FOUND",
    "Numero novedad"    => "NOT FOUND",
    "Dias (Numeros)"    => missing,
    "Horas (Numeros)"   => missing,
    "Date of PTO"       => missing,
    "Horas"             => missing,
    "Hours of PTO"      => missing,
    "Column2"           => 1,
    "IN/OUT"            => "",
    "PROCESADA"         => "",
)

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

function _empty_def()::DataFrame
    df = DataFrame()
    for col in Config.DEF_COLUMNS
        df[!, col] = Any[]
    end
    return df
end

function _normalize_def(df::DataFrame)::DataFrame
    for col in Config.DEF_COLUMNS
        col ∉ names(df) && (df[!, col] = fill(DEF_DEFAULTS[col], nrow(df)))
    end
    return df[!, Config.DEF_COLUMNS]
end

# ─────────────────────────────────────────────────────────────────────────────
# Cargar Def histórico
# ─────────────────────────────────────────────────────────────────────────────

"""
    load_def() -> DataFrame

Carga Def.xlsx si existe. Si no, intenta Def.csv.
Si ninguno existe → DataFrame vacío (primera corrida).
"""
function load_def()::DataFrame
    xlsx_path = Config.DEF_XLSX
    csv_path  = Config.DEF_CSV

    if isfile(xlsx_path)
        println("   Cargando histórico: $(basename(xlsx_path))")
        try
            xf = XLSX.readxlsx(xlsx_path)
            sh_names = XLSX.sheetnames(xf)
            sh_name  = "Def" ∈ sh_names ? "Def" : first(sh_names)
            df = DataFrame(XLSX.eachtablerow(xf[sh_name]))
            println("   ✓ Def cargado: $(nrow(df)) registros históricos.")
            return _normalize_def(df)
        catch e
            @warn "Error leyendo Def.xlsx: $e — intentando Def.csv..."
        end
    end

    if isfile(csv_path)
        println("   Cargando histórico desde CSV: $(basename(csv_path))")
        try
            df = CSV.read(csv_path, DataFrame; missingstring=["", "NA"])
            println("   ✓ Def.csv cargado: $(nrow(df)) registros.")
            return _normalize_def(df)
        catch e
            @warn "Error leyendo Def.csv: $e"
        end
    end

    println("   ► Primera corrida detectada: no existe Def previo.")
    println("     Se procesarán TODOS los IDs y se creará Def desde cero.")
    return _empty_def()
end

# ─────────────────────────────────────────────────────────────────────────────
# Detectar IDs nuevos
# ─────────────────────────────────────────────────────────────────────────────

"""
    find_new(unified, def_df) -> Vector{String}

Compara los IDs únicos de `unified` con el Def histórico.
Retorna solo los IDs que NO existen todavía en el Def.
"""
function find_new(unified::DataFrame, def_df::DataFrame)::Vector{String}
    all_ids = unique(unified.ID)

    if isempty(def_df) || nrow(def_df) == 0
        println("   Todos los IDs son nuevos: $(length(all_ids))")
        return all_ids
    end

    existing_ids = Set(string.(filter(!ismissing, def_df[!, "ID"])))
    new_ids = filter(id -> id ∉ existing_ids, all_ids)

    println("   IDs en histórico Def : $(length(existing_ids))")
    println("   IDs en fuente actual  : $(length(all_ids))")
    println("   IDs nuevos a procesar : $(length(new_ids))")
    return new_ids
end

# ─────────────────────────────────────────────────────────────────────────────
# Construir filas Def a partir de IDs
# ─────────────────────────────────────────────────────────────────────────────

"""
    build_def_rows(ids, unified) -> DataFrame

Para cada ID construye una fila Def descomprimiendo todos los campos
de la tabla unificada. Calcula Column1 y Column2.
"""
function build_def_rows(ids::Vector{String}, unified::DataFrame)::DataFrame
    isempty(ids) && return _empty_def()

    # Índice rápido ID → fila
    id_to_row = Dict{String,Int}()
    for (i, row) in enumerate(eachrow(unified))
        haskey(id_to_row, row.ID) || (id_to_row[row.ID] = i)
    end

    # Column1: cuántas veces aparece cada ID en unified
    id_count = Dict{String,Int}()
    for row in eachrow(unified)
        id_count[row.ID] = get(id_count, row.ID, 0) + 1
    end

    # Column2: cuántas filas comparten (SOLID, Fecha_Del_Evento)
    solid_date_count = Dict{Tuple{String,Any},Int}()
    for row in eachrow(unified)
        k = (string(coalesce(row.SOLID, "")), row.Fecha_Del_Evento)
        solid_date_count[k] = get(solid_date_count, k, 0) + 1
    end

    rows = Dict{String,Any}[]
    for id in ids
        i = get(id_to_row, id, nothing)

        if isnothing(i)
            push!(rows, Dict(
                "INDEX"             => "NOT FOUND",
                "ID"                => id,
                "Column1"           => 1,
                "LISTO"             => "SI",
                "SOLID"             => "NOT FOUND",
                "Fecha Salida"      => missing,
                "Fecha Llegada"     => missing,
                "Nombre y Apellido" => "NOT FOUND",
                "Novedad"           => "NOT FOUND",
                "Numero novedad"    => "NOT FOUND",
                "Dias (Numeros)"    => missing,
                "Horas (Numeros)"   => missing,
                "Date of PTO"       => missing,
                "Horas"             => missing,
                "Hours of PTO"      => missing,
                "Column2"           => 1,
                "IN/OUT"            => "",
                "PROCESADA"         => "",
            ))
            continue
        end

        r = unified[i, :]
        solid = string(coalesce(get(r, :SOLID, ""), ""))
        fde   = get(r, :Fecha_Del_Evento, missing)
        col2  = get(solid_date_count, (solid, fde), 1)

        push!(rows, Dict(
            "INDEX"             => string(get(r, :INDEX, "NOT FOUND")),
            "ID"                => id,
            "Column1"           => get(id_count, id, 1),
            "LISTO"             => "SI",
            "SOLID"             => solid,
            "Fecha Salida"      => get(r, :Fecha_Salida, missing),
            "Fecha Llegada"     => get(r, :Fecha_Llegada, missing),
            "Nombre y Apellido" => string(coalesce(get(r, :Nombre_y_Apellido, ""), "")),
            "Novedad"           => string(coalesce(get(r, :Novedad, ""), "")),
            "Numero novedad"    => string(coalesce(get(r, :Numero_novedad, ""), "")),
            "Dias (Numeros)"    => get(r, :Dias_Numeros, missing),
            "Horas (Numeros)"   => get(r, :Horas_Numeros, missing),
            "Date of PTO"       => fde,
            "Horas"             => get(r, :Horas_total, missing),
            "Hours of PTO"      => get(r, :Tiempo_Afectacion, missing),
            "Column2"           => col2,
            "IN/OUT"            => "",
            "PROCESADA"         => "SI",
        ))
    end

    isempty(rows) && return _empty_def()
    df = DataFrame(rows)
    # Asegurar orden de columnas
    for col in Config.DEF_COLUMNS
        col ∉ names(df) && (df[!, col] = fill(DEF_DEFAULTS[col], nrow(df)))
    end
    return df[!, Config.DEF_COLUMNS]
end

# ─────────────────────────────────────────────────────────────────────────────
# Actualizar Def con resultados del procesamiento
# ─────────────────────────────────────────────────────────────────────────────

"""
    update_def(def_df, valid_ids, out_ids, unified) -> DataFrame

1. Marca INDEX="NOT FOUND" en filas existentes cuyo ID ya no está en unified.
2. Construye filas para IDs válidos (IN/OUT = "").
3. Construye filas para IDs rechazados (IN/OUT = "OUT").
4. Une todo y ordena por INDEX numérico.
"""
function update_def(
    def_df::DataFrame,
    valid_ids::Vector{String},
    out_ids::Vector{String},
    unified::DataFrame,
)::DataFrame

    all_current_ids = Set(unified.ID)

    # Paso 1: marcar NOT FOUND en histórico
    updated_existing = copy(def_df)
    if !isempty(updated_existing)
        for i in 1:nrow(updated_existing)
            id_val = updated_existing[i, "ID"]
            !ismissing(id_val) && string(id_val) ∉ all_current_ids &&
                (updated_existing[i, "INDEX"] = "NOT FOUND")
        end
    end

    # Paso 2: filas válidas (procesadas OK)
    valid_rows = build_def_rows(valid_ids, unified)

    # Paso 3: filas rechazadas (OUT)
    out_rows = build_def_rows(out_ids, unified)
    if !isempty(out_rows)
        out_rows[!, "IN/OUT"] .= "OUT"
    end

    # Unir todas las partes
    parts = DataFrame[]
    !isempty(updated_existing) && nrow(updated_existing) > 0 &&
        push!(parts, updated_existing)
    !isempty(valid_rows) && nrow(valid_rows) > 0 && push!(parts, valid_rows)
    !isempty(out_rows)   && nrow(out_rows)   > 0 && push!(parts, out_rows)

    isempty(parts) && return _empty_def()

    result = vcat(parts...; cols=:union)
    result = _normalize_def(result)

    # Ordenar por INDEX (NOT FOUND al final)
    sort_key = map(v -> begin
        n = tryparse(Int, string(coalesce(v, "")))
        isnothing(n) ? typemax(Int) : n
    end, result[!, "INDEX"])
    result = result[sortperm(sort_key), :]

    println("   Def actualizado: $(nrow(result)) filas totales.")
    return result
end

# ─────────────────────────────────────────────────────────────────────────────
# Guardar Def
# ─────────────────────────────────────────────────────────────────────────────

"""
    save_def(def_df)

Guarda el Def en Def.xlsx (hoja "Def") y Def.csv.
Crea el directorio output/ si no existe.
"""
function save_def(def_df::DataFrame)
    isdir(Config.OUTPUT_DIR) || mkpath(Config.OUTPUT_DIR)

    # ── XLSX ──────────────────────────────────────────────────────────────────
    try
        XLSX.openxlsx(Config.DEF_XLSX; mode=:w) do xf
            sh = XLSX.addsheet!(xf, "Def")
            cols = Config.DEF_COLUMNS
            # Encabezados fila 1
            for (ci, col) in enumerate(cols)
                sh[1, ci] = col
            end
            # Datos desde fila 2
            for (ri, row) in enumerate(eachrow(def_df))
                for (ci, col) in enumerate(cols)
                    v = row[col]
                    sh[ri+1, ci] = ismissing(v) ? "" : v
                end
            end
        end
        println("   ✓ Def.xlsx guardado ($(nrow(def_df)) filas).")
    catch e
        @warn "Error guardando Def.xlsx: $e"
    end

    # ── CSV ───────────────────────────────────────────────────────────────────
    try
        CSV.write(Config.DEF_CSV, def_df; missingstring="")
        println("   ✓ Def.csv guardado.")
    catch e
        @warn "Error guardando Def.csv: $e"
    end
end

end # module DefManager
