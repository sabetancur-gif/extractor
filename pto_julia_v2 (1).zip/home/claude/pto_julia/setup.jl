"""
setup.jl
─────────────────────────────────────────────────────────────────────────────
Instala todas las dependencias del proyecto PTONovedades.
Ejecutar UNA sola vez antes de usar el sistema:

    julia setup.jl

Requiere conexión a internet.
─────────────────────────────────────────────────────────────────────────────
"""

using Pkg
Pkg.activate(@__DIR__)

println("=" ^ 62)
println("  SETUP — Sistema PTO Novedades v2.0")
println("  Solvo Global")
println("=" ^ 62)
println()

# Paquetes a instalar (los stdlib no necesitan instalación)
third_party = [
    ("CSV",        "Lectura/escritura de archivos CSV"),
    ("DataFrames", "Tablas y manipulación de datos"),
    ("XLSX",       "Lectura/escritura de archivos Excel .xlsx"),
    ("ODBC",       "Conexión a Azure Synapse (SQL Server)"),
    ("HTTP",       "Llamadas REST a Microsoft Graph / SharePoint"),
    ("JSON3",      "Parseo de respuestas JSON de la API de Graph"),
]

for (pkg, desc) in third_party
    println("  Instalando $(rpad(pkg, 12)) — $desc ...")
    try
        Pkg.add(pkg)
        println("    ✓ OK")
    catch e
        println("    ✗ Error: $e")
    end
end

println()
println("► Precompilando paquetes (puede tardar 2-5 minutos la primera vez)...")
Pkg.precompile()

println()
println("=" ^ 62)
println("  ✅  Setup completado.")
println()
println("  IMPORTANTE — Antes de ejecutar el sistema:")
println("  1. Edite src/Config.jl con sus credenciales reales:")
println("       • SYNAPSE_USER / SYNAPSE_PASSWORD")
println("       • SHAREPOINT_USER / SHAREPOINT_PASSWORD")
println("       • AZURE_TENANT_ID")
println("  2. Verifique que el ODBC Driver esté instalado:")
println("       Descargue desde: https://aka.ms/downloadmsodbcsql")
println()
println("  Luego ejecute:  julia main.jl")
println("=" ^ 62)
println()
